#include "vtasktabwidget.h"
#include "ui_vtasktabwidget.h"

#include "Model/VActivity/vtask.h"
#include "Controller/vtracecontroller.h"

/**
 * @brief VTaskTabWidget
 * Constructeur
 * @param parent L'objet parent
 */
VTaskTabWidget::VTaskTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VTaskTabWidget),
    _editing(false),
    _task(NULL)
{
    ui->setupUi(this);
}


/**
 * @brief ~VTaskTabWidget
 * Destructeur
 */
VTaskTabWidget::~VTaskTabWidget()
{
    delete ui;
}

/**
 * @brief setTask
 * Définit la tâche en cours d'édition
 * @param task La tâche en cours d'édition
 */
void VTaskTabWidget::setTask(VTask * task)
{
    if (task != _task)
    {
        VTraceController::get()->Info("VTaskTabWidget::setTask()", "Task defined");
        _task = task;
    }
    updateDisplay();
}

/**
 * @brief getTask
 * Obitent la tâche en cours d'édition
 * @return La tâche en cours d'édition
 */
VTask * VTaskTabWidget::getTask() const
{
    return _task;
}

/**
 * @brief updateDisplay
 * Met a jour les intefaces
 * en fonction de la tache sélectionnée
 */
void VTaskTabWidget::updateDisplay()
{
    if(_task == NULL)
    {
        ui->idLineEdit->setText("");
        ui->nameLineEdit->setText("");
        ui->iterativeCheckBox->setCheckState(Qt::Unchecked);
        ui->optionalCheckBox->setCheckState(Qt::Unchecked);
        ui->interruptibleCheckBox->setCheckState(Qt::Checked);
        ui->freeTextEdit->setPlainText("");
        this->setEnabled(false);
    }
    else
    {
        _editing = true;
        ui->idLineEdit->setText(_task->getId());
        ui->nameLineEdit->setText(_task->getName());
        ui->iterativeCheckBox->setCheckState(_task->getIterative() ? Qt::Checked : Qt::Unchecked);
        ui->optionalCheckBox->setCheckState(_task->getOptional() ? Qt::Checked : Qt::Unchecked);
        ui->interruptibleCheckBox->setCheckState(_task->getInterruptible() ? Qt::Checked : Qt::Unchecked);
        ui->freeTextEdit->setPlainText(_task->getFreeText());
        ui->freeTextEdit->moveCursor(QTextCursor::End);
        this->setEnabled(true);
        _editing = false;
    }
}

/**
 * @brief on_nameLineEdit_editingFinished
 * Gère la modification du nom
 */
void VTaskTabWidget::on_nameLineEdit_editingFinished()
{
    if(_task == NULL || _editing) return;
    if(_task->getName() != ui->nameLineEdit->text())
    {
        _task->setIdFromName(ui->nameLineEdit->text());
        _task->setName(ui->nameLineEdit->text());
    }
}

/**
 * @brief on_iterativeCheckBox_stateChanged
 * Gère le changement d'état de iterativeCheckBox
 * @param arg1 L'état de la checkbox
 */
void VTaskTabWidget::on_iterativeCheckBox_stateChanged(int arg1)
{
    if(_task == NULL || _editing) return;
    _task->setIterative(arg1 == 2); //Qt::Checked 2 The item is checked.
}

/**
 * @brief on_optionalCheckBox_stateChanged
 * Gère le changement d'état de optionalCheckBox
 * @param arg1 L'état de la checkbox
 */
void VTaskTabWidget::on_optionalCheckBox_stateChanged(int arg1)
{
    if(_task == NULL || _editing) return;
    _task->setOptional(arg1 == 2); //Qt::Checked 2 The item is checked.
}

/**
 * @brief on_interruptibleCheckBox_stateChanged
 * Gère le changement d'état de interruptibleCheckBox
 * @param arg1 L'état de la checkbox
 */
void VTaskTabWidget::on_interruptibleCheckBox_stateChanged(int arg1)
{
    if(_task == NULL || _editing) return;
    _task->setInterruptible(arg1 == 2); //Qt::Checked 2 The item is checked.
}

/**
 * @brief on_freeTextEdit_editingFinished
 * Gère la modification du free text
 */
void VTaskTabWidget::on_freeTextEdit_textChanged()
{
    if(_task == NULL || _editing) return;
    if(_task->getFreeText() != ui->freeTextEdit->toPlainText())
    {
        _task->setFreeText(ui->freeTextEdit->toPlainText());
    }
}
