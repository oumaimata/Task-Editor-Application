#include "vactivitywidget.h"
#include "ui_vactivitywidget.h"

#include "VActivityScene/vactivitytreescene.h"
#include "VActivityScene/vtaskitem.h"
#include "../../Controller/vtracecontroller.h"
#include "../../Model/vapplicationmodel.h"

/*!
 * \brief VActivityWidget::VActivityWidget
 * Constructeur
 * \param parent objet parent
 */
VActivityWidget::VActivityWidget(QWidget* parent) :
    QWidget(parent),
    ui(new Ui::VActivityWidget)
{
    VTraceController::get()->Debug("VActivityWidget::VActivityWidget()", "Begin");
    ui->setupUi(this);

    // Setting the scene of the tree view.
    _activityTreeScene = new VActivityTreeScene(ui->treeView);
    ui->treeView->setScene(_activityTreeScene);

    // Hiding textView by default.
    ui->xmlView->setVisible(false);
    ui->xmlView->setTabStopWidth(10);

    // Connecting signals from the scene when selection changes.
    connect(ui->treeView->scene(), SIGNAL(selectionChanged()), this, SLOT(updateProperties()));

    // Connecting signals from the activity model.
    VActivityModel* activityModel = &VApplicationModel::getInstance()->getActivityModel();

    connect(activityModel, SIGNAL(taskAdded(VTask*)), this, SLOT(updateXmlView(VTask*)));
    connect(activityModel, SIGNAL(taskRemoved(VTask*)), this, SLOT(updateXmlView(VTask*)));
    connect(activityModel, SIGNAL(taskModified(VTask*)), this, SLOT(updateXmlView(VTask*)));

    connect(activityModel, SIGNAL(taskAdded(VTask*)), _activityTreeScene, SLOT(addTaskItem(VTask*)));
    connect(activityModel, SIGNAL(taskRemoved(VTask*)), _activityTreeScene, SLOT(removeTaskItem(VTask*)));
    connect(activityModel, SIGNAL(taskModified(VTask*)), _activityTreeScene, SLOT(updateTaskItem(VTask*)));

    connect(activityModel, SIGNAL(modified(QString, QObject *)), this, SLOT(onModelModified(QString, QObject *)));

    ui->modelPropertiesWidget->setActivityModel(activityModel);
    ui->taskPropertiesWidget->setActivityModel(activityModel);

    VTraceController::get()->Debug("VActivityWidget::VActivityWidget()", "End");
}

/*!
 * \brief getSelectedTasks
 * Obtient la liste des tâches sélectionnées
 * \return La liste des tâches sélectionnées
 */
QList<QPointer<VTask> > VActivityWidget::getSelectedTasks()
{
   return  _activityTreeScene->getSelectedTasks();
}

VTaskItem * VActivityWidget::getTaskItem(VTask * task) const
{
    return _activityTreeScene->getTaskItem(task);
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VActivityWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VActivityWidget::onModelModified()
{
    onModelModified(NULL);
}

void VActivityWidget::onModelModified(QString message, QObject * object)
{
    VTask * task = qobject_cast<VTask *>(object);
    _activityTreeScene->updateTaskItem(task);
    updateXmlView(task);
    VActivityModel* activityModel = &VApplicationModel::getInstance()->getActivityModel();
    ui->modelPropertiesWidget->setActivityModel(activityModel);
    ui->taskPropertiesWidget->setActivityModel(activityModel);
}

/*!
 * \brief VActivityWidget::setTextViewVisible
 * Définie l'attribut Visible de textView à enabled
 * \param enabled si activé
 */
void VActivityWidget::setXmlViewVisible(bool enabled)
{
    ui->xmlView->setVisible(enabled);
}

/**
 * @brief updateXmlView
 * Met a jour le widget xmlView
 * @param task La tâche qui a été modifiée
 */
void VActivityWidget::updateXmlView(VTask* task)
{
    ui->xmlView->setPlainText("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                          VApplicationModel::getInstance()->getActivityModel().ToXml());
    if(task != NULL)
    {
        ui->xmlView->find("<task id=\"" + task->getId());
    }
}

/**
 * @brief VActivityWidget::on_addChildNodeButton_clicked
 * Gère le click sur le bouton d'ajout d'un noeud
 */
void VActivityWidget::on_addChildNodeButton_clicked()
{
    VTraceController::get()->Debug("VActivityWidget::on_addChildNodeButton_clicked()", "Begin");

    QList<VTaskItem*> selectedItems = ((VActivityTreeScene*) ui->treeView->scene())->getSelectedTaskItems();
    VTask* parent;

    if (selectedItems.length() > 0)
    {
        VTraceController::get()->Info("VActivityWidget::on_addChildNodeButton_clicked()", "Parent defined to the first selected task");
        parent = selectedItems.first()->getTask();
    }
    else
    {
        VTraceController::get()->Info("VActivityWidget::on_addChildNodeButton_clicked()", "No parent task");
        parent = NULL;
    }
    emit taskAddingAsked(parent);
    VTraceController::get()->Debug("VActivityWidget::on_addChildNodeButton_clicked()", "End");
}

/**
 * @brief VActivityWidget::on_removeNodeButton_clicked
 * Gère le click sur le bouton de suppression d'un noeud
 */
void VActivityWidget::on_removeNodeButton_clicked()
{
    VTraceController::get()->Debug("VActivityWidget::on_removeNodeButton_clicked()", "Begin");
    QList<VTaskItem*> selectedTaskItems = ((VActivityTreeScene*) ui->treeView->scene())->getSelectedTaskItems();

    while (selectedTaskItems.length() > 0)
    {
        VTraceController::get()->Info("VActivityWidget::on_removeNodeButton_clicked()", "Ask to remove the first selected task");
        emit taskRemovalAsked(selectedTaskItems.first()->getTask());
        selectedTaskItems = ((VActivityTreeScene*) ui->treeView->scene())->getSelectedTaskItems();
    }
    VTraceController::get()->Debug("VActivityWidget::on_removeNodeButton_clicked()", "End");
}

/**
 * @brief VActivityWidget::updateProperties
 * Met à jour les widgets VTaskPropertiesWidget
 */
void VActivityWidget::updateProperties()
{
    VTraceController::get()->Debug("VActivityWidget::updateProperties()", "Begin");

    QList<VTaskItem*> selectedTaskItems = ((VActivityTreeScene*) ui->treeView->scene())->getSelectedTaskItems();

    if (selectedTaskItems.length() > 0)
    {
        VTraceController::get()->Info("VActivityWidget::updateProperties()",
            "setTask on taskPropertiesWidget to the first selected task");
        ui->taskPropertiesWidget->setTask(selectedTaskItems.first()->getTask());
    }
    else
    {
        VTraceController::get()->Info("VActivityWidget::updateProperties()",
            "setTask on taskPropertiesWidget to NULL");
        ui->taskPropertiesWidget->setTask(NULL);
    }
    VTraceController::get()->Debug("VActivityWidget::updateProperties()", "End");
}


/**
 * @brief on_moveDownButton_clicked
 * Gère le click sur le bouton de décalage vers le bas d'une tâche
 */
void VActivityWidget::on_moveDownButton_clicked()
{
    QList<QPointer<VTask> > selectedTasks = ((VActivityTreeScene*) ui->treeView->scene())->getSelectedTasks();
    if (selectedTasks.length() > 0)
    {
        QPointer<VTask> selectedTask = selectedTasks.first();
        if(selectedTask == NULL) return;
        VTaskContainer * parent = qobject_cast<VTaskContainer *>(selectedTask->parent());
        if(parent == NULL) return;
        parent->moveDown(selectedTasks);
    }
}


/**
 * @brief on_moveUpButton_clicked
 * Gère le click sur le bouton de décalage vers le haut d'une tâche
 */
void VActivityWidget::on_moveUpButton_clicked()
{
    QList<QPointer<VTask> > selectedTasks = ((VActivityTreeScene*) ui->treeView->scene())->getSelectedTasks();
    if (selectedTasks.length() > 0)
    {
        QPointer<VTask> selectedTask = selectedTasks.first();
        if(selectedTask == NULL) return;
        VTaskContainer * parent = qobject_cast<VTaskContainer *>(selectedTask->parent());
        if(parent == NULL) return;
        parent->moveUp(selectedTasks);
    }
}
