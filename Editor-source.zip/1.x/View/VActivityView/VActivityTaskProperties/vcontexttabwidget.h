#pragma once
#ifndef VCONTEXTTABWIDGET_H
#define VCONTEXTTABWIDGET_H

#include <QWidget>
#include <QTreeWidgetItem>
#include <QTableWidgetItem>

class VTask;
class VContext;

namespace Ui {
class VContextTabWidget;
}

class VContextTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VContextTabWidget *ui;

    QFont * blackFont;

    /**
     * @brief task
     * Tâche en cours d'édition
     */
    VTask * _task;

    /**
     * @brief _context
     * Concext en cours d'édition
     */
    VContext * _context;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    /**
     * @brief VContextTabWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VContextTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VContextTabWidget
     * Destructeur
     */
    ~VContextTabWidget();

    /**
     * @brief setTask
     * Définit la tâche en cours d'édition
     * @param task La tâche en cours d'édition
     */
    void setTask(VTask *task);

    /**
     * @brief getTask
     * Obitent la tâche en cours d'édition
     * @return La tâche en cours d'édition
     */
    VTask * getTask() const;

private:

    /**
     * @brief updateDisplay
     * Met a jour les intefaces
     * en fonction de la tache sélectionnée
     */
    void updateDisplay();

    /**
     * @brief updateRefConceptDisplay
     * Met a jour l'inteface des ref concepts
     * en fonction de la tache sélectionnée
     */
    void updateRefConceptDisplay();

    /**
     * @brief updateParamDisplay
     * Met a jour l'inteface des params
     * en fonction de la tache sélectionnée
     */
    void updateParamDisplay();

    /**
     * @brief updateConstraintDisplay
     * Met a jour l'inteface des constraints
     * en fonction de la tache sélectionnée
     */
    void updateConstraintDisplay();

    /**
     * @brief setItemBackgroundColor
     * Définie le backgroundcolor de l'item de begin au nombre de colonne
     * @param item L'item à mettre à jour
     * @param beginIndex L'index de début
     */
    void setItemBackgroundColor(QTreeWidgetItem * item, int beginIndex);
    
private slots:

    /**
     * @brief on_addRefConceptButton_clicked
     * Gère l'ajout de RefConcept
     */
    void on_addRefConceptButton_clicked();

    /**
     * @brief on_refConceptWidget_itemChanged
     * Gère les modifications de RefConcept
     * @param item
     */
    void on_refConceptWidget_itemChanged(QTableWidgetItem *item);

    /**
     * @brief on_removeRefConceptButton_clicked
     * Gère la supression de RefConcept
     */
    void on_removeRefConceptButton_clicked();

    /**
     * @brief on_addRefConceptButton_clicked
     * Gère l'ajout de Param
     */
    void on_addParamButton_clicked();

    /**
     * @brief on_refConceptWidget_itemChanged
     * Gère les modifications de Param
     * @param item
     */
    void on_paramWidget_itemChanged(QTableWidgetItem *item);

    /**
     * @brief on_removeRefConceptButton_clicked
     * Gère la supression de Param
     */
    void on_removeParamButton_clicked();

    /**
     * @brief on_addConstraintButton_clicked
     * Gère l'ajout de constraint
     */
    void on_addConstraintButton_clicked();

    /**
     * @brief on_constraintWidget_itemChanged
     * Gère les modifications de constraint
     * @param item
     */
    void on_constraintWidget_itemChanged(QTreeWidgetItem *item, int column);

    /**
     * @brief on_removeConstraintButton_clicked
     * Gère la supression de constraint
     */
    void on_removeConstraintButton_clicked();
};

#endif // VCONTEXTTABWIDGET_H
