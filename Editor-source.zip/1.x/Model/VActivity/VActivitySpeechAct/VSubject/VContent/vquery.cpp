#include "vquery.h"
#include "../../../../../Controller/vtracecontroller.h"
#include <qdom.h>

VQuery::VQuery():
    _statement(NULL),
    _target("")
{

}

VQuery::VQuery(const VQuery& query, QObject* parent):
    VActivityModelElement(parent),
    _target(query._target)
{
    _statement = query._statement->clone();
}

VQuery::~VQuery()
{
    if(_statement != NULL)
        delete _statement;
}

void VQuery::setStatement(VStatement *statement){
    if (statement == NULL)
        return;

    _statement = statement;
    connect(statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    onModified("", statement);
}
void VQuery::setTarget(const QString& target){
    _target = target;
    onModified("Target changed");
}
VStatement* VQuery::getStatement()const{
    return _statement;
}
QString VQuery::getTarget()const{
    return _target;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VQuery::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VQuery::parseDom()", "<" + elem.tagName() + ">");

    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture du Performatif
            if(element.tagName() == "target")
            {
                QString myTarget = element.text();
                setTarget(myTarget);
            }
            // Lecture du subject
            else if(element.tagName() == "statement")
            {
                setStatement(new VStatement());
                _statement->parseDom(element);
            }
        }
        node = node.nextSibling();
    }

    VTraceController::get()->Info("VQuery::parseDom()", "</" + elem.tagName() + ">");
}


/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VQuery::ToXml(QString tabulation)
{
    QString tab = tabulation;
    QString RetVal = tabulation + "<query>\n";
    tab += "\t";
    RetVal += tab + "<target>" + (this->getTarget()) + "</target>\n";
    VStatement* my_statement = this->getStatement();
    RetVal += (my_statement->ToXml(tab));
    RetVal += tabulation + "</query>\n";
    return RetVal;
}

VQuery *VQuery::clone() const
{
    return new VQuery(*this);
}

