#include "vbasiscondition.h"

#include "Controller/vactivitycontroller.h"
#include "Controller/vapplicationcontroller.h"

VBasisCondition::VBasisCondition(QObject *parent) :
    VActivityModelElement(parent)
{
    _id = getUid();
}

VBasisCondition::VBasisCondition(const VBasisCondition& basisCondition, QObject *parent) :
    VActivityModelElement(parent)
{
    _id = basisCondition.getId();
}

void VBasisCondition::setId(qint64 id)
{
    if(_id != id)
    {
        _id = VApplicationController::getInstance()->getActivityController()->getNextValidConditionId(this, id);
        onModified(NULL);
    }
}

void VBasisCondition::setId(QString id)
{
    setId(id.toInt());
}

qint64 VBasisCondition::getId() const
{
    return _id;
}
