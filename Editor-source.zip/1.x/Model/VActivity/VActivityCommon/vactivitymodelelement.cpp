#include "vactivitymodelelement.h"

qint64 VActivityModelElement::currentUid = 0;

/**
 * @brief VActivityModelElement
 * Constructeur
 * @param uid Identifiant de l'élément
 * @param parent L'object parent
 */
VActivityModelElement::VActivityModelElement(QObject *parent) :
    QObject(parent),
    _uid(currentUid),
    _edit(false)
{
    currentUid++;
}

/**
 * @brief VActivityModelElement
 * Constructeur de copie
 * @param activityModelElement L'élément à copier
 */
VActivityModelElement::VActivityModelElement(const VActivityModelElement& activityModelElement) :
    QObject(activityModelElement.parent()),
    _uid(activityModelElement._uid),
    _edit(activityModelElement._edit)
{
}

/**
 * @brief getId
 * Obtient l'Id
 * @return L'id
 */
qint64 VActivityModelElement::getUid() const
{
    return _uid;
}

/**
 * @brief operator ==
 * Opérateur de comparaison
 * @param activityModelElement L'élément à comparer
 * @return Si les deux object sont éguaux
 */
bool VActivityModelElement::operator==(const VActivityModelElement& activityModelElement) const
{
    return _uid == activityModelElement._uid;
}

void VActivityModelElement::beginEdit()
{
    _edit = true;
}

void VActivityModelElement::endEdit()
{
    _edit = false;
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 */
void VActivityModelElement::onModified()
{
    onModified(NULL);
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 * @param object L'objet modifié
 */
void VActivityModelElement::onModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    emit modified(message, (object == NULL) ? this : object);
}
