#include "vtaskitem.h"

#include <QPainter>
#include <QPen>
#include <QBrush>
#include <QDrag>

#include "vtaskrectitem.h"
#include "vtaskconstructoritem.h"
#include "vactivitytreescene.h"
#include "Model/VActivity/VActivityConstructor/vconstructor.h"
#include "Model/VActivity/vtask.h"
#include "Controller/vtracecontroller.h"

/*!
 * \brief VTaskItem::VTaskItem
 * Constructeur
 * \param task La tache
 * \param parent L'objet parent
 */
VTaskItem::VTaskItem (VTask* task, QGraphicsItem* parent) :
    QGraphicsItemGroup(parent), _task(task)
{
    VTraceController::get()->Debug("VTaskItem::VTaskItem()", "Begin");

    this->setFlags(ItemStacksBehindParent);
    this->setHandlesChildEvents(false);

    _expanded = true;

    // Building items.
    _taskRectItem = new VTaskRectItem(TASKRECT_X, TASKRECT_Y, TASKRECT_WIDTH, TASKRECT_HEIGHT, task, this);
    _hLineInItem = new QGraphicsLineItem(HLINEIN_X1, HLINEIN_Y, HLINEIN_X2, HLINEIN_Y, this);
    _hLineInItem->setPen(QPen (Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    _hLineOutItem = new QGraphicsLineItem(HLINEOUT_X1, HLINEOUT_Y, HLINEOUT_X2, HLINEOUT_Y, this);
    _hLineOutItem->setPen(QPen (Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    _vLineItem = new QGraphicsLineItem(0, 0, 0, 0, this);
    _vLineItem->setPen(QPen (Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    _taskConstructorItem = new VTaskConstructorItem(CONSTR_X, CONSTR_Y, CONSTR_WIDTH, CONSTR_HEIGHT,
                                                    _expanded, this);
    _constrTextItem = new QGraphicsSimpleTextItem(getConstrText(), this);
    _constrTextItem->setPos(CONSTR_TEXT_X, CONSTR_TEXT_Y);

    // Depending on the existence of a parent task item, show or hide the horizontal line in.
    (this->getParentTaskItem() != NULL) ? _hLineInItem->show() : _hLineInItem->hide();

    VTraceController::get()->Debug("VTaskItem::VTaskItem()", "End");
}

/**
 * @brief getConstrText
 * Obtient le constructeur de la tâche
 * @return Le constructeur de la tâche
 */
QString VTaskItem::getConstrText() const
{
    return (_task->getConstructor() != NULL) ? VActivityConstructorTypeToString(_task->getConstructor()->getType()) : "";
}

/*!
 * \brief VTaskItem::type
 * Obtient le type
 * \return Le type
 */
int VTaskItem::type() const
{
    return Type;
}

/*!
 * \brief VTaskItem::paint
 * Dessine le VTaskItem
 * \param painter
 * \param option
 * \param widget
 */
void VTaskItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    VTraceController::get()->Debug("VTaskItem::paint()", "Begin");

    this->updateSubitemsPositions();
    QGraphicsItemGroup::paint(painter, option, widget);

    VTraceController::get()->Debug("VTaskItem::paint()", "End");
}

/*!
 * \brief VTaskItem::getHeight
 * Obtient la hauteur
 * \return La hauteur
 */
qreal VTaskItem::getHeight() const
{
    VTraceController::get()->Debug("VTaskItem::getHeight()", "Begin");

    qreal height = 0;

    // Getting children.
    QList<VTaskItem*> childTaskItems = getChildTaskItems();

    // If task item is expanded and it has at least one child.
    if (_expanded && childTaskItems.count() > 0)
    {
        VTaskItem* childTaskItem;
        foreach (childTaskItem, childTaskItems)
            height += childTaskItem->getHeight();
    }

    /*
     * If this task item has no child or is not expanded, height is equal to the
     * height of a task item plus the margin.
     */
    else
        height = TASKITEM_MARGIN_HEIGHT;

    VTraceController::get()->Debug("VTaskItem::getHeight()", "End");
    return height;
}

/*!
 * \brief VTaskItem::setExpanded
 * Définie si le VTAskItem est déplié
 * \param expanded si le VTAskItem est déplié
 */
void VTaskItem::setExpanded(bool expanded)
{
    if (expanded != _expanded)
    {
        _expanded = expanded;
        this->updateSubitemsPositions();
    }
}

/*!
 * \brief VTaskItem::getTask
 * Obtient la tache
 * \return La tache
 */
QPointer<VTask> VTaskItem::getTask()
{
    return _task;
}

/*!
 * \brief VTaskItem::getParentTaskItem
 * Obtient le TaskItem de la tache parente
 * \return Le taskItem de la tache parente
 */
VTaskItem* VTaskItem::getParentTaskItem() const
{
    return qgraphicsitem_cast<VTaskItem*>(this->parentItem());
}

/*!
 * \brief VTaskItem::getChildTaskItem
 * Obtient le TaskItem de la tâche passé en argument
 * \return Le TaskItem de la tâche passé en argument
 */
VTaskItem* VTaskItem::getChildTaskItem(VTask * task) const
{
    QList<VTaskItem*> childTaskItems = getChildTaskItems();
    VTaskItem * childTaskItem = NULL;
    foreach(childTaskItem, childTaskItems)
    {
        if(childTaskItem->_task == task) return childTaskItem;
    }
    return childTaskItem;
}

/*!
 * \brief VTaskItem::getChildTaskItems
 * Obtient les TaskItem des taches enfants
 * \return Les TaskItem des taches enfants
 */
QList<VTaskItem*> VTaskItem::getChildTaskItems() const
{
    VTraceController::get()->Debug("VTaskItem::getChildTaskItems()", "Begin");
    QList<QGraphicsItem*> childTaskItems = childItems();
    QList<VTaskItem*> result;
    QGraphicsItem* childTaskItem;

    foreach (childTaskItem, childTaskItems)
    {
        if (qgraphicsitem_cast<VTaskItem*>(childTaskItem) != NULL)
        {
            VTraceController::get()->Debug("VTaskItem::getChildTaskItems()", "Add a child to the result");
            result.push_back((VTaskItem*) childTaskItem);
        }
    }
    VTraceController::get()->Debug("VTaskItem::getChildTaskItems()", "End");
    return result;
}

/*!
 * \brief VTaskItem::updateSubitemsPositions
 * Met a jour la position des items enfants
 */
void VTaskItem::updateSubitemsPositions()
{
    if(_task == NULL) return;
    VTraceController::get()->Debug("VTaskItem::updateSubitemsPositions()", "Begin");
    // Getting children.
    QList<VTask*> childTasks = _task->getChildTasks();
    VTaskItem* childTaskItem;

    // If the task has at least a child.
    if (childTasks.count() > 0)
    {

        _taskConstructorItem->show();
        _hLineOutItem->show();

        // Task is expanded.
        if (_expanded)
        {
            _vLineItem->show();

            // Initializing hierarchy height and constructorVLineHeight.
            qreal currentHeight = 0;

            // Showing each child and positionning them.
            QListIterator<VTask*> childTaskIt(childTasks);
            while (childTaskIt.hasNext())
            {
                VTask * childTask = childTaskIt.next();
                childTaskItem = getChildTaskItem(childTask);
                if(childTaskItem != NULL)
                {
                    childTaskItem->show();
                    childTaskItem->setPos(TASKITEM_SUBTASKITEMS_X, currentHeight);

                    // If there is an item after this one, increment the current height.
                    if (childTaskIt.hasNext())
                        currentHeight += childTaskItem->getHeight();
                }
            }
            _vLineItem->setLine(VLINE_X, VLINE_Y1, VLINE_X, currentHeight + HLINEIN_Y);
        }

        // Task is not expanded.
        else
        {
            _vLineItem->hide();

            QList<VTaskItem*> childTaskItems = getChildTaskItems();
            // Hiding the children.
            foreach(childTaskItem, childTaskItems)
            {
                childTaskItem->hide();
            }
        }
    }
    else
    {
        _taskConstructorItem->hide();
        _hLineOutItem->hide();
        _vLineItem->hide();
    }

    VTaskItem* parentTaskItem = this->getParentTaskItem();
    if (parentTaskItem != NULL)
    {
        parentTaskItem->updateSubitemsPositions();
    }
    else
    {
        ((VActivityTreeScene*) this->scene())->updateItemsPositions();
    }

    VTraceController::get()->Debug("VTaskItem::updateSubitemsPositions()", "End");
}

/*!
 * \brief VTaskItem::updateContent
 * Met a jour le contenu
 */
void VTaskItem::updateContent()
{
    VTraceController::get()->Debug("VTaskItem::updateContent()", "Begin");
    if (_task)
    {
        // Constructor text content.
        _constrTextItem->setText(getConstrText());
    }
    _taskRectItem->update();
    VTraceController::get()->Debug("VTaskItem::updateContent()", "End");
}

/**
 * @brief setParentItem
 * Définit le parent du VTaskItem
 * Met à jour les graphismes concernés
 * @param newParent Le nouveau parent
 */
void VTaskItem::setParentItem(QGraphicsItem * newParent)
{
    QGraphicsItem::setParentItem(newParent);
    (this->getParentTaskItem() != NULL) ? _hLineInItem->show() : _hLineInItem->hide();
}
