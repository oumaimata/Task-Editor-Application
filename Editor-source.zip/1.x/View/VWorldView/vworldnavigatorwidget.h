#pragma once
#ifndef VWORLDNAVIGATORWIDGET_H
#define VWORLDNAVIGATORWIDGET_H

#include <QWidget>
#include <QTreeWidgetItem>

#include "Model/VWorld/vworldmodelelement.h"

class VWorldModel;
class VWObjectClass;
class VWActionClass;
class VWBehaviourClass;
class VWEventClass;

namespace Ui {
class VWorldNavigatorWidget;
}

class VWorldNavigatorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWorldNavigatorWidget *ui;

    VWorldModel * _worldModel;

    bool _edit;

    VWorldModelElement * _currentEdit;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief createObjectItem
     * Crée un QTreeWidgetItem correspondant à l'objet passé en argument
     * Méthode appelée récursivement sur l'arbre des objets
     * @param parentItem Le QTreeWidgetItem parent
     * @param object L'object
     * @return Le QTreeWidgetItem correspondant à l'objet passé en argument
     */
    QTreeWidgetItem * createObjectItem(QTreeWidgetItem * parentItem, VWObjectClass * object);
    
public:
    explicit VWorldNavigatorWidget(QWidget *parent = 0);
    ~VWorldNavigatorWidget();

    void setWorldModel(VWorldModel * worldModel);

    void setCurrentEdit(VWorldModelElement * curentEdit);

private slots:

    void updateDisplay();
    void on_addButton_clicked();
    void on_removeButton_clicked();

    void on_navigatorTreeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column);

signals:
    void editActionAsked(VWActionClass * actionClass);
    void editBehaviourAsked(VWBehaviourClass * behaviourClass);
    void editEventAsked(VWEventClass * eventClass);
    void editObjectAsked(VWObjectClass * objectClass);

    void removeAsked(VWorldModelElement * removed = NULL);
};

#endif // VWORLDNAVIGATORWIDGET_H
