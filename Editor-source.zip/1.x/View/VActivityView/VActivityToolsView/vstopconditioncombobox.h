#pragma once
#ifndef VSTOPCONDITIONCOMBOBOX_H
#define VSTOPCONDITIONCOMBOBOX_H

#include <QComboBox>
class VStopCondition;

class VStopConditionComboBox : public QComboBox
{
    Q_OBJECT
private:
    VStopCondition * _stopCondition;
public:
    explicit VStopConditionComboBox(VStopCondition * stopCondition, QWidget *parent = 0);
    
signals:
    
public slots:
    void stopConditionTypeChanged(QString s);
};

#endif // VSTOPCONDITIONCOMBOBOX_H
