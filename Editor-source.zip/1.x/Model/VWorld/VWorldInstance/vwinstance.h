#pragma once
#ifndef VWINSTANCE_H
#define VWINSTANCE_H

#include "../vworldmodelelement.h"

class VWObjectClass;
class VWProperty;
class VWPropertyValue;
class VWPropertyType;

class VWInstance : public VWorldModelElement
{
    Q_OBJECT
private:
    /**
     * @brief _class
     * La classe de l'instance
     */
    VWObjectClass * _class;

    /**
     * @brief _properties
     * La liste des propriétées
     */
    QMap<QPointer<VWProperty>, VWPropertyValue *> _valuedProperties;

public:
    /**
     * @brief VWInstance
     * Constructeur par défaut
     * @param parent L'objet parent
     */
    explicit VWInstance(QObject *parent = 0);

    /**
     * @brief VWInstance
     * @param o L'objet à copier
     */
    VWInstance(const VWInstance& o);

    /**
     * @brief ~VWInstance
     * Destructeur
     */
    ~VWInstance();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    void ParsePropertyValues(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setClass(VWObjectClass * cclass);
    VWObjectClass * getClass() const;

    void addValuedProperty(QString propertyName, QString value);
    void addValuedProperty(VWProperty * property, VWPropertyValue * value);
    void removeValuedProperty(VWProperty * property);
    QMap<QPointer<VWProperty>, VWPropertyValue *> getValuedProperties() const;
    QPointer<VWProperty> getValuedPropertyByUid(qint64 uid) const;
    QPointer<VWProperty> getValuedPropertyByName(QString name) const;
    QPointer<VWProperty> getValuedPropertyByType(VWPropertyType * type) const;
    VWPropertyValue * getValuedProperty(QPointer<VWProperty> property) const;
    VWPropertyValue * getValuedProperty(VWPropertyType * type) const;

public slots:
    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     */
    virtual void onModified();

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     * @param object L'object qui a été modifié
     */
    virtual void onModified(QString message, QObject * object = NULL);

    void onClassModified(QObject* object = NULL);
};

#endif // VWINSTANCE_H
