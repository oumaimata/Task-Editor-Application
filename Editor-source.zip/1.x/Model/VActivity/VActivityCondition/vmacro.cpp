#include "vmacro.h"

#include "vvar.h"

VMacro::VMacro(QObject *parent) :
    VActivityModelElement(parent)
{
}

VMacro::VMacro(const VMacro& macro, QObject *parent) :
    VActivityModelElement(parent)
{
    _operator = macro._operator;
    foreach(VVar * var, macro._vars)
    {
        addVar(var->clone());
    }
}

/**
 * @brief ~VMacro
 * Destructeur
 */
VMacro::~VMacro()
{
    while(_vars.count() > 0)
    {
        VVar * var = _vars.first();
        _vars.pop_front();
        delete var;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VMacro::parseDom(QDomElement elem)
{
    setOperator(elem.attribute("operator",""));
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de var
            if(element.tagName() == "var")
            {
                VVar * var = new VVar(this);
                var->parseDom(element);
                addVar(var);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VMacro::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<macro operator=\"" + VActivityMacroTypeToString(_operator) + "\">\n";
    for(int i = 0; i < _vars.count(); i++)
    {
        RetVal += _vars[i]->ToXml(tabulation + "\t");
    }
    RetVal += tabulation + "</macro>\n";
    return RetVal;
}

void VMacro::setOperator(VActivityMacroType ooperator)
{
    if(ooperator == SIZE_OF_VActivityMacroType)
    {
        onModified(tr("Operator changed"));
        return;
    }
    if(_operator != ooperator)
    {
        _operator = ooperator;
        onModified(tr("Operator changed"));
    }
}

void VMacro::setOperator(QString ooperator)
{
    setOperator(VActivityMacroTypeFromString(ooperator));
}

VActivityMacroType VMacro::getOperator() const
{
    return _operator;
}

void VMacro::addVar(VVar * var)
{
    if(var != NULL)
    {
        _vars.append(var);
        connect(var, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Var added"));
    }
}

void VMacro::removeVar(VVar * var)
{
    if(_vars.contains(var))
    {
        _vars.removeAll(var);
        disconnect(var, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Var removed"));
    }
}

QList<VVar *> VMacro::getVars() const
{
    return _vars;
}

VVar * VMacro::getVarById(qint64 uid) const
{
    for(int i = 0; i < _vars.count(); i++)
    {
        if(_vars[i]->getUid() == uid) return _vars[i];
    }
    return NULL;
}

/**
 * @brief clone
 * @return Le clone
 */
VMacro * VMacro::clone(QObject *parent) const
{
    return new VMacro(*this, parent);
}
