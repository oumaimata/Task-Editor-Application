#pragma once
#ifndef VWORLDWIDGET_H
#define VWORLDWIDGET_H

#include <QWidget>

#include "Model/VWorld/vworldmodelelement.h"

class VWComponentClass;
class VWActionClass;
class VWBehaviourClass;
class VWEventClass;
class VWObjectClass;
class VWInstance;

namespace Ui {
class VWorldWidget;
}

class VWorldWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWorldWidget *ui;

    QPointer<VWorldModelElement> _currentEdit;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    explicit VWorldWidget(QWidget *parent = 0);
    ~VWorldWidget();

    /*!
     * \brief VWorldWidget::setTextViewVisible
     * Définie l'attribut Visible de textView à enabled
     * \param enabled si activé
     */
    void setXmlViewVisible();

    void setCurrentEdit(QPointer<VWorldModelElement> currentEdit);

public slots:

    void onModelModified();

    void onModelModified(QString message, QObject * object = NULL);

    void onEditComponentAsked(VWComponentClass * componentClass);

    void onEditActionAsked(VWActionClass * actionClass);
    void onEditBehaviourAsked(VWBehaviourClass * behaviourClass);
    void onEditEventAsked(VWEventClass * eventClass);
    void onEditObjectAsked(VWObjectClass * objectClass);

    void onEditInstanceAsked(VWInstance * instance);

    void onRemoveAsked(VWorldModelElement * element);
};

#endif // VWORLDWIDGET_H
