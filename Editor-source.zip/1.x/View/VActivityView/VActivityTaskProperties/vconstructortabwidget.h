#pragma once
#ifndef VCONSTRUCTORTABWIDGET_H
#define VCONSTRUCTORTABWIDGET_H

#include <QWidget>
#include <QComboBox>

#include "Model/VActivity/VActivityConstructor/vactivityoperatortype.h"

class VTask;
class VConstructor;

namespace Ui {
class VConstructorTabWidget;
}

class VConstructorTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VConstructorTabWidget *ui;

    /**
     * @brief _typeComboBoxEdit
     * Si ui->typeComboBox est en cour d'édition
     */
    bool _edit;

    /**
     * @brief task
     * Tâche en cours d'édition
     */
    VTask * _task;

    /**
     * @brief _constructor
     * Le constructeur en cours d'édition
     */
    VConstructor * _constructor;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    /**
     * @brief VConstructorTabWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VConstructorTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VConstructorTabWidget
     * Destructeur
     */
    ~VConstructorTabWidget();

    /**
     * @brief setTask
     * Définit la tâche en cours d'édition
     * @param task La tâche en cours d'édition
     */
    void setTask(VTask *task);

    /**
     * @brief getTask
     * Obitent la tâche en cours d'édition
     * @return La tâche en cours d'édition
     */
    VTask * getTask() const;

private:

    /**
     * @brief updateDisplay
     * Met a jour les intefaces
     * en fonction de la tache sélectionnée
     */
    void updateDisplay();

    /**
     * @brief updateRelationDisplay
     * Met a jour l'inteface des relations
     * en fonction de la tache sélectionnée
     */
    void updateRelationDisplay();

    /**
     * @brief updateTypeDisplay
     * Met a jour l'inteface du type
     * en fonction de la tache sélectionnée
     */
    void updateTypeDisplay();

    /**
     * @brief getTaskCombo
     * Obtient une combo pour les tâches
     * @param selectedTask La tâche actuel
     * @return La combo
     */
    QComboBox * getTaskCombo(VTask * selectedTask);

    /**
     * @brief getOperatorCombo
     * Obtient une combo pour les opérateurs
     * @param selectedOperator L'opérateur actuel
     * @return La combo
     */
    QComboBox * getOperatorCombo(VActivityOperatorType selectedOperator);
    
private slots:

    /**
     * @brief on_addButton_clicked
     * Gère l'ajout de Relation
     */
    void on_addButton_clicked();

    /**
     * @brief relationChanged
     * Gère les modifications des combos d'opérateurs
     * @param position La position de la combo dans la table
     */
    void relationChanged(const QString & position);

    /**
     * @brief on_removeButton_clicked
     * Gère la supression de Relation
     */
    void on_removeButton_clicked();

    /**
     * @brief on_typeComboBox_currentIndexChanged
     * Gère la modification du type
     * @param index Index du nouvel item sémectioné
     */
    void on_typeComboBox_currentIndexChanged(int index);
};

#endif // VCONSTRUCTORTABWIDGET_H
