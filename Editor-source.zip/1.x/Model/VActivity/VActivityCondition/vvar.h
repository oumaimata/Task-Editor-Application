#pragma once
#ifndef VVAR_H
#define VVAR_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"

class VVar : public VActivityModelElement
{
    Q_OBJECT
private:

    QString _n;

    QString _id;

public:
    explicit VVar(QObject *parent = 0);

    VVar(const VVar& var, QObject *parent = 0);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setN(QString n);

    QString getN() const;

    void setId(QString id);

    QString getId() const;

    /**
     * @brief clone
     * @return Le clone
     */
    VVar * clone(QObject *parent = 0) const;
};

#endif // VVAR_H
