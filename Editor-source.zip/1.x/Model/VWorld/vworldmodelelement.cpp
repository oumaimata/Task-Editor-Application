#include "vworldmodelelement.h"

#include <QPair>

#include "vwparser.h"
#include "../../Controller/vtracecontroller.h"

qint64 VWorldModelElement::currentUid = 0;

/**
 * @brief VWorldModelElement
 * Constructeur
 * @param uid Identifiant de l'élément
 * @param parent L'object parent
 */
VWorldModelElement::VWorldModelElement(QObject *parent) :
    QObject(parent),
    _uid(currentUid),
    _name(""),
    _edit(false)
{
    currentUid++;
}

/**
 * @brief VActivityModelElement
 * Constructeur de copie
 * @param worldModelElement L'élément à copier
 */
VWorldModelElement::VWorldModelElement(const VWorldModelElement& worldModelElement) :
    QObject(worldModelElement.parent()),
    _uid(worldModelElement._uid),
    _name(worldModelElement._name)
{
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWorldModelElement::ParseDom(QDomElement elem)
{
    _edit = true;
    setName(VWParser::getName(elem));
    _edit = false;
}
/**
 * @brief getId
 * Obtient l'Id
 * @return L'id
 */
qint64 VWorldModelElement::getUid() const
{
    return _uid;
}

/**
 * @brief getCurrentUid
 * Obtient l'uid courant
 * @return L'uid courant
 */
qint64 VWorldModelElement::getCurrentUid()
{
    return currentUid;
}

/**
 * @brief setName
 * Définit le nom de l'élément
 * @param name Le nom de l'élément
 */
void VWorldModelElement::setName(QString name)
{
    if(name != _name)
    {
        _name = name.replace(" ", "");
        onNameModified(tr("Name changed"));
    }
}

/**
 * @brief getName
 * Obtient le nom de l'élément
 * @return Le nom de l'élément
 */
QString VWorldModelElement::getName() const
{
    return _name;
}

/**
 * @brief operator ==
 * Opérateur de comparaison
 * @param worldModelElement L'élément à comparer
 * @return Si les deux object sont éguaux
 */
bool VWorldModelElement::operator==(const VWorldModelElement& worldModelElement) const
{
    return _uid == worldModelElement._uid;
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 * @param object L'objet modifié
 */
void VWorldModelElement::onModified()
{
    onModified(NULL);
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 * @param object L'objet modifié
 */
void VWorldModelElement::onModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    VTraceController::get()->Info("VWorldModelElement::onModified()", message + " -> " + _name);
    emit modified(message, (object == NULL) ? this : object);
}

/**
 * @brief onNameModified
 * Envoie le signal nameModified(QString, QObject *)
 * @param object L'object qui a été modifié
 */
void VWorldModelElement::onNameModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    emit nameModified(message, (object == NULL) ? this : object);
    onModified(message, object);
}
