#include "vtaskcontainer.h"

#include "vtask.h"
#include "../../Controller/vtracecontroller.h"

/**
 * @brief VTaskContainer
 * Constructeur de VTaskContainer
 * @param parent L'object parent
 */
VTaskContainer::VTaskContainer(QObject* parent) : VActivityModelElement(parent){}

/**
 * @brief getChildTasks
 * Obtient une liste des taches filles
 * @return
 */
QList<VTask*> VTaskContainer::getChildTasks() const
{
    QList<VTask*> childTasks;
    QListIterator<QObject*> childrenIt (children()); // Utilise la méthode children() de QOject

    // Parcours la liste des enfants
    while (childrenIt.hasNext())
    {
        VTask* childTask = qobject_cast<VTask*>(childrenIt.next());
        if (childTask != NULL)
        {
            childTasks.push_back(childTask);
        }
    }
    return childTasks;
}

/**
 * @brief getAllChildTasks
 * Obtient une liste des tâches filles de toute l'arborescence
 * @return
 */
QList<VTask *> VTaskContainer::getAllChildTasks() const
{
    QList<VTask *> childTasks = getChildTasks();
    QList<VTask *> allChildTasks = getChildTasks();
    for(int i = 0; i < childTasks.count(); i++)
    {
        allChildTasks.append(childTasks[i]->getAllChildTasks());
    }
    return allChildTasks;
}

/**
 * @brief addChildTask
 * Ajout une tache fille à la tache courante
 * @param task La tache à ajouter
 */
void VTaskContainer::addChildTask(VTask* task)
{
    VTraceController::get()->Debug("VTaskContainer::addChildTask", "Begin");
    if (task == NULL)
    {
        task = new VTask(this);
    }
    else
    {
        task->setParent(this);
    }
    VTraceController::get()->Info("VTaskContainer::addChildTask", "Child task added");
    onChildTaskAdded(task);
    VTraceController::get()->Debug("VTaskContainer::addChildTask", "End");
}

/**
 * @brief VTaskContainer::onChildTaskAdded
 * Gère l'ajout des tâches filles
 * @param task La nouvelle tâche fille
 */
void VTaskContainer::onChildTaskAdded(VTask * task)
{
    this->childTaskAdded(task); // Fonction de notification récursive
    processChildTaskAdded();
}

/**
 * @brief processChildTaskAdded
 * Gère L'ajout des tâches filles
 */
void VTaskContainer::processChildTaskAdded(){}

/**
 * @brief removeChildTask
 * Retire une tache fille à la tache courante
 * @param task La tache à ajouter
 */
void VTaskContainer::removeChildTask(VTask* task)
{
    VTraceController::get()->Debug("VTaskContainer::removeChildTask", "Begin");

    if (task->parent() == this)
    {
        VTraceController::get()->Info("VTaskContainer::removeChildTask", "Remove task of children");
        task->setParent(NULL);

        VTraceController::get()->Info("VTaskContainer::removeChildTask", "Notify task removed");
        onChildTaskRemoved(task);

        VTraceController::get()->Info("VTaskContainer::removeChildTask", "Child task removed");
        delete task;
    }
    VTraceController::get()->Debug("VTaskContainer::removeChildTask", "End");
}

/**
 * @brief reorder
 * Met dans l'ordre les tâches selon l'ordre des tâches passé en argument
 * @param tasks La liste des tâches dans le nouvelle ordre
 */
void VTaskContainer::reorder(QList<VTask *> tasks)
{
    _edit = true;
    QList<VTask *> childTasks = getChildTasks();
    VTask * childTask;
    // Retire les tâches filles
    foreach(childTask, childTasks)
    {
        childTask->setParent(NULL);
    }
    // Ajoute les tâches dans l'ordre
    foreach(childTask, tasks)
    {
        if(childTasks.contains(childTask))
        {
            childTask->setParent(this);
            childTasks.removeAll(childTask);
        }
    }
    // Ajoute les tâches qui reste : normalement 0
    foreach(childTask, childTasks)
    {
        childTask->setParent(this);
        VTraceController::get()->Warning("VTaskContainer::reorder()", "Remaining task : " + childTask->getId());
    }
    _edit = false;
    onModified(tr("Tasks reordered"));
}

/**
 * @brief moveDown
 * Déplace les tâches passées en arguments vers le bas
 * @param tasks La liste des tâches à déplacer
 */
void VTaskContainer::moveDown(QList<QPointer<VTask> > tasks)
{
    _edit = true;
    QList<VTask *> oldOrderChildTasks = getChildTasks();
    QList<VTask *> newOrderChildTasks = getChildTasks();
    VTask * childTask;
    // Retire les tâches filles
    foreach(childTask, oldOrderChildTasks)
    {
        childTask->setParent(NULL);
    }
    // Parcours dans l'ordre inverse
    for(int i = oldOrderChildTasks.count() - 1; i >= 0; i--)
    {
        childTask = oldOrderChildTasks[i];
        if(tasks.contains(childTask)) // Si la tâche doit être déplacée
        {
            int from = newOrderChildTasks.indexOf(childTask);
            int to = qMin(from + 1, oldOrderChildTasks.count() - 1); // Vers la fin
            newOrderChildTasks.move(from, to); // On la déplace
        }
    }
    foreach(childTask, newOrderChildTasks)
    {
        childTask->setParent(this);
    }
    _edit = false;
    onModified(tr("Tasks moved down"));
}

/**
 * @brief moveUp
 * Déplace les tâches passées en arguments vers le haut
 * @param tasks La liste des tâches à déplacer
 */
void VTaskContainer::moveUp(QList<QPointer<VTask> > tasks)
{
    _edit = true;
    QList<VTask *> oldOrderChildTasks = getChildTasks();
    QList<VTask *> newOrderChildTasks = getChildTasks();
    VTask * childTask;
    // Retire les tâches filles
    foreach(childTask, oldOrderChildTasks)
    {
        childTask->setParent(NULL);
    }
    // Parcours dans l'ordre
    foreach(childTask, oldOrderChildTasks)
    {
        if(tasks.contains(childTask)) // Si la tâche doit être déplacée
        {
            int from = newOrderChildTasks.indexOf(childTask);
            int to = qMax(from - 1, 0); // Vers le début
            newOrderChildTasks.move(from, to); // On la déplace
        }
    }
    foreach(childTask, newOrderChildTasks)
    {
        childTask->setParent(this);
    }
    _edit = false;
    onModified(tr("Tasks moved up"));
}

/**
 * @brief onChildTaskRemoved
 * Gère la suppression des tâches filles
 */
void VTaskContainer::onChildTaskRemoved(VTask * task)
{
    this->childTaskRemoved(task);
    processChildTaskRemoved(task);
}

/**
 * @brief processChildTaskRemoved
 * Gère La suppression des tâches filles
 */
void VTaskContainer::processChildTaskRemoved(VTask * task){}
