#pragma once
#ifndef VACTIVITYCONTROLLER_H
#define VACTIVITYCONTROLLER_H

#include <QList>
#include <QPointer>

#include "../Model/VHistory/vhistoryset.h"

class VActivityWidget;
class VBasisCondition;
class VHistoryActivityWidget;
class VTask;

/*!
 * @brief The VActivityController class
 * Le controller du modèle d'activité
 */
class VActivityController : public QObject
{
    Q_OBJECT

private:

    bool _edit;

    bool _isCut;

    /*!
     * \brief _activityWidget
     * Pointeur vers le widget d'activité
     */
    VActivityWidget* _activityWidget;

    /**
     * @brief _historyActivityWidget
     * Pointeur vers le widget de l'historique
     */
    VHistoryActivityWidget* _historyActivityWidget;

    /**
     * @brief _taskClipboard
     * Liste des taches dans le presse papier
     */
    QList<QPointer<VTask> > _taskClipboard;

    /**
     * @brief _activityFileName
    */
    QString _activityFileName;

public:

    /*!
     * @brief VActivityController
     * Constructeur
     * @param activityWidget Le widget d'activité
     * @param historyActivityWidget Le widget d'historique de l'activité
     * @param parent
     */
    VActivityController(VActivityWidget* activityWidget,
                        VHistoryActivityWidget* historyActivityWidget,
                        QObject* parent = NULL);

    /**
     * @brief getActivityHistorySet
     * Obtient l'historique du modèle d'activité
     */
    VHistorySet * getActivityHistorySet();

    /**
     * @brief getActivityFutureSet
     * Obtient le future du modèle d'activité
     */
    VHistorySet * getActivityFutureSet();

    void loadModel(QString fileName);

    void undo();

    void redo();

    void cut();

    void copy();

    void paste();

    QString getNextValidTaskId(VTask * task, QString id) const;

    qint64 getNextValidConditionId(VBasisCondition * basisCondition, qint64 id) const;

    QString getActivityFileName() const;

    void setActivityFileName(const QString &activityFileName);

    bool isActivityModelSaved();

private:

    QList<QPointer<VTask> > getTaskClipboard();

    void setTaskClipboard(QList<QPointer<VTask> > tasks);

    void addChildTask(VTask * parent, VTask * task);

public slots :
    void historyHasChanged();

    /*!
     * @brief addTask Permet l'ajout d'une tache
     * @param parentTask La tache parente
     */
    void addTask(VTask* parentTask);

    /*!
     * @brief removeTask Permet la suppression d'une tache
     * @param task La tache
     */
    void removeTask(QPointer<VTask> task);
};

#endif // VACTIVITYCONTROLLER_H
