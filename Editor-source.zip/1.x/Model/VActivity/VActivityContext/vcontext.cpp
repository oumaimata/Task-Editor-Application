#include "vcontext.h"

#include "../VActivityCommon/vparam.h"
#include "../VActivityCommon/vrefconcept.h"
#include "vconstraint.h"

/**
 * @brief VContext
 * Constructeur du VContext
 * @param parent L'objet param
 */
VContext::VContext(QObject *parent) :
    VActivityModelElement(parent)
{
}

/**
 * @brief ~VContext
 * Destructeur
 */
VContext::~VContext()
{
    while(_refs.count() > 0)
    {
        VRefConcept * refConcept = _refs.first();
        _refs.pop_front();
        delete refConcept;
    }
    while(_params.count() > 0)
    {
        VParam * param = _params.first();
        _params.pop_front();
        delete param;
    }
    while(_constraints.count() > 0)
    {
        VConstraint * constraint = _constraints.first();
        _constraints.pop_front();
        delete constraint;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VContext::parseDom(QDomElement elem)
{
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de refs
            if(element.tagName() == "refs")
            {
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        // Lecture de ref-concept
                        if(subElement.tagName() == "ref-concept")
                        {
                            VRefConcept * refConcept = new VRefConcept(this);
                            refConcept->parseDom(subElement);
                            addRef(refConcept);
                        }
                        // Lecture de param
                        else if(subElement.tagName() == "param")
                        {
                            VParam * param = new VParam(this);
                            param->parseDom(subElement);
                            addParam(param);
                        }
                    }
                    subNode = subNode.nextSibling();
                }
            }
            // Lecture de constraints
            else if(element.tagName() == "constraints")
            {
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        // Lecture de constraint
                        if(subElement.tagName() == "constraint")
                        {
                            VConstraint * constraint = new VConstraint(this);
                            constraint->parseDom(subElement);
                            addConstraint(constraint);
                        }
                    }
                    subNode = subNode.nextSibling();
                }
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VContext::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<context>\n";
    RetVal += tabulation + "\t<refs>\n";

    // Ajouter les ref-concept
    for(int i = 0; i < _refs.count(); i++)
    {
        RetVal += _refs[i]->ToXml(tabulation + "\t\t");
    }
    // Ajouter les params
    for(int i = 0; i < _params.count(); i++)
    {
        RetVal += _params[i]->ToXml(tabulation + "\t\t");
    }

    RetVal += tabulation + "\t</refs>\n";
    if(_constraints.count() != 0)
    {
        RetVal += tabulation + "\t<constraints>\n";
        // Ajouter les contraintes
        for(int i = 0; i < _constraints.count(); i++)
        {
            RetVal += _constraints[i]->ToXml(tabulation + "\t\t");
        }

        RetVal += tabulation + "\t</constraints>\n";
    }
    RetVal += tabulation + "</context>\n";
    return RetVal;
}

/**
 * @brief addRef
 * Permet d'ajouter un VRefConcept
 * @param ref Un VRefConcept
 */
void VContext::addRef(VRefConcept * ref)
{
    if(ref != NULL)
    {
        _refs.append(ref);
        connect(ref, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified("", ref);
    }
}

/**
 * @brief removeRef
 * Permet de retirer un VRefConcept
 * @param ref Un VRefConcept
 */
void VContext::removeRef(VRefConcept * ref)
{
    if(_refs.contains(ref))
    {
        _refs.removeAll(ref);
        disconnect(ref, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified("", ref);
    }
}

/**
 * @brief getRefs
 * Obtient la liste des VRefConcept
 * @return La liste des VRefConcept
 */
QList<VRefConcept *> VContext::getRefs() const
{
    return _refs;
}

/**
 * @brief getRefById
 * Obtient le refconcept correspondant à l'id
 * @return Le refconcept correspondant à l'id
 */
VRefConcept * VContext::getRefById(qint64 uid) const
{
    for(int i = 0; i < _refs.count(); i++)
    {
        if(_refs[i]->getUid() == uid)
        {
            return _refs[i];
        }
    }
    return NULL;
}

/**
 * @brief addParam
 * Permet d'ajouter un VParam
 * @param param Un VParam
 */
void VContext::addParam(VParam * param)
{
    if(param != NULL)
    {
        _params.append(param);
        connect(param, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified("", param);
    }
}

/**
 * @brief removeParam
 * Permet de retirer un VParam
 * @param param Un VParam
 */
void VContext::removeParam(VParam * param)
{
    if(_params.contains(param))
    {
        _params.removeAll(param);
        disconnect(param, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified("", param);
    }
}

/**
 * @brief getParams
 * Obtient la liste des VParam
 * @return La liste des VParam
 */
QList<VParam *> VContext::getParams() const
{
    return _params;
}

/**
 * @brief getParamById
 * Obtient le param correspondant à l'id
 * @param uid L'id du param
 * @return Le param correspondant à l'id
 */
VParam * VContext::getParamById(qint64 uid) const
{
    for(int i = 0; i < _params.count(); i++)
    {
        if(_params[i]->getUid() == uid)
        {
            return _params[i];
        }
    }
    return NULL;
}

/**
 * @brief addConstraint
 * Permet d'ajouter un VConstraint
 * @param constraint Un VConstraint
 */
void VContext::addConstraint(VConstraint * constraint)
{
    if(constraint != NULL)
    {
        _constraints.append(constraint);
        connect(constraint, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified("", constraint);
    }
}

/**
 * @brief removeConstraint
 * Permet de retirer un VConstraint
 * @param constraint Un VConstraint
 */
void VContext::removeConstraint(VConstraint * constraint)
{
    if(_constraints.contains(constraint))
    {
        _constraints.removeAll(constraint);
        disconnect(constraint, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified("", constraint);
    }
}

/**
 * @brief getConstraints
 * Obtient la liste des VConstraint
 * @return La liste des VConstraint
 */
QList<VConstraint *> VContext::getConstraints() const
{
    return _constraints;
}

/**
 * @brief getConstraintById
 * Obtient le constraint correspondant à l'id
 * @param uid L'id du constraint
 * @return Le constraint correspondant à l'id
 */
VConstraint * VContext::getConstraintById(qint64 uid) const
{
    for(int i = 0; i < _constraints.count(); i++)
    {
        if(_constraints[i]->getUid() == uid)
        {
            return _constraints[i];
        }
    }
    return NULL;
}

/**
 * @brief clone
 * @return Le clone
 */
VContext * VContext::clone(QObject *parent) const
{
    VContext * context = new VContext(parent);
    foreach(VRefConcept * ref, _refs)
    {
        context->addRef(ref->clone());
    }
    foreach(VParam * param, _params)
    {
        context->addParam(param->clone());
    }
    foreach(VConstraint * constraint, _constraints)
    {
        context->addConstraint(constraint->clone());
    }
    return context;
}
