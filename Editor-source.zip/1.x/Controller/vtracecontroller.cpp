#include "vtracecontroller.h"

#include <iostream>
#include <QApplication>
#include <QTextStream>
#include <QIODevice>
#include <QDateTime>

/*!
 * \brief instanceVTraceController
 * L'instance de VTraceController
 */
VTraceController * VTraceController::instanceVTraceController = NULL;

/*!
 * \brief VTraceController
 * Constructeur
 * \param parent L'objet parent
 */
VTraceController::VTraceController(QObject* parent) :
    QObject(parent)
{
    minLevel = debug;
}

/*!
 * \brief getInstance
 * Obtient l'instance de trace (singleton)
 * \param parent L'objet parent
 * \return l'instance de trace
 */
VTraceController* VTraceController::get(QObject* parent)
{
    if(instanceVTraceController == NULL)
    {
        instanceVTraceController = new VTraceController(parent);
    }
    return instanceVTraceController;
}

/*!
 * \brief TraceLevelToString
 * Obtient une chaîne représentant un TraceLevel
 * \param level Le niveau de trace
 * \return La chaîne correspondante
 */
QString VTraceController::TraceLevelToString(TraceLevel level)
{
    switch(level)
    {
    case debug:
        return "Debug";
        break;
    case info:
        return "Info";
        break;
    case warning:
        return "Warning";
        break;
    case error:
        return "Error";
        break;
    default:
        return "";
        break;
    }
}

/*!
 * \brief getTraceLevelFromString
 * Obtient un TraceLevel à partir d'une chaîne
 * \param s Une chaîne représentant un TraceLevel
 * \return Le TraceLevel correspondant à s.
 */
VTraceController::TraceLevel VTraceController::getTraceLevelFromString(QString s)
{
    s = s.toLower();
    if(s == "debug")return debug;
    else if(s == "info")return info;
    else if(s == "warning")return warning;
    else if(s == "error")return error;
    else return debug;
}

/*!
 * \brief setFilePath
 * Définie filePath
 * Réinitialise le fichier de trace si path est différent de la valeur actuelle
 * \param path Chemin vers le fichier de trace
 */
void VTraceController::setFilePath(QString path)
{
    if(filePath != path)
    {
        filePath = path;
        file.setFileName(filePath + "/EDITOR_Trace.txt");

        // Vide le fichier de trace
        file.open(QIODevice::Truncate|QIODevice::WriteOnly);
        file.close();
    }
}

/*!
 * \brief getFilePath
 * Obtient le filePath
 * \return Retourne la valeur de filePath
 */
QString VTraceController::getFilePath()
{
    return filePath;
}

/*!
 * \brief setMinLevel
 * Définie minLevel
 * \param level Niveau minimum pour les traces
 */
void VTraceController::setMinLevel(TraceLevel level)
{
    minLevel = level;

    // Info sur le niveau de trace
    Write(QDateTime::currentDateTime().toString("[yyMMdd hh:mm:ss]") +
          " MinLevel defined to : " +
          TraceLevelToString(minLevel));

    // Info sur le dossier de l'application (si le parent est de type QApplication)
    QApplication* app = qobject_cast<QApplication*>(parent());
    if(app != NULL)
    {
        Write(QDateTime::currentDateTime().toString("[yyMMdd hh:mm:ss]") +
              " ApplicationDirPath : " + app->applicationDirPath());
    }
    else
    {
        Write(QDateTime::currentDateTime().toString("[yyMMdd hh:mm:ss]") +
              " Echec de qobject_cast<QApplication*>()");
    }

    // Info sur la local définie par le système
    Write(QDateTime::currentDateTime().toString("[yyMMdd hh:mm:ss]") +
          " Local : " + QLocale::system().name());
}

/*!
 * \brief setMinLevelFromString
 * Définie minLevel à partir d'une chaîne de caractère
 * \param s Niveau minimum pour les traces
 */
void VTraceController::setMinLevelFromString(QString s)
{
    setMinLevel(getTraceLevelFromString(s));
}

/*!
 * \brief getMinLevel
 * Obtient le minLevel
 * \return Retourne la valeur de minLevel
 */
VTraceController::TraceLevel VTraceController::getMinLevel()
{
    return minLevel;
}

/*!
 * \brief IsTraceActive
 * Si level est actif, retourne vrai sinon faux
 * \param level Le niveau de trace
 * \return Si le niveu de trace level est actif
 */
bool VTraceController::IsTraceActive(TraceLevel level)
{
    return level >= minLevel;
}

/*!
 * \brief Trace
 * Trace le message de la fonction si le niveau de trace est actif
 * \param level Le niveau de la trace
 * \param functionName Le nom de la fonction émettrice
 * \param message Le message de trace
 */
void VTraceController::Trace(TraceLevel level, QString functionName, QString message)
{
    if(IsTraceActive(level))
    {
        Write(
            QDateTime::currentDateTime().toString("[yyMMdd hh:mm:ss]") +
            " - " + TraceLevelToString(level) + " - " +
            functionName + " : " + message);
    }
}

/*!
 * \brief Write
 * Ecrit dans le fichier de trace
 * \param s La chaîne de caractère à écrire dans le fichier de trace
 */
void VTraceController::Write(QString s)
{
    // Si le chemin est valide, écrit dans le fichier
    if(file.open(QIODevice::Append | QIODevice::Text))
    {
        QTextStream stream(&file);
        stream << s << endl;
        file.close();
    }
    // Sinon la sortie s'effectue sur la console
    else
    {
        std::cout<< s.toStdString() <<std::endl;
    }
}

/*!
 * \brief Debug
 * Trace le message de debug de la fonction si le niveau de trace est actif
 * \param functionName Le nom de la fonction émettrice
 * \param message Le message de trace
 */
void VTraceController::Debug(QString functionName, QString message)
{
    Trace(debug, functionName, message);
}

/*!
 * \brief Info
 * Trace le message d'information de la fonction si le niveau de trace est actif
 * \param functionName Le nom de la fonction émettrice
 * \param message Le message de trace
 */
void VTraceController::Info(QString functionName, QString message)
{
    Trace(info, functionName, message);
}

/*!
 * \brief Warning
 * Trace le message de Warning de la fonction si le niveau de trace est actif
 * \param functionName Le nom de la fonction émettrice
 * \param message Le message de trace
 */
void VTraceController::Warning(QString functionName, QString message)
{
    Trace(warning, functionName, message);
}

/*!
 * \brief Error
 * Trace l'erreur de la fonction si le niveau de trace est actif
 * \param functionName Le nom de la fonction émettrice
 * \param message Le message de trace
 */
void VTraceController::Error(QString functionName, QString message)
{
    Trace(error, functionName, message);
}
