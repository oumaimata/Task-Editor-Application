#pragma once
#ifndef VMACRO_H
#define VMACRO_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"
#include "vactivitymacrotype.h"

class VVar;

class VMacro : public VActivityModelElement
{
    Q_OBJECT
private:

    VActivityMacroType _operator;

    QList<VVar *> _vars;

public:
    explicit VMacro(QObject *parent = 0);

    VMacro(const VMacro& macro, QObject *parent = 0);

    /**
     * @brief ~VMacro
     * Destructeur
     */
    ~VMacro();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setOperator(VActivityMacroType ooperator);

    void setOperator(QString ooperator);

    VActivityMacroType getOperator() const;

    void addVar(VVar * var);

    void removeVar(VVar * var);

    QList<VVar *> getVars() const;

    VVar * getVarById(qint64 uid) const;

    /**
     * @brief clone
     * @return Le clone
     */
    VMacro * clone(QObject *parent = 0) const;
};

#endif // VMACRO_H
