#include "vwinstanceeditorwidget.h"
#include "ui_vwinstanceeditorwidget.h"

#include <QDateEdit>
#include <QCheckBox>
#include <QComboBox>

#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vwproperty.h"
#include "Model/VWorld/vwpropertytype.h"
#include "Model/VWorld/vwpropertyvalue.h"
#include "Model/VWorld/VWorldInstance/vwinstance.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"

VWInstanceEditorWidget::VWInstanceEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWInstanceEditorWidget),
    _edit(false),
    _instance(NULL)
{
    ui->setupUi(this);
}

VWInstanceEditorWidget::~VWInstanceEditorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWInstanceEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWInstanceEditorWidget::setInstanceClass(VWInstance * instance)
{
    if(instance != _instance)
    {
        _instance = instance;
    }
    updateDisplay();
}

void VWInstanceEditorWidget::updateDisplay()
{
    _edit = true;
    ui->nameLineEdit->setText("");

    // Vider la table de propriété
    while(ui->propertyTableWidget->rowCount() > 0)
    {
        ui->propertyTableWidget->removeRow(0);
    }
    if(_instance == NULL) return;

    // Nom
    ui->nameLineEdit->setText(_instance->getName());

    // Les propriétés
    QSignalMapper* signalMapper = new QSignalMapper(this);
    QMap<QPointer<VWProperty>, VWPropertyValue *> valuedProperties = _instance->getValuedProperties();
    QList<QPointer<VWProperty> > properties = valuedProperties.keys();
    QList<VWPropertyValue *> values = valuedProperties.values();
    for(int i = 0; i < valuedProperties.keys().count(); i++)
    {
        ui->propertyTableWidget->insertRow(0);
    }
    for(int i = valuedProperties.keys().count() - 1; i >= 0; i--)
    {

        QTableWidgetItem * itemName = new QTableWidgetItem();
        itemName->setText(properties[i]->getName());
        itemName->setFlags(itemName->flags() & ~Qt::ItemIsEditable);
        itemName->setData(Qt::UserRole, properties[i]->getUid());
        ui->propertyTableWidget->setItem(i, 0, itemName);

        QTableWidgetItem * itemValue = new QTableWidgetItem();
        itemValue->setData(Qt::UserRole, properties[i]->getUid());
        if(properties[i]->getType() != NULL)
        {
            QString type = properties[i]->getType()->toString();
            if(type == "int" || type == "float" || type == "string")
            {
                itemValue->setText(values[i]->getBasicType());
            }
            else
            {
                QWidget * widget = getValueWidget(signalMapper, i, properties[i], values[i]);
                ui->propertyTableWidget->setCellWidget(i, 1, widget);
            }
        }
        ui->propertyTableWidget->setItem(i, 1, itemValue);

        QTableWidgetItem * itemType = new QTableWidgetItem();
        itemType->setFlags(itemType->flags() & ~Qt::ItemIsEditable);
        if(properties[i]->getType() != NULL) itemType->setText(properties[i]->getType()->toString());
        ui->propertyTableWidget->setItem(i, 2, itemType);
    }
    connect(signalMapper, SIGNAL(mapped(const QString &)), this, SLOT(valueChanged(const QString &)));
    ui->propertyTableWidget->resizeColumnsToContents();
    _edit = false;
}

QWidget * VWInstanceEditorWidget::getValueWidget(QSignalMapper* mapper, int index, VWProperty * property, VWPropertyValue * value)
{
    if (property == NULL || property->getType() == NULL) return NULL;
    QWidget * widget = NULL;
    QString type = property->getType()->toString();

    QPointer<VWComponentClass> component = property->getType()->getComponentClass();
    QPointer<VWObjectClass> object = property->getType()->getObjectClass();

    if(type == "Date")
    {
        widget = new QDateEdit(this);
        ((QDateEdit *)widget)->setDate(value->getDate());
        connect(((QDateEdit *)widget), SIGNAL(dateChanged(QDate)), mapper, SLOT(map()));
        mapper->setMapping(widget, QString("%1-%2").arg(index).arg(1));
    }
    else if(type == "DateTime")
    {
        widget = new QDateTimeEdit(this);
        ((QDateTimeEdit *)widget)->setDateTime(value->getDateTime());
        connect(((QDateTimeEdit *)widget), SIGNAL(dateTimeChanged(QDateTime)), mapper, SLOT(map()));
        mapper->setMapping(widget, QString("%1-%2").arg(index).arg(1));
    }
    else if(type == "bool")
    {
        widget = new QCheckBox(this);
        ((QCheckBox *) widget)->setChecked(value->getBoolean());
        connect(((QCheckBox *) widget), SIGNAL(toggled(bool)), mapper, SLOT(map()));
        mapper->setMapping(widget, QString("%1-%2").arg(index).arg(1));
    }
    else if(type == "domain:Boolean")
    {
        widget = new QComboBox(this);
        ((QComboBox *)widget)->addItem("domain:Unknown");
        ((QComboBox *)widget)->addItem("domain:True");
        ((QComboBox *)widget)->addItem("domain:False");
        ((QComboBox *)widget)->setCurrentText(value->getBasicType());
        connect((QComboBox *)widget, SIGNAL(currentIndexChanged(int)), mapper, SLOT(map()));
        mapper->setMapping(widget, QString("%1-%2").arg(index).arg(1));
    }
    else if(component != NULL)
    {
        widget = new QComboBox(this);

        // Création de la liste des instances possibles
        QList<VWInstance *> instances;
        QList<VWObjectClass *> objects = VApplicationModel::getInstance()->getWorldModel().getAllObjects(component);
        foreach(VWObjectClass * object, objects)
        {
            foreach(VWInstance * instance, object->getAllInstances())
            {
                if(!instances.contains(instance)) instances.append(instance);
            }
        }

        // Remplissage de la combo
        ((QComboBox *)widget)->addItem("");
        foreach(VWInstance * instance, instances)
        {
            ((QComboBox *)widget)->addItem(instance->getName(), instance->getUid());
        }
        if(value->getInstance() != NULL) ((QComboBox *)widget)->setCurrentText(value->getInstance()->getName());
        connect((QComboBox *)widget, SIGNAL(currentIndexChanged(int)), mapper, SLOT(map()));
        mapper->setMapping(widget, QString("%1-%2").arg(index).arg(1));
    }
    else if(object != NULL)
    {
        widget = new QComboBox(this);

        // Création de la liste des instances possibles
        QList<VWInstance *> instances;
        foreach(VWInstance * instance, object->getAllInstances())
        {
            if(!instances.contains(instance)) instances.append(instance);
        }

        // Remplissage de la combo
        ((QComboBox *)widget)->addItem("");
        foreach(VWInstance * instance, instances)
        {
            ((QComboBox *)widget)->addItem(instance->getName(), instance->getUid());
        }
        if(value->getInstance() != NULL) ((QComboBox *)widget)->setCurrentText(value->getInstance()->getName());
        connect((QComboBox *)widget, SIGNAL(currentIndexChanged(int)), mapper, SLOT(map()));
        mapper->setMapping(widget, QString("%1-%2").arg(index).arg(1));
    }
    return widget;
}

void VWInstanceEditorWidget::on_nameLineEdit_editingFinished()
{
    _instance->setName(ui->nameLineEdit->text());
}

void VWInstanceEditorWidget::on_removeButton_clicked()
{
    if(_instance == NULL) return;
    _instance->setClass(NULL);
    delete _instance;
    emit instanceRemoved();
}


/**
 * @brief valueChanged
 * Gère les modifications des combos de type
 * @param position La position du widget dans la table
 */
void VWInstanceEditorWidget::valueChanged(const QString & position)
{
    if(_edit) return;
    QStringList coordinates = position.split("-");
    int row = coordinates[0].toInt();
    int col = coordinates[1].toInt();
    QTableWidgetItem* item = ui->propertyTableWidget->item(row, col);

    if(item != NULL)
    {
        QString uid = item->data(Qt::UserRole).toString();
        QPointer<VWProperty> property = _instance->getValuedPropertyByUid(uid.toLong());
        VWPropertyValue * value = _instance->getValuedProperty(property);

        QString type = property->getType()->toString();
        QPointer<VWComponentClass> component = property->getType()->getComponentClass();
        QPointer<VWObjectClass> object = property->getType()->getObjectClass();

        if(type == "Date")
        {
            QDateEdit* widget = (QDateEdit*)ui->propertyTableWidget->cellWidget(row, col);
            value->setDate(widget->date());
        }
        else if(type == "DateTime")
        {
            QDateTimeEdit* widget = (QDateTimeEdit*)ui->propertyTableWidget->cellWidget(row, col);
            value->setDateTime(widget->dateTime());
        }
        else if(type == "bool")
        {
            QCheckBox* widget = (QCheckBox*)ui->propertyTableWidget->cellWidget(row, col);
            value->setBoolean(widget->isChecked());
        }
        else if(type == "domain:Boolean")
        {
            QComboBox* widget = (QComboBox*)ui->propertyTableWidget->cellWidget(row, col);
            value->setBasicType(widget->currentText());
        }
        else if(component != NULL)
        {
            QComboBox* widget = (QComboBox*)ui->propertyTableWidget->cellWidget(row, col);
            QString objectUid = widget->itemData(widget->currentIndex()).toString();
            VWInstance * instance = VApplicationModel::getInstance()->getWorldModel().getInstanceByUid(objectUid.toLong());
            value->setInstance(instance);
        }
        else if(object != NULL)
        {
            QComboBox* widget = (QComboBox*)ui->propertyTableWidget->cellWidget(row, col);
            QString objectUid = widget->itemData(widget->currentIndex()).toString();
            VWInstance * instance = object->getAllInstanceByUid(objectUid.toLong());
            value->setInstance(instance);
        }
    }
}

void VWInstanceEditorWidget::on_propertyTableWidget_itemChanged(QTableWidgetItem *item)
{
    if(_edit) return;

    qint64 uid = item->data(Qt::UserRole).toString().toInt();
    QPointer<VWProperty> property = _instance->getValuedPropertyByUid(uid);
    VWPropertyValue * value = _instance->getValuedProperty(property);
    QString type = property->getType()->toString();
    if(type == "int")
    {
        value->setBasicType(QString::number(item->text().toInt()));
    }
    else if(type == "float")
    {
        value->setBasicType(QString::number(item->text().toFloat()));
    }
    else if(type == "string")
    {
        value->setBasicType(item->text());
    }
}
