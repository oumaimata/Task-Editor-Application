#pragma once
#ifndef VWINSTANCETABWIDGET_H
#define VWINSTANCETABWIDGET_H

#include <QWidget>
#include <QTableWidgetItem>

#include "../../Model/VWorld/vworldmodelelement.h"

class VWObjectClass;
class VWInstance;

namespace Ui {
class VWInstanceTabWidget;
}

/**
 * @brief The VWInstanceTabWidget class
 * Affiche les instances de la classe et de ses sous classes
 */
class VWInstanceTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWInstanceTabWidget *ui;

    VWObjectClass * _objectClass;

    QPointer<VWorldModelElement> _currentEdit;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    explicit VWInstanceTabWidget(QWidget *parent = 0);
    ~VWInstanceTabWidget();

    void setObjectClass(VWObjectClass * objectClass);

    void setCurrentEdit(QPointer<VWorldModelElement> currentEdit);

private slots:
    void updateDisplay();

    void on_instanceTableWidget_itemDoubleClicked(QTableWidgetItem *item);

signals:
    void editInstanceAsked(VWInstance * instance);
};

#endif // VWINSTANCETABWIDGET_H
