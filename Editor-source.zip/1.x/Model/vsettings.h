#ifndef VSETTINGS
#define VSETTINGS

#include<QObject>
#include<QAction>
#include<QSettings>
#include<QApplication>
#include "../View/vmainwindow.h"
class VSettings : public QObject {

Q_OBJECT
public:
    enum FileType {ACTIVITY, WORLD};
    enum ActionFlags {ADD_ACTION_NEEDED, NO_ACTION_NEEDED};
    VSettings();
    ~VSettings();
    QAction* createActivityFileAction(const QString& fileName);
    QAction* createWorldFileAction(const QString& fileName);
    QAction* createAction (const QString& fileName, FileType fileType);
    void addActivityImportedFile(QAction* action);
    void addWorldImportedFile(QAction* action);
    ActionFlags beforeAddAction(QList<QAction*> *actions, QAction* action);
    void addImportedFile(QString& fileName, FileType fileType);
    QList<QAction *> getActivityImportedFiles() const;
    void setActivityImportedFiles(const QList<QAction *> &activityImportedFiles);
    QList<QAction *> getWorldImportedFiles() const;
    void setWorldImportedFiles(const QList<QAction *> &worldImportedFiles);
    void save();
    void load();
    void addActions(QStringList filesName, FileType fileType);

private:
    QList<QAction*> _activityImportedFiles;
    QList<QAction*> _worldImportedFiles;
    QSettings _qSettings;
    const int MAX_IMPORTED_FILES = 5;
    const QString ACTIVITY_IMPORTED_FILES_KEY = "activity_files";
    const QString WORLD_IMPORTED_FILES_KEY = "world_files";

    QVariant toQVariant(QList<QAction *> actions);

signals:
    void activityImportedFilesChanged(QList<QAction*>);
    void worldImportedFilesChanged(QList<QAction*>);
};

#endif // VSETTINGS

