#pragma once
#ifndef VTRACECONTROLLER_H
#define VTRACECONTROLLER_H

#include <QObject>
#include <QString>
#include <QFile>

/*!
 * \brief The VTraceController class
 * Permet de gérer le systeme de trace
 * Classe singleton accessible via getInstance()
 */
class VTraceController : public QObject
{
    Q_OBJECT

public:
    /*!
     * \brief The TraceLevel enum
     * Enumération des différents niveau de trace
     */
    enum TraceLevel
    {
       debug = 0,
       info = 1,
       warning = 2,
       error = 3
    };

private:
    /*!
     * \brief filePath
     * Chemin vers le fichier de trace
     */
    QString filePath;

    /*!
     * \brief file
     * Le fichier de trace
     */
    QFile file;

    /*!
     * \brief minLevel
     * Le niveau minimum de trace
     */
    TraceLevel minLevel;

    /*!
     * \brief instanceVTraceController
     * L'instance de VTraceController
     */
    static VTraceController * instanceVTraceController;

    /*!
     * \brief TraceLevelToString
     * Obtient une chaîne représentant un TraceLevel
     * \param level Le niveau de trace
     * \return La chaîne correspondante
     */
    static QString TraceLevelToString(TraceLevel level);

    /*!
     * \brief getTraceLevelFromString
     * Obtient un TraceLevel à partir d'une chaîne
     * \param s Une chaîne représentant un TraceLevel
     * \return Le TraceLevel correspondant à s.
     */
    static TraceLevel getTraceLevelFromString(QString s);

    /*!
     * \brief Write
     * Ecrit dans le fichier de trace
     * \param s La chaîne de caractère à écrire dans le fichier de trace
     */
    void Write(QString s);

    /*!
     * \brief VTraceController
     * Constructeur
     * \param parent L'objet parent
     */
    VTraceController(QObject* parent = NULL);
public:

    /*!
     * \brief getInstance
     * Obtient l'instance de trace (singleton)
     * \param parent L'objet parent
     * \return l'instance de trace
     */
    static VTraceController* get(QObject* parent = NULL);

    /*!
     * \brief setFilePath
     * Définie filePath
     * \param path Chemin vers le fichier de trace
     */
    void setFilePath(QString path);

    /*!
     * \brief getFilePath
     * Obtient le filePath
     * \return Retourne la valeur de filePath
     */
    QString getFilePath();

    /*!
     * \brief setMinLevel
     * Définie minLevel
     * \param level Niveau minimum pour les traces
     */
    void setMinLevel(TraceLevel level);

    /*!
     * \brief setMinLevelFromString
     * Définie minLevel à partir d'une chaîne de caractère
     * \param s Niveau minimum pour les traces
     */
    void setMinLevelFromString(QString s);

    /*!
     * \brief getMinLevel
     * Obtient le minLevel
     * \return Retourne la valeur de minLevel
     */
    TraceLevel getMinLevel();

    /*!
     * \brief IsTraceActive
     * Si level est actif, retourne vrai sinon faux
     * \param level Le niveau de trace
     * \return Si le niveu de trace level est actif
     */
    bool IsTraceActive(TraceLevel level);

    /*!
     * \brief Trace
     * Trace le message de la fonction si le niveau de trace est actif
     * \param level Le niveau de la trace
     * \param functionName Le nom de la fonction émettrice
     * \param message Le message de trace
     */
    void Trace(TraceLevel level, QString functionName, QString message);

    /*!
     * \brief Debug
     * Trace le message de debug de la fonction si le niveau de trace est actif
     * \param functionName Le nom de la fonction émettrice
     * \param message Le message de trace
     */
    void Debug(QString functionName, QString message);

    /*!
     * \brief Info
     * Trace le message d'information de la fonction si le niveau de trace est actif
     * \param functionName Le nom de la fonction émettrice
     * \param message Le message de trace
     */
    void Info(QString functionName, QString message);

    /*!
     * \brief Warning
     * Trace le message de Warning de la fonction si le niveau de trace est actif
     * \param functionName Le nom de la fonction émettrice
     * \param message Le message de trace
     */
    void Warning(QString functionName, QString message);

    /*!
     * \brief Error
     * Trace l'erreur de la fonction si le niveau de trace est actif
     * \param functionName Le nom de la fonction émettrice
     * \param message Le message de trace
     */
    void Error(QString functionName, QString message);
};

#endif // VTRACECONTROLLER_H
