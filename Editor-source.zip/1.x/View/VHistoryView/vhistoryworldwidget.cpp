#include "vhistoryworldwidget.h"
#include "ui_vhistoryworldwidget.h"

#include "../Model/VHistory/vhistoryset.h"

VHistoryWorldWidget::VHistoryWorldWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VHistoryWorldWidget)
{
    ui->setupUi(this);
    retranslate();
}

VHistoryWorldWidget::~VHistoryWorldWidget()
{
    delete ui;
}

/**
 * @brief setHistorySet
 * Définit le VHistorySet utilisé pour l'historique
 * @param historySet L'historique
 */
void VHistoryWorldWidget::setHistorySet(VHistorySet* historySet)
{
    ui->historyBasicWidget->setHistorySet(historySet);
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VHistoryWorldWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief VHistoryWorldWidget::retranslate
 * Traduction des widgets avec tr() hors du designer
 */
void VHistoryWorldWidget::retranslate()
{
    ui->historyBasicWidget->setTitle(tr("World model history"));
}
