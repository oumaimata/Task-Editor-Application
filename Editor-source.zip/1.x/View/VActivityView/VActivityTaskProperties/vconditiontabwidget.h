#pragma once
#ifndef VCONDITIONTABWIDGET_H
#define VCONDITIONTABWIDGET_H

#include <QWidget>
#include <QTreeWidgetItem>

class VTask;
class VCondition;
class VConditions;
class VConditionLogicalOperator;
class VTriple;
class VNotTriples;
class VStatement;

namespace Ui {
class VConditionTabWidget;
}

class VConditionTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VConditionTabWidget *ui;

    QFont * blackFont;

    /**
     * @brief _edit
     * Si l'édition est en cours
     */
    bool _edit;

    /**
     * @brief task
     * Tâche en cours d'édition
     */
    VTask * _task;

    /**
     * @brief _conditions
     * Les conditions en cours d'édition
     */
    VConditions * _conditions;
    
public:
    /**
     * @brief VConditionTabWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VConditionTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VConditionTabWidget
     * Destructeur
     */
    ~VConditionTabWidget();

    /**
     * @brief setTask
     * Définit la tâche en cours d'édition
     * @param task La tâche en cours d'édition
     */
    void setTask(VTask *task);

    /**
     * @brief getTask
     * Obitent la tâche en cours d'édition
     * @return La tâche en cours d'édition
     */
    VTask * getTask() const;

    /**
     * @brief setConditions
     * Définit les conditions en cours d'édition
     * @param condition Les conditions en cours d'édition
     */
    void setConditions(VConditions * conditions);

    /**
     * @brief getCondition
     * Obitent les conditions en cours d'édition
     * @return Les conditions en cours d'édition
     */
    VConditions * getConditions() const;

private:

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief updateDisplay
     * Met a jour l'inteface
     * en fonction de la tache sélectionnée
     */
    void updateDisplay();

    /**
     * @brief addCLOItem
     * Retourne et ajoute un item d'arbre correspondant à un CLO
     * @param parent L'item parent
     * @param cLO Le clo
     * @param parentCLO Le parent du clo sinon null
     * @return Un item d'arbre correspondant à un statement
     */
    QTreeWidgetItem * addCLOItem(QTreeWidgetItem * parent, VConditionLogicalOperator * cLO);

    /**
     * @brief addStatementItem
     * Retourne et ajoute un item d'arbre correspondant à un statement
     * @param parent L'item parent
     * @param statement Le statemnt
     * @param condition la condition
     * @param cLO L'opérateur logique de condition
     * @return Un item d'arbre correspondant à un statement
     */
    QTreeWidgetItem *addStatementItem(QTreeWidgetItem *parent, VStatement * statement, VCondition * condition = 0, VConditionLogicalOperator * cLO = 0);

    /**
     * @brief addTripleItem
     * Retourne et ajoute un item d'arbre correspondant à un triple
     * @param parent L'item parent
     * @param triple
     * @param statement
     * @param notTriples
     * @return Un item d'arbre correspondant à un triple
     */
    QTreeWidgetItem *addTripleItem(QTreeWidgetItem *parent, VTriple * triple, VStatement * statement, VNotTriples * notTriples = 0);

    /**
     * @brief setItemBackgroundColor
     * Définie le backgroundcolor de l'item de begin au nombre de colonne
     * @param item L'item à mettre à jour
     * @param beginIndex L'index de début
     */
    void setItemBackgroundColor(QTreeWidgetItem * item, int beginIndex);

private slots:
    /**
     * @brief on_addButton_clicked
     * Gère le click sur le bouton pour ajouter un tag
     */
    void on_addButton_clicked();

    /**
     * @brief on_treeWidget_itemChanged
     * Gère les modifications des items
     * @param item L'item modifié
     * @param column La colonne concernée
     */
    void on_treeWidget_itemChanged(QTreeWidgetItem *item, int column);

    /**
     * @brief on_removeButton_clicked
     * Gère le click sur le bouton pour supprimer un tag
     */
    void on_removeButton_clicked();

    /**
     * @brief on_logicalOperatorComboBox_currentIndexChanged
     * Gère les changements de sélections pour l'opérateur logique
     * @param index L'index de l'item sélectionné
     */
    void on_logicalOperatorComboBox_currentIndexChanged(int index);
};

#endif // VCONDITIONTABWIDGET_H
