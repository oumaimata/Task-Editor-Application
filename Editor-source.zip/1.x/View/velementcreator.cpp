#include "velementcreator.h"
#include "ui_velementcreator.h"

VElementCreator::VElementCreator(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VElementCreator)
{
    ui->setupUi(this);
    this->setWindowModality(Qt::ApplicationModal);
}

VElementCreator::~VElementCreator()
{
    delete ui;
}

/**
 * @brief setName
 * Défnie le nom de l'élément à créer
 * @param name Le nom de l'élément à créer
 */
void VElementCreator::setName(QString name)
{
    ui->lineEdit->setText(name);
}

/**
 * @brief getName
 * Obitent le nom de l'élément à créer
 * @return Le nom de l'élément à créer
 */
QString VElementCreator::getName()
{
    return ui->lineEdit->text();
}

/**
 * @brief getDialogResult
 * Obtient le résultat de la fenêtre de dialogue
 * @return Le résultat de la fenêtre de dialogue
 * -1 : Cancel
 *  0 : Create
 *  1 : Create and Edit
 */
int VElementCreator::getDialogResult()
{
    return m_DialogResult;
}

/**
 * @brief close
 * Overrides QWidget::close()
 */
void VElementCreator::close()
{
    QWidget::close();
    closed();
}

/**
 * @brief on_bCreate_clicked
 * Gère la clique sur le bouton Create
 */
void VElementCreator::on_bCreate_clicked()
{
    m_DialogResult = 0;
    this->close();
}

/**
 * @brief on_bCreateAndEdit_clicked
 * Gère la clique sur le bouton Create and Edit
 */
void VElementCreator::on_bCreateAndEdit_clicked()
{
    m_DialogResult = 1;
    this->close();
}

/**
 * @brief on_bCancel_clicked
 * Gère la clique sur le bouton Cancel
 */
void VElementCreator::on_bCancel_clicked()
{
    m_DialogResult = -1;
    this->close();
}
