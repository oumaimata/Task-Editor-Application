#pragma once
#ifndef VTAGTABWIDGET_H
#define VTAGTABWIDGET_H

#include <QWidget>
#include <QTreeWidgetItem>
#include <QColorDialog>


class VActivityModel;

namespace Ui {
class VTagTabWidget;
}

/**
 * @brief The VTagTabWidget class
 * Permet l'édition des tags
 */
class VTagTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VTagTabWidget *ui;

    /**
     * @brief _activityModel
     * Le modèle d'activité en cours
     */
    VActivityModel * _activityModel;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    explicit VTagTabWidget(QWidget *parent = 0);

    ~VTagTabWidget();

    /**
     * @brief setActivityModel
     * Définit le modèle d'activité en cours
     * @param activityModel Le modèle d'activité en cours
     */
    void setActivityModel(VActivityModel * activityModel);

private slots:
    /**
     * @brief updateDisplay
     * Met à jour l'affichage
     */
    void updateDisplay();

    /**
     * @brief on_treeWidget_itemChanged
     * Gère les modifications des items
     * @param item L'item modifié
     * @param column La colonne concernée
     */
    void on_treeWidget_itemChanged(QTreeWidgetItem *item, int column);

    /**
     * @brief on_treeWidget_clicked
     * Gère les clicks sur les items
     * @param item L'item modifié
     * @param column La colonne concernée
     */
    void on_treeWidget_itemClicked(QTreeWidgetItem *item, int column);

    /**
     * @brief on_addButton_clicked
     * Gère le click sur le bouton pour ajouter un tag
     */
    void on_addButton_clicked();

    /**
     * @brief on_removeButton_clicked
     * Gère le click sur le bouton pour supprimer un tag
     */
    void on_removeButton_clicked();

    /**
     * @brief on_treeWidget_itemSelectionChanged
     * Gère le changement de sélection
     * Pour le bouton de suppression
     */
    void on_treeWidget_itemSelectionChanged();
};

#endif // VTAGTABWIDGET_H
