#include "vmainwindow.h"
#include "ui_vmainwindow.h"
#include <iostream>
#include <QMessageBox>

#include "VWorldView/vworldwidget.h"
#include "VActivityView/vactivitywidget.h"
#include "VHistoryView/vhistoryactivitywidget.h"
#include "VHistoryView/vhistoryworldwidget.h"
#include "../Controller/vtracecontroller.h"
#include "../Controller/vapplicationcontroller.h"

/*!
 * \brief VMainWindow::VMainWindow
 * Constructeur
 * \param parent L'objet parent
 */
VMainWindow::VMainWindow(QWidget* parent) :
    QMainWindow(parent),
    ui(new Ui::VMainWindow)
{
    VTraceController::get()->Debug("VMainWindow::VMainWindow()", "Begin");
    ui->setupUi(this);
    VTraceController::get()->Debug("VMainWindow::VMainWindow()", "End");
}

/*!
 * \brief VMainWindow::getActivityWidget
 * Obtient le widget d'activité
 * \return Le widget d'activité
 */
VActivityWidget* VMainWindow::getActivityWidget()
{
    VTraceController::get()->Info("VMainWindow::getActivityWidget()", "ActivityWidget asked");
    return ui->activityWidget;
}

/*!
 * \brief VMainWindow::getWorldWidget
 * Obtient le widget du monde
 * \return Le widget du monde
 */
VWorldWidget* VMainWindow::getWorldWidget()
{
    VTraceController::get()->Info("VMainWindow::getWorldWidget()", "WorldWidget asked");
    return ui->worldWidget;
}

/*!
 * \brief VMainWindow::getActivityHistoryWidget
 * Obtient le widget d'historique de l'activité
 * \return Le widget d'historique de l'activité
 */
VHistoryActivityWidget* VMainWindow::getHistoryActivityWidget()
{
    return ui->historyWidget->getHistoryActivityWidget();
}

/*!
 * \brief VMainWindow::getHistoryWorldWidget
 * Obtient le widget d'historique du monde
 * \return Le widget d'historique du monde
 */
VHistoryWorldWidget* VMainWindow::getHistoryWorldWidget()
{
    return ui->historyWidget->getHistoryWorldWidget();
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VMainWindow::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QMainWindow::changeEvent(event);
}

/*!
 * \brief VMainWindow::on_actionQuit_triggered
 * Gère la demande de fermeture via le menu
 */
void VMainWindow::on_actionQuit_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionQuit_triggered()", "Quit asked");
    emit quitAsked();
//    qApp->quit();
}

/*!
 * \brief VMainWindow::on_actionDisplayActivityXml_triggered
 * \param checked Si coché
 *  Gère la demande d'affichage du TextView d'activityWidget
 */
void VMainWindow::on_actionDisplayActivityXml_triggered(bool checked)
{
    VTraceController::get()->Info("VMainWindow::on_actionDisplayActivityText_triggered()", "Activity XML view triggered");
    ui->activityWidget->setXmlViewVisible(checked);
}

/*!
 * \brief VMainWindow::on_actionDisplayWorldXml_triggered
 * \param checked Si coché
 *  Gère la demande d'affichage du TextView de worldModel
 */
void VMainWindow::on_actionDisplayWorldXml_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionDisplayWorldXml_triggered()", "World XML view triggered");
    ui->worldWidget->setXmlViewVisible();
}
/*!
 * \brief on_actionNewActivityModel_triggered
 *  Gère la demande de création d'un nouveau modèle du d'activité
 */
void VMainWindow::on_actionNewActivityModel_triggered(){
    VTraceController::get()->Info("VMainWindow::on_actionNewActivityModel_triggered()", "NewActivityModel triggered");
    emit newActivityModelAsked();
}
/**
 * @brief on_actionImportActivityModel_triggered
 * Gère la demande d'import d'un modèle d'activité
 */
void VMainWindow::on_actionImportActivityModel_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionImportActivityModel_triggered()", "ImportActivityModel triggered");
    emit activityModelImportAsked("");
}
/**
 * @brief on_actionSaveActivityModel_triggered
 * Gère la demande d'enregistrement d'un modèle d'activité
 */
void VMainWindow::on_actionSaveActivityModel_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionSaveActivityModel_triggered()", "SaveActivityModel triggered");
    emit activityModelSaveAsked();
}
/**
 * @brief on_actionExportActivityModel_triggered
 * Gère la demande d'export d'un modèle d'activité
 */
void VMainWindow::on_actionExportActivityModel_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionExportActivityModel_triggered()", "ExportActivityModel triggered");
    emit activityModelExportAsked("");
}

/**
 * @brief on_actionNewWorldModel_triggered
 * Gère la demande de création d'un nouveau modèle du monde
 */
void VMainWindow::on_actionNewWorldModel_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionNewWorldModel_triggered()", "NewWorldModel triggered");
    emit newWorldModelAsked();
}
/**
 * @brief on_actionImportWorldModel_triggered
 * Gère la demande d'import d'un modèle du monde
 */
void VMainWindow::on_actionImportWorldModel_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionImportWorldModel_triggered()", "ImportWorldModel triggered");
    emit worldModelImportAsked("");
}


void VMainWindow::on_actionSaveWorldModel_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionSaveWorldModel_triggered()", "SaveWorldModel triggered");
    emit worldModelSaveAsked();
}
/**
 * @brief on_actionExportWorldModel_triggered
 * Gère la demande d'export d'un modèle du monde
 */
void VMainWindow::on_actionExportWorldModel_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionExportWorldModel_triggered()", "ExportWorldModel triggered");
    emit worldModelExportAsked(NULL);
}

/**
 * @brief on_actionUndo_triggered
 * Gère la demande annuler
 */
void VMainWindow::on_actionUndo_triggered()
{
    ui->actionRedo->setEnabled(false);
    ui->actionUndo->setEnabled(false);
    int index = ui->tabWidget->currentIndex();
    if(index == 0)
    {
        VActivityController * activityCtrler = VApplicationController::getInstance()->getActivityController();
        activityCtrler->undo();
    }
    else if(index == 1)
    {
        VWorldController * worldCtrler = VApplicationController::getInstance()->getWorldController();
        worldCtrler->undo();
    }
    ui->actionRedo->setEnabled(true);
    ui->actionUndo->setEnabled(true);
    changeStatus(tr("Undo done"));
}

/**
 * @brief on_actionRedo_triggered
 * Gère la demande rétablir
 */
void VMainWindow::on_actionRedo_triggered()
{
    ui->actionRedo->setEnabled(false);
    ui->actionUndo->setEnabled(false);
    int index = ui->tabWidget->currentIndex();
    if(index == 0)
    {
        VActivityController * activityCtrler = VApplicationController::getInstance()->getActivityController();
        activityCtrler->redo();
    }
    else if(index == 1)
    {
        VWorldController * worldCtrler = VApplicationController::getInstance()->getWorldController();
        worldCtrler->redo();
    }
    ui->actionRedo->setEnabled(true);
    ui->actionUndo->setEnabled(true);
    changeStatus(tr("Redo done"));
}

/**
 * @brief on_actionCut_triggered
 * Gère la demande Cut
 */
void VMainWindow::on_actionCut_triggered()
{
    if(ui->tabWidget->currentIndex() != 0) return;
    emit cutAsked();
}

/**
 * @brief on_actionCopy_triggered
 * Gère la demande Copy
 */
void VMainWindow::on_actionCopy_triggered()
{
    if(ui->tabWidget->currentIndex() != 0) return;
    emit copyAsked();
}

/**
 * @brief on_actionPaste_triggered
 * Gère la demande Paste
 */
void VMainWindow::on_actionPaste_triggered()
{
    if(ui->tabWidget->currentIndex() != 0) return;
    emit pasteAsked();
}

/*!
 * \brief VMainWindow::on_actionEnglish_triggered
 * Le bouton English du menu a été clické
 */
void VMainWindow::on_actionEnglish_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionEnglish_triggered()", "Ask for change of language : English");
    updateLanguageMenu("en");
    emit englishLanguageAsked();
}

/*!
 * \brief VMainWindow::on_actionFrench_triggered
 * Le bouton French du menu a été clické
 */
void VMainWindow::on_actionFrench_triggered()
{
    VTraceController::get()->Info("VMainWindow::on_actionFrench_triggered()", "Ask for change of language : French");
    updateLanguageMenu("fr");
    emit frenchLanguageAsked();
}

void VMainWindow::on_menuActivityRecentImportedFiles_triggered(QAction * action){
     emit activityModelImportAsked(action->text());
}
void VMainWindow::on_menuWorldRecentImportedFiles_triggered(QAction * action){
     emit worldModelImportAsked(action->text());
}

/**
 * @brief VMainWindow::updateLanguageMenu
 * Freeze the item of the current language passed by lang
 * @param lang The current language
 */
void VMainWindow::updateLanguageMenu(QString lang)
{
    VTraceController::get()->Info("VMainWindow::updateLanguageMenu()", "Freeze the item of the current language");
    ui->actionEnglish->setEnabled(lang != "en");
    ui->actionFrench->setEnabled(lang != "fr");
}

void VMainWindow::switchToActivity()
{
    ui->tabWidget->setCurrentIndex(0);
}

void VMainWindow::switchToWorld()
{
    ui->tabWidget->setCurrentIndex(1);
}

void VMainWindow::switchToHistory()
{
    ui->tabWidget->setCurrentIndex(2);
}

/**
 * @brief VMainWindow::on_tabWidget_currentChanged
 * Met à jour les raccourcis en fonction de la vue d'actuelle
 * @param index Index du groupe d'onglet
 */
void VMainWindow::on_tabWidget_currentChanged(int index)
{
    // Change shortcut : Import / Export
    ui->actionNewActivityModel->setShortcut(QStringLiteral(""));
    ui->actionSaveActivityModel->setShortcut(QStringLiteral(""));
    ui->actionImportActivityModel->setShortcut(QStringLiteral(""));
    ui->actionExportActivityModel->setShortcut(QStringLiteral(""));
    ui->actionNewWorldModel->setShortcut(QStringLiteral(""));
    ui->actionSaveWorldModel->setShortcut(QStringLiteral(""));
    ui->actionImportWorldModel->setShortcut(QStringLiteral(""));
    ui->actionExportWorldModel->setShortcut(QStringLiteral(""));
    if(index == 0)
    {
        ui->actionNewActivityModel->setShortcut(QStringLiteral("Ctrl+N"));
        ui->actionImportActivityModel->setShortcut(QStringLiteral("Ctrl+O"));
        ui->actionSaveActivityModel->setShortcut(QStringLiteral("Ctrl+S"));
        ui->actionExportActivityModel->setShortcut(QStringLiteral("Ctrl+SHIFT+S"));
    }
    else if(index == 1)
    {
        ui->actionNewWorldModel->setShortcut(QStringLiteral("Ctrl+N"));
        ui->actionImportWorldModel->setShortcut(QStringLiteral("Ctrl+O"));
        ui->actionSaveWorldModel->setShortcut(QStringLiteral("Ctrl+S"));
        ui->actionExportWorldModel->setShortcut(QStringLiteral("Ctrl+SHIFT+S"));
    }

    // Enable : Cut / Copy / Paste
    ui->actionCut->setEnabled(index == 0);
    ui->actionCopy->setEnabled(index == 0);
    ui->actionPaste->setEnabled(index == 0);
}

void VMainWindow::closeEvent(QCloseEvent *event){
    event->ignore();
    emit quitAsked();
}

void VMainWindow::changeStatus(QString status){
    VMainWindow::statusBar()->showMessage(status, 3000);
}

void VMainWindow::updateActivityRecentImportedFiles(QList<QAction*> actions){
    ui->menuActivityRecentImportedFiles->addActions(actions);
}
void VMainWindow::updateWorldRecentImportedFiles(QList<QAction*> actions){
    ui->menuWorldRecentImportedFiles->addActions(actions);
}

void VMainWindow::updateState(){
    QString windowTitle = this->windowTitle();
    if(VApplicationController::getInstance()->isApplicationSaved()){
        if(windowTitle.endsWith("*")){
            windowTitle.remove(this->windowTitle().size() - 1, 1);
            this->setWindowTitle(windowTitle);
        }
    }
    else
    {
        if(!windowTitle.endsWith("*"))
            this->setWindowTitle(windowTitle +  "*");
    }
}
