#pragma once
#ifndef VWEVENTCLASSEDITORWIDGET_H
#define VWEVENTCLASSEDITORWIDGET_H

#include <QWidget>

class VWEventClass;

namespace Ui {
class VWEventClassEditorWidget;
}

class VWEventClassEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWEventClassEditorWidget *ui;

    bool _edit;

    VWEventClass * _eventClass;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    void retranslate();
    
public:
    explicit VWEventClassEditorWidget(QWidget *parent = 0);
    ~VWEventClassEditorWidget();

    void setEventClass(VWEventClass * eventClass);

private slots:
    void updateDisplay();
    void on_nameLineEdit_editingFinished();
    void on_addBehaviourButton_clicked();
    void on_removeBehaviourButton_clicked();
    void on_durativeRadioButton_toggled(bool checked);
    void on_punctualRadioButton_toggled(bool checked);
    void on_exogenousRadioButton_toggled(bool checked);
    void on_endogenousRadioButton_toggled(bool checked);
    void on_beginComboBox_currentIndexChanged(int index);
    void on_endComboBox_currentIndexChanged(int index);
};

#endif // VWEVENTCLASSEDITORWIDGET_H
