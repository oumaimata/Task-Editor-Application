#pragma once
#ifndef VWENTITYCLASS_H
#define VWENTITYCLASS_H

#include "vwcomponentclass.h"
#include "../vworldmodelelement.h"

class VWEntityClass : public VWorldModelElement
{
    Q_OBJECT
protected:
    /**
     * @brief _components
     * Les composants de l'entité
     */
    QList<QPointer<VWComponentClass> > _components;

public:
    /**
     * @brief VWEntityClass
     * Constructeur par défaut
     * @param parent L'objet parent
     */
    explicit VWEntityClass(QObject *parent = 0);

    /**
     * @brief VWEntityClass
     * @param o L'objet à copier
     */
    VWEntityClass(const VWEntityClass& o);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    /**
     * @brief ParseComponentDom
     * Permet de parser les components
     * @param elem Un élément du dom
     */
    void ParseComponentDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void addComponent(QString componentName);
    void addComponent(VWComponentClass * component);
    void removeComponent(VWComponentClass * component);
    QList<QPointer<VWComponentClass> > getComponents() const;
    QPointer<VWComponentClass> getComponentByUid(qint64 uid) const;
    
};

#endif // VWENTITYCLASS_H
