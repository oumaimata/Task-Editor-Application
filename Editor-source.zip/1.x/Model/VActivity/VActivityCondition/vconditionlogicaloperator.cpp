#include "vconditionlogicaloperator.h"

#include "vstatement.h"

VConditionLogicalOperator::VConditionLogicalOperator(QObject *parent) :
    VActivityModelElement(parent),
    _type("AND")
{
}

VConditionLogicalOperator::VConditionLogicalOperator(const VConditionLogicalOperator& cLO, QObject *parent) :
    VActivityModelElement(parent)
{
    _type = cLO._type;
    foreach(VStatement * statement, cLO._statements)
    {
        addStatement(statement->clone());
    }
    foreach(VConditionLogicalOperator * child, cLO._childs)
    {
        addChild(child->clone());
    }
}

/**
 * @brief ~VConditionLogicalOperator
 * Destructeur
 */
VConditionLogicalOperator::~VConditionLogicalOperator()
{
    while(_statements.count() > 0)
    {
        VStatement * statement = _statements.first();
        _statements.pop_front();
        delete statement;
    }
    while(_childs.count() > 0)
    {
        VConditionLogicalOperator * cLO = _childs.first();
        _childs.pop_front();
        delete cLO;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VConditionLogicalOperator::parseDom(QDomElement elem)
{
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de statement
            if(element.tagName() == "statement")
            {
                VStatement * statement = new VStatement(this);
                statement->parseDom(element);
                addStatement(statement);
            }
            // Lecture de CLO
            else
            {
                VConditionLogicalOperator * cLO = new VConditionLogicalOperator(this);
                cLO->parseDom(element);
                cLO->setType(element.tagName());
                addChild(cLO);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VConditionLogicalOperator::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<" + _type + ">\n";

    for(int i = 0; i < _childs.count(); i++)
    {
        RetVal += _childs[i]->ToXml(tabulation + "\t");
    }

    for(int i = 0; i < _statements.count(); i++)
    {
        RetVal += _statements[i]->ToXml(tabulation + "\t");
    }
    RetVal += tabulation + "</" + _type + ">\n";
    return RetVal;
}

void VConditionLogicalOperator::setType(QString type)
{
    if(_type != type)
    {
        _type = type;
        onModified(NULL);
    }
}

QString VConditionLogicalOperator::getType() const
{
    return _type;
}

void VConditionLogicalOperator::addStatement(VStatement * statement)
{
    if(statement != NULL)
    {
        _statements.append(statement);
        connect(statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Statement added"));
    }
}

void VConditionLogicalOperator::removeStatement(VStatement * statement)
{
    if(_statements.contains(statement))
    {
        _statements.removeAll(statement);
        disconnect(statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Statement removed"));
    }
}

QList<VStatement *> VConditionLogicalOperator::getStatements() const
{
    return _statements;
}

VStatement * VConditionLogicalOperator::getStatementById(qint64 uid) const
{
    for(int i = 0; i < _statements.count(); i++)
    {
        if(_statements[i]->getUid() == uid) return _statements[i];
    }
    return NULL;
}

void VConditionLogicalOperator::addChild(VConditionLogicalOperator * cLO)
{
    if(cLO != NULL)
    {
        _childs.append(cLO);
        connect(cLO, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Logical operator child added"));
    }
}

void VConditionLogicalOperator::removeChild(VConditionLogicalOperator * cLO)
{
    if(_childs.contains(cLO))
    {
        _childs.removeAll(cLO);
        disconnect(cLO, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Logical operator child removed"));
    }
}

QList<VConditionLogicalOperator *> VConditionLogicalOperator::getChilds() const
{
    return _childs;
}

VConditionLogicalOperator * VConditionLogicalOperator::getChildById(qint64 uid) const
{
    for(int i = 0; i < _childs.count(); i++)
    {
        if(_childs[i]->getUid() == uid) return _childs[i];
        else
        {
            VConditionLogicalOperator * cLOs = _childs[i]->getChildById(uid);
            if(cLOs != NULL) return cLOs;
        }
    }
    return NULL;
}

QString VConditionLogicalOperator::toString(QString tabulation) const
{
    QString RetVal = "";
    if(_statements.count() != 0 || _childs.count() != 0)
    {
        RetVal += "\n" + tabulation + _type;
        foreach(VStatement * statement, _statements)
        {
            RetVal += statement->toString(tabulation + "\t");
        }
        foreach(VConditionLogicalOperator * child, _childs)
        {
            RetVal += child->toString(tabulation + "\t");
        }
    }
    return RetVal;
}

/**
 * @brief clone
 * @return Le clone
 */
VConditionLogicalOperator * VConditionLogicalOperator::clone(QObject *parent) const
{
    return new VConditionLogicalOperator(*this, parent);
}
