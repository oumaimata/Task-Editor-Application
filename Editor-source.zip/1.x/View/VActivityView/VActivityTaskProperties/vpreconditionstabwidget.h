#pragma once
#ifndef VPRECONDITIONSTABWIDGET_H
#define VPRECONDITIONSTABWIDGET_H

#include <QWidget>

class VTask;
class VConditions;

namespace Ui {
class VPreconditionsTabWidget;
}

class VPreconditionsTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VPreconditionsTabWidget *ui;

    /**
     * @brief task
     * Tâche en cours d'édition
     */
    VTask * _task;

    /**
     * @brief _Conditions
     * Liste de conditions Favorable de la tâche
     */
    VConditions * _favorableConditions;

    /**
     * @brief _regulatoryConditions
     * Liste de conditions Regulatory de la tâche
     */
    VConditions * _regulatoryConditions;

    /**
     * @brief _nomologicalConditions
     * Liste de conditions Nomological de la tâche
     */
    VConditions * _nomologicalConditions;

    /**
     * @brief _contextualConditions
     * Liste de conditions Contextual de la tâche
     */
    VConditions * _contextualConditions;

public:

    /**
     * @brief VPreconditionsTabWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VPreconditionsTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VPreconditionsTabWidget
     * Destructeur
     */
    ~VPreconditionsTabWidget();

    /**
     * @brief setTask
     * Définit la tâche en cours d'édition
     * @param task La tâche en cours d'édition
     */
    void setTask(VTask *task);

    /**
     * @brief getTask
     * Obitent la tâche en cours d'édition
     * @return La tâche en cours d'édition
     */
    VTask * getTask() const;
};

#endif // VPRECONDITIONSTABWIDGET_H
