#include "vvar.h"

VVar::VVar(QObject *parent) :
    VActivityModelElement(parent),
    _n(""),
    _id("")
{
}

VVar::VVar(const VVar& var, QObject *parent) :
    VActivityModelElement(parent)
{
    _n = var._n;
    _id = var._id;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VVar::parseDom(QDomElement elem)
{
    setN(elem.attribute("n", ""));
    setId(elem.attribute("id", ""));
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VVar::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<var";
    if(!_n.isEmpty() && !_n.isNull()) RetVal += " n=\"" + _n + "\"";
    if(!_id.isEmpty() && !_id.isNull()) RetVal += " id=\"" + _id + "\"";
    RetVal += " />\n";
    return RetVal;
}

void VVar::setN(QString n)
{
    if(_n != n)
    {
        _n = n;
        onModified(tr("N changed"));
    }
}

QString VVar::getN() const
{
    return _n;
}

void VVar::setId(QString id)
{
    if(_id != id)
    {
        _id = id;
        onModified(tr("Id changed"));
    }
}

QString VVar::getId() const
{
    return _id;
}

/**
 * @brief clone
 * @return Le clone
 */
VVar * VVar::clone(QObject *parent) const
{
    return new VVar(*this, parent);
}
