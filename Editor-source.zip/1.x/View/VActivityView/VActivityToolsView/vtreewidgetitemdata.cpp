#include "vtreewidgetitemdata.h"

#include <QVariant>

#include "Model/VActivity/VActivityCondition/vstopcondition.h"
#include "Model/VActivity/VActivityCondition/vcondition.h"
#include "Model/VActivity/VActivityCondition/vconditionlogicaloperator.h"
#include "Model/VActivity/VActivityCondition/vstatement.h"
#include "Model/VActivity/VActivityCondition/vnottriples.h"
#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivityCondition/vmacro.h"
#include "Model/VActivity/VActivityCondition/vvar.h"

VTreeWidgetItemData::VTreeWidgetItemData(VCondition *condition,
                                         VConditionLogicalOperator * cLO,
                                         VStatement * statement,
                                         VNotTriples * notTriples,
                                         VTriple * triple,
                                         VMacro * macro,
                                         VVar * var) :
    _stopCondition(NULL),
    _condition(condition),
    _cLO(cLO),
    _addressee(NULL),
    _agent(NULL),
    _statement(statement),
    _notTriples(notTriples),
    _triple(triple),
    _macro(macro),
    _var(var),
    _other(false),
    _type("")
{

}

VTreeWidgetItemData::VTreeWidgetItemData(VAddressee *addressee,
                                         VWInstance* agent,
                                         VStatement * statement,
                                         VNotTriples * notTriples,
                                         VTriple * triple,
                                         VMacro * macro,
                                         VVar * var) :
    _stopCondition(NULL),
    _condition(NULL),
    _cLO(NULL),
    _addressee(addressee),
    _agent(agent),
    _statement(statement),
    _notTriples(notTriples),
    _triple(triple),
    _macro(macro),
    _var(var),
    _other(false),
    _type("")
{

}

VTreeWidgetItemData::VTreeWidgetItemData(VWInstance* agent,
                                         VStatement * statement,
                                         VNotTriples * notTriples,
                                         VTriple * triple,
                                         VMacro * macro,
                                         VVar * var) :
    _stopCondition(NULL),
    _condition(NULL),
    _cLO(NULL),
    _addressee(NULL),
    _agent(agent),
    _statement(statement),
    _notTriples(notTriples),
    _triple(triple),
    _macro(macro),
    _var(var),
    _other(false),
    _type("")
{

}



VTreeWidgetItemData::VTreeWidgetItemData(VStatement * statement,
                                         VNotTriples * notTriples,
                                         VTriple * triple,
                                         VMacro * macro,
                                         VVar * var) :
    _stopCondition(NULL),
    _condition(NULL),
    _cLO(NULL),
    _addressee(NULL),
    _agent(NULL),
    _statement(statement),
    _notTriples(notTriples),
    _triple(triple),
    _macro(macro),
    _var(var),
    _other(false),
    _type("")
{

}


VTreeWidgetItemData::VTreeWidgetItemData(VStopCondition * stopCondition,
                    VStatement * statement,
                    VNotTriples * notTriples,
                    VTriple * triple,
                    VMacro * macro,
                    VVar * var) :
    _stopCondition(stopCondition),
    _condition(NULL),
    _cLO(NULL),
    _addressee(NULL),
    _agent(NULL),
    _statement(statement),
    _notTriples(notTriples),
    _triple(triple),
    _macro(macro),
    _var(var),
    _other(false),
    _type("")
{

}

QVariant VTreeWidgetItemData::getQVariant(VCondition *condition,
                                          VConditionLogicalOperator * cLO,
                                          VStatement * statement,
                                          VNotTriples * notTriples,
                                          VTriple * triple,
                                          VMacro * macro,
                                          VVar * var)
{
    return QVariant::fromValue(new VTreeWidgetItemData(condition, cLO, statement, notTriples, triple, macro, var));
}


QVariant VTreeWidgetItemData::getQVariant(VAddressee * addressee,
                                          VWInstance* agent,
                                          VStatement * statement,
                                          VNotTriples * notTriples,
                                          VTriple * triple,
                                          VMacro * macro,
                                          VVar * var)
{
    return QVariant::fromValue(new VTreeWidgetItemData(addressee, agent, statement, notTriples, triple, macro, var));
}


QVariant VTreeWidgetItemData::getQVariant(VWInstance* agent,
                                          VStatement * statement,
                                          VNotTriples * notTriples,
                                          VTriple * triple,
                                          VMacro * macro,
                                          VVar * var)
{
    return QVariant::fromValue(new VTreeWidgetItemData(agent, statement, notTriples, triple, macro, var));
}

QVariant VTreeWidgetItemData::getQVariant(VStatement * statement,
                                          VNotTriples * notTriples,
                                          VTriple * triple,
                                          VMacro * macro,
                                          VVar * var)
{
    return QVariant::fromValue(new VTreeWidgetItemData(statement, notTriples, triple, macro, var));
}

QVariant VTreeWidgetItemData::getQVariant(VStopCondition * stopCondition,
                                          VStatement * statement,
                                          VNotTriples * notTriples,
                                          VTriple * triple,
                                          VMacro * macro,
                                          VVar * var)
{
    return QVariant::fromValue(new VTreeWidgetItemData(stopCondition, statement, notTriples, triple, macro, var));
}

QVariant VTreeWidgetItemData::getOther(QString type, VStopCondition * stopCondition)
{
    VTreeWidgetItemData * data = new VTreeWidgetItemData(stopCondition);
    data->setIsOther(true);
    data->setType(type);
    return QVariant::fromValue(data);
}

void VTreeWidgetItemData::setStopCondition(VStopCondition * stopCondition)
{
    _stopCondition = stopCondition;
}

VStopCondition * VTreeWidgetItemData::getStopCondition() const
{
    return _stopCondition;
}

void VTreeWidgetItemData::setCondition(VCondition * condition)
{
    _condition = condition;
}

VCondition * VTreeWidgetItemData::getCondition() const
{
    return _condition;
}

void VTreeWidgetItemData::setCLO(VConditionLogicalOperator * cLO)
{
    _cLO = cLO;
}

VConditionLogicalOperator * VTreeWidgetItemData::getCLO() const
{
    return _cLO;
}

VAddressee *VTreeWidgetItemData::getAddressee() const
{
    return _addressee;
}

void VTreeWidgetItemData::setAddressee(VAddressee *addressee)
{
    _addressee = addressee;
}

void VTreeWidgetItemData::setStatement(VStatement * statement)
{
    _statement = statement;
}

VStatement * VTreeWidgetItemData::getStatement() const
{
    return _statement;
}

VWInstance *VTreeWidgetItemData::getAgent() const
{
    return _agent;
}

void VTreeWidgetItemData::setAgent(VWInstance *agent)
{
    _agent = agent;
}

void VTreeWidgetItemData::setNotTriples(VNotTriples * notTriples)
{
    _notTriples = notTriples;
}

VNotTriples * VTreeWidgetItemData::getNotTriples() const
{
    return _notTriples;
}

void VTreeWidgetItemData::setTriple(VTriple * triple)
{
    _triple = triple;
}

VTriple * VTreeWidgetItemData::getTriple() const
{
    return _triple;
}

void VTreeWidgetItemData::setMacro(VMacro * macro)
{
    _macro = macro;
}

VMacro * VTreeWidgetItemData::getMacro() const
{
    return _macro;
}

void VTreeWidgetItemData::setVar(VVar * var)
{
    _var = var;
}

VVar * VTreeWidgetItemData::getVar() const
{
    return _var;
}

void VTreeWidgetItemData::setIsOther(bool other)
{
    _other = other;
}

bool VTreeWidgetItemData::getIsOther() const
{
    return _other;
}

void VTreeWidgetItemData::setType(QString type)
{
    _type = type;
}

QString VTreeWidgetItemData::getType() const
{
    return _type;
}
