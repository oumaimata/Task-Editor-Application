#include "vrefconcept.h"

QList<VRefConcept *> VRefConcept::s_refConcepts;

VRefConcept::VRefConcept(QObject *parent) :
    VActivityModelElement(parent),
    _concept(""),
    _ref(""),
    _predicate("")
{
    s_refConcepts.append(this);
}

VRefConcept::VRefConcept(const VRefConcept& refconcept, QObject *parent) :
    VActivityModelElement(parent)
{
    _concept = refconcept._concept;
    _ref = refconcept._ref;
    _predicate = refconcept._predicate;
}

VRefConcept::~VRefConcept()
{
    s_refConcepts.removeAll(this);
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VRefConcept::parseDom(QDomElement elem)
{
    setConcept(elem.attribute("concept",""));
    setRef(elem.attribute("ref",""));
    setPredicate(elem.attribute("predicate",""));
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VRefConcept::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<ref-concept";
    if(!_concept.isEmpty() && !_concept.isNull()) RetVal += " concept=\"" + _concept + "\"";
    RetVal += " ref=\"" + _ref + "\"";
    if(!_predicate.isEmpty() && !_predicate.isNull()) RetVal += " predicate=\"" + _predicate + "\"";
    RetVal += " />\n";
    return RetVal;
}

void VRefConcept::setConcept(QString concept)
{
    if(_concept != concept)
    {
        _concept = concept;
        onModified(tr("Concept changed"));
    }
}

QString VRefConcept::getConcept() const
{
    return _concept;
}

void VRefConcept::setRef(QString ref)
{
    if(_ref != ref)
    {
        _ref = ref;
        onModified(tr("Ref changed"));
    }
}

QString VRefConcept::getRef() const
{
    return _ref;
}

void VRefConcept::setPredicate(QString predicate)
{
    if(_predicate != predicate)
    {
        _predicate = predicate;
        onModified(tr("Predicate changed"));
    }
}

QString VRefConcept::getPredicate() const
{
    return _predicate;
}

VRefConcept * VRefConcept::getRefConcept(qint64 uid)
{
    VRefConcept * refConcept;
    foreach(refConcept, s_refConcepts)
    {
        if(refConcept->getUid() == uid) return refConcept;
    }
    return NULL;
}


QList<VRefConcept *> VRefConcept::getAllRefConcepts()
{
    QList<VRefConcept *> RetVal;

    VRefConcept * refConcept;
    foreach(refConcept, s_refConcepts)
    {
        if((!refConcept->_predicate.isNull() && !refConcept->_predicate.isEmpty()) ||
           (!refConcept->_ref.isNull() && !refConcept->_ref.isEmpty()))
        {
            bool alreadyInRetVal = false;
            VRefConcept * retValRefConcept;
            foreach(retValRefConcept, RetVal)
            {
                alreadyInRetVal = alreadyInRetVal || (refConcept->_predicate == retValRefConcept->_predicate &&
                                                      refConcept->_ref == retValRefConcept->_ref &&
                                                      (refConcept->_concept == retValRefConcept->_concept ||
                                                       refConcept->_concept.isNull() || refConcept->_concept.isEmpty() ||
                                                       retValRefConcept->_concept.isNull() || retValRefConcept->_concept.isEmpty()));
            }
            if(!alreadyInRetVal) RetVal.append(refConcept);
        }
    }

    return RetVal;
}


/**
 * @brief clone
 * @return Le clone
 */
VRefConcept * VRefConcept::clone(QObject *parent) const
{
    return new VRefConcept(*this, parent);
}
