#pragma once
#ifndef VCONSTRAINT_H
#define VCONSTRAINT_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"

class VTriple;

class VConstraint : public VActivityModelElement
{
    Q_OBJECT
private:

    /**
     * @brief _triples
     * Liste des triplets
     */
    QList<VTriple *> _triples;

public:
    /**
     * @brief VConstraint
     * Constructeur du VConstraint
     * @param parent L'objet parent
     */
    explicit VConstraint(QObject *parent = 0);

    /**
     * @brief VConstraint
     * Constructeur de recopie
     * @param constraint VConstraint à copier
     */
    VConstraint(const VConstraint& constraint, QObject *parent = 0);

    /**
     * @brief ~VConstraint
     * Destructeur
     */
    ~VConstraint();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    /**
     * @brief addTriple
     * Permet d'ajouter un VTriple
     * @param triple Un VTriple
     */
    void addTriple(VTriple * triple);

    /**
     * @brief removeTriple
     * Permet de retirer un VTriple
     * @param triple Un VTriple
     */
    void removeTriple(VTriple * triple);

    /**
     * @brief getTriples
     * Obtient la liste des VTriple
     * @return La liste des VTriple
     */
    QList<VTriple *> getTriples() const;

    /**
     * @brief getTripleById
     * Obtient le triple correspondant à l'id
     * @param id L'id du triple
     * @return Le triple correspondant à l'id
     */
    VTriple * getTripleById(qint64 uid) const;

    /**
     * @brief clone
     * @return Le clone
     */
    VConstraint *clone(QObject *parent = 0) const;
};

#endif // VCONSTRAINT_H
