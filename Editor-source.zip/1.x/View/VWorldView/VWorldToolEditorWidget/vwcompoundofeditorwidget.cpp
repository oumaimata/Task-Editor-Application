#include "vwcompoundofeditorwidget.h"
#include "ui_vwcompoundofeditorwidget.h"

#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwentityclass.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"

VWCompoundOfEditorWidget::VWCompoundOfEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWCompoundOfEditorWidget),
    _edit(false),
    _entity(NULL)
{
    ui->setupUi(this);
}

VWCompoundOfEditorWidget::~VWCompoundOfEditorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWCompoundOfEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWCompoundOfEditorWidget::setEntity(VWEntityClass * entity)
{
    if(entity != _entity)
    {
        _entity = entity;
    }
    updateDisplay();
}

void VWCompoundOfEditorWidget::updateDisplay()
{
    _edit = true;

    // Vider la combo
    ui->componentComboBox->clear();
    // Vider la table
    while(ui->componentTableWidget->rowCount() > 0)
    {
        ui->componentTableWidget->removeRow(0);
    }

    if(_entity == NULL) return;
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();

    // Remplir la combo
    VWComponentClass * component;
    QList<VWComponentClass * > components = worldModel->getAllComponents();
    foreach(component, components)
    {
        if(!_entity->getComponents().contains(component))
        {
            ui->componentComboBox->addItem(component->getName(), component->getUid());
        }
    }

    // Remplir la table
    QPointer<VWComponentClass> qComponent;
    QList<QPointer<VWComponentClass> > qComponents = _entity->getComponents();
    foreach(qComponent, qComponents)
    {
        if(qComponent != NULL)
        {
            ui->componentTableWidget->insertRow(0);
            QTableWidgetItem* item = new QTableWidgetItem();
            item->setText(qComponent->getName());
            item->setData(Qt::UserRole, qComponent->getUid());
            ui->componentTableWidget->setItem(0, 0, item);
        }
    }
    ui->componentTableWidget->resizeColumnsToContents();

    _edit = false;
}

void VWCompoundOfEditorWidget::on_addComponentButton_clicked()
{
    if(_edit || _entity == NULL) return;
    QString uid = ui->componentComboBox->itemData(ui->componentComboBox->currentIndex()).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWComponentClass * component = worldModel->getComponentByUid(uid.toLong());
    if(component != NULL) _entity->addComponent(component);
}

void VWCompoundOfEditorWidget::on_removeComponentButton_clicked()
{
    if(_edit || _entity == NULL) return;
    if(ui->componentTableWidget->selectedItems().count() == 0) return;
    QTableWidgetItem * item = ui->componentTableWidget->selectedItems().first();
    QString uid = item->data(Qt::UserRole).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWComponentClass * component = worldModel->getComponentByUid(uid.toLong());
    if(component != NULL) _entity->removeComponent(component);
}
