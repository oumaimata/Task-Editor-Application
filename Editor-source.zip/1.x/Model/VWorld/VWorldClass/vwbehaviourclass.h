#pragma once
#ifndef VWBEHAVIOURCLASS_H
#define VWBEHAVIOURCLASS_H

#include "vwentityclass.h"

class VWEventClass;

class VWBehaviourClass : public VWEntityClass
{
    Q_OBJECT
private:
    /**
     * @brief _isDurative
     * Si le comportement dure dans le temps
     */
    bool _isDurative;

    /**
     * @brief _isPunctual
     * Si le comportement est situé dans le temps
     */
    bool _isPunctual;

    /**
     * @brief _events
     * Liste des événements déclenchés par le comportement
     */
    QList<QPointer<VWEventClass> > _events;

    /**
     * @brief _properties
     * Liste des VWProperty
     */
    VWProperties * _properties;

public:
    /**
     * @brief VWBehaviourClass
     * Constructeur par défaut
     * @param parent L'objet parent
     */
    explicit VWBehaviourClass(QObject *parent = 0);

    /**
     * @brief VWBehaviourClass
     * @param o L'objet à copier
     */
    VWBehaviourClass(const VWBehaviourClass& o);

    /**
     * @brief ~VWBehaviourClass
     * Destructeur
     */
    ~VWBehaviourClass();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setIsDurative(bool isDurative);
    bool getIsDurative() const;

    void setIsPunctual(bool isPunctual);
    bool getIsPunctual() const;

    void addEvent(VWEventClass * event);
    void removeEvent(VWEventClass * event);
    QList<QPointer<VWEventClass> > getEvents() const;

    QPointer<VWProperty> addProperty(QDomElement elem);
    VWProperties * getProperties() const;
    
};

#endif // VWBEHAVIOURCLASS_H
