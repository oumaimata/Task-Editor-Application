#pragma once
#ifndef VWORLDMODEL_H
#define VWORLDMODEL_H

#include "vworldmodelelement.h"

class VWActionClass;
class VWBehaviourClass;
class VWComponentClass;
class VWObjectClass;
class VWEventClass;
class VWInstance;

class VWorldModel : public VWorldModelElement
{
    Q_OBJECT
private:
    QString _namespaceUri;
    QString _domainNamespaceUri;
    QMap<QString, QString> _otherNamespacesUri;

    QList<VWComponentClass *> _components;
    QList<VWActionClass *> _actions;
    QList<VWBehaviourClass *> _behaviours;
    QList<VWObjectClass *> _objects;
    QList<VWEventClass *> _events;
public:
    /**
     * @brief VWorldModel
     * Constructeur par défaut
     * @param parent L'objet parent
     */
    explicit VWorldModel(QObject *parent = 0);

    /**
     * @brief ~VWorldModel
     * Destructeur
     */
    ~VWorldModel();
    /**
     * @brief newWorldModel
     * Crée un nouveau modèle du monde
     */
    void newWorldModel();
    /**
     * @brief resetModel
     * Vide le model
     */
    void resetModel();

    /**
     * @brief loadModel
     * Permet de charger un model
     * @param xmlModel Le modèle en xml
     */
    void loadModel(QString xmlModel);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml();

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation);

    /**
     * @brief executeQuery
     * Execute une requète SPARQL dans JENA
     * @param query La requète
     * @return Le résultat de la requète
     */
    QString executeQuery(QString query);

    void setNamespace(QString ns);
    void setNamespace(QString ns, QString otherNs);
    QString getNamespace() const;
    void setDomainNamespace(QString ns);
    QString getDomainNamespace() const;
    void addNamespace(QString prefix, QString ns);
    void removeNamespace(QString prefix);
    QString getNamespace(QString prefix) const;
    QMap<QString, QString> getNamespaces() const;

    void addComponent(VWComponentClass * component);
    void addComponent(QDomElement elem);
    void removeComponent(VWComponentClass * component);
    QList<VWComponentClass *> getComponents() const;
    QList<VWComponentClass *> getAllComponents() const;
    VWComponentClass * getComponentByUid(qint64 uid) const;
    VWComponentClass * getComponentByName(QString name) const;

    void addAction(VWActionClass * action);
    void addAction(QDomElement elem);
    void removeAction(VWActionClass * action);
    QList<VWActionClass *> getActions() const;
    VWActionClass * getActionByUid(qint64 uid) const;
    VWActionClass * getActionByName(QString name) const;

    void addBehaviour(VWBehaviourClass * behaviour);
    void addBehaviour(QDomElement elem);
    void removeBehaviour(VWBehaviourClass * behaviour);
    QList<VWBehaviourClass *> getBehaviours() const;
    VWBehaviourClass * getBehaviourByUid(qint64 uid) const;
    VWBehaviourClass * getBehaviourByName(QString name) const;

    void addObject(VWObjectClass * object);
    void addObject(QDomElement elem);
    void removeObject(VWObjectClass * object);
    QList<VWObjectClass *> getObjects() const;
    QList<VWObjectClass *> getAllObjects() const;
    QList<VWObjectClass *> getAllObjects(VWComponentClass * component) const;
    VWObjectClass * getObjectByUid(qint64 uid) const;
    VWObjectClass * getObjectByName(QString name) const;

    QList<VWInstance *> getAllInstances() const;
    VWInstance * getInstanceByUid(qint64 uid) const;
    VWInstance * getInstanceByName(QString name) const;

    void addEvent(VWEventClass * event);
    void addEvent(QDomElement elem);
    void removeEvent(VWEventClass * event);
    QList<VWEventClass *> getEvents() const;
    VWEventClass * getEventByUid(qint64 uid) const;
    VWEventClass * getEventByName(QString name) const;

public slots:
    void onModified();
    void onModified(QString message, QObject *object = NULL);
};

#endif // VWORLDMODEL_H
