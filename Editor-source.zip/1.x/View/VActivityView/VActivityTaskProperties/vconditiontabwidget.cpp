#include "vconditiontabwidget.h"
#include "ui_vconditiontabwidget.h"

#include <QInputDialog>

#include "../VActivityToolsView/vtreewidgetitemdata.h"
#include "../VActivityToolsView/vstatementtypecombobox.h"
#include "../VActivityToolsView/vtriplesubjectwidget.h"
#include "../VActivityToolsView/vtripleobjectwidget.h"
#include "../VActivityToolsView/vtripleobjectcheckbox.h"
#include "../VActivityToolsView/vtriplepredicatecombobox.h"

#include "Model/VActivity/vtask.h"
#include "Model/VActivity/VActivityCondition/vcondition.h"
#include "Model/VActivity/VActivityCondition/vconditions.h"
#include "Model/VActivity/VActivityCondition/vconditionlogicaloperator.h"
#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivityCondition/vnottriples.h"
#include "Model/VActivity/VActivityCondition/vstatement.h"
#include "Model/VActivity/VActivityCondition/vmacro.h"
#include "Model/VActivity/VActivityCondition/vvar.h"
#include "Controller/vtracecontroller.h"

/**
 * @brief VConditionsTabWidget
 * Constructeur
 * @param parent L'objet parent
 */
VConditionTabWidget::VConditionTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VConditionTabWidget),
    _edit(false),
    _task(NULL),
    _conditions(NULL)
{
    ui->setupUi(this);
    blackFont = new QFont();
    blackFont->setWeight(QFont::Black);
}

/**
 * @brief ~VConditionsTabWidget
 * Destructeur
 */
VConditionTabWidget::~VConditionTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VConditionTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setTask
 * Définit la tâche en cours d'édition
 * @param task La tâche en cours d'édition
 */
void VConditionTabWidget::setTask(VTask * task)
{
    if (task != _task)
    {
        VTraceController::get()->Info("VConditionTabWidget::setTask()", "Task defined");
        _task = task;
        _conditions = NULL;
    }
    updateDisplay();
}

/**
 * @brief getTask
 * Obitent la tâche en cours d'édition
 * @return La tâche en cours d'édition
 */
VTask * VConditionTabWidget::getTask() const
{
    return _task;
}

/**
 * @brief setConditions
 * Définit les conditions en cours d'édition
 * @param condition Les conditions en cours d'édition
 */
void VConditionTabWidget::setConditions(VConditions * conditions)
{
    if (conditions != _conditions)
    {
        _conditions = conditions;
    }
    updateDisplay();
}

/**
 * @brief getConditions
 * Obitent les conditions en cours d'édition
 * @return Les conditions en cours d'édition
 */
VConditions * VConditionTabWidget::getConditions() const
{
    return _conditions;
}

/**
 * @brief updateDisplay
 * Met a jour les intefaces
 * en fonction de la tache sélectionnée
 */
void VConditionTabWidget::updateDisplay()
{
    _edit = true;
    // Vide l'arbre
    int topLevelItemCount = ui->treeWidget->topLevelItemCount();
    for(int i = 0; i < topLevelItemCount; i++)
    {
        ui->treeWidget->takeTopLevelItem(0);
    }
    setEnabled(false);

    if(_conditions != NULL && _task != NULL)
    {
        foreach(VCondition * condition, _conditions->getConditions())
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(ui->treeWidget);
            item->setExpanded(true);
            item->setText(0, condition->getType());
            item->setFlags(item->flags() | Qt::ItemIsEditable);
            item->setText(1, QString::number(condition->getId()));
            item->setFont(0, *blackFont);
            item->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(condition));
            setItemBackgroundColor(item, 2);
            foreach(VConditionLogicalOperator * cLO, condition->getCLOs())
            {
                QTreeWidgetItem * itemCLO = new QTreeWidgetItem(item);
                itemCLO->setExpanded(true);
                itemCLO->setText(0, cLO->getType());
                itemCLO->setFont(0, *blackFont);
                itemCLO->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(condition, cLO));
                setItemBackgroundColor(itemCLO, 1);

                foreach(VConditionLogicalOperator * child, cLO->getChilds())
                {
                    addCLOItem(itemCLO, child);
                }

                foreach(VStatement * statement, cLO->getStatements())
                {
                    addStatementItem(itemCLO, statement, NULL, cLO);
                }
            }
            foreach(VStatement * statement, condition->getStatements())
            {
                addStatementItem(item, statement, condition);
            }
        }
        ui->treeWidget->resizeColumnToContents(0);
        ui->treeWidget->resizeColumnToContents(1);
        ui->treeWidget->resizeColumnToContents(2);
        ui->treeWidget->resizeColumnToContents(3);
        setEnabled(true);
    }
    _edit = false;
}

/**
 * @brief addCLOItem
 * Retourne et ajoute un item d'arbre correspondant à un CLO
 * @param parent L'item parent
 * @param cLO Le clo
 * @param parentCLO Le parent du clo sinon null
 * @return Un item d'arbre correspondant à un statement
 */
QTreeWidgetItem * VConditionTabWidget::addCLOItem(QTreeWidgetItem * parent, VConditionLogicalOperator * cLO)
{
    QTreeWidgetItem * item = new QTreeWidgetItem(parent);
    item->setExpanded(true);
    item->setFlags(item->flags() | Qt::ItemIsEditable);
    item->setText(0, cLO->getType());
    item->setFont(0, *blackFont);
    item->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(NULL, cLO));
    setItemBackgroundColor(item, 1);
    foreach(VConditionLogicalOperator * child, cLO->getChilds())
    {
        addCLOItem(item, child);
    }

    foreach(VStatement * statement, cLO->getStatements())
    {
        addStatementItem(item, statement, NULL, cLO);
    }
    return item;
}

/**
 * @brief addStatementItem
 * Retourne un item d'arbre correspondant à un statement
 * @param parent L'item parent
 * @param statement Le statemnt
 * @param cLOId L'id du clo
 * @param parentCLOId L'id du clo parent sinon null
 * @return Un item d'arbre correspondant à un statement
 */
QTreeWidgetItem * VConditionTabWidget::addStatementItem(QTreeWidgetItem * parent, VStatement * statement, VCondition * condition, VConditionLogicalOperator * cLO)
{
    QTreeWidgetItem * statementItem = new QTreeWidgetItem(parent);
    statementItem->setExpanded(true);
    statementItem->setFlags(statementItem->flags() | Qt::ItemIsEditable);
    statementItem->setText(0, "statement");
    statementItem->setFont(0, *blackFont);
    statementItem->setToolTip(1, "Type");
    QComboBox * typeComboBox = new VStatementTypeComboBox(statement);
    ui->treeWidget->setItemWidget(statementItem, 1, typeComboBox);

    statementItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(condition, cLO, statement));
    setItemBackgroundColor(statementItem, 2);
    parent->addChild(statementItem);

    foreach(VNotTriples * notTriples, statement->getNotTriples())
    {
        QTreeWidgetItem * notTripleItem = new QTreeWidgetItem(statementItem);
        notTripleItem->setText(0, "NOT");
        notTripleItem->setFont(0, *blackFont);
        notTripleItem->setExpanded(true);
        notTripleItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, notTriples));
        setItemBackgroundColor(notTripleItem, 1);
        statementItem->addChild(notTripleItem);

        foreach(VTriple * triple, notTriples->getTriples())
        {
            addTripleItem(notTripleItem, triple, statement, notTriples);
        }
    }

    foreach(VTriple * triple, statement->getTriples())
    {
        addTripleItem(statementItem, triple, statement);
    }

    foreach(VMacro * macro, statement->getMacros())
    {
        QTreeWidgetItem * macroItem = new QTreeWidgetItem(statementItem);
        macroItem->setExpanded(true);
        macroItem->setFlags(macroItem->flags() | Qt::ItemIsEditable);
        macroItem->setText(0, "macro");
        macroItem->setFont(0, *blackFont);
        macroItem->setText(1, VActivityMacroTypeToString(macro->getOperator())); macroItem->setToolTip(1, "Operator");
        macroItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, NULL, NULL, macro));
        setItemBackgroundColor(macroItem, 2);
        statementItem->addChild(macroItem);

        foreach(VVar * var, macro->getVars())
        {
            QTreeWidgetItem * varItem = new QTreeWidgetItem(macroItem);
            varItem->setFlags(varItem->flags() | Qt::ItemIsEditable);
            varItem->setText(0, "var");
            varItem->setFont(0, *blackFont);
            varItem->setText(1, var->getN()); varItem->setToolTip(1, "n");
            varItem->setText(2, var->getId()); varItem->setToolTip(2, "id");
            varItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, NULL, NULL, macro, var));
            setItemBackgroundColor(varItem, 3);
            macroItem->addChild(varItem);
        }
    }
    return statementItem;
}

/**
 * @brief addTripleItem
 * Retourne et ajoute un item d'arbre correspondant à un triple
 * @param parent L'item parent
 * @param triple
 * @param statement
 * @param notTriples
 * @return Un item d'arbre correspondant à un triple
 */
QTreeWidgetItem * VConditionTabWidget::addTripleItem(QTreeWidgetItem *parent, VTriple * triple, VStatement * statement, VNotTriples * notTriples)
{
    QTreeWidgetItem * tripleItem = new QTreeWidgetItem(parent);
    tripleItem->setFlags(tripleItem->flags() | Qt::ItemIsEditable);
    tripleItem->setText(0, "triple");
    tripleItem->setFont(0, *blackFont);
    tripleItem->setToolTip(1, "Subject");
    tripleItem->setToolTip(2, "Predicate");
    tripleItem->setToolTip(3, "Object");

    QComboBox * subjectComboBox = new VTripleSubjectWidget(statement, triple);
    ui->treeWidget->setItemWidget(tripleItem, 1, subjectComboBox);

    if(statement->getType() == domain)
    {
        QComboBox * predicateComboBox = new VTriplePredicateComboBox(statement, triple);
        ui->treeWidget->setItemWidget(tripleItem, 2, predicateComboBox);

        QComboBox * objectComboBox = new VTripleObjectWidget(statement, triple);
        ui->treeWidget->setItemWidget(tripleItem, 3, objectComboBox);
    }
    else if(statement->getType() == activity)
    {
        tripleItem->setText(2, triple->getPredicate());

        QCheckBox * objectCheckBox = new VTripleObjectCheckBox(statement, triple);
        ui->treeWidget->setItemWidget(tripleItem, 3, objectCheckBox);
    }

    tripleItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, notTriples, triple));
    setItemBackgroundColor(tripleItem, 4);
    parent->addChild(tripleItem);
    return tripleItem;
}

/**
 * @brief setItemBackgroundColor
 * Définie le backgroundcolor de l'item de begin au nombre de colonne
 * @param item L'item à mettre à jour
 * @param beginIndex L'index de début
 */
void VConditionTabWidget::setItemBackgroundColor(QTreeWidgetItem * item, int beginIndex)
{
    for(int i = beginIndex; i < 7; i++)
    {
        item->setBackgroundColor(i, QColor(230, 230, 230));
    }
}

/**
 * @brief on_addButton_clicked
 * Gère le click sur le bouton pour ajouter un tag
 */
void VConditionTabWidget::on_addButton_clicked()
{
    if(ui->treeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedQTreeWidgetItem = ui->treeWidget->selectedItems().first();
        VTreeWidgetItemData * selectedItem = selectedQTreeWidgetItem->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

        if(selectedItem == NULL) return;

        // Déclaration :
        VCondition * condition = selectedItem->getCondition();
        VConditionLogicalOperator * cLO = selectedItem->getCLO();
        VStatement * statement = selectedItem->getStatement();
        VNotTriples * notTriples = selectedItem->getNotTriples();
        VTriple * triple = selectedItem->getTriple();
        VMacro * macro = selectedItem->getMacro();
        VVar * var = selectedItem->getVar();

        // Traitement des ajouts:
        if(macro != NULL)
        {
            var = new VVar(macro);
            macro->addVar(var);
        }
        else if(triple != NULL)
        {
            if(notTriples == NULL)
            {
                triple = new VTriple(statement);
                statement->addTriple(triple);
            }
            else
            {
                triple = new VTriple(notTriples);
                notTriples->addTriple(triple);
            }
        }
        else if(notTriples != NULL)
        {
            triple = new VTriple(notTriples);
            notTriples->addTriple(triple);
        }
        else if(statement != NULL)
        {
            // Demander soit nottriples soit triple soit macro -> IHM de demande à l'utilisateur
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a triple or a macro or a NOT ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "triple")
                {
                    triple = new VTriple(statement);
                    statement->addTriple(triple);
                }
                else if(choice.toLower() == "not")
                {
                    notTriples = new VNotTriples(statement);
                    triple = new VTriple(notTriples);
                    notTriples->addTriple(triple);
                    statement->addNotTriples(notTriples);
                }
                else if(choice.toLower() == "macro")
                {
                    macro = new VMacro(statement);
                    statement->addMacro(macro);
                }
            }
        }
        else if(cLO != NULL)
        {
            // Demander soit statement soit CLO -> IHM de demande à l'utilisateur
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a statement or a logical operator (AND, NOT, OR, XOR) ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "statement")
                {
                    statement = new VStatement(cLO);
                    cLO->addStatement(statement);
                }
                else if(choice.toLower() == "and" || choice.toLower() == "not" || choice.toLower() == "xor" || choice.toLower() == "or")
                {
                    VConditionLogicalOperator * newCLO = new VConditionLogicalOperator((QObject *)cLO);
                    newCLO->setType(choice.toUpper());
                    cLO->addChild(newCLO);
                }
            }
        }
        else if(condition != NULL)
        {
            // Demander soit statement soit CLO -> IHM de demande à l'utilisateur
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a statement or a logical operator (AND, NOT, OR, XOR) ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "statement")
                {
                    statement = new VStatement(condition);
                    condition->addStatement(statement);
                }
                else if(choice.toLower() == "and" || choice.toLower() == "not" || choice.toLower() == "xor" || choice.toLower() == "or")
                {
                    VConditionLogicalOperator * newCLO = new VConditionLogicalOperator((QObject *)cLO);
                    newCLO->setType(choice.toUpper());
                    condition->addCLO(newCLO);
                }
            }
        }

    }
    else
    {
        VCondition * condition = new VCondition(_conditions);
        _conditions->addCondition(condition);
    }
}

/**
 * @brief on_treeWidget_itemChanged
 * Gère les modifications des items
 * @param item L'item modifié
 * @param column La colonne concernée
 */
void VConditionTabWidget::on_treeWidget_itemChanged(QTreeWidgetItem *item, int column)
{
    if(_edit) return;
    VTreeWidgetItemData * selectedItem = item->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

    if(selectedItem == NULL) return;

    // Déclaration :
    VCondition * condition = selectedItem->getCondition();
    VStatement * statement = selectedItem->getStatement();
    VTriple * triple = selectedItem->getTriple();
    VMacro * macro = selectedItem->getMacro();
    VVar * var = selectedItem->getVar();

    // Traitement des modifications:
    if(var != NULL)
    {
        if(column == 1)
        {
            var->setN(item->text(column));
            return;
        }
        else if(column == 2)
        {
            var->setId(item->text(column));
            return;
        }
    }
    else if(macro != NULL)
    {
        if(column == 1)
        {
            macro->setOperator(item->text(column));
        }
    }
    else if(triple != NULL)
    {
        if(column == 1)
        {
            triple->setSubject(item->text(column));
        }
        else if(column == 2)
        {
            triple->setPredicate(item->text(column));
        }
        else if(column == 3)
        {
            triple->setObject(item->text(column));
        }
    }
    else if(statement != NULL)
    {
        if(column == 1)
        {
            statement->setType(item->text(column));
        }
    }
    else if(condition != NULL)
    {
        if(column == 1)
        {
            condition->setId(item->text(column));
        }
    }
    updateDisplay();
}

/**
 * @brief on_removeButton_clicked
 * Gère le click sur le bouton pour supprimer un tag
 */
void VConditionTabWidget::on_removeButton_clicked()
{
    if(ui->treeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedQTreeWidgetItem = ui->treeWidget->selectedItems().first();
        VTreeWidgetItemData * selectedItem = selectedQTreeWidgetItem->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

        if(selectedItem == NULL) return;

        // Déclaration :
        VCondition * condition = selectedItem->getCondition();
        VConditionLogicalOperator * cLO = selectedItem->getCLO();
        VStatement * statement = selectedItem->getStatement();
        VNotTriples * notTriples = selectedItem->getNotTriples();
        VTriple * triple = selectedItem->getTriple();
        VMacro * macro = selectedItem->getMacro();
        VVar * var = selectedItem->getVar();

        // Traitement des suppressions:
        if(var != NULL)
        {
            macro->removeVar(var);
            delete var;
        }
        else if(macro != NULL)
        {
            statement->removeMacro(macro);
            delete macro;
        }
        else if(triple != NULL)
        {
            if(notTriples != NULL)
            {
                notTriples->removeTriple(triple);
            }
            else if(statement != NULL)
            {
                statement->removeTriple(triple);
            }
            delete triple;
        }
        else if(notTriples != NULL)
        {
            statement->removeNotTriples(notTriples);
            delete notTriples;
        }
        else if(statement != NULL)
        {
            if(cLO != NULL)
            {
                cLO->removeStatement(statement);
                delete statement;
            }
            else if(condition != NULL)
            {
                condition->removeStatement(statement);
                delete statement;
            }
        }
        else if(cLO != NULL)
        {
            condition->removeCLO(cLO);
            delete cLO;
        }
        else if(condition != NULL)
        {
            _conditions->removeCondition(condition);
            delete condition;
        }
    }
}

void VConditionTabWidget::on_logicalOperatorComboBox_currentIndexChanged(int index)
{
    _conditions->setLogicalOperator(ui->logicalOperatorComboBox->itemText(index));
}
