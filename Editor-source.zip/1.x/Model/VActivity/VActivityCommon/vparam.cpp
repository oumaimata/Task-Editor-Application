#include "vparam.h"

VParam::VParam(QObject *parent) :
    VActivityModelElement(parent),
    _value(""),
    _predicate("")
{
}

VParam::VParam(const VParam& param, QObject *parent) :
    VActivityModelElement(parent)
{
    _value = param._value;
    _predicate = param._predicate;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VParam::parseDom(QDomElement elem)
{
    setValue(elem.attribute("value",""));
    setPredicate(elem.attribute("predicate",""));
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VParam::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<param";
    RetVal += " value=\"" + _value + "\"";
    RetVal += " predicate=\"" + _predicate + "\"";
    RetVal += " />\n";
    return RetVal;
}

void VParam::setValue(QString value)
{
    if(_value != value)
    {
        _value = value;
        onModified(tr("Value changed"));
    }
}

QString VParam::getValue() const
{
    return _value;
}

void VParam::setPredicate(QString predicate)
{
    if(_predicate != predicate)
    {
        _predicate = predicate;
        onModified(tr("Predicate changed"));
    }
}

QString VParam::getPredicate() const
{
    return _predicate;
}

/**
 * @brief clone
 * @return Le clone
 */
VParam * VParam::clone(QObject *parent) const
{
    return new VParam(*this, parent);
}
