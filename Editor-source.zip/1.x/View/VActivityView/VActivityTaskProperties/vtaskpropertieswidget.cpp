#include "vtaskpropertieswidget.h"
#include "ui_vtaskpropertieswidget.h"


#include "Model/VActivity/vtask.h"
#include "Model/VActivity/vactivitymodel.h"
#include "Controller/vtracecontroller.h"

/*!
 * \brief VTaskPropertiesWidget::VTaskPropertiesWidget
 * Constructeur
 * \param parent L'objet parent
 */
VTaskPropertiesWidget::VTaskPropertiesWidget(QWidget* parent) :
    QTabWidget(parent),
    ui(new Ui::VTaskPropertiesWidget),
    _task(NULL),
    _activityModel(NULL)
{
    VTraceController::get()->Debug("VTaskPropertiesWidget::VTaskPropertiesWidget()", "Begin");
    ui->setupUi(this);
    update();
    VTraceController::get()->Debug("VTaskPropertiesWidget::VTaskPropertiesWidget()", "End");
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VTaskPropertiesWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/*!
 * \brief VTaskPropertiesWidget::setTask
 * Définie Task et se connect au signal taskModified
 * \param task La nouvelle valeur pour Task
 */
void VTaskPropertiesWidget::setTask(VTask* task)
{
    VTraceController::get()->Debug("VTaskPropertiesWidget::setTask()", "Begin");
    if (task != _task)
    {
        if (_task != NULL)
        {
            disconnect(_task, NULL, this, NULL);
            VTraceController::get()->Info("VTaskPropertiesWidget::setTask()", "task disconnected");
        }

        _task = task;

        if (_task != NULL)
        {
            connect(_task, SIGNAL(modified(QString, QObject*)), this, SLOT(update(QString, QObject*)));
            VTraceController::get()->Info("VTaskPropertiesWidget::setTask()", "task connected");
        }

        update();
    }
    VTraceController::get()->Debug("VTaskPropertiesWidget::setTask()", "End");
}

/**
 * @brief setActivityModel
 * Définit le modèle d'activité en cours
 * @param activityModel Le modèle d'activité en cours
 */
void VTaskPropertiesWidget::setActivityModel(VActivityModel * activityModel)
{
    _activityModel = activityModel;
    update();
}

/*!
 * \brief VTaskPropertiesWidget::update
 * Met a jour les onglets action et objects
 */
void VTaskPropertiesWidget::update()
{
    update(NULL);
}

/*!
 * \brief VTaskPropertiesWidget::update
 * Met a jour les onglets action et objects
 */
void VTaskPropertiesWidget::update(QString, QObject*)
{
    VTraceController::get()->Debug("VTaskPropertiesWidget::update()", "Begin");

        if(_task != NULL)
        {
            this->setTabEnabled(2, _task->getConstructor() != NULL);
            this->setTabEnabled(3, _task->getOperation() != NULL);
        }
        else
        {
            this->setTabEnabled(2, true);
            this->setTabEnabled(3, true);
        }

    VTraceController::get()->Info("VTaskPropertiesWidget::update()", "setTask on subPages");
    ui->taskPage->setTask(_task);
    ui->contextPage->setTask(_task);
    ui->constructorPage->setTask(_task);
    ui->operationPage->setTask(_task);
    ui->preconditionsPage->setTask(_task);
    ui->satisfactionsPage->setTask(_task);
    ui->satisfactionsPage->setConditions(_task == NULL ? NULL : _task->getSatisfactionConditions());
    ui->stopConditionsPage->setTask(_task);
    ui->stopConditionsPage->setStopConditions(_task == NULL ? NULL : _task->getStopConditions());
    ui->refTagsPage->setTask(_task);

    VTraceController::get()->Info("VTaskPropertiesWidget::update()", "setActivityModel on subPages");
    ui->refTagsPage->setActivityModel(_activityModel);

    VTraceController::get()->Debug("VTaskPropertiesWidget::update()", "End");
}
