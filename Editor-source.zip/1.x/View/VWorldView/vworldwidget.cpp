#include "vworldwidget.h"
#include "ui_vworldwidget.h"

#include "Controller/vtracecontroller.h"
#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldInstance/vwinstance.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"
#include "Model/VWorld/VWorldClass/vwactionclass.h"
#include "Model/VWorld/VWorldClass/vwbehaviourclass.h"
#include "Model/VWorld/VWorldClass/vweventclass.h"

VWorldWidget::VWorldWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWorldWidget),
    _currentEdit(NULL)
{
    ui->setupUi(this);
    ui->xmlTextEdit->setTabStopWidth(10);
    // Connecting signals from the activity model.
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();

    connect(worldModel, SIGNAL(modified(QString, QObject *)), this, SLOT(onModelModified(QString, QObject *)));

    // Connect signal form componentNavigatorWidget
    connect(ui->componentNavigatorWidget, SIGNAL(editComponentAsked(VWComponentClass *)),
            this, SLOT(onEditComponentAsked(VWComponentClass *)));

    connect(ui->componentNavigatorWidget, SIGNAL(removeAsked(VWorldModelElement *)),
            this, SLOT(onRemoveAsked(VWorldModelElement *)));

    // Connect signal form worldNavigatorWidget
    connect(ui->worldNavigatorWidget, SIGNAL(editActionAsked(VWActionClass *)),
            this, SLOT(onEditActionAsked(VWActionClass *)));
    connect(ui->worldNavigatorWidget, SIGNAL(editBehaviourAsked(VWBehaviourClass *)),
            this, SLOT(onEditBehaviourAsked(VWBehaviourClass *)));
    connect(ui->worldNavigatorWidget, SIGNAL(editEventAsked(VWEventClass *)),
            this, SLOT(onEditEventAsked(VWEventClass *)));
    connect(ui->worldNavigatorWidget, SIGNAL(editObjectAsked(VWObjectClass *)),
            this, SLOT(onEditObjectAsked(VWObjectClass *)));

    connect(ui->worldNavigatorWidget, SIGNAL(removeAsked(VWorldModelElement *)),
            this, SLOT(onRemoveAsked(VWorldModelElement *)));

    // Connect signal form instanceTabWidget
    connect(ui->instanceTabWidget, SIGNAL(editInstanceAsked(VWInstance *)),
            this, SLOT(onEditInstanceAsked(VWInstance *)));

    ui->worldNavigatorWidget->setWorldModel(worldModel);
    ui->componentNavigatorWidget->setWorldModel(worldModel);
    ui->namespaceTabWidget->setWorldModel(worldModel);
}

VWorldWidget::~VWorldWidget()
{
    delete ui;
}

/*!
 * \brief VWorldWidget::setTextViewVisible
 * Définie l'attribut Visible de textView à enabled
 * \param enabled si activé
 */
void VWorldWidget::setXmlViewVisible()
{
    // Afficher la vue XML
    ui->tabWidget->setCurrentWidget(ui->xmlTabWidget);
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWorldWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWorldWidget::onModelModified()
{
    onModelModified(NULL);
}

void VWorldWidget::onModelModified(QString message, QObject * object)
{
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    ui->xmlTextEdit->setPlainText(worldModel->ToXml());
    ui->worldEditorWidget->updateDisplay(NULL);
    ui->namespaceTabWidget->updateDisplay();
    setCurrentEdit(_currentEdit);
}

void VWorldWidget::setCurrentEdit(QPointer<VWorldModelElement> currentEdit)
{
    _currentEdit = currentEdit;
    ui->worldNavigatorWidget->setCurrentEdit(_currentEdit);
    ui->componentNavigatorWidget->setCurrentEdit(_currentEdit);
    ui->instanceTabWidget->setCurrentEdit(_currentEdit);
    ui->worldEditorWidget->setCurrentEdit(_currentEdit);
}

void VWorldWidget::onEditActionAsked(VWActionClass * actionClass)
{
    ui->worldEditorWidget->editActionClass(actionClass);
    setCurrentEdit(actionClass);
}

void VWorldWidget::onEditBehaviourAsked(VWBehaviourClass * behaviourClass)
{
    ui->worldEditorWidget->editBehaviourClass(behaviourClass);
    setCurrentEdit(behaviourClass);
}

void VWorldWidget::onEditComponentAsked(VWComponentClass * componentClass)
{
    ui->worldEditorWidget->editComponentClass(componentClass);
    setCurrentEdit(componentClass);
}

void VWorldWidget::onEditEventAsked(VWEventClass * eventClass)
{
    ui->worldEditorWidget->editEventClass(eventClass);
    setCurrentEdit(eventClass);
}

void VWorldWidget::onEditObjectAsked(VWObjectClass * objectClass)
{
    ui->worldEditorWidget->editObjectClass(objectClass);
    ui->instanceTabWidget->setObjectClass(objectClass);
    setCurrentEdit(objectClass);
}

void VWorldWidget::onEditInstanceAsked(VWInstance * instance)
{
    ui->worldEditorWidget->editInstance(instance);
    setCurrentEdit(instance);
}

void VWorldWidget::onRemoveAsked(VWorldModelElement * element)
{
    if(_currentEdit == NULL)
    {
         setCurrentEdit(NULL);
        return;
    }
    if(element == _currentEdit) setCurrentEdit(NULL);
    else if(element == NULL)
    {
        setCurrentEdit(_currentEdit);
    }
    else
    {
        VWComponentClass * component = qobject_cast<VWComponentClass *>(element);
        if(component != NULL)
        {
            // Vérification que l'on ne supprime pas le père de l'élément en cours d'édition
            // Si l'élément cours d'édition est le fils du coup on sort du mode d'édition
            VWComponentClass * currentComponent = component->getChildByUid(_currentEdit->getUid());
            if(currentComponent != NULL) setCurrentEdit(NULL);
            return;
        }
        VWObjectClass * object = qobject_cast<VWObjectClass *>(element);
        if(object != NULL)
        {
            // Vérification que l'on ne supprime pas le père de l'élément en cours d'édition
            // Si l'élément cours d'édition est le fils du coup on sort du mode d'édition
            VWObjectClass * currentObject = object->getChildByUid(_currentEdit->getUid());
            if(currentObject != NULL) setCurrentEdit(NULL);
            return;
        }
    }
}
