#include "vgeneraltabwidget.h"
#include "ui_vgeneraltabwidget.h"

#include "Model/VActivity/vprefix.h"
#include "Model/VActivity/vactivitymodel.h"

/**
 * @brief VGeneralTabWidget
 * Constructeur
 * @param parent L'objet parent
 */
VGeneralTabWidget::VGeneralTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VGeneralTabWidget),
    _activityModel(NULL)
{
    ui->setupUi(this);
}

/**
 * @brief ~VGeneralTabWidget
 * Destructeur
 */
VGeneralTabWidget::~VGeneralTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VGeneralTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setActivityModel
 * Définit le modèle d'activité en cours
 * @param activityModel Le modèle d'activité en cours
 */
void VGeneralTabWidget::setActivityModel(VActivityModel * activityModel)
{
    if(activityModel != _activityModel)
    {
        _activityModel = activityModel;
    }
    updateDisplay();
}

/**
 * @brief updateDisplay
 * Met à jour l'affichage
 */
void VGeneralTabWidget::updateDisplay()
{
    // Met à jour la version
    ui->versionLineEdit->setText(_activityModel->getVersion());

    // Met à jour la table de namespaces
    int countRow = ui->namespacesWidget->rowCount();
    for(int i = 0; i < countRow; i++)
    {
        ui->namespacesWidget->removeRow(0);
    }
    QList<VPrefix *> namespaces = _activityModel->getNamespaces();
    for(int i = 0; i < namespaces.count(); i++)
    {
        ui->namespacesWidget->insertRow(0);

        VPrefix * prefix = namespaces[i];

        QTableWidgetItem* itemName = new QTableWidgetItem();
        itemName->setText(prefix->getName());
        itemName->setData(Qt::UserRole, prefix->getName());
        ui->namespacesWidget->setItem(0, 0, itemName);

        QTableWidgetItem* itemIri = new QTableWidgetItem();
        itemIri->setText(prefix->getIri());
        itemIri->setData(Qt::UserRole, prefix->getName());
        ui->namespacesWidget->setItem(0, 1, itemIri);
    }
}

/**
 * @brief VGeneralTabWidget::on_versionLineEdit_editingFinished
 * Gère la fin de l'édition de la version en mettant à jour le modèle
 */
void VGeneralTabWidget::on_versionLineEdit_editingFinished()
{
    _activityModel->setVersion(ui->versionLineEdit->text());
}

/**
 * @brief on_addButton_clicked
 * Gère le click sur le bouton ajouté
 * -> ajoute un nouveau prefix au modèle
 */
void VGeneralTabWidget::on_addButton_clicked()
{
    VPrefix * prefix = new VPrefix(_activityModel);
    _activityModel->addNamespace(prefix);
}

/**
 * @brief on_removeButton_clicked
 * Gère le click sur le bouton supprimer
 * -> retire le préfix sélectionné du modèle
 */
void VGeneralTabWidget::on_removeButton_clicked()
{
    QList<QTableWidgetItem *> selectedItems = ui->namespacesWidget->selectedItems();
    if(selectedItems.count() == 2)
    {
        QString var = selectedItems.first()->data(Qt::UserRole).toString();
        VPrefix * prefix = _activityModel->getNamespace(var);
        if(prefix != NULL)
        {
            _activityModel->removeNamespace(prefix);
            delete prefix;
        }
    }
}

/**
 * @brief VGeneralTabWidget::on_namespacesWidget_cellChanged
 * Gère l'édition des cellules
 * @param row La ligne de la cellule modifiée
 * @param column La colonne de la cellule modifiée
 */
void VGeneralTabWidget::on_namespacesWidget_cellChanged(int row, int column)
{
    QTableWidgetItem * item = ui->namespacesWidget->item(row, column);
    if(item != NULL)
    {
        QString var = item->data(Qt::UserRole).toString();
        VPrefix * prefix = _activityModel->getNamespace(var);
        if(prefix == NULL) return;
        if(column == 0 && prefix->getName() != item->text())
        {
            // Vérification de l'unicitée
            if(_activityModel->getNamespace(item->text()) == NULL)
            {
                prefix->setName(item->text());
            }
            else
            {
                item->setText(prefix->getName());
            }

        }
        else if(column == 1)
        {
            prefix->setIri(item->text());
        }
    }
}
