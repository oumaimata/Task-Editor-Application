#ifndef VADDRESSEE_H
#define VADDRESSEE_H
#include "../../VActivityCommon/vactivitymodelelement.h"
#include "../../VActivityCondition/vstatement.h"
#include "../../../VWorld/VWorldInstance/vwinstance.h"
#include "../../../../Controller/vtracecontroller.h"

class VAddressee : public VActivityModelElement
{
    Q_OBJECT
public:
    VAddressee();
    VAddressee(const VAddressee& addressee, QObject* parent = 0);
    ~VAddressee();
    void addAgent(VWInstance* agent);
    void replaceAgent(int index, VWInstance* agent);
    void removeAgent(VWInstance * agent);
    void addStatement(VStatement* statement);
    void removeStatement(VStatement * statement);

    QList<VWInstance *> getAgents() const;
    void setAgents(const QList<VWInstance *> &agents);

    QList<VStatement *> getStatements() const;
    void setStatements(const QList<VStatement *> &statements);

    VAddressee* clone()const;

    QString ToXml(QString tabulation = "");
    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

private:

    QList<VWInstance *> _agents;
    QList<VStatement *> _statements;

};

#endif // VADDRESSEE_H
