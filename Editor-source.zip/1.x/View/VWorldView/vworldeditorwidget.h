#pragma once
#ifndef VWORLDEDITORWIDGET_H
#define VWORLDEDITORWIDGET_H

#include <QWidget>

#include "Model/VWorld/vworldmodelelement.h"

class VWActionClassEditorWidget;
class VWBehaviourClassEditorWidget;
class VWComponentClassEditorWidget;
class VWEventClassEditorWidget;
class VWObjectClassEditorWidget;
class VWInstanceEditorWidget;

class VWActionClass;
class VWBehaviourClass;
class VWComponentClass;
class VWEventClass;
class VWObjectClass;
class VWInstance;

namespace Ui {
class VWorldEditorWidget;
}

/**
 * @brief The VWorldEditorWidget class
 * Redispatch vers les editeurs correspondants à l'élément en cours d'édition
 */
class VWorldEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWorldEditorWidget *ui;

    VWActionClassEditorWidget * actionClassEditorWidget;
    VWBehaviourClassEditorWidget * behaviourClassEditorWidget;
    VWComponentClassEditorWidget * componentClassEditorWidget;
    VWEventClassEditorWidget * eventClassEditorWidget;
    VWObjectClassEditorWidget * objectClassEditorWidget;
    VWInstanceEditorWidget * instanceEditorWidget;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    explicit VWorldEditorWidget(QWidget *parent = 0);
    ~VWorldEditorWidget();

    void setCurrentEdit(QPointer<VWorldModelElement> currentEdit);

    void editActionClass(VWActionClass * actionClass);
    void editBehaviourClass(VWBehaviourClass * behaviourClass);
    void editComponentClass(VWComponentClass * componentClass);
    void editEventClass(VWEventClass * eventClass);
    void editObjectClass(VWObjectClass * objectClass);
    void editInstance(VWInstance * instance);

public slots:
    void updateDisplay(QWidget * widget = NULL);

    void onInstanceRemoved();
};

#endif // VWORLDEDITORWIDGET_H
