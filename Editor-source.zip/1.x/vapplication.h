#pragma once
#ifndef VAPPLICATION_H
#define VAPPLICATION_H

#include <QtWidgets/QApplication>
#include <Model/vsettings.h>

class VMainWindow;
class VApplicationController;
class VTraceController;
class VActivityController;
class VWorldController;

/*!
 * \brief The VApplication class
 * L'application
 */
class VApplication : public QApplication
{
    Q_OBJECT

private:
    VMainWindow* _mainWindow;
    VApplicationController* _appCtrler;
    VTraceController* _traceCtrler;
    VActivityController* _activityCtrler;
    VWorldController* _worldCtrler;
public:

    /*!
     * \brief VApplication
     * Constructeur
     * \param argc Nombre d'arguments
     * \param argv Tableau contenant les différents arguments
     */
    VApplication(int argc, char* argv[]);

    /*!
     * \brief ~VApplication
     *Destructeur
     */
    ~VApplication();

    /*!
     * \brief exec
     * Lance l'exécution de l'application
     * \return Le résultat de l'exécution
     */
    virtual int exec();
};

#endif // VAPPLICATION_H
