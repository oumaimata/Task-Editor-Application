#include "vtripleobjectcheckbox.h"

#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivityCondition/vstatement.h"

VTripleObjectCheckBox::VTripleObjectCheckBox(VStatement * statement, VTriple * triple, QWidget *parent) :
    QCheckBox(parent),
    _triple(triple),
    _statement(statement)
{
    this->setChecked(_triple->getObject() == "true");
    connect(this, SIGNAL(toggled(bool)), this, SLOT(onToggled(bool)));
}

void VTripleObjectCheckBox::onToggled(bool value)
{
    _triple->setObject(value);
}
