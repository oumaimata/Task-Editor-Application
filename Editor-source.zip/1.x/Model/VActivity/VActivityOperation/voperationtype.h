#pragma once
#ifndef VOPERATIONTYPE
#define VOPERATIONTYPE


#include <QString>

/**
 * @brief VOperationType enum
 * Enumération des différents type d'Operations
 */
enum VOperationType
{
    ACTION,
    SPEECHACT,
    UNDEFINED_OPERATION_TYPE
};

static QString VOperationTypeToString(VOperationType type)
{
    if(type == ACTION)
        return "action";
    else if(type == SPEECHACT)
        return "speech_act";

   return "undefined_operation_type";
}

static VOperationType VOperationTypeFromString(QString type)
{
    type = type.toLower();

    QString actionString = VOperationTypeToString(ACTION);
    if(type == actionString)
        return ACTION;

    QString speechActString = VOperationTypeToString(SPEECHACT);
    if(type == speechActString)
        return SPEECHACT;

    return UNDEFINED_OPERATION_TYPE;
}




#endif // VOPERATIONTYPE

