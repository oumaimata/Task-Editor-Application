#pragma once
#ifndef VTASKTABWIDGET_H
#define VTASKTABWIDGET_H

#include <QWidget>

class VTask;

namespace Ui {
class VTaskTabWidget;
}

class VTaskTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VTaskTabWidget *ui;

    /**
     * @brief _editing
     * Si le widget est en cour d'édition
     */
    bool _editing;

    /**
     * @brief task
     * Tâche en cours d'édition
     */
    VTask * _task;
    
public:
    /**
     * @brief VTaskTabWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VTaskTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VTaskTabWidget
     * Destructeur
     */
    ~VTaskTabWidget();

    /**
     * @brief setTask
     * Définit la tâche en cours d'édition
     * @param task La tâche en cours d'édition
     */
    void setTask(VTask *task);

    /**
     * @brief getTask
     * Obitent la tâche en cours d'édition
     * @return La tâche en cours d'édition
     */
    VTask * getTask() const;

private:

    /**
     * @brief updateDisplay
     * Met a jour l'inteface
     * en fonction de la tache sélectionnée
     */
    void updateDisplay();
    
private slots:
    /**
     * @brief on_nameLineEdit_editingFinished
     * Gère la modification du nom
     */
    void on_nameLineEdit_editingFinished();

    /**
     * @brief on_iterativeCheckBox_stateChanged
     * Gère le changement d'état de iterativeCheckBox
     * @param arg1 L'état de la checkbox
     */
    void on_iterativeCheckBox_stateChanged(int arg1);

    /**
     * @brief on_optionalCheckBox_stateChanged
     * Gère le changement d'état de optionalCheckBox
     * @param arg1 L'état de la checkbox
     */
    void on_optionalCheckBox_stateChanged(int arg1);

    /**
     * @brief on_interruptibleCheckBox_stateChanged
     * Gère le changement d'état de interruptibleCheckBox
     * @param arg1 L'état de la checkbox
     */
    void on_interruptibleCheckBox_stateChanged(int arg1);

    /**
     * @brief on_freeTextEdit_editingFinished
     * Gère la modification du free text
     */
    void on_freeTextEdit_textChanged();
};

#endif // VTASKTABWIDGET_H
