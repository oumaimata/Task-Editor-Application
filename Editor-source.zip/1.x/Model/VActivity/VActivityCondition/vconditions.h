#pragma once
#ifndef VCONDITIONS_H
#define VCONDITIONS_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"

class VCondition;
class VBasisCondition;

class VConditions : public VActivityModelElement
{
    Q_OBJECT

private:
    QString _type;

    QString _logicalOperator;

    QList<VCondition *> _conditions;

public:
    explicit VConditions(QObject *parent = 0);

    VConditions(const VConditions& conditions, QObject *parent = 0);

    /**
     * @brief ~VConditions
     * Destructeur
     */
    ~VConditions();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setType(QString type);
    QString getType() const;

    void setLogicalOperator(QString logicalOperator);
    QString getLogicalOperator() const;

    void addCondition(VCondition * condition);
    void removeCondition(VCondition * condition);
    QList<VCondition *> getConditions() const;
    QList<VBasisCondition *> getBasisConditions() const;
    VCondition * getConditionByUid(qint64 uid) const;

    /**
     * @brief clone
     * @return Le clone
     */
    VConditions * clone(QObject *parent = 0) const;
};

#endif // VCONDITIONS_H
