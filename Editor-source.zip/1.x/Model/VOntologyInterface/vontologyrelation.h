#ifndef VONTOLOGYRELATION_H
#define VONTOLOGYRELATION_H

#include <QString>

class VOntologyConcept;

/*!
 \brief
 \deprecated
*/
class VOntologyRelation
{
private:
    QString _name;
    VOntologyConcept& _range;

public:
    /*!
     \brief

    */
    VOntologyRelation(QString name, VOntologyConcept& range);


    /*!
     \brief

    */
    const QString getName() const;


    /*!
     \brief

    */
    VOntologyConcept& getRange();


    /*!
     \brief

     \param concept
    */
    bool operator==(const VOntologyRelation& relation) const;


    /*!
     \brief

     \param concept
    */
    bool operator==(const QString relationName) const;
};

#endif // VONTOLOGYRELATION_H
