#include "vhistoryactivitywidget.h"
#include "ui_vhistoryactivitywidget.h"

#include "../Model/VHistory/vhistoryset.h"

VHistoryActivityWidget::VHistoryActivityWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VHistoryActivityWidget)
{
    ui->setupUi(this);
    retranslate();
}

VHistoryActivityWidget::~VHistoryActivityWidget()
{
    delete ui;
}

/**
 * @brief setHistorySet
 * Définit le VHistorySet utilisé pour l'historique
 * @param historySet L'historique
 */
void VHistoryActivityWidget::setHistorySet(VHistorySet* historySet)
{
    ui->historyBasicWidget->setHistorySet(historySet);
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VHistoryActivityWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief VHistoryWorldWidget::retranslate
 * Traduction des widgets avec tr() hors du designer
 */
void VHistoryActivityWidget::retranslate()
{
    ui->historyBasicWidget->setTitle(tr("Activity model history"));
}
