#include "vweventclasseditorwidget.h"
#include "ui_vweventclasseditorwidget.h"

#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vweventclass.h"
#include "Model/VWorld/VWorldClass/vwbehaviourclass.h"

VWEventClassEditorWidget::VWEventClassEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWEventClassEditorWidget),
    _edit(false),
    _eventClass(NULL)
{
    ui->setupUi(this);
    retranslate();
}

VWEventClassEditorWidget::~VWEventClassEditorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWEventClassEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWEventClassEditorWidget::retranslate()
{
    ui->propertiesEditorWidget->setLabelCol(0, tr("Parameter"));
    ui->propertiesEditorWidget->setLabelCol(1, tr("Type"));
}

void VWEventClassEditorWidget::setEventClass(VWEventClass * eventClass)
{
    if(eventClass != _eventClass)
    {
        _eventClass = eventClass;
    }
    updateDisplay();
}

void VWEventClassEditorWidget::updateDisplay()
{
    _edit = true;
    ui->nameLineEdit->setText("");
    ui->beginComboBox->clear();
    ui->endComboBox->clear();
    ui->behaviourComboBox->clear();
    while(ui->behaviourTableWidget->rowCount() > 0)
    {
        ui->behaviourTableWidget->removeRow(0);
    }
    if(_eventClass == NULL) return;
    // Récupétation du modèle
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();

    // Nom
    ui->nameLineEdit->setText(_eventClass->getName());

    // Begin/End ComboBox
    if(_eventClass->getIsDurative())
    {
        ui->beginComboBox->setEnabled(true);
        ui->endComboBox->setEnabled(true);
        if(_eventClass->getBeginingEvent() == NULL) ui->beginComboBox->addItem("");
        if(_eventClass->getEndingEvent() == NULL) ui->endComboBox->addItem("");
        VWEventClass * event;
        QList<VWEventClass *> events = worldModel->getEvents();
        foreach(event, events)
        {
            if(event->getIsPunctual())
            {
                // Ajoute les events qui sont ponctuel et différent de celui de fin
                if(event != _eventClass->getEndingEvent()) ui->beginComboBox->addItem(event->getName(), event->getUid());
                // Ajoute les events qui sont ponctuel et différent de celui de début
                if(event != _eventClass->getBeginingEvent()) ui->endComboBox->addItem(event->getName(), event->getUid());
            }
        }
        if(_eventClass->getBeginingEvent() != NULL) ui->beginComboBox->setCurrentText(_eventClass->getBeginingEvent()->getName());
        if(_eventClass->getEndingEvent() != NULL) ui->endComboBox->setCurrentText(_eventClass->getEndingEvent()->getName());
    }
    else
    {
        ui->beginComboBox->setEnabled(false);
        ui->endComboBox->setEnabled(false);
    }

    // RadioButton
    ui->durativeRadioButton->setChecked(_eventClass->getIsDurative());
    ui->punctualRadioButton->setChecked(_eventClass->getIsPunctual());
    ui->endogenousRadioButton->setChecked(_eventClass->getIsEndogenous());
    ui->exogenousRadioButton->setChecked(_eventClass->getIsExogenous());

    // Behaviours
    QPointer<VWBehaviourClass> qBehaviour;
    QList<QPointer<VWBehaviourClass> > qBehaviours = _eventClass->getBehaviours();
    foreach(qBehaviour, qBehaviours)
    {
        if(qBehaviour != NULL)
        {
            ui->behaviourTableWidget->insertRow(0);
            QTableWidgetItem* item = new QTableWidgetItem();
            item->setText(qBehaviour->getName());
            item->setData(Qt::UserRole, qBehaviour->getUid());
            ui->behaviourTableWidget->setItem(0, 0, item);
        }
    }
    ui->behaviourTableWidget->resizeColumnsToContents();

    // Behaviours disponibles pour l'ajout
    VWBehaviourClass * behaviour;
    QList<VWBehaviourClass *> behaviours = worldModel->getBehaviours();
    foreach(behaviour, behaviours)
    {
        if(!_eventClass->getBehaviours().contains(behaviour))
        {
            ui->behaviourComboBox->addItem(behaviour->getName(), behaviour->getUid());
        }
    }

    ui->propertiesEditorWidget->setProperties(_eventClass->getProperties());

    // Component
    ui->componentEditorWidget->setEntity(_eventClass);
    _edit = false;
}

void VWEventClassEditorWidget::on_nameLineEdit_editingFinished()
{
    if(_edit) return;
    _eventClass->setName(ui->nameLineEdit->text());
}

void VWEventClassEditorWidget::on_addBehaviourButton_clicked()
{
    QString uid = ui->behaviourComboBox->itemData(ui->behaviourComboBox->currentIndex()).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWBehaviourClass * behaviour = worldModel->getBehaviourByUid(uid.toLong());
    if(behaviour != NULL) _eventClass->addBehaviour(behaviour);
}

void VWEventClassEditorWidget::on_removeBehaviourButton_clicked()
{
    if(ui->behaviourTableWidget->selectedItems().count() == 0) return;
    QTableWidgetItem * item = ui->behaviourTableWidget->selectedItems().first();
    QString uid = item->data(Qt::UserRole).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWBehaviourClass * behaviour = worldModel->getBehaviourByUid(uid.toLong());
    if(behaviour != NULL) _eventClass->removeBehaviour(behaviour);
}

void VWEventClassEditorWidget::on_durativeRadioButton_toggled(bool checked)
{
    if(_edit) return;
    _eventClass->setIsDurative(checked);
}

void VWEventClassEditorWidget::on_punctualRadioButton_toggled(bool checked)
{
    if(_edit) return;
    _eventClass->setIsPunctual(checked);
}

void VWEventClassEditorWidget::on_exogenousRadioButton_toggled(bool checked)
{
    if(_edit) return;
    _eventClass->setIsExogenous(checked);
}

void VWEventClassEditorWidget::on_endogenousRadioButton_toggled(bool checked)
{
    if(_edit) return;
    _eventClass->setIsEndogenous(checked);
}

void VWEventClassEditorWidget::on_beginComboBox_currentIndexChanged(int index)
{
    if(_edit) return;
    QString uid = ui->beginComboBox->itemData(index).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWEventClass * event = worldModel->getEventByUid(uid.toLong());
    _eventClass->setBeginingEvent(event);
}

void VWEventClassEditorWidget::on_endComboBox_currentIndexChanged(int index)
{
    if(_edit) return;
    QString uid = ui->endComboBox->itemData(index).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWEventClass * event = worldModel->getEventByUid(uid.toLong());
    _eventClass->setEndingEvent(event);
}
