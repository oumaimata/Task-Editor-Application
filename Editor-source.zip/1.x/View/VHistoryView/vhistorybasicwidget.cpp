#include "vhistorybasicwidget.h"
#include "ui_vhistorybasicwidget.h"

#include "../Model/VHistory/vhistoryset.h"

VHistoryBasicWidget::VHistoryBasicWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VHistoryBasicWidget)
{
    ui->setupUi(this);

    // Création des colonnes
    ui->historyTable->setColumnCount(3);
    retranslate();
}

/**
 * @brief updateDisplay
 * Met a jour le tableau en fonction de historySet
 */
void VHistoryBasicWidget::updateDisplay()
{
    int RowCount = ui->historyTable->rowCount();
    for(int i = 0; i < RowCount; i++)
    {
        ui->historyTable->removeRow(0);
    }
    if(historySet == NULL) return;
    int historySetCount = historySet->size();
    for(int i = 0; i < historySetCount; i++)
    {
        ui->historyTable->insertRow(0);
    }
    for(int i = 0; i < historySetCount; i++)
    {
        VHistoryState historyState = historySet->at(historySetCount - i - 1);

        QTableWidgetItem* itemDate = new QTableWidgetItem();
        itemDate->setText(historyState.getTime().toString("dd/MM/yyyy hh:mm:ss"));
        ui->historyTable->setItem(i, 0, itemDate);

        QTableWidgetItem* itemLabel = new QTableWidgetItem();
        itemLabel->setText(historyState.getLabel());
        ui->historyTable->setItem(i, 1, itemLabel);

        QTableWidgetItem* itemDesc = new QTableWidgetItem();
        itemDesc->setText(historyState.getDesc());
        ui->historyTable->setItem(i, 2, itemDesc);
    }
    ui->historyTable->resizeColumnsToContents();
}

/**
 * @brief setTitle Définit le titre du widget
 * @param s Le titre
 */
void VHistoryBasicWidget::setTitle(const QString s)
{
    ui->titleLabel->setText(s);
}

/**
 * @brief setHistorySet
 * Définit le VHistorySet utilisé pour l'historique
 * @param historySet L'historique
 */
void VHistoryBasicWidget::setHistorySet(VHistorySet* historySet)
{
    this->historySet = historySet;
    connect(historySet, SIGNAL(hasChanged()), this, SLOT(updateDisplay()));
}

/**
 * @brief getTitle Obtient le titre du widget
 * @return Le titre
 */
QString VHistoryBasicWidget::getTitle()
{
    return ui->titleLabel->text();
}

VHistoryBasicWidget::~VHistoryBasicWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VHistoryBasicWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}


/**
 * @brief VTaskActionPickingDialog::retranslate
 * Traduction des widgets avec tr() hors du designer
 */
void VHistoryBasicWidget::retranslate()
{
    QStringList labels;
    labels << tr("Date") << tr("Label") << tr("Description");
    ui->historyTable->setHorizontalHeaderLabels(labels);
}
