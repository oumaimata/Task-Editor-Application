#pragma once
#ifndef VMODELPROPERTIESWIDGET_H
#define VMODELPROPERTIESWIDGET_H

#include <QTabWidget>

class VActivityModel;

namespace Ui {
class VModelPropertiesWidget;
}

/**
 * @brief The VModelPropertiesWidget class
 * Permet l'affichage de deux onglets:
 * - VGeneralTabWidget : permet l'édition de la version du model et des namespaces
 * - VTagTabWidget : permet l'édition des tags
 */
class VModelPropertiesWidget : public QTabWidget
{
    Q_OBJECT

private:
    Ui::VModelPropertiesWidget *ui;

    /**
     * @brief _activityModel
     * Le modèle d'activité en cours
     */
    VActivityModel * _activityModel;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    explicit VModelPropertiesWidget(QWidget *parent = 0);

    ~VModelPropertiesWidget();

    /**
     * @brief setActivityModel
     * Définit le modèle d'activité en cours
     * @param activityModel Le modèle d'activité en cours
     */
    void setActivityModel(VActivityModel * activityModel);
};

#endif // VMODELPROPERTIESWIDGET_H
