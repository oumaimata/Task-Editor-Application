#pragma once
#ifndef VWCOMPONENTCLASSEDITORWIDGET_H
#define VWCOMPONENTCLASSEDITORWIDGET_H

#include <QWidget>

class VWComponentClass;

namespace Ui {
class VWComponentClassEditorWidget;
}

class VWComponentClassEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWComponentClassEditorWidget *ui;

    bool _edit;

    VWComponentClass * _componentClass;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    void retranslate();
    
public:
    explicit VWComponentClassEditorWidget(QWidget *parent = 0);
    ~VWComponentClassEditorWidget();

    void setComponentClass(VWComponentClass * componentClass);
private slots:
    void updateDisplay();
    void on_nameLineEdit_editingFinished();
    void on_hasStateCheckBox_toggled(bool checked);
};

#endif // VWCOMPONENTCLASSEDITORWIDGET_H
