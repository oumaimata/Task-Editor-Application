#pragma once
#ifndef VSELECTQUERYRESULT_H
#define VSELECTQUERYRESULT_H

#include <QtXml>
#include <QStringList>
#include <QList>
#include <QMap>

class VSelectQueryResult
{
private:
     QDomDocument _document;

public:
    VSelectQueryResult(const QString& queryResult);

    QList<QMap<QString, QString> > getVariablesValues(const QStringList& variables = QStringList()) const;

    QStringList getVariableValue(const QString& variable) const;
};

#endif // VSELECTQUERYRESULT_H
