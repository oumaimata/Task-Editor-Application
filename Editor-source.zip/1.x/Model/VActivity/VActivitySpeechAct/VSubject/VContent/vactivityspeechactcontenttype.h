#ifndef VACTIVITYSPEECHACTCONTENTTYPE_H
#define VACTIVITYSPEECHACTCONTENTTYPE_H

#include <QString>

enum VSpeechActContentType {
    PLAIN_TEXT,
    STATEMENT,
    QUERY,
    UNDEFINED_SPEECH_ACT_TYPE
};

Q_DECLARE_METATYPE(VSpeechActContentType);

static QString VSpeechActContentTypeToString(VSpeechActContentType contentType){
    switch(contentType)
    {
        case PLAIN_TEXT: return "plain_text";
        case STATEMENT: return "statement";
        case QUERY: return "query";
        default: return "undefined_speech_act_type";
    }
}

static VSpeechActContentType VSpeechActContentTypeFromString(QString contentType){
    contentType = contentType.toLower();

    QString plainTextString = VSpeechActContentTypeToString(PLAIN_TEXT);
    if(contentType == plainTextString)
        return PLAIN_TEXT;

    QString statementString = VSpeechActContentTypeToString(STATEMENT);
    if(contentType == statementString)
        return STATEMENT;

    QString queryString = VSpeechActContentTypeToString(QUERY);
    if(contentType == queryString)
        return QUERY;

    return UNDEFINED_SPEECH_ACT_TYPE;
}

#endif // VACTIVITYSPEECHACTCONTENTTYPE_H
