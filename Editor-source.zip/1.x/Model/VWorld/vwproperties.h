#pragma once
#ifndef VWPROPERTIES_H
#define VWPROPERTIES_H

#include <QObject>
#include <QtXml>

class VWProperty;
class VWComponentClass;
class VWorldModelElement;

class VWProperties : public QObject
{
    Q_OBJECT
private:
    QString _type;

    bool _isShared;

    QPointer<VWorldModelElement> _worldModelElement;
    QPointer<VWComponentClass> _component;

    /**
     * @brief _properties
     * La liste des propriétées
     */
    QList<QPointer<VWProperty> > _properties;
protected:
    bool _edit;

public:
    explicit VWProperties(QObject *parent = 0);

    ~VWProperties();

    void setWorldModelElement(QPointer<VWorldModelElement> worldModelElement);
    void setComponent(QPointer<VWComponentClass> component);

    void clear();

    void setIsShared(bool isShared);
    bool getIsShared() const;

    void setType(QString type);
    QString getType() const;

    QPointer<VWProperty> addProperty(QDomElement elem);
    void addProperty(QPointer<VWProperty> property);
    void removeProperty(QPointer<VWProperty> property);
    void removeProperty(QString propertyName);
    QList<QPointer<VWProperty> > getProperties() const;
    QPointer<VWProperty> getPropertyByUid(qint64 uid) const;

protected slots:

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     */
    void onModified();

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     * @param object L'object qui a été modifié
     */
    void onModified(QString message, QObject * object = NULL);

signals:

    /**
     * @brief modified
     * Signal envoyé lors de modification sur un VWorldModelElement
     * @param object L'object qui a été modifié
     */
    void modified(QString message, QObject * object);
    
};

#endif // VWPROPERTIES_H
