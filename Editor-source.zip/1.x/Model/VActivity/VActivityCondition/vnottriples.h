#pragma once
#ifndef VNOTTRIPLES_H
#define VNOTTRIPLES_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"

class VTriple;

class VNotTriples : public VActivityModelElement
{
    Q_OBJECT

private:

    QList<VTriple *> _triples;

public:

    explicit VNotTriples(QObject *parent = 0);

    VNotTriples(const VNotTriples& notTriples, QObject *parent = 0);

    /**
     * @brief ~VNotTriples
     * Destructeur
     */
    ~VNotTriples();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "") const;

    void addTriple(VTriple * triple);
    void removeTriple(VTriple * triple);
    QList<VTriple *> getTriples() const;
    VTriple * getTripleById(qint64 uid) const;

    QString toString(QString tabulation = "") const;

    /**
     * @brief clone
     * @return Le clone
     */
    VNotTriples * clone(QObject *parent = 0) const;
};

#endif // VNOTTRIPLES_H
