#pragma once
#ifndef VMAINWINDOW_H
#define VMAINWINDOW_H

#include <QMainWindow>

class VActivityWidget;
class VWorldWidget;
class VHistoryActivityWidget;
class VHistoryWorldWidget;

namespace Ui {
class VMainWindow;
}

/*!
 * \brief The VMainWindow class
 *  Fernêtre principale du programme
 */
class VMainWindow : public QMainWindow
{
    Q_OBJECT

private:
    Ui::VMainWindow *ui;

public:
    /*!
     * \brief VMainWindow::VMainWindow
     * Constructeur
     * \param parent L'objet parent
     */
    explicit VMainWindow(QWidget* parent = NULL);

    /*!
     * \brief VMainWindow::getActivityWidget
     * Obtient le widget d'activité
     * \return Le widget d'activité
     */
    VActivityWidget* getActivityWidget();

    /*!
     * \brief VMainWindow::getWorldWidget
     * Obtient le widget du monde
     * \return Le widget du monde
     */
    VWorldWidget* getWorldWidget();

    /*!
     * \brief VMainWindow::getActivityHistoryWidget
     * Obtient le widget d'historique de l'activité
     * \return Le widget d'historique de l'activité
     */
    VHistoryActivityWidget* getHistoryActivityWidget();

    /*!
     * \brief VMainWindow::getHistoryWorldWidget
     * Obtient le widget d'historique du monde
     * \return Le widget d'historique du monde
     */
    VHistoryWorldWidget* getHistoryWorldWidget();

    /**
     * @brief VMainWindow::updateLanguageMenu
     * Freeze the item of the current language passed by lang
     * @param lang The current language
     */
    void updateLanguageMenu(QString lang);

    void switchToActivity();
    void switchToWorld();
    void switchToHistory();

private:
    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief changeEvent
     * Permet de quitter l'application
     */
    void closeEvent(QCloseEvent *event);

signals:
    /**
     * @brief newActivityModelAsked
     * Signal de demande de création d'un nouveau modèle d'activité
     */
    void newActivityModelAsked();
    /**
     * @brief activityModelImportAsked
     * Signal de demande d'import d'un modèle d'activité
     */
    void activityModelImportAsked(QString);
    /**
     * @brief activityModelSaveAsked
     * Signal de demande d'enregistrement d'un modèle d'activité
     */
    void activityModelSaveAsked();
    /**
     * @brief activityModelExportAsked
     * Signal de demande d'export d'un modèle d'activité
     */
    void activityModelExportAsked(QString);
    /**
     * @brief newWorldModelAsked
     * Signal de demande de création d'un nouveau modèle du monde
     */
    void newWorldModelAsked();
    /**
     * @brief worldModelImportAsked
     * Signal de demande d'import d'un modèle du monde
     */
    void worldModelImportAsked(QString);

    void worldModelSaveAsked();
    /**
     * @brief worldModelExportAsked
     * Signal de demande d'export d'un modèle du monde
    */
    void worldModelExportAsked();
    /**
     * @brief worldModelExportAsked
     * Signal de demande d'export d'un modèle du monde
     */
    void worldModelExportAsked(QString);

    /*!
     * \brief cutAsked
     * Signal de demande cut
     */
    void cutAsked();

    /*!
     * \brief copyAsked
     * Signal de demande copy
     */
    void copyAsked();

    /*!
     * \brief pasteAsked
     * Signal de demande paste
     */
    void pasteAsked();
    /*!
     * \brief quitAsked();
     * Signal de demande quitter le programme
     */
    void quitAsked();

    /*!
     * \brief frenchLanguageAsked
     * Signal de demande du passage au français
     */
    void frenchLanguageAsked();

    /*!
     * \brief englisLanguagehAsked
     * Signal de demande du passage a l'anglais
     */
    void englishLanguageAsked();

private slots:

    /*!
     * \brief VMainWindow::on_actionQuit_triggered
     * Gère la demande de fermeture via le menu
     */
    void on_actionQuit_triggered();

    /*!
     * \brief VMainWindow::on_actionDisplayActivityXml_triggered
     * \param checked Si coché
     *  Gère la demande d'affichage du TextView d'activityWidget
     */
    void on_actionDisplayActivityXml_triggered(bool checked);

    /*!
     * \brief VMainWindow::on_actionDisplayWorldXml_triggered
     * \param checked Si coché
     *  Gère la demande d'affichage du TextView de worldModel
     */
    void on_actionDisplayWorldXml_triggered();
    /*!
     * \brief on_actionNewActivityModel_triggered
     *  Gère la demande de création d'un nouveau modèle du d'activité
     */
    void on_actionNewActivityModel_triggered();
    /**
     * @brief on_actionImportActivityModel_triggered
     * Gère la demande d'import d'un modèle d'activité
     */
    void on_actionImportActivityModel_triggered();

    /**
     * @brief on_actionSaveActivityModel_triggered
     * Gère la demande d'enregistrement d'un modèle d'activité
     */
    void on_actionSaveActivityModel_triggered();

    /**
     * @brief on_actionExportActivityModel_triggered
     * Gère la demande d'export d'un modèle d'activité
     */
    void on_actionExportActivityModel_triggered();
    /**
     * @brief on_actionNewWorldModel_triggered
     * Gère la demande de création d'un nouveau modèle du monde
     */
    void on_actionNewWorldModel_triggered();
    /**
     * @brief on_actionImportWorldModel_triggered
     * Gère la demande d'import d'un modèle du monde
     */
    void on_actionImportWorldModel_triggered();
    /**
     * @brief on_actionSaveWorldModel_triggered
     * Gère la demande d'enregistrement d'un modèle du monde
     */
    void on_actionSaveWorldModel_triggered();
    /**
     * @brief on_actionExportWorldModel_triggered
     * Gère la demande d'export d'un modèle du monde
     */
    void on_actionExportWorldModel_triggered();

    /**
     * @brief on_actionUndo_triggered
     * Gère la demande annuler
     */
    void on_actionUndo_triggered();

    /**
     * @brief on_actionRedo_triggered
     * Gère la demande rétablir
     */
    void on_actionRedo_triggered();

    /**
     * @brief on_actionCut_triggered
     * Gère la demande Cut
     */
    void on_actionCut_triggered();

    /**
     * @brief on_actionCopy_triggered
     * Gère la demande Copy
     */
    void on_actionCopy_triggered();

    /**
     * @brief on_actionPaste_triggered
     * Gère la demande Paste
     */
    void on_actionPaste_triggered();

    /*!
     * \brief on_actionEnglish_triggered
     * Le bouton English du menu a été clické
     */
    void on_actionEnglish_triggered();

    /*!
     * \brief on_actionFrench_triggered
     * Le bouton French du menu a été clické
     */
    void on_actionFrench_triggered();

    /**
     * @brief on_tabWidget_currentChanged
     * Met à jour les raccourcis en fonction de la vue d'actuelle
     * @param index Index du groupe d'onglet
     */
    void on_tabWidget_currentChanged(int index);


    void on_menuActivityRecentImportedFiles_triggered(QAction * action);
    void on_menuWorldRecentImportedFiles_triggered(QAction * action);


public slots:
    void changeStatus(QString status);
    void updateActivityRecentImportedFiles(QList<QAction*> actions);
    void updateWorldRecentImportedFiles(QList<QAction*> actions);
    void updateState();
};

#endif // VMAINWINDOW_H
