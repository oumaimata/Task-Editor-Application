#include "vpreconditionstabwidget.h"
#include "ui_vpreconditionstabwidget.h"

#include "Model/VActivity/vtask.h"
#include "Model/VActivity/VActivityCondition/vconditions.h"
#include "Controller/vtracecontroller.h"

VPreconditionsTabWidget::VPreconditionsTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VPreconditionsTabWidget),
    _task(NULL),
    _favorableConditions(NULL),
    _regulatoryConditions(NULL),
    _nomologicalConditions(NULL),
    _contextualConditions(NULL)
{
    ui->setupUi(this);
}

VPreconditionsTabWidget::~VPreconditionsTabWidget()
{
    delete ui;
}

/**
 * @brief setTask
 * Définit la tâche en cours d'édition
 * @param task La tâche en cours d'édition
 */
void VPreconditionsTabWidget::setTask(VTask * task)
{
    if (task != _task)
    {
        VTraceController::get()->Info("VConstructorTabWidget::setTask()", "Task defined");
        _task = task;
        _favorableConditions = (_task == NULL) ? NULL : _task->getFavorableConditions();
        _regulatoryConditions = (_task == NULL) ? NULL : _task->getRegulatoryConditions();
        _nomologicalConditions = (_task == NULL) ? NULL : _task->getNomologicalConditions();
        _contextualConditions = (_task == NULL) ? NULL : _task->getContextualConditions();
    }
    ui->favorableConditionTabWidget->setTask(_task);
    ui->regulatoryConditionTabWidget->setTask(_task);
    ui->nomologicalConditionTabWidget->setTask(_task);
    ui->contextualConditionTabWidget->setTask(_task);

    ui->favorableConditionTabWidget
            ->setConditions(_favorableConditions);
    ui->regulatoryConditionTabWidget
            ->setConditions(_regulatoryConditions);
    ui->nomologicalConditionTabWidget
            ->setConditions(_nomologicalConditions);
    ui->contextualConditionTabWidget
            ->setConditions(_contextualConditions);
}

/**
 * @brief getTask
 * Obitent la tâche en cours d'édition
 * @return La tâche en cours d'édition
 */
VTask * VPreconditionsTabWidget::getTask() const
{
    return _task;
}
