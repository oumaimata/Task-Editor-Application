#include "vhistoryset.h"

VHistorySet::VHistorySet(): QObject(){}

VHistorySet::VHistorySet(const VHistorySet & historySet):
    QObject()
{
    for(int i = 0; i < historySet.listHistoryState.count(); i++)
    {
        listHistoryState.push_back(historySet.at(i));
    }
}

const VHistoryState VHistorySet::last() const{
    VHistoryState historyState = listHistoryState.last();
    return historyState;
}

QString VHistorySet::lastValue() const
{
    VHistoryState historyState = listHistoryState.last();
    return historyState.getValue();
}

void VHistorySet::push_back(QString label, QString desc)
{
    push_back(label, desc, NULL);
}

void VHistorySet::push_back(QString label, QString desc, QString value)
{
    listHistoryState.push_back(VHistoryState(label, desc, value));
    hasChanged();
}

VHistoryState VHistorySet::pop_back()
{
    VHistoryState historyState = listHistoryState.last();
    listHistoryState.pop_back();
    hasChanged();
    return historyState;
}

VHistoryState VHistorySet::pop_front()
{
    VHistoryState historyState = listHistoryState.front();
    listHistoryState.pop_front();
    hasChanged();
    return historyState;
}

void VHistorySet::clear()
{
    listHistoryState.clear();
    hasChanged();
}

int VHistorySet::size() const
{
    return listHistoryState.size();
}

const VHistoryState VHistorySet::at(int index) const
{
    return listHistoryState.at(index);
}

VHistoryState VHistorySet::getLastHistoryStateSaved() const
{
    return _lastHistoryStateSaved;
}

void VHistorySet::setLastHistoryStateSaved(VHistoryState lastHistoryStateSaved)
{
    _lastHistoryStateSaved = lastHistoryStateSaved;
}
