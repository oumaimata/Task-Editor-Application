#pragma once
#ifndef VSATISFACTIONCOMBOBOX_H
#define VSATISFACTIONCOMBOBOX_H

#include <QComboBox>

class VStopCondition;

class VSatisfactionComboBox : public QComboBox
{
    Q_OBJECT
private:
    VStopCondition * _stopCondition;
public:
    explicit VSatisfactionComboBox(VStopCondition * stopCondition, QWidget *parent = 0);
    
signals:
    
public slots:
    void satisfactionTypeChanged(QString s);
    
};

#endif // VSATISFACTIONCOMBOBOX_H
