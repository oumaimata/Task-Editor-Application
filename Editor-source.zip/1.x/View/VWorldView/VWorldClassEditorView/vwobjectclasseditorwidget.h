#pragma once
#ifndef VWOBJECTCLASSEDITORWIDGET_H
#define VWOBJECTCLASSEDITORWIDGET_H

#include <QWidget>

class VWObjectClass;

namespace Ui {
class VWObjectClassEditorWidget;
}

class VWObjectClassEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWObjectClassEditorWidget *ui;

    bool _edit;

    VWObjectClass * _objectClass;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    void retranslate();
    
public:
    explicit VWObjectClassEditorWidget(QWidget *parent = 0);
    ~VWObjectClassEditorWidget();

    void setObjectClass(VWObjectClass * objectClass);

private slots:
    void updateDisplay();
    void on_nameLineEdit_editingFinished();
    void on_addInstanceButton_clicked();
    void typeToggled(bool);
};

#endif // VWOBJECTCLASSEDITORWIDGET_H
