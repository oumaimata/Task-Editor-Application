#ifndef VPLAINTEXT_H
#define VPLAINTEXT_H

#include "../../../VActivityCommon/vactivitymodelelement.h"
#include <qdom.h>

class VPlainText : public VActivityModelElement
{

private:
    QString _text;

public:
    VPlainText();
    VPlainText(const VPlainText &plainText, QObject* parent = 0);
    ~VPlainText();
    QString getText() const;
    void setText(const QString& text);
    VPlainText& operator=(const VPlainText& plainText);
    
    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);
    
    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");
    VPlainText* clone()const;

};

#endif // VPLAINTEXT_H
