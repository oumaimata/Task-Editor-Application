#include "vontologyinterface.h"

#include "vselectqueryresult.h"
#include "../../Controller/vtracecontroller.h"

VOntologyInterface* VOntologyInterface::_instance;

VOntologyInterface::VOntologyInterface(QObject* parent) :
    QObject(parent),
    _jenaBridge(this)
{
}

VOntologyInterface* VOntologyInterface::getInstance()
{
    if (_instance == NULL)
        _instance = new VOntologyInterface(NULL);
    return _instance;
}

bool VOntologyInterface::loadOntology(const QString& file)
{
    return _jenaBridge.loadOntology(file, "", "RDF/XML");
}

QList<QString> VOntologyInterface::getSubclassesOf(const QString& concept)
{
    QList<QString> subClasses;

    if (_jenaBridge.hasOntologyLoaded())
    {
        // Executing query
        QString res = _jenaBridge.selectQuery("SELECT DISTINCT ?n "
                                              "WHERE { "
                                              "?n rdfs:subClassOf "
                                              "<" + concept + "> .}");
        VSelectQueryResult queryResult(res);

        // Processing result
        QStringList list = queryResult.getVariableValue("n");
        for (int i = 0; i < list.size(); ++i)
        {
            QString value = list[i];

            if (!value.isNull() && value.split("#").at(1) != "Nothing")
                subClasses.push_back(value);
        }
    }

    return subClasses;
}

QList<QString> VOntologyInterface::getDirectSubclassesOf(const QString& concept)
{
    QList<QString> subClasses;

    if (_jenaBridge.hasOntologyLoaded())
    {
        // Executing query
        QString res = _jenaBridge.selectQuery("SELECT DISTINCT ?n "
                                              "WHERE { "
                                              "?n rdfs:subClassOf "
                                              "<" + concept + "> .}");
        VSelectQueryResult queryResult(res);

        // Processing result
        QStringList list = queryResult.getVariableValue("n");
        for (int i = 0; i < list.size(); ++i)
        {
            QString value = list[i];

            // Don't take subclasses of the subclasses
            if (!value.isNull() && value.split("#").at(1) != "Nothing"
                    && !_jenaBridge.askQuery("ASK WHERE { "
                                             "?n rdfs:subClassOf <" + concept + ">. "
                                             "<" + value + "> rdfs:subClassOf ?n. "
                                             "FILTER (?n != <" + value + ">)}"))
                subClasses.push_back(value);
        }
    }

    return subClasses;
}

QList<QString> VOntologyInterface::getRelatedOf(const QString& concept)
{
    QList<QString> related;

    if (_jenaBridge.hasOntologyLoaded())
    {
        // Executing query
        QString res = _jenaBridge.selectQuery("SELECT DISTINCT ?n "
                                              "WHERE {?p rdfs:domain <"
                                              + concept + ">. "
                                              "?p rdfs:range ?n. "
                                              "FILTER(?p != owl:bottomObjectProperty)}");
        VSelectQueryResult queryResult(res);

        // Processing result
        QStringList list = queryResult.getVariableValue("n");
        for (int i = 0; i < list.size(); ++i)
        {
            QString value = list[i];

            // Don't take subclasses of the subclasses
            if (!value.isNull() && value.split("#").at(1) != "Nothing")
                related.push_back(value);
        }
    }

    return related;
}

QString VOntologyInterface::getConcept(const QString& conceptName)
{
    if (_jenaBridge.hasOntologyLoaded())
    {
        // Executing query
        QString res = _jenaBridge.selectQuery("SELECT DISTINCT ?n "
                                              "WHERE {?n owl:equivalentClass "
                                              + _jenaBridge.getPrefix() + ":"
                                              + conceptName + ".} ");
        VSelectQueryResult queryResult(res);

        // Processing result
        QStringList list = queryResult.getVariableValue("n");
        for (int i = 0; i < list.size(); ++i)
        {
            QString value = list[i];

            if (!value.isNull() && value.split("#").at(1) != "Nothing")
                return value;
        }
    }

    return NULL;
}

/**
 * @brief executeQuery
 * Execute une requète SPARQL dans JENA
 * @param query La requète
 * @return Le résultat de la requète
 */
QString VOntologyInterface::executeQuery(const QString& query)
{
    if (!_jenaBridge.hasOntologyLoaded())
    {
        VTraceController::get()->Error("VOntologyInterface::executeQuery", "no ontology loaded");
        return tr("Error : no world model loaded");
    }
    QString result;
    if (query.startsWith("SELECT"))
        result = _jenaBridge.selectQuery(query);
    else if (query.startsWith("ASK"))
        result = _jenaBridge.askQuery(query) ? "true" : "false";
    else
        result = tr("Error : query invalid");

    if(result.isNull() || result.isEmpty()) result = tr("No results");
    return result;
}
