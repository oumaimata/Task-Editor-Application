#pragma once
#ifndef VACTIVITYMODELELEMENT_H
#define VACTIVITYMODELELEMENT_H

#include <QObject>

/**
 * @brief The VActivityModelElement class
 * Classe de base de tous les éléments du modèle d'activité
 * _uid est unique
 */
class VActivityModelElement : public QObject
{
    Q_OBJECT
private:

    /**
     * @brief _currentUid
     * Compteur automatique d'identifiant
     */
    static qint64 currentUid;

    /**
     * @brief _uid
     * Identifiant unique de l'élément
     */
    qint64 _uid;

protected:

    /**
     * @brief _edit
     * Si l'élément est en cours d'édition
     */
    bool _edit;

public:
    /**
     * @brief VActivityModelElement
     * Constructeur
     * @param parent L'object parent
     */
    explicit VActivityModelElement(QObject *parent = 0);

    /**
     * @brief VActivityModelElement
     * Constructeur de copie
     * @param activityModelElement L'élément à copier
     */
    VActivityModelElement(const VActivityModelElement& activityModelElement);

    /**
     * @brief getUid
     * Obtient l'Uid
     * @return L'uid
     */
    qint64 getUid() const;

    /**
     * @brief operator ==
     * Opérateur de comparaison
     * @param activityModelElement L'élément à comparer
     * @return Si les deux object sont éguaux
     */
    bool operator==(const VActivityModelElement& activityModelElement) const;

    void beginEdit();

    void endEdit();

protected slots:

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     */
    void onModified();

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     * @param object L'object qui a été modifié
     */
    void onModified(QString message, QObject * object = NULL);

signals:

    /**
     * @brief modified
     * Signal envoyé lors de modification sur un VActivityModelElement
     * @param object L'object qui a été modifié
     */
    void modified(QString message, QObject * object);
    
};

#endif // VACTIVITYMODELELEMENT_H
