#include "vwinstancetabwidget.h"
#include "ui_vwinstancetabwidget.h"

#include "../../Model/VWorld/VWorldInstance/vwinstance.h"
#include "../../Model/VWorld/VWorldClass/vwobjectclass.h"

VWInstanceTabWidget::VWInstanceTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWInstanceTabWidget),
    _objectClass(NULL)
{
    ui->setupUi(this);
}

VWInstanceTabWidget::~VWInstanceTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWInstanceTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWInstanceTabWidget::setObjectClass(VWObjectClass * objectClass)
{
    if(_objectClass != objectClass)
    {
        _objectClass = objectClass;
    }
    updateDisplay();
}

void VWInstanceTabWidget::setCurrentEdit(QPointer<VWorldModelElement> currentEdit)
{
    if(currentEdit != NULL)
    {
        _currentEdit = currentEdit;
        VWInstance * instance = qobject_cast<VWInstance *>(currentEdit);
        VWObjectClass * objectClass = qobject_cast<VWObjectClass *>(currentEdit);
        if(objectClass != NULL) _objectClass = objectClass;
        if(instance == NULL && objectClass == NULL) _objectClass = NULL;
    }
    else
    {
        _currentEdit = _objectClass = NULL;
    }
    updateDisplay();
}

void VWInstanceTabWidget::updateDisplay()
{
    while(ui->instanceTableWidget->rowCount() > 0)
        ui->instanceTableWidget->removeRow(0);
    if(_objectClass == NULL) return;
    VWInstance * instance;
    QList<VWInstance *> instances = _objectClass->getAllInstances();
    foreach(instance, instances)
    {
        ui->instanceTableWidget->insertRow(0);

        QTableWidgetItem* itemName = new QTableWidgetItem();
        itemName->setText(instance->getName());
        itemName->setData(Qt::UserRole, QString::number(instance->getUid()));
        ui->instanceTableWidget->setItem(0, 0, itemName);
        itemName->setSelected(instance == _currentEdit);

        QTableWidgetItem* itemClass = new QTableWidgetItem();
        itemClass->setText(instance->getClass()->getName());
        itemClass->setData(Qt::UserRole, QString::number(instance->getUid()));
        ui->instanceTableWidget->setItem(0, 1, itemClass);
    }
}

void VWInstanceTabWidget::on_instanceTableWidget_itemDoubleClicked(QTableWidgetItem *item)
{
    if(_objectClass == NULL) return;
    QString uid = item->data(Qt::UserRole).toString();

    VWInstance * instance = _objectClass->getAllInstanceByUid(uid.toLong());
    if(instance != NULL)
    {
        emit editInstanceAsked(instance);
        return;
    }
}
