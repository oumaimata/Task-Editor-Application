#pragma once
#ifndef VAPPLICATIONCONTROLLER_H
#define VAPPLICATIONCONTROLLER_H

#include <QObject>
#include <QTranslator>
#include <QSettings>

#include "vactivitycontroller.h"
#include "vworldcontroller.h"
#include "Model/vsettings.h"

class VMainWindow;

/*!
 * @brief The VApplicationController class
 * Le Controller de l'application
 */
class VApplicationController : public QObject
{
    Q_OBJECT

private:

    static VApplicationController* _instance;

    /*!
     * \brief _mainWindow
     * Pointeur vers la fenêtre principale
     */
    VMainWindow* _mainWindow;

    /**
     * @brief frenchTranslator
     * Pointeur vers le traducteur français
     */
    QTranslator* frenchTranslator;

    /**
     * @brief _activityCtrler
     * Pointeur vers le controller d'activité
     */
    VActivityController * _activityCtrler;

    /**
     * @brief _worldCtrler
     * Pointeur vers le controller du monde
     */
    VWorldController * _worldCtrler;

    /*!
     * @brief VApplicationController
     * Constructeur
     * @param mainWindow Widget de la fenêtre principale
     * @param parent
     */
    VApplicationController(VMainWindow* mainWindow, QObject* parent = NULL);

public:

    /**
     * @brief getInstance
     * Obtient l'instance de VApplicationController
     * @return L'instance de VApplicationController
     */
    static VApplicationController* getInstance(VMainWindow * mainWindow = NULL, QObject* parent = NULL);

    /**
     * @brief autoLanguage Choisie la langue de l'application automatiquement
     */
    void autoLanguage();

    void switchToActivity();
    void switchToWorld();
    void switchToHistory();

    void setActivityController(VActivityController *  activityCtrler);
    VActivityController * getActivityController() const;

    void setWorldController(VWorldController * worldCtrler);
    VWorldController * getWorldController() const;


public slots:
    /*!
     * @brief newActivityModel
     * slot connecté au signal _mainWindow->newActivityModelAsked()
     * Permet la création d'un nouveau modèle d'activité
     */
    void newActivityModel();
    /*!
     * @brief importActivityModel
     * slot connecté au signal _mainWindow->activityModelImportAsked()
     * Permet l'import d'un modèle d'activité
     */
    void importActivityModel(QString fileName);
    /*!
     * @brief saveActivityModel
     * slot connecté au signal _mainWindow->activityModelSaveAsked()
     * Permet l'enregistrement d'un modèle d'activité
     */
    void saveActivityModel();
    /*!
     * @brief exportActivityModel
     * slot connecté au signal _mainWindow->activityModelExportAsked()
     * Permet l'export d'un modèle d'activité
     */
    void exportActivityModel(QString fileName);
    /*!
     * @brief VApplicationController::newWorldModel
     * slot connecté au signal _mainWindow->newWorldModelAsked()
     * Permet la création d'un nouveau modèle du monde
     */
    void newWorldModel();
    /*!
     * @brief importWorldModel
     * slot connecté au signal _mainWindow->worldModelImportAsked()
     * Permet l'import d'un modèle du monde
     */
    void importWorldModel(QString fileName);

    void saveWorldModel();
    /**
     * @brief exportWorldModel
     * slot connecté au signal _mainWindow->worldModelExportAsked()
     * Permet l'export d'un modèle du monde
     */
    void exportWorldModel();

    /**
     * @brief exportWorldModel
     * slot connecté au signal _mainWindow->worldModelExportAsked()
     * Permet l'export d'un modèle du monde
     * @param fileName Nom du fichier pour l'export
     */
    void exportWorldModel(QString fileName);

    /**
     * @brief activityCut
     * Slot connecté au signal _mainWindow->cutAsked()
     * Permet de couper une partie de l'arbre d'activité
     */
    void activityCut();

    /**
     * @brief activityCopy
     * Slot connecté au signal _mainWindow->copyAsked()
     * Permet de copier une partie de l'arbre d'activité
     */
    void activityCopy();

    /**
     * @brief activityPaste
     * Slot connecté au signal _mainWindow->pasteAsked()
     * Permet de coller une partie de l'arbre d'activité
     */
    void activityPaste();

    /**
     * @brief quit
     * Slot connecté au signal _mainWindow->quitAsked()
     * Permet quitter le programme
     */
    void quit();

    /**
     * @brief frenchLanguage
     * Slot connecté au signal _mainWindow->frenchLanguageAsked()
     * Permet le passage au français
     */
    void frenchLanguage();

    /**
     * @brief englishLanguage
     * Slot connecté au signal _mainWindow->englishLanguageAsked()
     * Permet le passage a l'anglais
     */
    void englishLanguage();

    bool isApplicationSaved();

    void saveSettings();

signals:
    void newStatus(QString);
};

#endif // VAPPLICATIONCONTROLLER_H
