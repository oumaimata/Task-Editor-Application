#pragma once
#ifndef VSUBJECT_H
#define VSUBJECT_H
#include "../../VActivityCommon/vactivitymodelelement.h"

#include "VContent/vspeechactcontent.h"

class VSubject : public VActivityModelElement
{
    Q_OBJECT
public:
    VSubject();
    VSubject(const VSubject& subject, QObject* parent =  0);
    ~VSubject();

    QString *getPerformative() const;
    void setPerformative(QString *performative);

    VSpeechActContent *getContent() const;
    void setContent(VSpeechActContent *content);
    
    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);
    
    QString ToXml(QString tabulation ="");

    VSubject* clone() const;

private:
    QString* _performative;
    VSpeechActContent* _content;
};

#endif // VSUBJECT_H
