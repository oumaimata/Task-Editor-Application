#pragma once
#ifndef VTASKITEM_H
#define VTASKITEM_H

/*
 * Drawing constants.
 */
#define TASKITEM_WIDTH 210.0
#define TASKITEM_BASE_HEIGHT 30.0

#define HLINEIN_WIDTH_PROP 0.22
#define HLINEIN_WIDTH TASKITEM_WIDTH * HLINEIN_WIDTH_PROP
#define HLINEIN_X1 0
#define HLINEIN_X2 HLINEIN_X1 + HLINEIN_WIDTH
#define HLINEIN_Y TASKRECT_Y + 0.5 * TASKRECT_HEIGHT

#define TASKRECT_WIDTH_PROP 0.53
#define TASKRECT_X HLINEIN_X2
#define TASKRECT_Y 0.5 * (TASKITEM_BASE_HEIGHT - TASKRECT_HEIGHT)
#define TASKRECT_WIDTH TASKRECT_WIDTH_PROP * TASKITEM_WIDTH
#define TASKRECT_HEIGHT_PROP 1.0
#define TASKRECT_HEIGHT TASKITEM_BASE_HEIGHT * TASKRECT_HEIGHT_PROP

#define HLINEOUT_WIDTH_PROP 0.15
#define HLINEOUT_WIDTH TASKITEM_WIDTH * HLINEOUT_WIDTH_PROP
#define HLINEOUT_X1 TASKRECT_X + TASKRECT_WIDTH
#define HLINEOUT_X2 HLINEOUT_X1 + HLINEOUT_WIDTH
#define HLINEOUT_Y TASKITEM_BASE_HEIGHT / 2

#define CONSTR_WIDTH_PROP 0.10
#define CONSTR_HEIGHT_PROP 0.8
#define CONSTR_X HLINEOUT_X2
#define CONSTR_Y 0.5 * (TASKITEM_BASE_HEIGHT - CONSTR_HEIGHT)
#define CONSTR_WIDTH CONSTR_WIDTH_PROP * TASKITEM_WIDTH
#define CONSTR_HEIGHT TASKITEM_BASE_HEIGHT * CONSTR_HEIGHT_PROP

#define CONSTR_TEXT_X HLINEOUT_X1 + HLINEOUT_WIDTH // / 2
#define CONSTR_TEXT_Y CONSTR_Y - CONSTR_TEXT_HEIGHT
#define CONSTR_TEXT_WIDTH HLINEOUT_WIDTH - 0.5 * CONSTR_WIDTH
#define CONSTR_TEXT_HEIGHT 0.5 * TASKRECT_HEIGHT

#define VLINE_X CONSTR_X + 0.5 * CONSTR_WIDTH
#define VLINE_Y1 CONSTR_Y + CONSTR_HEIGHT

#define TASKITEM_MARGIN 20.0
#define TASKITEM_MARGIN_HEIGHT TASKITEM_BASE_HEIGHT + TASKITEM_MARGIN
#define TASKITEM_SUBTASKITEMS_X TASKITEM_WIDTH - 0.5 * CONSTR_WIDTH

#include <QtWidgets/QGraphicsItemGroup>
#include <QGraphicsSimpleTextItem>
#include <QGraphicsLineItem>

#include "Model/VActivity/vtask.h"

class VTaskRectItem;
class VTaskConstructorItem;

/**
 * @brief The VTaskItem class
 * Outil graphique permettant de visualiser une tâche (rectangle bleu)
 */
class VTaskItem : public QGraphicsItemGroup
{
private:
    QPointer<VTask> _task;
    VTaskRectItem* _taskRectItem;
    QGraphicsLineItem* _hLineInItem;
    QGraphicsLineItem* _hLineOutItem;
    QGraphicsLineItem* _vLineItem;
    VTaskConstructorItem* _taskConstructorItem;
    QGraphicsSimpleTextItem* _constrTextItem;
    bool _expanded;

    /**
     * @brief getConstrText
     * Obtient le constructeur de la tâche
     * @return Le constructeur de la tâche
     */
    QString getConstrText() const;

public:

    enum {Type = UserType + 1};

    /*!
     * \brief VTaskItem::VTaskItem
     * Constructeur
     * \param task La tache
     * \param parent L'objet parent
     */
    VTaskItem(VTask* task, QGraphicsItem* parent = NULL);

    /*!
     * \brief VTaskItem::type
     * Obtient le type
     * \return Le type
     */
    virtual int type() const;

    /*!
     * \brief VTaskItem::paint
     * Dessine le VTaskItem
     * \param painter
     * \param option
     * \param widget
     */
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget);

    /*!
     * \brief VTaskItem::getHeight
     * Obtient la hauteur
     * \return La hauteur
     */
    qreal getHeight() const;

    /*!
     * \brief VTaskItem::getTask
     * Obtient la tache
     * \return La tache
     */
    QPointer<VTask> getTask();

    /*!
     * \brief VTaskItem::getParentTaskItem
     * Obtient le TaskItem de la tache parente
     * \return Le taskItem de la tache parente
     */
    VTaskItem* getParentTaskItem() const;

    /*!
     * \brief VTaskItem::getChildTaskItem
     * Obtient le TaskItem de la tâche passé en argument
     * \return Le TaskItem de la tâche passé en argument
     */
    VTaskItem* getChildTaskItem(VTask * task) const;

    /*!
     * \brief VTaskItem::getChildTaskItems
     * Obtient les TaskItem des taches enfants
     * \return Les TaskItem des taches enfants
     */
    QList<VTaskItem*> getChildTaskItems() const;

    /*!
     * \brief VTaskItem::setExpanded
     * Définie si le VTAskItem est déplié
     * \param expanded si le VTAskItem est déplié
     */
    void setExpanded(bool expanded);

    /*!
     * \brief VTaskItem::updateSubitemsPositions
     * Met a jour la position des items enfants
     */
    void updateSubitemsPositions();

    /*!
     * \brief VTaskItem::updateContent
     * Met a jour le contenu
     */
    void updateContent();

    /**
     * @brief setParentItem
     * Définit le parent du VTaskItem
     * Met à jour les graphismes concernés
     * @param newParent Le nouveau parent
     */
    void setParentItem(QGraphicsItem * newParent);
};

#endif // VTASKITEM_H
