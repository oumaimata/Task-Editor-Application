#include "vwproperty.h"

#include "vwparser.h"
#include "vwpropertytype.h"
#include "vworldmodelelement.h"
#include "VWorldClass/vwcomponentclass.h"
#include "VWorldClass/vwactionclass.h"

qint64 VWProperty::currentUid = 0;

QHash<QString, QList<VWProperty *> > VWProperty::s_sharedProperties = EmptyList();

VWProperty::VWProperty(QObject *parent):
    QObject(parent),
    _uid(currentUid),
    _isShared(false),
    _type(NULL),
    _edit(false)
{
    currentUid++;
    _type = new VWPropertyType();
    connect(_type, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWProperty::ParseDom(QDomElement elem)
{
    setName(VWParser::getName(elem));
    QPair<QList<QString>, QString> domaineAndRange = VWParser::getDomaineAndRange(elem);
    VWPropertyType * type = new VWPropertyType();
    type->fromString(domaineAndRange.second);
    setType(type);
}

QString VWProperty::ToXml()
{
    return ToXml(NULL);
}

QString VWProperty::ToXml(QString tabulation)
{
    if(_worldModelElements.length() == 0)return NULL;
    QString RetVal = tabulation + "<owl:ObjectProperty rdf:ID=\"" + getName()+ "\">\n";

    VWActionClass * action = qobject_cast<VWActionClass *>(_worldModelElements[0]);
    if(action != NULL)
    {
        RetVal += tabulation + "\t<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#action-target\"/>\n";
    }

    if(_worldModelElements.length() >= 1)
    {
        RetVal += tabulation + "\t" + "<rdfs:domain>\n";
        RetVal += tabulation + "\t\t" + "<owl:Class>\n";
        RetVal += tabulation + "\t\t\t" + "<owl:unionOf rdf:parseType=\"Collection\">\n";
        for(int i = 0; i< _worldModelElements.length();)
        {
            if(_worldModelElements[i] != NULL)
            {
                RetVal += tabulation + "\t\t\t\t<owl:Class rdf:about=\"#" + _worldModelElements[i]->getName() + "\"/>\n";
                i++;
            }
            else
            {
                _worldModelElements.removeAt(i);
            }
        }
        RetVal += tabulation + "\t\t\t" + "</owl:unionOf>\n";
        RetVal += tabulation + "\t\t" + "</owl:Class>\n";
        RetVal += tabulation + "\t" + "</rdfs:domain>\n";
    }
    RetVal += tabulation + "\t<rdfs:range rdf:resource=\"" + getType()->toXml() + "\"/>\n";
    RetVal += tabulation + "</owl:ObjectProperty>\n";
    return RetVal;
}

qint64 VWProperty::getUid() const
{
    return _uid;
}

void VWProperty::setName(QString name)
{
    if(name != _name)
    {
        _name = name;
        onModified(tr("Name changed"));
    }
}

QString VWProperty::getName() const
{
    return _name;
}

void VWProperty::setIsShared(QString type, bool isShared)
{
    if(_isShared != isShared)
    {
        _isShared = isShared;
        if(s_sharedProperties.contains(type))
        {
            if(_isShared)
            {
                s_sharedProperties[type].append(this);
            }
            else
            {
                s_sharedProperties[type].removeAll(this);
            }
        }
    }
}

bool VWProperty::getIsShared() const
{
    return _isShared;
}

void VWProperty::addWorldModelElement(QPointer<VWorldModelElement> worldModelElement)
{
    if(worldModelElement != NULL)
        _worldModelElements.append(worldModelElement);
}

void VWProperty::removeWorldModelElement(QPointer<VWorldModelElement> worldModelElement)
{
    if(worldModelElement != NULL)
        _worldModelElements.removeAll(worldModelElement);
}

void VWProperty::setType(VWPropertyType * type)
{
    if(type != _type)
    {
        if(_type != NULL) disconnect(_type, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        _type = type;
        if(_type != NULL) connect(_type, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Type changed"));
    }
}

VWPropertyType * VWProperty::getType() const
{
    return _type;
}

QList<VWProperty *> VWProperty::getSharedProperties()
{
    return getSharedProperties(NULL);
}

QList<VWProperty *> VWProperty::getSharedProperties(QString type)
{
    if(type.isNull() || type.isEmpty())
    {
        QList<VWProperty *> result;
        for(int i = 0; i < s_sharedProperties.keys().count(); i++)
        {
            result.append(s_sharedProperties.values()[i]);
        }
        return result;
    }
    else
    {
        return (s_sharedProperties.contains(type) ? s_sharedProperties[type] : QList<VWProperty *>());
    }
}

VWProperty * VWProperty::getSharedPropertyByUid(QString type, qint64 uid)
{
    foreach(VWProperty * property, getSharedProperties(type))
    {
        if(property->getUid() == uid) return property;
    }
    return NULL;
}

/**
 * @brief operator ==
 * Opérateur de comparaison
 * @param worldModelElement L'élément à comparer
 * @return Si les deux object sont éguaux
 */
bool VWProperty::operator==(const VWProperty& property) const
{
    return _uid == property._uid;
}

void VWProperty::setComponent(QPointer<VWComponentClass> component)
{
    _component = component;
}

QPointer<VWComponentClass> VWProperty::getComponent() const
{
    return _component;
}

/**
 * @brief EmptyList
 * Utile pour l'initialisation de s_sharedProperties
 * @return Une liste vide
 */
QHash<QString, QList<VWProperty *> > VWProperty::EmptyList()
{
    QHash<QString, QList<VWProperty *> > list;
    list.insert("action-behaviour-event", QList<VWProperty *>());
    list.insert("object", QList<VWProperty *>());
    list.insert("component", QList<VWProperty *>());
    return list;
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 */
void VWProperty::onModified()
{
    onModified(NULL);
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 * @param object L'objet modifié
 */
void VWProperty::onModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    emit modified(message, (object == NULL) ? this : object);
}
