#pragma once
#ifndef VGENERALTABWIDGET_H
#define VGENERALTABWIDGET_H

#include <QWidget>

class VActivityModel;

namespace Ui {
class VGeneralTabWidget;
}

/**
 * @brief The VGeneralTabWidget class
 * Permet l'édition de la version du model et des namespaces
 */
class VGeneralTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VGeneralTabWidget *ui;

    /**
     * @brief _activityModel
     * Le modèle d'activité en cours
     */
    VActivityModel * _activityModel;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    /**
     * @brief VGeneralTabWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VGeneralTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VGeneralTabWidget
     * Destructeur
     */
    ~VGeneralTabWidget();

    /**
     * @brief setActivityModel
     * Définit le modèle d'activité en cours
     * @param activityModel Le modèle d'activité en cours
     */
    void setActivityModel(VActivityModel * activityModel);

private slots:
    /**
     * @brief updateDisplay
     * Met à jour l'affichage
     */
    void updateDisplay();

    /**
     * @brief on_versionLineEdit_editingFinished
     * Gère la fin de l'édition de la version en mettant à jour le modèle
     */
    void on_versionLineEdit_editingFinished();

    /**
     * @brief on_addButton_clicked
     * Gère le click sur le bouton ajouté
     * -> ajoute un nouveau prefix au modèle
     */
    void on_addButton_clicked();

    /**
     * @brief on_removeButton_clicked
     * Gère le click sur le bouton supprimer
     * -> retire le préfix sélectionné du modèle
     */
    void on_removeButton_clicked();

    /**
     * @brief on_namespacesWidget_cellChanged
     * Gère l'édition des cellules
     * @param row La ligne de la cellule modifiée
     * @param column La colonne de la cellule modifiée
     */
    void on_namespacesWidget_cellChanged(int row, int column);
};

#endif // VGENERALTABWIDGET_H
