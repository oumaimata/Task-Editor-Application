#include "vcondition.h"

#include "vconditionlogicaloperator.h"
#include "vstatement.h"
#include "Controller/vactivitycontroller.h"
#include "Controller/vapplicationcontroller.h"

VCondition::VCondition(QObject* parent):
    VBasisCondition(parent)
{
}

VCondition::VCondition(const VCondition &condition, QObject *parent) :
    VBasisCondition(condition, parent),
    _type(condition._type)
{
    foreach(VConditionLogicalOperator * cLO, condition._CLOs)
    {
        addCLO(cLO->clone());
    }
    foreach(VStatement * statement, condition._statements)
    {
        addStatement(statement->clone());
    }
}

/**
 * @brief ~VCondition
 * Destructeur
 */
VCondition::~VCondition()
{
    while(_CLOs.count() > 0)
    {
        VConditionLogicalOperator * cLO = _CLOs.first();
        _CLOs.pop_front();
        delete cLO;
    }
    while(_statements.count() > 0)
    {
        VStatement * statement = _statements.first();
        _statements.pop_front();
        delete statement;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VCondition::parseDom(QDomElement elem)
{
    setId(elem.attribute("id",""));
    setType(elem.tagName());
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString tagName = element.tagName().toUpper();
            // Lecture de CLO
            if(tagName == "AND" || tagName == "OR" ||
               tagName == "XOR" || tagName == "NOT")
            {
                VConditionLogicalOperator * cLO = new VConditionLogicalOperator(this);
                cLO->parseDom(element);
                addCLO(cLO);
            }
            else
            {
                VStatement * statement = new VStatement(this);
                statement->parseDom(element);
                addStatement(statement);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VCondition::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<" + _type + " id=\"" + QString::number(getId()) + "\">\n";

    for(int i = 0; i < _statements.count(); i++)
    {
        RetVal += _statements[i]->ToXml(tabulation + "\t");
    }

    for(int i = 0; i < _CLOs.count(); i++)
    {
        RetVal += _CLOs[i]->ToXml(tabulation + "\t");
    }

    RetVal += tabulation + "</" + _type + ">\n";
    return RetVal;
}

void VCondition::setType(QString type)
{
    type = type.toLower();
    if(type[type.size() - 1] == 's')
    {
        type = type.remove(type.size() - 1, 1);
    }
    if(type != _type)
    {
        _type = type;
        onModified(NULL);
    }
}

QString VCondition::getType()
{
    return _type;
}

void VCondition::addCLO(VConditionLogicalOperator *cLO)
{
    if(cLO != NULL)
    {
        _CLOs.append(cLO);
        connect(cLO, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("CLO added"));
    }
}

void VCondition::removeCLO(VConditionLogicalOperator * cLO)
{
    if(_CLOs.contains(cLO))
    {
        _CLOs.removeAll(cLO);
        disconnect(cLO, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("CLO removed"));
    }
}

QList<VConditionLogicalOperator *> VCondition::getCLOs() const
{
    return _CLOs;
}

VConditionLogicalOperator * VCondition::getCLOById(qint64 uid) const
{
    for(int i = 0; i < _CLOs.count(); i++)
    {
        if(_CLOs[i]->getUid() == uid) return _CLOs[i];
        else
        {
            VConditionLogicalOperator * cLOs = _CLOs[i]->getChildById(uid);
            if(cLOs != NULL) return cLOs;
        }
    }
    return NULL;
}

void VCondition::addStatement(VStatement * statement)
{
    if(statement != NULL)
    {
        _statements.append(statement);
        connect(statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Statement added"));
    }
}

void VCondition::removeStatement(VStatement * statement)
{
    if(_statements.contains(statement))
    {
        _statements.removeAll(statement);
        disconnect(statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Statement removed"));
    }
}

QList<VStatement *> VCondition::getStatements() const
{
    return _statements;
}

VStatement * VCondition::getStatementById(qint64 uid) const
{
    for(int i = 0; i < _statements.count(); i++)
    {
        if(_statements[i]->getUid() == uid) return _statements[i];
    }
    return NULL;
}

QString VCondition::toString(QString tabulation) const
{
    QString RetVal = "";
    if(_statements.count() != 0 || _CLOs.count() != 0)
    {
        RetVal = tabulation + "Condition";
        foreach(VStatement * statement, _statements)
        {
            RetVal += statement->toString(tabulation + "\t");
        }
        foreach(VConditionLogicalOperator * CLo, _CLOs)
        {
            RetVal += CLo->toString(tabulation + "\t");
        }
    }
    return RetVal;
}


/**
 * @brief clone
 * @return Le clone
 */
VCondition * VCondition::clone(QObject *parent) const
{
    return new VCondition(*this, parent);
}
