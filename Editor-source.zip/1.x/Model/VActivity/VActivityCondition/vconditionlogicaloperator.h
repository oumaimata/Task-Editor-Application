#pragma once
#ifndef VCONDITIONLOGICALOPERATOR_H
#define VCONDITIONLOGICALOPERATOR_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"

class VStatement;

class VConditionLogicalOperator : public VActivityModelElement
{
    Q_OBJECT
private:
    QString _type;

    QList<VStatement *> _statements;

    QList<VConditionLogicalOperator *> _childs;
public:
    explicit VConditionLogicalOperator(QObject *parent = 0);

    VConditionLogicalOperator(const VConditionLogicalOperator& cLO, QObject *parent = 0);

    /**
     * @brief ~VConditionLogicalOperator
     * Destructeur
     */
    ~VConditionLogicalOperator();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setType(QString type);
    QString getType() const;

    void addStatement(VStatement * statement);
    void removeStatement(VStatement * statement);
    QList<VStatement *> getStatements() const;
    VStatement * getStatementById(qint64 uid) const;

    void addChild(VConditionLogicalOperator * cLO);
    void removeChild(VConditionLogicalOperator * cLO);
    QList<VConditionLogicalOperator *> getChilds() const;
    VConditionLogicalOperator * getChildById(qint64 uid) const;

    QString toString(QString tabulation = "") const;

    /**
     * @brief clone
     * @return Le clone
     */
    VConditionLogicalOperator * clone(QObject *parent = 0) const;
};

#endif // VCONDITIONLOGICALOPERATOR_H
