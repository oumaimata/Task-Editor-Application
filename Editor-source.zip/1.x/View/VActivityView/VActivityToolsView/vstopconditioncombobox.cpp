#include "vstopconditioncombobox.h"

#include "Model/VActivity/VActivityCondition/vstopcondition.h"

VStopConditionComboBox::VStopConditionComboBox(VStopCondition * stopCondition, QWidget *parent) :
    QComboBox(parent),
    _stopCondition(stopCondition)
{
    this->addItem("satisfaction");
    this->addItem("statement");
    this->addItem("duration");
    this->addItem("iteration");
    this->addItem("instance");
    this->setCurrentText(_stopCondition->getType());
    connect(this, SIGNAL(currentTextChanged(QString)), this, SLOT(stopConditionTypeChanged(QString)));
}

void VStopConditionComboBox::stopConditionTypeChanged(QString s)
{
    _stopCondition->setType(s);
}
