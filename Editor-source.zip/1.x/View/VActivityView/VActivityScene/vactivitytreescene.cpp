#include "vactivitytreescene.h"

#include <QGraphicsView>
#include <QGraphicsItem>

#include "vtaskitem.h"
#include "vtaskrectitem.h"
#include "Controller/vtracecontroller.h"
#include "Model/vapplicationmodel.h"

/*!
 * \brief VActivityTreeScene::VActivityTreeScene
 * Constructeur
 * \param parent L'objet parent
 */
VActivityTreeScene::VActivityTreeScene(QObject* parent) :
    QGraphicsScene(parent)
{
}

/*!
 * \brief VActivityTreeScene::getRootTasksItems
 * Obtient les items racines
 * \return Une liste d'item racine
 */
QList<VTaskItem*> VActivityTreeScene::getRootTasksItems()
{
    VTraceController::get()->Debug("VActivityTreeScene::getRootTasksItems()", "Begin");

    QList<VTaskItem*> rootTasksItems;
    QList<VTask*> childTasks = VApplicationModel::getInstance()->getActivityModel().getChildTasks();
    VTask* childTask;
    VTaskItem* childTaskItem;

    foreach (childTask, childTasks)
    {
        childTaskItem = this->getTaskItem(childTask);
        if (childTaskItem != NULL)
        {
            VTraceController::get()->Debug("VActivityTreeScene::getRootTasksItems()", "child task add to the result");
            rootTasksItems.push_back(childTaskItem);
        }
    }

    VTraceController::get()->Debug("VActivityTreeScene::getRootTasksItems()", "End");
    return rootTasksItems;
}

/*!
 * \brief VActivityTreeScene::getTaskItem
 * Trouve le TaskItem correspondant à task
 * \param task La tache recherchée
 * \return Le takItem correspondant s'il existe, null sinon
 */
VTaskItem* VActivityTreeScene::getTaskItem(VTask* task)
{
    VTraceController::get()->Debug("VActivityTreeScene::getTaskItem()", "Begin");
    if (task != NULL)
    {
        QListIterator<QGraphicsItem*> itemsIt(this->items());

        while (itemsIt.hasNext())
        {
            QGraphicsItem* item = itemsIt.next();

            // If the item is a VTaskItem and it's the task item.
            if (qgraphicsitem_cast<VTaskItem*>(item))
            {
                VTaskItem* taskItem = (VTaskItem*) item;
                if (taskItem->getTask() == task)
                {
                    VTraceController::get()->Info("VActivityTreeScene::getTaskItem()", "TaskItem found for " + task->getId());
                    VTraceController::get()->Debug("VActivityTreeScene::getTaskItem()", "End");
                    return (VTaskItem*) item;
                }
            }
        }
    }
    VTraceController::get()->Info("VActivityTreeScene::getTaskItem()", "TaskItem not found");
    VTraceController::get()->Debug("VActivityTreeScene::getTaskItem()", "End");
    return NULL;
}

/*!
 * \brief VActivityTreeScene::getSelectedTaskItems
 * Obtient la liste des items sélectionnés
 * \return La liste des items sélectionné
 */
QList<VTaskItem*> VActivityTreeScene::getSelectedTaskItems()
{
    VTraceController::get()->Debug("VActivityTreeScene::getSelectedTaskItems()", "Begin");

    const QList<QGraphicsItem*>& selectedItems = this->selectedItems();
    QGraphicsItem* selectedItem;
    QList<VTaskItem*> selectedTaskItems;

    foreach (selectedItem, selectedItems)
    {
        if (selectedItem->type() == VTaskRectItem::Type)
        {
            QGraphicsItem* parentItem = selectedItem->parentItem();
            if (parentItem->type() == VTaskItem::Type)
            {
                VTraceController::get()->Info("VActivityTreeScene::getSelectedTaskItems()", "Add a task to the result");
                selectedTaskItems.push_back((VTaskItem*) parentItem);
            }
        }
    }

    VTraceController::get()->Debug("VActivityTreeScene::getSelectedTaskItems()", "End");
    return selectedTaskItems;
}

/*!
 * \brief VActivityTreeScene::getSelectedTasks
 * Obtient la liste des tâches sélectionnées
 * \return La liste des tâches sélectionnées
 */
QList<QPointer<VTask> > VActivityTreeScene::getSelectedTasks()
{
    QList<QPointer<VTask> > RetVal;
    foreach(VTaskItem* taskItem, getSelectedTaskItems())
    {
        RetVal.append(taskItem->getTask());
    }
    return RetVal;
}

/*!
 * \brief VActivityTreeScene::updateItemsPositions
 * Met a jour la position des items
 */
void VActivityTreeScene::updateItemsPositions()
{
    VTraceController::get()->Debug("VActivityTreeScene::updateItemsPositions()", "Begin");
    qreal rootTaskItemY = 0;
    QList<VTaskItem*> rootTasksItems = this->getRootTasksItems();

    // Positionning each child.
    VTaskItem* rootTaskItem;
    foreach(rootTaskItem, rootTasksItems)
    {
        VTraceController::get()->Info("VActivityTreeScene::updateItemsPositions()", "Positionning a child");
        rootTaskItem->setPos(0, rootTaskItemY);
        rootTaskItemY += rootTaskItem->getHeight();
    }

    // Updating scene rect
    this->views().first()->setSceneRect(this->itemsBoundingRect());
    VTraceController::get()->Debug("VActivityTreeScene::updateItemsPositions()", "End");
}

/*!
 * \brief VActivityTreeScene::updateTaskItem
 * \param task
 */
void VActivityTreeScene::updateTaskItem(VTask* task)
{
    VTraceController::get()->Debug("VActivityTreeScene::updateTaskItem()", "Begin");
    if(task == NULL)
    {
        updateItemsPositions();
    }
    VTaskItem* taskItem = getTaskItem(task);
    if (taskItem != NULL)
    {
        VTraceController::get()->Info("VActivityTreeScene::updateTaskItem()", "Update the content of the TaskItem");
        taskItem->updateContent();

        // Verification si le parent a changé
        VTaskItem* parentTaskItem = getTaskItem(qobject_cast<VTask*> (task->parent()));
        if(taskItem->getParentTaskItem() != parentTaskItem)
        {
            taskItem->setParentItem(parentTaskItem);
        }
        taskItem->updateSubitemsPositions();
    }

    VTraceController::get()->Debug("VActivityTreeScene::updateTaskItem()", "End");
}

/*!
 * \brief VActivityTreeScene::addTaskItem
 * Ajoute un TaskItem avec pour tache Task
 * \param task La tache du TaskItem
 */
void VActivityTreeScene::addTaskItem(VTask* task)
{
    VTraceController::get()->Debug("VActivityTreeScene::addTaskItem()", "Begin");

    VTask* parent = qobject_cast<VTask*>(task->parent());
    VTaskItem* parentItem = this->getTaskItem(parent);

    // If the task has no parent and therefore no parent item.
    if (parent == NULL)
    {
        VTraceController::get()->Info("VActivityTreeScene::addTaskItem()", "No parent -> add the taskItem to the VActivityTreeScene");
        this->addItem(new VTaskItem(task, NULL));
        this->updateItemsPositions();
    }
    else if (parentItem != NULL)
    {
        VTraceController::get()->Info("VActivityTreeScene::addTaskItem()", "Parent -> add the taskItem to the parent");
        VTaskItem* taskItem = new VTaskItem(task, parentItem);
        taskItem->updateSubitemsPositions();
    }

    VTraceController::get()->Debug("VActivityTreeScene::addTaskItem()", "End");
}

/*!
 * \brief VActivityTreeScene::removeTaskItem
 * Supprime un TaskItem correspondant à la tache task
 * \param task La tache du TaskItem
 */
void VActivityTreeScene::removeTaskItem(VTask* task)
{
    VTraceController::get()->Debug("VActivityTreeScene::removeTaskItem()", "Begin");
    VTaskItem* taskItem = this->getTaskItem(task);

    if (taskItem != NULL)
    {
        VTraceController::get()->Info("VActivityTreeScene::removeTaskItem()", "TaskItem removed");
        VTaskItem* parentTaskItem = taskItem->getParentTaskItem();

        if (parentTaskItem != NULL)
            parentTaskItem->updateSubitemsPositions();
        else
            this->updateItemsPositions();

        this->removeItem(taskItem);
        delete taskItem;
    }
    VTraceController::get()->Debug("VActivityTreeScene::removeTaskItem()", "End");
}
