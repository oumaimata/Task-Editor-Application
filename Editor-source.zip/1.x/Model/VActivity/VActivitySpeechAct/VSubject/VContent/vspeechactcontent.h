#pragma once
#ifndef VSPEECHACTCONTENT_H
#define VSPEECHACTCONTENT_H
#include "../../../VActivityCommon/vactivitymodelelement.h"
#include "vactivityspeechactcontenttype.h"

#include "vplaintext.h"
#include "vquery.h"


class VSpeechActContent : public VActivityModelElement
{
    Q_OBJECT

public:
    VSpeechActContent();
    VSpeechActContent(const VSpeechActContent& content);
    VSpeechActContent(VPlainText *plainText);
    VSpeechActContent(VStatement *statement);
    VSpeechActContent(VQuery *query);
    ~VSpeechActContent();
    void setType(VSpeechActContentType type);
    void setPlainText(VPlainText *plainText);
    void setStatement(VStatement*statement);
    void setQuery(VQuery *query);
    VSpeechActContentType getType()const;
    VPlainText* getPlainText()const;
    VStatement* getStatement()const;
    VQuery *getQuery()const;
    
    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);
    
    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    VSpeechActContent* clone();

private:
    VSpeechActContentType _type;
    VPlainText* _plainText;
    VStatement* _statement;
    VQuery* _query;

};

#endif // VSPEECHACTCONTENT_H
