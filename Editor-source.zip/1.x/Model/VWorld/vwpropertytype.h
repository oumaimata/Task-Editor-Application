#pragma once
#ifndef VWPROPERTYTYPE_H
#define VWPROPERTYTYPE_H

#include <QObject>

#include "VWorldClass/vwcomponentclass.h"
#include "VWorldClass/vwobjectclass.h"

/**
 * @brief The VWPropertyType class
 * Permet de stocker les informations de l'élément type
 * des listes de propriétés <Name, Type>
 * Type possibles:
 *     - Type de base: int, string, bool, float, Date, DateTime, domain:Boolean
 *     - Sous-classes d'action, behaviour, component, event, object.
 */
class VWPropertyType : public QObject
{
    Q_OBJECT
private:
    /**
     * @brief _basicType
     * Pour les types de base
     */
    QString _basicType;

    /**
     * @brief _componentType
     * Pour le type component
     */
    QPointer<VWComponentClass> _componentType;

    /**
     * @brief _objectType
     * Pour le type object
     */
    QPointer<VWObjectClass> _objectType;
protected:
    bool _edit;
public:
    explicit VWPropertyType(QObject *parent = 0);

    void fromString(QString s);

    QString toString() const;

    QString toXml() const;

    QPointer<VWComponentClass> getComponentClass() const;
    QPointer<VWObjectClass> getObjectClass() const;

protected slots:

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     */
    void onModified();

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     * @param object L'object qui a été modifié
     */
    void onModified(QString message, QObject * object = NULL);

signals:

    /**
     * @brief modified
     * Signal envoyé lors de modification sur un VWorldModelElement
     * @param object L'object qui a été modifié
     */
    void modified(QString message, QObject * object);
    
};

#endif // VWPROPERTYTYPE_H
