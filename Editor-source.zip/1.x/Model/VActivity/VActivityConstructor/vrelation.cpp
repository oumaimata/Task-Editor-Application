#include "vrelation.h"

#include "../vtask.h"
#include "vconstructor.h"

VRelation::VRelation(QObject *parent) :
    VActivityModelElement(parent),
    _taskLh(NULL),
    _taskRh(NULL)
{
}

VRelation::VRelation(const VRelation& relation, QObject *parent):
    VActivityModelElement(parent)
{
    _taskLh = relation._taskLh;
    _lh = relation._lh;
    _operator = relation._operator;
    _rh = relation._rh;
    _taskRh = relation._taskRh;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VRelation::parseDom(QDomElement elem)
{
    setLh(elem.attribute("lh",""));
    setOperator(elem.attribute("operator",""));
    setRh(elem.attribute("rh",""));
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VRelation::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<relation";
    RetVal += " lh=\"" + _lh + "\"";
    RetVal += " operator=\"" + VActivityOperatorTypeToString(_operator) + "\"";
    RetVal += " rh=\"" + _rh + "\"";
    RetVal += " />\n";
    return RetVal;
}

/**
 * @brief AfterTasksParsed
 * Définie les tâches des relations
 * @param task La tâche du constructeur
 */
void VRelation::AfterTasksParsed(VTask * task)
{
    if(task == NULL) return;
    _taskLh = task->getTaskById(_lh);
    _taskRh = task->getTaskById(_rh);
}

void VRelation::setLh(QString lh)
{
    if(_lh != lh)
    {
        _lh = lh;
        onModified(NULL);
    }
}

QString VRelation::getLh()
{
    return (_taskLh != NULL) ? _taskLh->getId() : _lh;
}

void VRelation::setTaskLh(QPointer<VTask> taskLh)
{
    if(_taskLh != taskLh)
    {
        _taskLh = taskLh;
        if(_taskLh != NULL) _lh = _taskLh->getId();
        onModified(tr("Lh task changed"));
    }
}

QPointer<VTask> VRelation::getTaskLh() const
{
    return _taskLh;
}

void VRelation::setOperator(VActivityOperatorType ooperator)
{
    if(ooperator == SIZE_OF_VActivityOperatorType)
    {
        onModified(tr("Operator changed"));
        return;
    }
    if(_operator != ooperator)
    {
        _operator = ooperator;
        onModified(tr("Operator changed"));
    }
}

void VRelation::setOperator(QString ooperator)
{
    setOperator(VActivityOperatorTypeFromString(ooperator));
}

VActivityOperatorType VRelation::getOperator()
{
    return _operator;
}

void VRelation::setRh(QString rh)
{
    if(_rh != rh)
    {
        _rh = rh;
        onModified(NULL);
    }
}

QString VRelation::getRh()
{
    return (_taskRh != NULL) ? _taskRh->getId() : _rh;
}

void VRelation::setTaskRh(QPointer<VTask> taskRh)
{
    if(_taskRh != taskRh)
    {
        _taskRh = taskRh;
        if(_taskRh != NULL) _rh = _taskRh->getId();
        onModified(tr("Rh task changed"));
    }
}

QPointer<VTask> VRelation::getTaskRh() const
{
    return _taskRh;
}

/**
 * @brief clone
 * @return Le clone
 */
VRelation * VRelation::clone(QObject *parent) const
{
    return new VRelation(*this, parent);
}
