#pragma once
#ifndef VPREFIX_H
#define VPREFIX_H

#include <QtXml>

#include "VActivityCommon/vactivitymodelelement.h"

class VPrefix : public VActivityModelElement
{
    Q_OBJECT

private:

    /**
     * @brief name
     * Le nom du préfix
     */
    QString _name;

    /**
     * @brief iri
     * L'iri du préfix
     */
    QString _iri;

public:
    /**
     * @brief VPrefix
     * @param parent L'objet parent
     */
    VPrefix(QObject* parent = NULL);

    /**
     * @brief VPrefix
     * @param name Le nom du préfix
     * @param iri L'iri du préfix
     * @param parent L'objet parent
     */
    VPrefix(QString name, QString iri, QObject* parent = NULL);

    /**
     * @brief VPrefix
     * Constructeur de copie
     * @param prefix Préfix à copier
     */
    VPrefix(const VPrefix& prefix, QObject *parent = 0);

    /**
     * @brief setName
     * Définit le nom du préfix
     * @param name Le nom du préfix
     */
    void setName(QString name);

    /**
     * @brief getName
     * Obtient le nom du préfix
     * @return Le nom du préfix
     */
    QString getName() const;

    /**
     * @brief setIri
     * Définit l'iri du préfix
     * @param name L'iri du préfix
     */
    void setIri(QString iri);

    /**
     * @brief getIri
     * Obtient l'iri du préfix
     * @return L'iri du préfix
     */
    QString getIri() const;

    /**
     * @brief operator ==
     * @param prefix Préfixe à comparer
     * @return Si les deux préfixe sont identiques
     */
    bool operator==(const VPrefix& prefix) const;

    /**
     * @brief parseDom Charge un élément du dom
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

signals:
    void modified();
};

#endif // VPREFIX_H
