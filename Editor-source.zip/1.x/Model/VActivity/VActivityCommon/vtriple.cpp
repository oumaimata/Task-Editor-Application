#include "vtriple.h"

#include "../vtask.h"
#include "../../VWorld/vworldmodelelement.h"
#include "../../VWorld/vwproperty.h"

VTriple::VTriple(QObject *parent) :
    VActivityModelElement(parent),
    _predicate(""),
    _propertyPredicate(NULL),
    _subject(""),
    _worldElementSubject(NULL),
    _taskSubject(NULL),
    _object(""),
    _worldElementObject(NULL)
{
}

VTriple::VTriple(const VTriple& triple, QObject *parent):
    VActivityModelElement(parent),
    _predicate(triple._predicate),
    _propertyPredicate(triple._propertyPredicate),
    _subject(triple._subject),
    _worldElementSubject(triple._worldElementSubject),
    _taskSubject(triple._taskSubject),
    _object(triple._object),
    _worldElementObject(triple._worldElementObject)
{
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VTriple::parseDom(QDomElement elem)
{
    setPredicate(elem.attribute("predicate",""));
    setSubject(elem.attribute("subject",""));
    setObject(elem.attribute("object",""));
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VTriple::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<triple";
    if(!getPredicate().isEmpty() && !getPredicate().isNull()) RetVal += " predicate=\"" + getPredicate() + "\"";
    if(!getSubject().isEmpty() && !getSubject().isNull()) RetVal += " subject=\"" + getSubject() + "\"";
    if(!getObject().isEmpty() && !getObject().isNull()) RetVal += " object=\"" + getObject() + "\"";
    RetVal += " />\n";
    return RetVal;
}

void VTriple::setPredicate(VWProperty * property)
{
    if(property != _propertyPredicate)
    {
        _propertyPredicate = property;
         if(_propertyPredicate != NULL) _predicate = "";
        onModified(tr("Predicate changed"));
    }
}
void VTriple::setPredicate(QString predicate)
{
    if(_predicate != predicate)
    {
        _predicate = predicate;
        if(_predicate != NULL) _propertyPredicate = NULL;
        onModified(tr("Predicate changed"));
    }
}
QString VTriple::getPredicate() const
{
    if(_propertyPredicate != NULL)
        return _propertyPredicate->getName();
    else
        return _predicate;
}

void VTriple::setSubject(VWorldModelElement * worldModelElement)
{
    if(worldModelElement != _worldElementSubject)
    {
        _worldElementSubject = worldModelElement;
        if(_worldElementSubject != NULL)
        {
            _taskSubject = NULL;
            _subject = "";
        }
        onModified(tr("Subject changed"));
    }
}
void VTriple::setSubject(VTask * task)
{
    if(task != _taskSubject)
    {
        _taskSubject = task;
        if(_taskSubject != NULL)
        {
            _worldElementSubject = NULL;
            _subject = "";
        }
        onModified(tr("Subject changed"));
    }
}
void VTriple::setSubject(QString subject)
{
    if(_subject != subject)
    {
        _subject = subject;
        if(_subject != NULL)
        {
            _worldElementSubject = NULL;
            _taskSubject = NULL;
        }
        onModified(tr("Subject changed"));
    }
}
QString VTriple::getSubject() const
{
    if(_worldElementSubject != NULL)
        return _worldElementSubject->getName();
    else if(_taskSubject != NULL)
        return _taskSubject->getId();
    else
        return _subject;
}

void VTriple::setObject(VWorldModelElement * worldModelElement)
{
    if(worldModelElement != _worldElementObject)
    {
        _worldElementObject = worldModelElement;
        if(_worldElementObject != NULL)
        {
            _object = "";
        }
        onModified(tr("Object changed"));
    }
}
void VTriple::setObject(bool value)
{
    QString s = value ? "true" : "false";
    setObject(s);
}

void VTriple::setObject(QString object)
{
    if(_object != object)
    {
        _object = object;
        if(_object != NULL)
        {
            _worldElementSubject = NULL;
        }
        onModified(tr("Object changed"));
    }
}
QString VTriple::getObject() const
{
    if(_worldElementObject != NULL)
        return _worldElementObject->getName();
    else
        return _object;
}

QString VTriple::toString(QString tabulation) const
{
    return "\n" + tabulation + "(\"" + getSubject() + "\", \"" + getPredicate() + "\", \"" + getObject() + "\")";
}

/**
 * @brief clone
 * @return Le clone
 */
VTriple * VTriple::clone(QObject *parent) const
{
    VTriple * triple = new VTriple(*this, parent);
    return triple;
}
