#pragma once
#ifndef VWOBJECTCLASS_H
#define VWOBJECTCLASS_H

#include "vwentityclass.h"

class VWInstance;
class VWProperties;

class VWObjectClass : public VWEntityClass
{
    Q_OBJECT
private:
    /**
     * @brief _parent
     * L'objet parent
     */
    VWObjectClass * _parent;

    /**
     * @brief _childs
     * Les objets enfants
     * Contrainte: les enfants sont du même type
     */
    QList<VWObjectClass *> _childs;

    /**
     * @brief _properties
     * La liste des instances de cette classe
     */
    QList<VWInstance *> _instances;

    /**
     * @brief _type
     * enum Concrete, Abstract et Agent
     */
    QString _type;

    /**
     * @brief _typeIsEditable
     * Si le type est éditable
     * (editable si pas de parent)
     * @see _type
     */
    bool _typeIsEditable;

    VWProperties * _properties;
public:
    /**
     * @brief VWObjectClass
     * Constructeur par défaut
     * @param parent L'objet parent
     */
    explicit VWObjectClass(QObject *parent = 0);

    /**
     * @brief VWObjectClass
     * @param o L'objet à copier
     */
    VWObjectClass(const VWObjectClass& o);

    /**
     * @brief ~VWObjectClass
     * Destructeur
     */
    ~VWObjectClass();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setParent(VWObjectClass * parent);
    VWObjectClass * getParent() const;

    void addChild(VWObjectClass * child);
    void removeChild(VWObjectClass * child);
    QList<VWObjectClass *> getChilds() const;
    QList<VWObjectClass *> getAllChilds() const;
    QList<VWObjectClass *> getAllChilds(VWComponentClass * component) const;
    VWObjectClass * getChildByUid(qint64 uid) const;
    VWObjectClass * getChildByName(QString name) const;

    void setType(QString type);
    QString getType() const;

    void setTypeIsEditable(bool typeIsEditable);
    bool getTypeIsEditable() const;

    void addInstance(VWInstance * instance);
    void removeInstance(VWInstance * instance);

    QList<VWInstance *> getInstances() const;
    QList<VWInstance *> getAllInstances() const;
    VWInstance * getInstanceByUid(qint64 uid) const;
    VWInstance * getAllInstanceByUid(qint64 uid) const;
    VWInstance * getAllInstanceByName(QString name) const;

    QPointer<VWProperty> addProperty(QDomElement elem);
    VWProperties * getProperties() const;
    QList<QPointer<VWProperty> > getAllProperties() const;

    void onClassModified(QObject * object = NULL);

public slots:
    void onModified();
    void onModified(QString message, QObject * object = NULL);

signals:
    void classModified(QObject * object = NULL);
};

#endif // VWOBJECTCLASS_H
