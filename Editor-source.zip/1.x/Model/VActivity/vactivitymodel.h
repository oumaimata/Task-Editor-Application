#pragma once
#ifndef VACTIVITYMODEL_H
#define VACTIVITYMODEL_H

#include <QtXml>

#include "vtaskcontainer.h"
#include "VActivitySpeechAct/VSubject/VContent/vactivityspeechactcontenttype.h"

class VTag;
class VTask;
class VPrefix;
class VSpeechAct;
class VBasisCondition;
class VTaskContainter;

/*!
 This class contains all the tasks of the application and provides
 an interface to manage those tasks and signals for events
 related to the tasks.
 \brief The activity model of the application.
*/
class VActivityModel : public VTaskContainer
{
    Q_OBJECT

private:
    /**
     * @brief _version
     * Version du modèle
     */
    QString _version;

    /**
     * @brief _namespaces
     * Liste de préfix
     */
    QList<VPrefix *> _namespaces;

    /**
     * @brief _tags
     * Liste de tags
     */
    QList<QPointer<VTag> > _tags;

    /**
     * @brief _predifinedTags
     * Liste de tags prédéfinis
     */
    QMap<QString,QColor> _predifinedTags;

    /**
     * @brief _speechActs
     * Liste d'actes de langage
     */
    QList<QPointer<VSpeechAct> > _speechActs;
    /**
     * @brief _predefiniedPerformatives
     * Liste des performatifs pouvant être utilisés dans les actes de langage
     */
    QMap<QString, QList<VSpeechActContentType> > _predefiniedPerformatives;


protected:
    /*!
     Overrides childTaskAdded(VTask* parent)
    */
    void childTaskAdded(VTask* task);

    /*!
     Overrides childTaskRemoved(VTask* parent)
    */
    void childTaskRemoved(VTask* task);

    /*!
     Overrides childTaskModified(VTask* parent)
    */
    void childTaskModified(VTask* task);

public:
    /*!
     \brief Default constructor of the class, inherited from QObject.
     \param parent The parent of the object.
    */
    explicit VActivityModel(QObject* parent = NULL);

    /**
     * @brief newActivityModel
     * crèe un nouveau model
     */
    void newActivityModel();
    /**
     * @brief setDefaultActivityModel
     * affecte un modèle par défaut
     */
    void setDefaultActivityModel();
    /**
     * @brief VActivityModel
     * Destructeur
     */
    ~VActivityModel();

    /**
     * @brief resetModel
     * Vide le model
     */
    void resetModel();

    /**
     * @brief loadModel
     * Permet de charger un model
     * @param xmlModel Le modèle en xml
     */
    void loadModel(QString xmlModel);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    /**
     * @brief CreateTaskTree
     * Creation de l'arborescence entre les taches car
     * @param treeOfTaskById représentation de l'arborescence des taches
     */
    void CreateTaskTree(QMap<VTask *, QList<QString> > treeOfTaskById);

    /**
     * @brief CreateRefTagOfTasks
     * Creation des références aux ref-tags des task
     * @param refTagOfTaskById liste de pair de (id tache, pair (id tag, value tag))
     */
    void CreateRefTagOfTasks(QMap<VTask *, QMap<QString, QString> > refTagOfTaskById);

    /**
     * @brief CreateTagTree
     * Creation de l'arborescence entre les tags
     * @param treeOfTagsById Liste de pair (id père, id fils)
     */
    void CreateTagTree(QMap<int, int> treeOfTagsById);

    VTask * getTaskByUid(qint64 uid) const;

    /**
     * @brief getTaskById
     * Obtient la tâche ayant l'id passé en argument
     * @param id L'id d'un tâche
     * @return La tâche si elle existe sinon null
     */
    VTask * getTaskById(QString id) const;

    /**
     * @brief getTagById
     * Obtient le tag ayant l'id passé en argument
     * @param id L'id d'un tag
     * @return Le tag s'i elle'il existe sinon null
     */
    VTag * getTagById(qint64 uid);

    // --- setter & getter --- begin

    void setVersion(QString version);

    QString getVersion();

    void addNamespace(VPrefix *prefix);

    void removeNamespace(VPrefix *prefix);

    VPrefix * getNamespace(QString prefix) const;

    QList<VPrefix *> getNamespaces();

    void addTag(QPointer<VTag> tag);

    void removeTag(QPointer<VTag> tag);

    QList<QPointer<VTag> > getTags() const;

    // --- setter & getter --- end

    QList<VBasisCondition *> getAllBasisConditions() const;

    QList<QPointer<VSpeechAct> > getSpeechActs() const;

    void setSpeechActs(QList<QPointer<VSpeechAct> > speechActs);

    QMap<QString, QList<VSpeechActContentType> > getPredefiniedPerformatives() const;

    void setPredefiniedPerformatives(QMap<QString, QList<VSpeechActContentType> > predefiniedPerformatives);

signals:
    /*!
     \brief Signal sent when a task has been added to the activity model.
     \param parent The parent task of the added task.
    */
    void taskAdded(VTask* parent);

    /*!
     \brief Signal sent when a task has been deleted from the activity model.
     \param parent The parent task of the deleted task.
    */
    void taskRemoved(VTask* parent);

    /*!
     \brief Signal sent when a task has been modified in the activity model.
     \param task The modified task.
    */
    void taskModified(VTask* task);

public slots:

    void onModified();

    void onModified(QString message, QObject * object = NULL);
};

#endif // VACTIVITYMODEL_H
