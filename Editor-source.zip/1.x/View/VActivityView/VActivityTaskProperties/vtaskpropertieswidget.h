#pragma once
#ifndef VTASKPROPERTIESWIDGET_H
#define VTASKPROPERTIESWIDGET_H

#include <QTabWidget>

class VTask;
class VActivityModel;

namespace Ui {
class VTaskPropertiesWidget;
}

/*!
 \brief
*/
class VTaskPropertiesWidget : public QTabWidget
{
    Q_OBJECT

private:
    Ui::VTaskPropertiesWidget *ui;

    /**
     * @brief _task
     * La tâche en cour d'édition
     */
    VTask* _task;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief _activityModel
     * Le modèle d'activité
     */
    VActivityModel * _activityModel;

public:

    /**
     * @brief VTaskPropertiesWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VTaskPropertiesWidget(QWidget* parent = NULL);

    /**
     * @brief setTask
     * Définit la tâche
     * @param task La tâche
     */
    void setTask(VTask* task);

    /**
     * @brief setActivityModel
     * Définit le modèle d'activité en cours
     * @param activityModel Le modèle d'activité en cours
     */
    void setActivityModel(VActivityModel * activityModel);

public slots:
    /**
     * @brief update
     * Met à jour les widget contenus
     */
    void update();

    /**
     * @brief update
     * Met à jour les widget contenus
     */
    void update(QString message, QObject *object = NULL);
};

#endif // VTASKPROPERTIESWIDGET_H
