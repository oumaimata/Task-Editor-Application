#pragma once
#ifndef VWACTIONCLASS_H
#define VWACTIONCLASS_H

#include "vwentityclass.h"

class VWBehaviourClass;
class VWProperties;

class VWActionClass : public VWEntityClass
{
    Q_OBJECT
private:
    /**
     * @brief _behaviours
     * Liste des comportements activables
     */
    QList<QPointer<VWBehaviourClass> > _behaviours;

    /**
     * @brief _properties
     * Liste des VWProperty
     */
    VWProperties * _properties;

public:
    /**
     * @brief VWActionClass
     * Constructeur par défaut
     * @param parent L'objet parent
     */
    explicit VWActionClass(QObject *parent = 0);

    /**
     * @brief VWActionClass
     * @param o L'objet à copier
     */
    VWActionClass(const VWActionClass& o);

    /**
     * @brief ~VWActionClass
     * Destructeur
     */
    ~VWActionClass();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void addBehaviour(VWBehaviourClass * behaviourClass);
    void removeBehaviour(VWBehaviourClass * behaviourClass);
    QList<QPointer<VWBehaviourClass> > getBehaviours() const;

    QPointer<VWProperty> addProperty(QDomElement elem);
    VWProperties * getProperties() const;
};

#endif // VWACTIONCLASS_H
