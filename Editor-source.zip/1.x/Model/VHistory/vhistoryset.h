#pragma once
#ifndef VHISTORYSET_H
#define VHISTORYSET_H

#include <QObject>
#include "vhistorystate.h"

/**
 * @brief The VHistorySet class
 * Ensemble de VHistoryState
 * @see VHistoryState
 */
class VHistorySet : public QObject
{
    Q_OBJECT

private:
    QList<VHistoryState> listHistoryState;
    /**
     * @brief _lastHistoryStateSaved;
     * Dernier HistoryState enregistré
    */
    VHistoryState _lastHistoryStateSaved;

public:

    VHistorySet();

    VHistorySet(const VHistorySet & historySet);

    const VHistoryState last() const;

    QString lastValue() const;

    void push_back(QString label, QString desc);

    void push_back(QString label, QString desc, QString value);

    VHistoryState pop_back();

    VHistoryState pop_front();

    void clear();

    int size() const;

    const VHistoryState at(int index) const;

    VHistoryState getLastHistoryStateSaved() const;

    void setLastHistoryStateSaved(const VHistoryState lastHistoryStateSaved);

signals:
    void hasChanged();
};

#endif // VHISTORYSET_H
