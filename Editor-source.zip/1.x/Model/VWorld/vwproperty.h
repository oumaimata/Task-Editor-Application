#pragma once
#ifndef VWPROPERTY_H
#define VWPROPERTY_H

#include <QtXml>

class VWPropertyType;
class VWComponentClass;
class VWorldModelElement;

/**
 * @brief VWProperty
 * Gère les propriétés
 * Name + Type
 */
class VWProperty : public QObject
{
    Q_OBJECT
private:

    /**
     * @brief _currentUid
     * Compteur automatique d'identifiant
     */
    static qint64 currentUid;

    static QHash<QString, QList<VWProperty *> > s_sharedProperties;

    /**
     * @brief _uid
     * Identifiant unique de l'élément
     */
    qint64 _uid;

    QString _name;

    bool _isShared;

    VWPropertyType * _type;

    QPointer<VWComponentClass> _component;

    QList<QPointer<VWorldModelElement> > _worldModelElements;
protected:
    bool _edit;
public:
    explicit VWProperty(QObject *parent = 0);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    QString ToXml();

    QString ToXml(QString tabulation);

    qint64 getUid() const;

    void setName(QString name);

    QString getName() const;

    void setIsShared(QString type, bool isShared);

    bool getIsShared() const;

    void addWorldModelElement(QPointer<VWorldModelElement> worldModelElement);
    void removeWorldModelElement(QPointer<VWorldModelElement> worldModelElement);

    void setType(VWPropertyType * type);

    VWPropertyType * getType() const;

    static QList<VWProperty *> getSharedProperties();

    static QList<VWProperty *> getSharedProperties(QString type);

    static VWProperty * getSharedPropertyByUid(QString type, qint64 uid);

    /**
     * @brief operator ==
     * Opérateur de comparaison
     * @param worldModelElement L'élément à comparer
     * @return Si les deux object sont éguaux
     */
    bool operator==(const VWProperty& property) const;

    void setComponent(QPointer<VWComponentClass> component);

    QPointer<VWComponentClass> getComponent() const;

private:

    /**
     * @brief EmptyList
     * Utile pour l'initialisation de s_sharedProperties
     * @return Une liste vide
     */
    static QHash<QString, QList<VWProperty *> > EmptyList();

protected slots:

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     */
    void onModified();

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     * @param object L'object qui a été modifié
     */
    void onModified(QString message, QObject * object = NULL);

signals:

    /**
     * @brief modified
     * Signal envoyé lors de modification sur un VWorldModelElement
     * @param object L'object qui a été modifié
     */
    void modified(QString message, QObject * object);
};

#endif // VWPROPERTY_H
