#pragma once
#ifndef VSPEECHACT_H
#define VSPEECHACT_H
#include "../VActivityCommon/vactivitymodelelement.h"
#include "VAddressee/vaddressee.h"
#include "VSubject/vsubject.h"
class VSpeechActContent;


class VSpeechAct : public VActivityModelElement
{
    Q_OBJECT
public:
    VSpeechAct(QObject* parent = 0);
    VSpeechAct(const VSpeechAct& speechAct, QObject* parent = 0);
    ~VSpeechAct();

    VAddressee* getAddressee() const;
    void setAddressee(VAddressee *addressee);

    VSubject* getSubject() const;
    void setSubject(VSubject* subject);
    
    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);
    
    QString ToXml(QString tabulation = "");

    VSpeechAct* clone()const;

private:

    VAddressee* _addressee;
    VSubject* _subject;

};

#endif // VSPEECHACT_H
