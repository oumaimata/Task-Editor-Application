#pragma once
#ifndef VTRIPLEPREDICATECOMBOBOX_H
#define VTRIPLEPREDICATECOMBOBOX_H

#include <QComboBox>

class VTriple;
class VStatement;

class VTriplePredicateComboBox : public QComboBox
{
    Q_OBJECT
private:
    VTriple * _triple;
    VStatement * _statement;
public:
    explicit VTriplePredicateComboBox(VStatement * statement, VTriple * triple, QWidget *parent = 0);

public slots:
    void onCurrentIndexChanged(int index);
};

#endif // VTRIPLEPREDICATECOMBOBOX_H
