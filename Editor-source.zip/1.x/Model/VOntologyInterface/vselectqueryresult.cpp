#include "vselectqueryresult.h"

#include <exception>
#include <stdexcept>

VSelectQueryResult::VSelectQueryResult(const QString& queryResult): // throw(std::runtime_error)
    _document("SelectQueryResult")
{
    if (!_document.setContent(queryResult))
    {
        throw std::runtime_error("Unable to parse XML query result.");
    }
}

QList<QMap<QString, QString> > VSelectQueryResult::getVariablesValues(const QStringList& variables) const //throw(std::runtime_error)
{
    QStringList neededVariables;
    QDomElement rootElem = _document.documentElement();
    QList<QMap<QString, QString> > result;

    /*
     * Getting needed variables.
     */
    // No variables specified, get all of them.
    if (variables.isEmpty())
    {
        QDomElement headElem = rootElem.firstChildElement("head");
        if (headElem.isNull())
            throw std::runtime_error("Select query result has no element named head.");

        QDomElement variableElem = headElem.firstChildElement("variable");
        while (!variableElem.isNull())
        {
            if (variableElem.hasAttribute("name"))
                neededVariables.push_back(variableElem.attribute("name"));
            variableElem = variableElem.nextSiblingElement("variable");
        }
    }
    // Variables specified
    else
    {
        neededVariables = variables;
    }

    /*
     * Getting variables values.
     */
    QDomElement resultsElem = rootElem.firstChildElement("results");
    if (resultsElem.isNull())
    {
        throw std::runtime_error("Select query result has no element named results.");
    }

    QDomElement resultElem = resultsElem.firstChildElement("result");
    while (!resultElem.isNull())
    {
        QMap<QString, QString> bindings;

        QDomElement bindingElem = resultElem.firstChildElement("binding");
        while (!bindingElem.isNull())
        {
            QString bindingName = bindingElem.attribute("name");
            if (!bindingName.isNull() && neededVariables.contains(bindingName))
                bindings.insert(bindingName, bindingElem.firstChildElement().text());

            bindingElem = bindingElem.nextSiblingElement("binding");
        }

        if (!bindings.isEmpty())
            result.push_back(bindings);

        resultElem = resultElem.nextSiblingElement("result");
    }

    return result;
}

QStringList VSelectQueryResult::getVariableValue(const QString& variable) const // throw(std::runtime_error)
{
    QDomElement rootElem = _document.documentElement();
    QStringList result;

    /*
     * Getting variables value.
     */
    QDomElement resultsElem = rootElem.firstChildElement("results");
    if (resultsElem.isNull())
        throw std::runtime_error("Select query result has no element named results.");

    QDomElement resultElem = resultsElem.firstChildElement("result");
    while (!resultElem.isNull())
    {
        QDomElement bindingElem = resultElem.firstChildElement("binding");
        while (!bindingElem.isNull())
        {
            QString bindingName = bindingElem.attribute("name");
            if (!bindingName.isNull() && bindingName == variable)
            {
                result.push_back(bindingElem.firstChildElement().text());
            }

            bindingElem = bindingElem.nextSiblingElement("binding");
        }

        resultElem = resultElem.nextSiblingElement("result");
    }

    return result;
}
