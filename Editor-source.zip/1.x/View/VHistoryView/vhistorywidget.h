#pragma once
#ifndef VHISTORYWIDGET_H
#define VHISTORYWIDGET_H

#include <QWidget>

class VHistoryActivityWidget;
class VHistoryWorldWidget;

namespace Ui {
class VHistoryWidget;
}

/**
 * @brief The VHistoryWidget class
 * Classe permettant l'affichage des historiques (activité + monde)
 */
class VHistoryWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VHistoryWidget *ui;
    
public:
    explicit VHistoryWidget(QWidget *parent = 0);
    ~VHistoryWidget();

    VHistoryActivityWidget* getHistoryActivityWidget();
    VHistoryWorldWidget* getHistoryWorldWidget();
    
private:
    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
};

#endif // VHISTORYWIDGET_H
