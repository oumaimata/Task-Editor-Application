#pragma once
#ifndef VTASKCONSTRUCTORITEM_H
#define VTASKCONSTRUCTORITEM_H

#include <QGraphicsEllipseItem>

class VTaskItem;

/**
 * @brief The VTaskConstructorItem class
 * Outil graphique permettant d'afficher le système de dépliement des tâches.
 * Il consiste en un rond qui contient
 * - un "+" si les sous-tâches sont repliées
 * - un "-" si les sous-tâches sont depliées
 */
class VTaskConstructorItem : public QGraphicsEllipseItem
{
private:
    bool _expanded;
    VTaskItem * _taskItem;

protected:

    /*!
     * \brief VTaskConstructorItem::mouseDoubleClickEvent
     * Gère l'événement souris du double click
     * \param event Les informations sur l'événement
     */
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event);

    /*!
     * \brief VTaskConstructorItem::mouseMoveEvent
     * Gère l'événement souris du déplacement de la souris
     * \param event Les informations sur l'événement
     */
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);

    /*!
     * \brief VTaskConstructorItem::dragEnterEvent
     * Gère l'événement souris du glisser (du glisser/déposer)
     * \param event Les informations sur l'événement
     */
    void dragEnterEvent(QGraphicsSceneDragDropEvent* event);

    /*!
     * \brief VTaskConstructorItem::dropEvent
     * Gère l'événement souris déposer (du glisser/déposer)
     * \param event Les informations sur l'événement
     */
    void dropEvent(QGraphicsSceneDragDropEvent* event);

    /*!
     * \brief VTaskConstructorItem::itemChange
     * Gère le changement de sélection
     * \param change Les informations sur l'événement
     * \param value Si sélectionné
     * \return value
     */
    QVariant itemChange(GraphicsItemChange change, const QVariant &value);

public:
    enum {Type = UserType + 2};

    /*!
     * \brief VTaskConstructorItem::VTaskConstructorItem
     * Constructeur
     * \param x La position sur l'axe des x
     * \param y La position sur l'axe des y
     * \param width La largueur
     * \param height La longueur
     * \param expanded Si déplié
     * \param parent L'objet parent
     */
    VTaskConstructorItem(qreal x, qreal y, qreal width, qreal height, bool expanded, VTaskItem* parent);

    /*!
     * \brief VTaskConstructorItem::type
     * Obtient Type
     * \return Le type
     */
    virtual int type() const;

    /*!
     * \brief VTaskConstructorItem::paint
     * Dessine le controle
     * \param painter
     * \param option
     * \param widget
     */
    virtual void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget);
};

#endif // VTASKCONSTRUCTORITEM_H
