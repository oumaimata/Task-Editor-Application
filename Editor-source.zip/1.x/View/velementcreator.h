#pragma once
#ifndef VELEMENTCREATOR_H
#define VELEMENTCREATOR_H

#include <QWidget>

namespace Ui {
class VElementCreator;
}

class VElementCreator : public QWidget
{
    Q_OBJECT

private:
    /**
     * @brief m_DialogResult
     * Le résultat de la fenêtre de dialogue
     */
    int m_DialogResult;
    
public:
    /**
     * @brief VElementCreator
     * Constructeur
     * @param parent Le widget parent
     */
    explicit VElementCreator(QWidget *parent = 0);

    /**
     * @brief ~VElementCreator
     * Destructeur
     */
    ~VElementCreator();

    /**
     * @brief setName
     * Défnie le nom de l'élément à créer
     * @param name Le nom de l'élément à créer
     */
    void setName(QString name);

    /**
     * @brief getName
     * Obitent le nom de l'élément à créer
     * @return Le nom de l'élément à créer
     */
    QString getName();

    /**
     * @brief getDialogResult
     * Obtient le résultat de la fenêtre de dialogue
     * @return Le résultat de la fenêtre de dialogue
     * -1 : Cancel
     *  0 : Create
     *  1 : Create and Edit
     */
    int getDialogResult();

    /**
     * @brief close
     * Overrides QWidget::close()
     */
    void close();

signals:
    void closed();
    
private slots:
    /**
     * @brief on_bCreate_clicked
     * Gère la clique sur le bouton Create
     */
    void on_bCreate_clicked();

    /**
     * @brief on_bCreateAndEdit_clicked
     * Gère la clique sur le bouton Create and Edit
     */
    void on_bCreateAndEdit_clicked();

    /**
     * @brief on_bCancel_clicked
     * Gère la clique sur le bouton Cancel
     */
    void on_bCancel_clicked();

private:
    Ui::VElementCreator *ui;
};

#endif // VELEMENTCREATOR_H
