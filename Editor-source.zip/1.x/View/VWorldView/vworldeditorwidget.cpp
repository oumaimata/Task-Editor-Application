#include "vworldeditorwidget.h"
#include "ui_vworldeditorwidget.h"

#include "VWorldClassEditorView/vwactionclasseditorwidget.h"
#include "VWorldClassEditorView/vwbehaviourclasseditorwidget.h"
#include "VWorldClassEditorView/vwcomponentclasseditorwidget.h"
#include "VWorldClassEditorView/vweventclasseditorwidget.h"
#include "VWorldClassEditorView/vwobjectclasseditorwidget.h"
#include "VWorldInstanceEditorView/vwinstanceeditorwidget.h"

#include "Model/VWorld/VWorldClass/vwactionclass.h"
#include "Model/VWorld/VWorldClass/vwbehaviourclass.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"
#include "Model/VWorld/VWorldClass/vweventclass.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"
#include "Model/VWorld/VWorldInstance/vwinstance.h"

VWorldEditorWidget::VWorldEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWorldEditorWidget)
{
    ui->setupUi(this);
    actionClassEditorWidget = new VWActionClassEditorWidget(this);
    behaviourClassEditorWidget = new VWBehaviourClassEditorWidget(this);
    componentClassEditorWidget = new VWComponentClassEditorWidget(this);
    eventClassEditorWidget = new VWEventClassEditorWidget(this);
    objectClassEditorWidget = new VWObjectClassEditorWidget(this);
    instanceEditorWidget = new VWInstanceEditorWidget(this);

    this->layout()->addWidget(actionClassEditorWidget);
    this->layout()->addWidget(behaviourClassEditorWidget);
    this->layout()->addWidget(componentClassEditorWidget);
    this->layout()->addWidget(eventClassEditorWidget);
    this->layout()->addWidget(objectClassEditorWidget);
    this->layout()->addWidget(instanceEditorWidget);

    connect(instanceEditorWidget, SIGNAL(instanceRemoved()), this, SLOT(onInstanceRemoved()));

    updateDisplay();
}

VWorldEditorWidget::~VWorldEditorWidget()
{
    if(actionClassEditorWidget != NULL) delete actionClassEditorWidget;
    if(behaviourClassEditorWidget != NULL) delete behaviourClassEditorWidget;
    if(componentClassEditorWidget != NULL) delete componentClassEditorWidget;
    if(eventClassEditorWidget != NULL) delete eventClassEditorWidget;
    if(objectClassEditorWidget != NULL) delete objectClassEditorWidget;
    if(instanceEditorWidget != NULL) delete instanceEditorWidget;
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWorldEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWorldEditorWidget::setCurrentEdit(QPointer<VWorldModelElement> currentEdit)
{
    if(currentEdit == NULL)
    {
        updateDisplay();
        return;
    }
    VWActionClass * actionClass = qobject_cast<VWActionClass *>(currentEdit);
    if(actionClass != NULL)
    {
        editActionClass(actionClass);
        return;
    }
    VWBehaviourClass * behaviourClass = qobject_cast<VWBehaviourClass *>(currentEdit);
    if(behaviourClass != NULL)
    {
        editBehaviourClass(behaviourClass);
        return;
    }
    VWComponentClass * componentClass = qobject_cast<VWComponentClass *>(currentEdit);
    if(componentClass != NULL)
    {
        editComponentClass(componentClass);
        return;
    }
    VWEventClass * eventClass = qobject_cast<VWEventClass *>(currentEdit);
    if(eventClass != NULL)
    {
        editEventClass(eventClass);
        return;
    }
    VWObjectClass * objectClass = qobject_cast<VWObjectClass *>(currentEdit);
    if(objectClass != NULL)
    {
        editObjectClass(objectClass);
        return;
    }
    VWInstance * instance = qobject_cast<VWInstance *>(currentEdit);
    if(instance != NULL)
    {
        editInstance(instance);
        return;
    }
}

void VWorldEditorWidget::editActionClass(VWActionClass * actionClass)
{
    actionClassEditorWidget->setActionClass(actionClass);
    updateDisplay(actionClassEditorWidget);
}

void VWorldEditorWidget::editBehaviourClass(VWBehaviourClass * behaviourClass)
{
    behaviourClassEditorWidget->setBehaviourClass(behaviourClass);
    updateDisplay(behaviourClassEditorWidget);
}

void VWorldEditorWidget::editComponentClass(VWComponentClass * componentClass)
{
    componentClassEditorWidget->setComponentClass(componentClass);
    updateDisplay(componentClassEditorWidget);
}

void VWorldEditorWidget::editEventClass(VWEventClass * eventClass)
{
    eventClassEditorWidget->setEventClass(eventClass);
    updateDisplay(eventClassEditorWidget);
}

void VWorldEditorWidget::editObjectClass(VWObjectClass * objectClass)
{
    objectClassEditorWidget->setObjectClass(objectClass);
    updateDisplay(objectClassEditorWidget);
}

void VWorldEditorWidget::editInstance(VWInstance * instance)
{
    instanceEditorWidget->setInstanceClass(instance);
    updateDisplay(instanceEditorWidget);
}

void VWorldEditorWidget::updateDisplay(QWidget * widget)
{
    actionClassEditorWidget->hide();
    behaviourClassEditorWidget->hide();
    componentClassEditorWidget->hide();
    eventClassEditorWidget->hide();
    objectClassEditorWidget->hide();
    instanceEditorWidget->hide();

    if(widget != NULL) widget->show();
}

void VWorldEditorWidget::onInstanceRemoved()
{
    setCurrentEdit(NULL);
}
