#include <iostream>
#include <QInputDialog>
#include "voperationtabwidget.h"
#include "ui_voperationtabwidget.h"


#include "../../velementcreator.h"

#include "Model/vapplicationmodel.h"
#include "Model/VActivity/vtask.h"
#include "Model/VActivity/VActivityCommon/vrefconcept.h"
#include "Model/VActivity/VActivityOperation/voperation.h"
#include "Model/VActivity/VActivityCommon/vparam.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwactionclass.h"
#include "Controller/vtracecontroller.h"
#include "Controller/vapplicationcontroller.h"
#include "../VActivityToolsView/vtreewidgetitemdata.h"

#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivityCondition/vnottriples.h"
#include "Model/VActivity/VActivityCondition/vstatement.h"
#include "Model/VActivity/VActivityCondition/vmacro.h"
#include "Model/VActivity/VActivityCondition/vvar.h"
#include "Controller/vtracecontroller.h"
#include "Model/VActivity/VActivitySpeechAct/VSubject/VContent/vactivityspeechactcontenttype.h"
#include "View/VActivityView/VActivityToolsView/vagentcombobox.h"
#include "View/VActivityView/VActivityToolsView/vstatementtypecombobox.h"
#include "View/VActivityView/VActivityToolsView/vtripleobjectcheckbox.h"
#include "View/VActivityView/VActivityToolsView/vtriplepredicatecombobox.h"
#include "View/VActivityView/VActivityToolsView/vtripleobjectwidget.h"
#include "View/VActivityView/VActivityToolsView/vtriplesubjectwidget.h"
#include "View/VActivityView/VActivityToolsView/vinstancecombobox.h"

/**
 * @brief VOperationTabWidget
 * Constructeur
 * @param parent L'objet parent
 */
VOperationTabWidget::VOperationTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VOperationTabWidget),
    _actionComboBoxEdit(false),
    _performativeComboBoxEdit(false),
    _contentTypeGroupEdit(false),
    _task(NULL),
    _operation(NULL),
    _elementCreator(NULL)
{
    ui->setupUi(this);

    /*setup the SpeechAct widget*/
    ui->speechActWidget->setVisible(false);
    ui->performativeComboBox->addItem("");
    QMap<QString, QList<VSpeechActContentType> > performatives= VApplicationModel::getInstance()->getActivityModel().getPredefiniedPerformatives();
    QMapIterator<QString, QList<VSpeechActContentType> > i(performatives);
    while(i.hasNext()){
        i.next();
        QStringList contentTypeStringList;
        foreach(VSpeechActContentType contentType, i.value()){
            contentTypeStringList.append(VSpeechActContentTypeToString( contentType));
        }
        ui->performativeComboBox->addItem(i.key(),QVariant::fromValue(contentTypeStringList));
    }

}

/**
 * @brief ~VOperationTabWidget
 * Destructeur
 */
VOperationTabWidget::~VOperationTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VOperationTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setTask
 * Définit la tâche en cours d'édition
 * @param task La tâche en cours d'édition
 */
void VOperationTabWidget::setTask(VTask * task)
{
    if (task != _task)
    {
        VTraceController::get()->Info("VOperationTabWidget::setTask()", "Task defined");
        _task = task;
    }
    _operation = (_task == NULL) ? NULL : _task->getOperation();
    updateDisplay();
}

/**
 * @brief getTask
 * Obitent la tâche en cours d'édition
 * @return La tâche en cours d'édition
 */
VTask * VOperationTabWidget::getTask() const
{
    return _task;
}

/**
 * @brief updateDisplay
 * Met a jour les intefaces
 * en fonction de la tache sélectionnée
 */
void VOperationTabWidget::updateDisplay()
{
    // Vide la vue refconcept
    int RowCountRefConcept = ui->refConceptWidget->rowCount();
    for(int i = 0; i < RowCountRefConcept; i++)
    {
        ui->refConceptWidget->removeRow(0);
    }
    // Vide la vue param
    int RowCountParam = ui->paramWidget->rowCount();
    for(int i = 0; i < RowCountParam; i++)
    {
        ui->paramWidget->removeRow(0);
    }
    // Vide la combo d'action
    _actionComboBoxEdit = true;
    ui->actionComboBox->clear();

    //
    _performativeComboBoxEdit = true;
    ui->performativeComboBox->setCurrentIndex(0);
    _contentTypeGroupEdit = true;
    ui->contentTypeGroup->setExclusive(false);
    ui->statementRadioButton->setChecked(false);
    ui->queryRadioButton->setChecked(false);
    ui->plainTextRadioButton->setChecked(false);
    ui->statementRadioButton->setEnabled(false);
    ui->queryRadioButton->setEnabled(false);
    ui->plainTextRadioButton->setEnabled(false);
    ui->contentTypeGroup->setExclusive(true);
    _contentTypeGroupEdit = false;

    ui->contentStatementWidget->setEnabled(false);
    ui->addresseeStatementWidget->setEnabled(false);
    ui->targetWidget->setEnabled(false);
    ui->targetLineEdit->clear();

    //Vide les arbres des statements
    int topLevelItemCount = ui->contentStatementTreeWidget->topLevelItemCount();
    for(int i = 0; i < topLevelItemCount; i++)
    {
        ui->contentStatementTreeWidget->takeTopLevelItem(0);
    }

    topLevelItemCount = ui->addresseeStatementTreeWidget->topLevelItemCount();
    for(int i = 0; i < topLevelItemCount; i++)
    {
        ui->addresseeStatementTreeWidget->takeTopLevelItem(0);
    }





    if(_task == NULL || _operation == NULL)
    {
        this->setEnabled(false);
    }
    else
    {
        this->setEnabled(true);
        updateRefConceptDisplay();
        updateParamDisplay();
        updateActionDisplay();
        updateSpeechActDisplay();

    }
}

/**
 * @brief updateRefConceptDisplay
 * Met a jour l'inteface des ref concepts
 * en fonction de la tache sélectionnée
 */
void VOperationTabWidget::updateRefConceptDisplay()
{
    // Met a jour la vue
    QList<VRefConcept *> refs = _operation->getRefs();
    for(int i = 0; i < refs.count(); i++)
    {
        ui->refConceptWidget->insertRow(0);

        QTableWidgetItem* itemPredicate = new QTableWidgetItem();
        itemPredicate->setText(refs[i]->getPredicate());
        itemPredicate->setData(Qt::UserRole, QString::number(refs[i]->getUid()));
        ui->refConceptWidget->setItem(0, 0, itemPredicate);

        QTableWidgetItem* itemRef = new QTableWidgetItem();
        itemRef->setText(refs[i]->getRef());
        itemRef->setData(Qt::UserRole, QString::number(refs[i]->getUid()));
        ui->refConceptWidget->setItem(0, 1, itemRef);
    }
    // Update de la combo
    ui->refConceptComboBox->clear();
    ui->refConceptComboBox->addItem("");
    QList<VRefConcept *> refConcepts = VRefConcept::getAllRefConcepts();
    for(int i = 0; i < refConcepts.count(); i++)
    {
        ui->refConceptComboBox->addItem(refConcepts[i]->getPredicate() + " - " +
                                        refConcepts[i]->getRef(), QString::number(refConcepts[i]->getUid()));
    }
}


void VOperationTabWidget::updateSpeechActDisplay()
{
    VSpeechAct * speechAct = _operation->getSpeechAct();
    if(speechAct != NULL){
        //performatif
        QString * performative = speechAct->getSubject()->getPerformative();
        if(performative != NULL){
            int currentIndex = ui->performativeComboBox->findText(*performative);
            ui->performativeComboBox->setCurrentIndex(currentIndex);
        }
        else ui->performativeComboBox->setCurrentIndex(0);

        //type de contenu du speech act
        VStatement * contentStatement = NULL;
        VSpeechActContentType contentType = speechAct->getSubject()->getContent()->getType();
        if(contentType == STATEMENT){
            ui->statementRadioButton->setChecked(true);
            contentStatement = speechAct->getSubject()->getContent()->getStatement();
        }
        else if(contentType == QUERY){
            ui->queryRadioButton->setChecked(true);
            QString targetText = speechAct->getSubject()->getContent()->getQuery()->getTarget();
            ui->targetLineEdit->setText(targetText);
            contentStatement = speechAct->getSubject()->getContent()->getQuery()->getStatement();
        }
        else if(contentType == PLAIN_TEXT)
            ui->plainTextRadioButton->setChecked(true);


        if(contentStatement != NULL){
            ui->contentStatementWidget->setEnabled(true);
            addStatementItem(ui->contentStatementTreeWidget, NULL, contentStatement);
        }

        //addressee
        VAddressee*  addressee = speechAct->getAddressee();
        if(addressee != NULL){
            ui->addresseeStatementWidget->setEnabled(true);
            addAddresseeItem(ui->addresseeStatementTreeWidget, addressee);
        }


    }
    _performativeComboBoxEdit = false;
}

/**
 * @brief on_addRefConceptButton_clicked
 * Gère l'ajout de RefConcept
 */
void VOperationTabWidget::on_addRefConceptButton_clicked()
{
    VRefConcept * newRefConcept = new VRefConcept();

    QString id = ui->refConceptComboBox->itemData(ui->refConceptComboBox->currentIndex()).toString();
    if(!id.isNull() && !id.isEmpty())
    {
        VRefConcept * refConcept = VRefConcept::getRefConcept(id.toLong());
        newRefConcept->setPredicate(refConcept->getPredicate());
        newRefConcept->setRef(refConcept->getRef());
    }
    _operation->addRef(newRefConcept);
}

/**
 * @brief on_refConceptWidget_itemChanged
 * Gère les modifications de RefConcept
 * @param item
 */
void VOperationTabWidget::on_refConceptWidget_itemChanged(QTableWidgetItem *item)
{
    if(item != NULL)
    {
        QString var = item->data(Qt::UserRole).toString();
        VRefConcept * refConcept = _operation->getRefById(var.toInt());
        if(refConcept == NULL) return;
        if(item->column() == 0)
        {
            if(refConcept->getPredicate() != item->text())
            {
                refConcept->setPredicate(item->text());
            }
        }
        else if(item->column() == 1)
        {
            if(refConcept->getRef() != item->text())
            {
                refConcept->setRef(item->text());
            }
        }
    }
}

/**
 * @brief on_removeRefConceptButton_clicked
 * Gère la supression de RefConcept
 */
void VOperationTabWidget::on_removeRefConceptButton_clicked()
{
    QList<QTableWidgetItem *> selectedItems = ui->refConceptWidget->selectedItems();
    if(selectedItems.count() == 2)
    {
        QString var = selectedItems.first()->data(Qt::UserRole).toString();
        VRefConcept * refConcept = _operation->getRefById(var.toInt());
        if(refConcept != NULL)
        {
            _operation->removeRef(refConcept);
            delete refConcept;
            updateDisplay();
        }
    }
}

/**
 * @brief updateParamDisplay
 * Met a jour l'inteface des params
 * en fonction de la tache sélectionnée
 */
void VOperationTabWidget::updateParamDisplay()
{
    // Met a jour la vue
    QList<VParam *> params = _operation->getParams();
    for(int i = 0; i < params.count(); i++)
    {
        ui->paramWidget->insertRow(0);

        QTableWidgetItem* itemPredicate = new QTableWidgetItem();
        itemPredicate->setText(params[i]->getPredicate());
        itemPredicate->setData(Qt::UserRole, QString::number(params[i]->getUid()));
        ui->paramWidget->setItem(0, 0, itemPredicate);

        QTableWidgetItem* itemValue = new QTableWidgetItem();
        itemValue->setText(params[i]->getValue());
        itemValue->setData(Qt::UserRole, QString::number(params[i]->getUid()));
        ui->paramWidget->setItem(0, 1, itemValue);
    }
}

/**
 * @brief on_addRefConceptButton_clicked
 * Gère l'ajout de RefConcept
 */
void VOperationTabWidget::on_addParamButton_clicked()
{
    VParam * param = new VParam();
    _operation->addParam(param);
}

/**
 * @brief on_refConceptWidget_itemChanged
 * Gère les modifications de RefConcept
 * @param item
 */
void VOperationTabWidget::on_paramWidget_itemChanged(QTableWidgetItem *item)
{
    if(item != NULL)
    {
        QString var = item->data(Qt::UserRole).toString();
        VParam * param = _operation->getParamById(var.toInt());
        if(param == NULL) return;
        if(item->column() == 0)
        {
            if(param->getPredicate() != item->text())
            {
                param->setPredicate(item->text());
            }
        }
        else if(item->column() == 1)
        {
            if(param->getValue() != item->text())
            {
                param->setValue(item->text());
            }
        }
    }
}

/**
 * @brief on_removeRefConceptButton_clicked
 * Gère la supression de RefConcept
 */
void VOperationTabWidget::on_removeParamButton_clicked()
{
    QList<QTableWidgetItem *> selectedItems = ui->paramWidget->selectedItems();
    if(selectedItems.count() == 2)
    {
        QString var = selectedItems.first()->data(Qt::UserRole).toString();
        VParam * param = _operation->getParamById(var.toInt());
        if(param != NULL)
        {
            _operation->removeParam(param);
            delete param;
        }
    }
}

/**
 * @brief updateActionDisplay
 * Met a jour l'inteface de l'action
 * en fonction de la tache sélectionnée
 */
void VOperationTabWidget::updateActionDisplay()
{
    // Update de la combo d'action
    ui->actionComboBox->addItem("");

    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    QList<VWActionClass *> actions = worldModel->getActions();
    foreach(VWActionClass * action, actions)
    {
        ui->actionComboBox->addItem(action->getName(), action->getUid());
    }

    if(_operation->getAction() != NULL) ui->actionComboBox->setCurrentText(_operation->getAction()->getName());
    _actionComboBoxEdit = false;
}

/**
 * @brief on_actionComboBox_currentIndexChanged
 * Gère la modification de l'action
 * @param index Index du nouvel item sémectioné
 */
void VOperationTabWidget::on_actionComboBox_currentIndexChanged(int index)
{
    if(_task == NULL || _operation == NULL || _actionComboBoxEdit) return;
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    QString uid = ui->actionComboBox->itemData(index).toString();
    _operation->setAction(worldModel->getActionByUid(uid.toLong()));
}

/**
 * @brief VOperationTabWidget::on_addNewAction_clicked
 * Gère la demande d'ajout d'une nouvelle action
 */
void VOperationTabWidget::on_addNewAction_clicked()
{
    if(_task == NULL || _operation == NULL || _actionComboBoxEdit) return;

    _elementCreator = new VElementCreator(NULL);
    connect(_elementCreator, SIGNAL(closed()), this, SLOT(onElementCreatorClose()));
    _elementCreator->setWindowTitle(tr("Create an action"));
    _elementCreator->setName("Action " + QString::number(VWActionClass::getCurrentUid() + 1));
    _elementCreator->show();
}

void VOperationTabWidget::onElementCreatorClose()
{
    if(_elementCreator == NULL) return;

    // Create the new element
    if(_elementCreator->getDialogResult() >= 0)
    {
        VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
        VWActionClass * actionClass = new VWActionClass();
        actionClass->setName(_elementCreator->getName());
        worldModel->addAction(actionClass); // Add to the model
        _operation->setAction(actionClass); // Create the reference in the opertation's task

        // Open the new action in edition
        if(_elementCreator->getDialogResult() == 1)
        {
            VApplicationController::getInstance()->switchToWorld();
            VApplicationController::getInstance()->getWorldController()
                    ->setCurrentEdit(actionClass);
        }
    }
    disconnect(_elementCreator, SIGNAL(closed()), this, SLOT(onElementCreatorClose()));
    delete _elementCreator;
    _elementCreator = NULL;
}

void VOperationTabWidget::on_operationTypeGroup_buttonClicked(QAbstractButton *button){
    if( button->objectName() == "actionRadioButton"){
        ui->actionsWidget->setVisible(true);
        ui->speechActWidget->setVisible(false);
        _operation->setType(ACTION);

    }
    if(button->objectName() == "speechActRadioButton"){
        ui->speechActWidget->setVisible(true);
        ui->actionsWidget->setVisible(false);
        _operation->setType(SPEECHACT);
    }
}

void VOperationTabWidget::on_performativeComboBox_currentIndexChanged(int index){

    if(_task == NULL || _operation == NULL)
        return;

    if( _performativeComboBoxEdit == false){
        QString* performative = new QString (ui->performativeComboBox->itemText(index));
        if(!performative->isEmpty()){
            //Création du speech act s'il n'existe pas
            if(_operation->getSpeechAct() == NULL){
                VSpeechAct * speechAct = new VSpeechAct();
                VSubject * subject = new VSubject();
                VSpeechActContent * content = new VSpeechActContent();
                VAddressee* addressee = new VAddressee();
                subject->setContent(content);
                subject->setPerformative(performative);
                speechAct->setSubject(subject);
                speechAct->setAddressee(addressee);
                _operation->setSpeechAct(speechAct);
            }
            else{
                QString* oldPerformative = _operation->getSpeechAct()->getSubject()->getPerformative();
                if(oldPerformative != NULL) delete oldPerformative;
                _operation->getSpeechAct()->getSubject()->setPerformative(performative);
            }
            //updateSpeechActDisplay(); // A MODIFIER
        }
    }


    ui->statementRadioButton->setEnabled(false);
    ui->plainTextRadioButton->setEnabled(false);
    ui->queryRadioButton->setEnabled(false);

    //affichage des buttons radio correspondants aux types du contenu
    QStringList contentTypesStringList =  ui->performativeComboBox->itemData(index).toStringList();
    foreach(QString contentTypeString, contentTypesStringList){
        VSpeechActContentType contentType = VSpeechActContentTypeFromString( contentTypeString );
        if(contentType == STATEMENT)
            ui->statementRadioButton->setEnabled(true);
        if(contentType == QUERY)
            ui->queryRadioButton->setEnabled(true);
        if(contentType == PLAIN_TEXT)
            ui->plainTextRadioButton->setEnabled(true);
    }
}


void VOperationTabWidget::on_contentTypeGroup_buttonToggled(QAbstractButton *button, bool checked)
{
    if(_task == NULL || _operation == NULL || _contentTypeGroupEdit == true)
        return;
    VSpeechActContent* content = _operation->getSpeechAct()->getSubject()->getContent();
    if(checked == true){
        ui->contentStatementWidget->setEnabled(false);
        ui->targetWidget->setEnabled(false);

        QString typeString;
        if(button->objectName() == "plainTextRadioButton"){
            typeString = "PLAINTEXT";
        }
        else if(button->objectName() == "queryRadioButton"){
            typeString = "QUERY";
            ui->contentStatementWidget->setEnabled(true);
            ui->targetWidget->setEnabled(true);
            VStatement* statement = NULL;
            if(content->getStatement() != NULL){
                statement = content->getStatement();
                content->setStatement(NULL);
            }
            else statement = new VStatement();
            VQuery* query = content->getQuery();
            if(query == NULL ){
                query = new VQuery();
                query->setStatement(statement);
                content->setQuery(query);
            }
        }
        else if(button->objectName() == "statementRadioButton"){
            typeString = "STATEMENT";
            ui->contentStatementWidget->setEnabled(true);
            VStatement* statement = NULL;
            statement =  _operation->getSpeechAct()->getSubject()->getContent()->getStatement();
            if (statement == NULL){
                VStatement * statement = new VStatement();
                _operation->getSpeechAct()->getSubject()->getContent()->setStatement(statement);
            }

        }
        else typeString = "undefined_speech_act_type";

        content->setType(VSpeechActContentTypeFromString(typeString));
    }
}

void VOperationTabWidget::on_addContentStatementButton_clicked()
{
    if(ui->contentStatementTreeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedQTreeWidgetItem = ui->contentStatementTreeWidget->selectedItems().first();
        VTreeWidgetItemData * selectedItem = selectedQTreeWidgetItem->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

        if(selectedItem == NULL) return;

        // Déclaration :
        VCondition * condition = selectedItem->getCondition();
        VConditionLogicalOperator * cLO = selectedItem->getCLO();
        VStatement * statement = selectedItem->getStatement();
        VNotTriples * notTriples = selectedItem->getNotTriples();
        VTriple * triple = selectedItem->getTriple();
        VMacro * macro = selectedItem->getMacro();
        VVar * var = selectedItem->getVar();

        // Traitement des ajouts:
        if(macro != NULL)
        {
            var = new VVar(macro);
            macro->addVar(var);
        }
        else if(triple != NULL)
        {
            if(notTriples == NULL)
            {
                triple = new VTriple(statement);
                statement->addTriple(triple);
            }
            else
            {
                triple = new VTriple(notTriples);
                notTriples->addTriple(triple);
            }
        }
        else if(notTriples != NULL)
        {
            triple = new VTriple(notTriples);
            notTriples->addTriple(triple);
        }
        else if(statement != NULL)
        {
            // Demander soit nottriples soit triple soit macro -> IHM de demande à l'utilisateur
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a triple or a macro or a NOT ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "triple")
                {
                    triple = new VTriple(statement);
                    statement->addTriple(triple);
                }
                else if(choice.toLower() == "not")
                {
                    notTriples = new VNotTriples(statement);
                    triple = new VTriple(notTriples);
                    notTriples->addTriple(triple);
                    statement->addNotTriples(notTriples);
                }
                else if(choice.toLower() == "macro")
                {
                    macro = new VMacro(statement);
                    statement->addMacro(macro);
                }
            }
        }
        else if(cLO != NULL)
        {
            // Demander soit statement soit CLO -> IHM de demande à l'utilisateur
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a statement or a logical operator (AND, NOT, OR, XOR) ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "statement")
                {
//                    statement = new VStatement(cLO);
//                    cLO->addStatement(statement);
                    statement = new VStatement();
                }
//                else if(choice.toLower() == "and" || choice.toLower() == "not" || choice.toLower() == "xor" || choice.toLower() == "or")
//                {
//                    VConditionLogicalOperator * newCLO = new VConditionLogicalOperator((QObject *)cLO);
//                    newCLO->setType(choice.toUpper());
//                    cLO->addChild(newCLO);
//                }
            }
        }
        else if(condition != NULL)
        {
            // Demander soit statement soit CLO -> IHM de demande à l'utilisateur
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a statement or a logical operator (AND, NOT, OR, XOR) ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "statement")
                {
//                    statement = new VStatement(condition);
//                    condition->addStatement(statement);
                       statement = new VStatement();

                }
//                else if(choice.toLower() == "and" || choice.toLower() == "not" || choice.toLower() == "xor" || choice.toLower() == "or")
//                {
//                    VConditionLogicalOperator * newCLO = new VConditionLogicalOperator((QObject *)cLO);
//                    newCLO->setType(choice.toUpper());
//                    condition->addCLO(newCLO);
//                }
            }
        }

    }
    else
    {
//        VSpeechAct* speechAct = _operation->getSpeechAct();

//        VSpeechActContentType type = _operation->getSpeechAct()->getSubject()->getContent()->getType();
//        VStatement * statement = NULL;

//        if(type == STATEMENT){
//            statement =  speechAct->getSubject()->getContent()->getStatement();
//            if (statement == NULL){
//                VStatement * statement = new VStatement();
//                speechAct->getSubject()->getContent()->setStatement(statement);
//            }
//        }
//        if(type == QUERY){
//            VQuery * query = speechAct->getSubject()->getContent()->getQuery();
//            if(query == NULL ){
//                query = new VQuery();
//                query->setStatement(new VStatement());
//                speechAct->getSubject()->getContent()->setQuery(query);
//            }
//        }
    }
}

void VOperationTabWidget::on_removeContentStatementButton_clicked()
{
    if(ui->contentStatementTreeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedQTreeWidgetItem = ui->contentStatementTreeWidget->selectedItems().first();
        VTreeWidgetItemData * selectedItem = selectedQTreeWidgetItem->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

        if(selectedItem == NULL) return;

        // Déclaration :
        VStatement * statement = selectedItem->getStatement();
        VNotTriples * notTriples = selectedItem->getNotTriples();
        VTriple * triple = selectedItem->getTriple();
        VMacro * macro = selectedItem->getMacro();
        VVar * var = selectedItem->getVar();

        // Traitement des suppressions:
        if(var != NULL)
        {
            macro->removeVar(var);
            delete var;
        }
        else if(macro != NULL)
        {
            statement->removeMacro(macro);
            delete macro;
        }
        else if(triple != NULL)
        {
            if(notTriples != NULL)
            {
                notTriples->removeTriple(triple);
            }
            else if(statement != NULL)
            {
                statement->removeTriple(triple);
            }
            delete triple;
        }
        else if(notTriples != NULL)
        {
            statement->removeNotTriples(notTriples);
            delete notTriples;
        }
//        else if(statement != NULL)
//        {
//            if(cLO != NULL)
//            {
//                cLO->removeStatement(statement);
//                delete statement;
//            }
//            else if(condition != NULL)
//            {
//                condition->removeStatement(statement);
//                delete statement;
//            }
//        }
    }
}

void VOperationTabWidget::on_targetLineEdit_editingFinished()
{
    QString targetText = ui->targetLineEdit->text();
    if(_task == NULL || _operation == NULL)
        return;

    if(_operation->getSpeechAct() != NULL){
        _operation->getSpeechAct()->getSubject()->getContent()->getQuery()->setTarget(targetText);
    }
}


void VOperationTabWidget::on_addAddresseeStatementButton_clicked()
{
    if(ui->addresseeStatementTreeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedQTreeWidgetItem = ui->addresseeStatementTreeWidget->selectedItems().first();
        VTreeWidgetItemData * selectedItem = selectedQTreeWidgetItem->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

        if(selectedItem == NULL) return;

        // Déclaration :
        VAddressee * addressee = selectedItem->getAddressee();
        VStatement * statement = selectedItem->getStatement();
        VNotTriples * notTriples = selectedItem->getNotTriples();
        VTriple * triple = selectedItem->getTriple();
        VMacro * macro = selectedItem->getMacro();
        VVar * var = selectedItem->getVar();

        // Traitement des ajouts:
        if(macro != NULL)
        {
            var = new VVar(macro);
            macro->addVar(var);
        }
        else if(triple != NULL)
        {
            if(notTriples == NULL)
            {
                triple = new VTriple(statement);
                statement->addTriple(triple);
            }
            else
            {
                triple = new VTriple(notTriples);
                notTriples->addTriple(triple);
            }
        }
        else if(notTriples != NULL)
        {
            triple = new VTriple(notTriples);
            notTriples->addTriple(triple);
        }
        else if(statement != NULL)
        {
            // Demander soit nottriples soit triple soit macro -> IHM de demande à l'utilisateur
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a triple or a macro or a NOT ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "triple")
                {
                    triple = new VTriple(statement);
                    statement->addTriple(triple);
                }
                else if(choice.toLower() == "not")
                {
                    notTriples = new VNotTriples(statement);
                    triple = new VTriple(notTriples);
                    notTriples->addTriple(triple);
                    statement->addNotTriples(notTriples);
                }
                else if(choice.toLower() == "macro")
                {
                    macro = new VMacro(statement);
                    statement->addMacro(macro);
                }
            }
        }
        else if(addressee != NULL)
        {
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a statement or an agent ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "statement")
                {
                    statement = new VStatement(addressee);
                    addressee->addStatement(statement);
                }
                else if(choice.toLower() == "agent")
                {
                    VWInstance * instance = new VWInstance();
                    addressee->addAgent(instance);
                }
            }
        }

    }
    else
    {


    }
}

/**
 * @brief addAddresseeItem
 * Retourne et ajoute un item d'arbre correspondant à un addAddresseeItem
 */
QTreeWidgetItem * VOperationTabWidget::addAddresseeItem(QTreeWidget * parent, VAddressee * addressee)
{
    QTreeWidgetItem * item = new QTreeWidgetItem(parent);
    item->setExpanded(true);
    item->setFlags(item->flags() | Qt::ItemIsEditable);
    item->setText(0, tr("Addressee"));
    item->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(addressee));

    foreach(VStatement * statement, addressee->getStatements())
    {
        addStatementItem(ui->addresseeStatementTreeWidget, item, statement);
    }

    int i = 0;
    int size = addressee->getAgents().size();
    for(i =0; i< size; i++ ){
        addAgentItem(ui->addresseeStatementTreeWidget, item, addressee,i );
    }
    return item;
}

QTreeWidgetItem *VOperationTabWidget::addAgentItem(QTreeWidget *tree, QTreeWidgetItem *parent, VAddressee* addressee, int agentIndex)
{
    VWInstance* agent = addressee->getAgents().at(agentIndex);
    QTreeWidgetItem * agentItem = new QTreeWidgetItem(parent);
    agentItem->setText(0,"Agent");
    agentItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(agent));
    VAgentComboBox* agentComboBox = new VAgentComboBox(addressee, agentIndex, tree);
    tree->setItemWidget(agentItem, 1, agentComboBox);
    parent->addChild(agentItem);

    return agentItem;
}

QTreeWidgetItem * VOperationTabWidget::addStatementItem(QTreeWidget * tree, QTreeWidgetItem* parent, VStatement * statement)
{
    QTreeWidgetItem * statementItem = new QTreeWidgetItem(tree);
    statementItem->setExpanded(true);
    statementItem->setFlags(statementItem->flags() | Qt::ItemIsEditable);
    statementItem->setText(0, "statement");
//    statementItem->setFont(0, *blackFont);
    statementItem->setToolTip(1, "Type");
    QComboBox * typeComboBox = new VStatementTypeComboBox(statement);
    tree->setItemWidget(statementItem, 1, typeComboBox);

    statementItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement));
//    setItemBackgroundColor(statementItem, 2);
    if (parent != NULL){
        parent->addChild(statementItem);
    }
//    foreach(VNotTriples * notTriples, statement->getNotTriples())
//    {
//        QTreeWidgetItem * notTripleItem = new QTreeWidgetItem(statementItem);
//        notTripleItem->setText(0, "NOT");
//        notTripleItem->setFont(0, *blackFont);
//        notTripleItem->setExpanded(true);
//        notTripleItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, notTriples));
//        setItemBackgroundColor(notTripleItem, 1);
//        statementItem->addChild(notTripleItem);

//        foreach(VTriple * triple, notTriples->getTriples())
//        {
//            addTripleItem(notTripleItem, triple, statement, notTriples);
//        }
//    }

        foreach(VTriple * triple, statement->getTriples())
        {
            addTripleItem(tree, statementItem, triple, statement, NULL);
        }

//    foreach(VMacro * macro, statement->getMacros())
//    {
//        QTreeWidgetItem * macroItem = new QTreeWidgetItem(statementItem);
//        macroItem->setExpanded(true);
//        macroItem->setFlags(macroItem->flags() | Qt::ItemIsEditable);
//        macroItem->setText(0, "macro");
//        macroItem->setFont(0, *blackFont);
//        macroItem->setText(1, VActivityMacroTypeToString(macro->getOperator())); macroItem->setToolTip(1, "Operator");
//        macroItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, NULL, NULL, macro));
//        setItemBackgroundColor(macroItem, 2);
//        statementItem->addChild(macroItem);

//        foreach(VVar * var, macro->getVars())
//        {
//            QTreeWidgetItem * varItem = new QTreeWidgetItem(macroItem);
//            varItem->setFlags(varItem->flags() | Qt::ItemIsEditable);
//            varItem->setText(0, "var");
//            varItem->setFont(0, *blackFont);
//            varItem->setText(1, var->getN()); varItem->setToolTip(1, "n");
//            varItem->setText(2, var->getId()); varItem->setToolTip(2, "id");
//            varItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, NULL, NULL, macro, var));
//            setItemBackgroundColor(varItem, 3);
//            macroItem->addChild(varItem);
//        }
//    }
    return statementItem;
}

QTreeWidgetItem * VOperationTabWidget::addTripleItem(QTreeWidget* tree, QTreeWidgetItem *parent, VTriple * triple, VStatement * statement, VNotTriples * notTriples)
{
    QTreeWidgetItem * tripleItem = new QTreeWidgetItem(parent);
    tripleItem->setFlags(tripleItem->flags() | Qt::ItemIsEditable);
    tripleItem->setText(0, "triple");
    //tripleItem->setFont(0, *blackFont);
    tripleItem->setToolTip(1, "Subject");
    tripleItem->setToolTip(2, "Predicate");
    tripleItem->setToolTip(3, "Object");

    QComboBox * subjectComboBox = new VTripleSubjectWidget(statement, triple);
    tree->setItemWidget(tripleItem, 1, subjectComboBox);

    if(statement->getType() == domain)
    {
        QComboBox * predicateComboBox = new VTriplePredicateComboBox(statement, triple);
        tree->setItemWidget(tripleItem, 2, predicateComboBox);

        QComboBox * objectComboBox = new VTripleObjectWidget(statement, triple);
        tree->setItemWidget(tripleItem, 3, objectComboBox);
    }
    else if(statement->getType() == activity)
    {
        tripleItem->setText(2, triple->getPredicate());

        QCheckBox * objectCheckBox = new VTripleObjectCheckBox(statement, triple);
        tree->setItemWidget(tripleItem, 3, objectCheckBox);
    }

    tripleItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, notTriples, triple));
    //setItemBackgroundColor(tripleItem, 4);
    parent->addChild(tripleItem);
    return tripleItem;
}


void VOperationTabWidget::on_removeAddresseeStatementButton_clicked(){
    if(ui->addresseeStatementTreeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedQTreeWidgetItem = ui->addresseeStatementTreeWidget->selectedItems().first();
        VTreeWidgetItemData * selectedItem = selectedQTreeWidgetItem->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

        if(selectedItem == NULL) return;

        // Déclaration :
        VAddressee * addressee = _operation->getSpeechAct()->getAddressee();
        VWInstance * agent = selectedItem->getAgent();
        VStatement * statement = selectedItem->getStatement();
        VNotTriples * notTriples = selectedItem->getNotTriples();
        VTriple * triple = selectedItem->getTriple();
        VMacro * macro = selectedItem->getMacro();
        VVar * var = selectedItem->getVar();

        // Traitement des suppressions:
        if(var != NULL)
        {
            macro->removeVar(var);
            delete var;
        }
        else if(macro != NULL)
        {
            statement->removeMacro(macro);
            delete macro;
        }
        else if(triple != NULL)
        {
            if(notTriples != NULL)
            {
                notTriples->removeTriple(triple);
            }
            else if(statement != NULL)
            {
                statement->removeTriple(triple);
            }
            delete triple;
        }
        else if(notTriples != NULL)
        {
            statement->removeNotTriples(notTriples);
            delete notTriples;
        }
        else if(statement != NULL)
        {
            if(addressee != NULL)
            {
                addressee->removeStatement(statement);
                delete statement;
            }
        }
        else if(agent != NULL)
        {
            if(addressee != NULL)
            {
                addressee->removeAgent(agent);
            }
        }
    }
}
