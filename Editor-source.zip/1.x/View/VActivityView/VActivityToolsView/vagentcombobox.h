#ifndef VAGENTCOMBOBOX_H
#define VAGENTCOMBOBOX_H
#include <QComboBox>

class VAddressee;

class VAgentComboBox : public QComboBox
{
    Q_OBJECT
public:
    VAgentComboBox(VAddressee *addressee, int agentIndex, QWidget* parent = 0);
    ~VAgentComboBox();

private:
    VAddressee* _addressee;
    int _agentIndex;
public slots:
    void instanceChanged(QString s);
};


#endif // VAGENTCOMBOBOX_H
