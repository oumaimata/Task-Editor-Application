#pragma once
#ifndef VOPERATION_H
#define VOPERATION_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"
#include "voperationtype.h"
#include "../Model/VActivity/VActivitySpeechAct/vspeechact.h"

class VParam;
class VRefConcept;
class VWActionClass;
class VSpeechAct;
/**
 * @brief The VOperation class
 * La classe VOperation permet de décrire une opération du modèle d'activité.
 * une opération est constituée d'une action et de ressource(s).
 * \see VResource
 */
class VOperation : public VActivityModelElement
{
    Q_OBJECT
private:

    /**
     * @brief _type
     * Type de l'opération {Action ou Speech Act)
     */
    VOperationType _type;

    /**
     * @brief _action
     * Action de la tache
     */
    QPointer<VWActionClass> _actionClass;

    /**
     * @brief _speechAct
     * Acte de langage de la tâche
     */
    QPointer<VSpeechAct> _speechAct;

    /**
     * @brief _refs
     * Liste des références aux concepts
     */
    QList<VRefConcept *> _refs;

    /**
     * @brief _params
     * Liste des paramètres
     */
    QList<VParam *> _params;

public:
    /**
     * @brief VOperation
     *Constructeur
     * @param elem L'object parent
     */
    VOperation(QObject* parent = NULL);

    VOperation(const VOperation& operation, QObject* parent = NULL);

    /**
     * @brief ~VOperation
     * Destructeur
     */
    ~VOperation();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    VOperationType getType() const;

    void setType(const VOperationType &type);

    /**
     * @brief getAction
     * Définit l'action de l'opération
     * @param actionClass L'action
     */
    void setAction(QPointer<VWActionClass> actionClass);

    /**
     * @brief getAction
     * Obtient l'action de l'opération
     * @return L'action de l'opération
     */
    QPointer<VWActionClass> getAction() const;
    /**
     * @brief getSpeechAct
     */
    QPointer<VSpeechAct> getSpeechAct() const;
    /**
     * @brief setSpeechAct
     */
    void setSpeechAct(QPointer<VSpeechAct> speechAct);

    /**
     * @brief addRef
     * Permet d'ajouter un VRefConcept
     * @param ref Un VRefConcept
     */
    void addRef(VRefConcept * ref);

    /**
     * @brief removeRef
     * Permet de retirer un VRefConcept
     * @param ref Un VRefConcept
     */
    void removeRef(VRefConcept * ref);

    /**
     * @brief getRefs
     * Obtient la liste des VRefConcept
     * @return La liste des VRefConcept
     */
    QList<VRefConcept *> getRefs() const;

    /**
     * @brief getRefById
     * Obtient le refconcept correspondant à l'id
     * @param id L'id du refconcept
     * @return Le refconcept correspondant à l'id
     */
    VRefConcept * getRefById(qint64 uid) const;

    /**
     * @brief addParam
     * Permet d'ajouter un VParam
     * @param param Un VParam
     */
    void addParam(VParam * param);

    /**
     * @brief removeParam
     * Permet de retirer un VParam
     * @param param Un VParam
     */
    void removeParam(VParam * param);

    /**
     * @brief getParams
     * Obtient la liste des VParam
     * @return La liste des VParam
     */
    QList<VParam *> getParams() const;

    /**
     * @brief getParamById
     * Obtient le param correspondant à l'id
     * @param uid L'id du param
     * @return Le param correspondant à l'id
     */
    VParam * getParamById(qint64 uid) const;

    /**
     * @brief clone
     * @return Le clone
     */
    VOperation * clone(QObject* parent = NULL) const;

};

#endif // VOPERATION_H
