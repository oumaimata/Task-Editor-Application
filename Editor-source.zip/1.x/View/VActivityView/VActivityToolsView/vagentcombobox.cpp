#include "vagentcombobox.h"
#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldInstance/vwinstance.h"
#include "Model/VActivity/VActivitySpeechAct/VAddressee/vaddressee.h"


VAgentComboBox::VAgentComboBox(VAddressee* addressee, int agentIndex, QWidget* parent):
    QComboBox(parent),
    _addressee(addressee),
    _agentIndex(agentIndex)
{

    VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
    QList<VWInstance *> instances = worldModel->getAllInstances();

    addItem("");

    foreach(VWInstance * instance, instances)
    {
        addItem(instance->getName(), instance->getUid());
        if(instance->getUid() == addressee->getAgents().at(agentIndex)->getUid())
            setCurrentIndex(count() - 1);
    }

    connect(this, SIGNAL(currentTextChanged(QString)), this, SLOT(instanceChanged(QString)));

}

VAgentComboBox::~VAgentComboBox()
{

}

void VAgentComboBox::instanceChanged(QString s)
{
    VWInstance* oldAgent = _addressee->getAgents().at(_agentIndex);
    if(currentText() == ""){
        _addressee->removeAgent(oldAgent);
    }
    else{

        int index = currentIndex();
        QString uid = this->itemData(index).toString();
        VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
        VWInstance * newAgent = worldModel->getInstanceByUid(uid.toLong());

        if(newAgent != NULL)
        {
            if(oldAgent->getClass() == NULL)
                delete oldAgent;
            _addressee->replaceAgent(_agentIndex, newAgent);
        }
    }
}

