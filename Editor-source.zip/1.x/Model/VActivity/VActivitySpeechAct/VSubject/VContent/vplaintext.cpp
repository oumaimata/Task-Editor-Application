#include "vplaintext.h"
#include "../../../../../Controller/vtracecontroller.h"
#include <qdom.h>

VPlainText::VPlainText()
{

}

VPlainText::VPlainText(const VPlainText &plainText, QObject* parent):
    VActivityModelElement(parent),
    _text(plainText._text)
{

}
VPlainText::~VPlainText()
{

}

QString VPlainText::getText() const{
    return _text;
}

void VPlainText::setText(const QString &text){
    _text = text;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VPlainText::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VPlainText::parseDom()", "<" + elem.tagName() + ">");
        QString myPlainText = elem.text();
        setText(myPlainText);

    VTraceController::get()->Info("VPlainText::parseDom()", "</" + elem.tagName() + ">");
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VPlainText::ToXml(QString tabulation)
{
    QString tab = tabulation;
    QString RetVal = tabulation + "<plainText>\n";
    tab += "\t";
    QString my_text = this->getText();
    RetVal += tab + my_text + "\n";
    RetVal += tabulation + "</plainText>\n";

    return RetVal;
}

VPlainText *VPlainText::clone() const
{
    return new VPlainText(*this);
}
