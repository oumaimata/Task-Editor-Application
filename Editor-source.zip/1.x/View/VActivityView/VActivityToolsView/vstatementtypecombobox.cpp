#include "vstatementtypecombobox.h"

#include "Model/VActivity/VActivityCondition/vstatement.h"
#include "Model/VActivity/VActivityCondition/vactivitystatementtype.h"

VStatementTypeComboBox::VStatementTypeComboBox(VStatement * statement, QWidget *parent) :
    QComboBox(parent),
    _statement(statement)
{
    for(int i = 0; i < SIZE_OF_VActivityStatementType; i ++)
    {
        this->addItem(VActivityStatementTypeToString((VActivityStatementType)i));
    }
    this->setCurrentText(VActivityStatementTypeToString(statement->getType()));
    connect(this, SIGNAL(currentTextChanged(QString)), this, SLOT(statementTypeChanged(QString)));
}

void VStatementTypeComboBox::statementTypeChanged(QString s)
{
    _statement->setType(VActivityStatementTypeFromString(s));
}
