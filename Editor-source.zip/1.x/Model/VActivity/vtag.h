#pragma once
#ifndef VTAG_H
#define VTAG_H

#include <QtXml>
#include <QColor>

#include "VActivityCommon/vactivitymodelelement.h"

/**
 * @brief The VTag class
 * Permet de décrire un Tag qui sera référencé par VTask et VActivityModel
 * @see VTask
 * @see VActivityModel
 */
class VTag : public VActivityModelElement
{
    Q_OBJECT
private:

    /**
     * @brief initialized
     * Si la liste des couleurs est initialisée
     */
    static bool initialized;

    /**
     * @brief EmptyList
     * Utile pour l'initialisation de s_colors
     * @return Une liste vide de couleurs
     */
    static QList<QColor> EmptyList();

    /**
     * @brief defaultColor
     * Couleur par défaut du tag
     */
    static QColor defaultColor;

    qint64 _id;

    /**
     * @brief _name
     * Nom du tag
     */
    QString _name;

    /**
     * @brief _valued
     * Si le tag possède une valeur
     * La valeur sera attribuée dans les ref-tag
     * @see VRefTag
     */
    bool _valued;

    /**
     * @brief _visible
     * Vrai si le tag doit être visible dans le graphisme d'une tâche
     * Faux sinon
     */
    bool _visible;

    /**
     * @brief _color
     * La couleur associée au tag
     */
    QColor _color;

    /**
     * @brief _childs
     * Liste des Tags fils
     */
    QList<VTag *> _childs;

protected:
    /**
     * @brief childTagAdded
     * Notifie au Tag parent que le tag passé en paramètre a été ajouté
     * @param tag Le nouveau tag
     */
    void childTagAdded(VTag* tag);

    /**
     * @brief childTagRemoved
     * Notifie au Tag parent que le tag passé en paramètre a été supprimé
     * @param tag L'ancien tag
     */
    void childTagRemoved(VTag* tag);

public:
    /**
     * @brief VTag
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VTag(QObject *parent = 0);

    /**
     * @brief VTag
     * Constructeur de recopie
     * @param tag Tag à copier
     */
    VTag(const VTag& tag, QObject *parent = 0);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    /**
     * @brief getTagById
     * Obtient le tag ayant l'id passé en argument
     * @param id L'id d'un tag
     * @return Le tag s'i elle'il existe sinon null
     */
    VTag* getTagById(qint64 id);

    /**
     * @brief getTagParentFromDom
     * Obtient l'id du tag père
     * @param elem Un élément du dom
     * @return L'id du tag père
     */
    QString getTagParentFromDom(QDomElement elem);

    /**
     * @brief setParent
     * Surcharge afin de suivre l'évolution de l'arborescence
     * @param object L'objet parent
     */
    void setParent(QObject * object);

    /**
     * @brief setId
     * Définit l'Id
     * @param id L'id
     */
    void setId(qint64 id);

    /**
     * @brief setId
     * Définit l'Id
     * @param id L'id
     */
    void setId(QString id);

    /**
     * @brief getId
     * Obtient l'Id
     * @return L'id
     */
    qint64 getId() const;

    /**
     * @brief setName
     * Définit le nom
     * @param name Le nom
     */
    void setName(QString name);

    /**
     * @brief getName
     * Obtient le nom
     * @return Le nom
     */
    QString getName() const;

    /**
     * @brief setValued
     * Définie si le tag possède une valeur
     * @param valued Si le tag possède une valeur
     */
    void setValued(bool valued);

    /**
     * @brief setValued
     * Définie si le tag possède une valeur
     * @param valued Si le tag possède une valeur
     */
    void setValued(QString valued);

    /**
     * @brief getValued
     * Obtient si le tag possède une valeur
     * @return Si le tag possède une valeur
     */
    bool getValued() const;

   /**
    * @brief setVisible
    * set l'attribut à partir d'un QString. Utile pour la conversion depuis XML.
    */
    void setVisible(QString isVisible);
    /**
     * @brief setVisible
     * Vrai si le tag doit être visible dans le graphisme d'une tâche
     * Faux sinon
     * @param visible si le tag doit être visible
     */
    void setVisible(bool visible);

    /**
     * @brief getVisible
     * Vrai si le tag doit être visible dans le graphisme d'une tâche
     * Faux sinon
     * @return si le tag doit être visible
     */
    bool getVisible() const;

    /**
     * @brief setColor
     * Définit la couleur associée au tag
     * @param color La couleur associée au tag
     */
    void setColor(QColor color);

    /**
     * @brief getColor
     * Obtient la couleur associée au tag
     * @return La couleur associée au tag
     */
    QColor getColor() const;

    /**
     * @brief getChildTags
     * Obtient une liste des tags fils
     * @return Une liste des tags fils
     */
    QList<VTag *> getChildTags() const;

    /**
     * @brief getAllChildTags
     * Obtient une liste des tags fils de toute l'arborescence
     * @return Une liste des tags fils de toute l'arborescence
     */
    QList<VTag *> getAllChildTags() const;

    /**
     * @brief addChildTag
     * Ajout un tag fils au tag courant
     * @param tag Le tag à ajouter
     */
    void addChildTag(VTag* tag = NULL);

    /**
     * @brief removeChildTag
     * Retire un tag fils au tag courant
     * @param tag Le tag à ajouter
     */
    void removeChildTag(VTag* tag);

signals:
    /**
     * @brief tagAdded
     * Signal d'ajout de tag
     * @param tag Le nouveau tag
     */
    void tagAdded(VTag* tag);

    /**
     * @brief tagRemoved
     * Signal de suppression de tag
     * @param tag L'ancien tag
     */
    void tagRemoved(VTag* tag);

    /**
     * @brief tagDestroyed
     * Signal la destruction d'un tag
     * @param tag Le tag détruit
     */
    void tagDestroyed(VTag * tag);
};

#endif // VTAG_H
