#include "vwactionclasseditorwidget.h"
#include "ui_vwactionclasseditorwidget.h"

#include "../../velementcreator.h"
#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwactionclass.h"
#include "Model/VWorld/VWorldClass/vwbehaviourclass.h"
#include "Controller/vapplicationcontroller.h"

VWActionClassEditorWidget::VWActionClassEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWActionClassEditorWidget),
    _edit(false),
    _actionClass(NULL),
    _elementCreator(NULL)
{
    ui->setupUi(this);
    retranslate();
}

VWActionClassEditorWidget::~VWActionClassEditorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWActionClassEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWActionClassEditorWidget::retranslate()
{
    ui->propertiesEditorWidget->setLabelCol(0, tr("Parameter"));
    ui->propertiesEditorWidget->setLabelCol(1, tr("Type"));
}

void VWActionClassEditorWidget::setActionClass(VWActionClass * actionClass)
{
    if(actionClass != _actionClass)
    {
        _actionClass = actionClass;
    }
    updateDisplay();
}

void VWActionClassEditorWidget::updateDisplay()
{
    _edit = true;
    ui->nameLineEdit->setText("");
    ui->behaviourComboBox->clear();
    while(ui->behaviourTableWidget->rowCount() > 0)
    {
        ui->behaviourTableWidget->removeRow(0);
    }
    if(_actionClass == NULL) return;
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();

    // Nom
    ui->nameLineEdit->setText(_actionClass->getName());

    // Les behaviours
    QPointer<VWBehaviourClass> qBehaviour;
    QList<QPointer<VWBehaviourClass> > qBehaviours = _actionClass->getBehaviours();
    foreach(qBehaviour, qBehaviours)
    {
        if(qBehaviour != NULL)
        {
            ui->behaviourTableWidget->insertRow(0);
            QTableWidgetItem* item = new QTableWidgetItem();
            item->setText(qBehaviour->getName());
            item->setData(Qt::UserRole, qBehaviour->getUid());
            ui->behaviourTableWidget->setItem(0, 0, item);
        }
    }
    ui->behaviourTableWidget->resizeColumnsToContents();
    ui->behaviourComboBox->addItem("");
    VWBehaviourClass * behaviour;
    QList<VWBehaviourClass *> behaviours = worldModel->getBehaviours();
    foreach(behaviour, behaviours)
    {
        if(!_actionClass->getBehaviours().contains(behaviour))
        {
            ui->behaviourComboBox->addItem(behaviour->getName(), behaviour->getUid());
        }
    }

    ui->propertiesEditorWidget->setProperties(_actionClass->getProperties());

    // Component
    ui->componentEditorWidget->setEntity(_actionClass);
    _edit = false;
}

void VWActionClassEditorWidget::on_nameLineEdit_editingFinished()
{
    _actionClass->setName(ui->nameLineEdit->text());
}

void VWActionClassEditorWidget::on_addBehaviourButton_clicked()
{
    QString uid = ui->behaviourComboBox->itemData(ui->behaviourComboBox->currentIndex()).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWBehaviourClass * behaviour = worldModel->getBehaviourByUid(uid.toLong());
    if(behaviour != NULL) _actionClass->addBehaviour(behaviour);
    else
    {
        _elementCreator = new VElementCreator(NULL);
        connect(_elementCreator, SIGNAL(closed()), this, SLOT(onElementCreatorClose()));
        _elementCreator->setWindowTitle(tr("Create a behaviour"));
        _elementCreator->setName("Behaviour " + QString::number(VWActionClass::getCurrentUid()));
        _elementCreator->show();
    }
}

void VWActionClassEditorWidget::on_removeBehaviourButton_clicked()
{
    if(ui->behaviourTableWidget->selectedItems().count() == 0) return;
    QTableWidgetItem * item = ui->behaviourTableWidget->selectedItems().first();
    QString uid = item->data(Qt::UserRole).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWBehaviourClass * behaviour = worldModel->getBehaviourByUid(uid.toLong());
    if(behaviour != NULL) _actionClass->removeBehaviour(behaviour);
}

/**
 * @brief onElementCreatorClose
 * Gère la fermeture de la fenêtre d'ajout de behaviour
 */
void VWActionClassEditorWidget::onElementCreatorClose()
{
    if(_elementCreator == NULL) return;

    // Create the new element
    if(_elementCreator->getDialogResult() >= 0)
    {
        VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
        VWBehaviourClass * behaviourClass = new VWBehaviourClass();
        behaviourClass->setName(_elementCreator->getName());
        worldModel->addBehaviour(behaviourClass); // Add to the model
        _actionClass->addBehaviour(behaviourClass); // Create the reference in the opertation's task

        // Open the new action in edition
        if(_elementCreator->getDialogResult() == 1)
        {
            VApplicationController::getInstance()->getWorldController()
                    ->setCurrentEdit(behaviourClass);
        }
    }
    disconnect(_elementCreator, SIGNAL(closed()), this, SLOT(onElementCreatorClose()));
    delete _elementCreator;
    _elementCreator = NULL;
}
