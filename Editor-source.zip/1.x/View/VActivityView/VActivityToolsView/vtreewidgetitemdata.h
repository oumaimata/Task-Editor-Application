#pragma once
#ifndef VTREEWIDGETITEMDATA_H
#define VTREEWIDGETITEMDATA_H

#include <QObject>
#include <QVariant>

class VStopCondition;
class VCondition;
class VConditionLogicalOperator;
class VAddressee;
class VWInstance;
class VStatement;
class VNotTriples;
class VTriple;
class VMacro;
class VVar;

class VTreeWidgetItemData : public QObject
{
    Q_OBJECT
private:
    VStopCondition * _stopCondition;
    VCondition * _condition;
    VConditionLogicalOperator * _cLO;
    VAddressee * _addressee;
    VWInstance* _agent;
    VStatement * _statement;
    VNotTriples * _notTriples;
    VTriple * _triple;
    VMacro * _macro;
    VVar * _var;

    bool _other;
    QString _type;

public:
    VTreeWidgetItemData(VCondition *condition,
                        VConditionLogicalOperator * cLO = 0,
                        VStatement * statement = 0,
                        VNotTriples * notTriples = 0,
                        VTriple * triple = 0,
                        VMacro * macro = 0,
                        VVar * var = 0);

    VTreeWidgetItemData(VAddressee * addressee ,
                        VWInstance* agent = 0,
                        VStatement * statement = 0,
                        VNotTriples * notTriples = 0,
                        VTriple * triple = 0,
                        VMacro * macro = 0,
                        VVar * var = 0);

    VTreeWidgetItemData(VWInstance * agent,
                        VStatement * statement = 0,
                        VNotTriples * notTriples = 0,
                        VTriple * triple = 0,
                        VMacro * macro = 0,
                        VVar * var = 0);

    VTreeWidgetItemData(VStatement * statement,
                        VNotTriples * notTriples = 0,
                        VTriple * triple = 0,
                        VMacro * macro = 0,
                        VVar * var = 0);

    VTreeWidgetItemData(VStopCondition * stopCondition,
                        VStatement * statement = 0,
                        VNotTriples * notTriples = 0,
                        VTriple * triple = 0,
                        VMacro * macro = 0,
                        VVar * var = 0);

    static QVariant getQVariant(VCondition *condition,
                                VConditionLogicalOperator * cLO = 0,
                                VStatement * statement = 0,
                                VNotTriples * notTriples = 0,
                                VTriple * triple = 0,
                                VMacro * macro = 0,
                                VVar * var = 0);

    static QVariant getQVariant(VAddressee* addressee,
                                VWInstance* agent = 0,
                                VStatement * statement = 0,
                                VNotTriples * notTriples = 0,
                                VTriple * triple = 0,
                                VMacro * macro = 0,
                                VVar * var = 0);

    static QVariant getQVariant(VWInstance* agent,
                                VStatement * statement = 0,
                                VNotTriples * notTriples = 0,
                                VTriple * triple = 0,
                                VMacro * macro = 0,
                                VVar * var = 0);

    static QVariant getQVariant(VStatement * statement,
                                VNotTriples * notTriples = 0,
                                VTriple * triple = 0,
                                VMacro * macro = 0,
                                VVar * var = 0);

    static QVariant getQVariant(VStopCondition * stopCondition,
                                VStatement * statement = 0,
                                VNotTriples * notTriples = 0,
                                VTriple * triple = 0,
                                VMacro * macro = 0,
                                VVar * var = 0);

    static QVariant getOther(QString type, VStopCondition * stopCondition);

    void setStopCondition(VStopCondition * stopCondition);
    VStopCondition * getStopCondition() const;

    void setCondition(VCondition * condition);
    VCondition * getCondition() const;

    void setCLO(VConditionLogicalOperator * cLO);
    VConditionLogicalOperator *  getCLO() const;

    VAddressee *getAddressee() const;
    void setAddressee(VAddressee *addressee);

    void setStatement(VStatement * statement);
    VStatement * getStatement() const;

    VWInstance *getAgent() const;
    void setAgent(VWInstance *agent);

    void setNotTriples(VNotTriples * notTriples);
    VNotTriples * getNotTriples() const;

    void setTriple(VTriple * triple);
    VTriple * getTriple() const;

    void setMacro(VMacro * macro);
    VMacro * getMacro() const;

    void setVar(VVar * var);
    VVar * getVar() const;

    void setIsOther(bool other);
    bool getIsOther() const;

    void setType(QString type);
    QString getType() const;    

};

#endif // VTREEWIDGETITEMDATA_H
