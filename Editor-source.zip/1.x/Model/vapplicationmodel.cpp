#include "vapplicationmodel.h"

VApplicationModel* VApplicationModel::_instance;

/**
 * @brief VApplicationModel
 * Default constructor of the application model, inherited from QObject.
 * @param parent The parent of the object
 */


VApplicationModel::VApplicationModel(QObject* parent) :
    QObject(parent)
{
}

/**
 * @brief getInstance
 * Get the instance of VApplicationModel
 * @return The instance
 */
VApplicationModel* VApplicationModel::getInstance()
{
    if (_instance == NULL)
        _instance = new VApplicationModel(qApp);
    return _instance;
}

/**
 * @brief getActivityModel
 * Get the activity model of the application
 * @return A const reference to the activity model of the application
 */
VActivityModel& VApplicationModel::getActivityModel()
{
    return _activityModel;
}

/**
 * @brief getActivityHistorySet
 * L'historique pour le modèle d'activité
 */
VHistorySet& VApplicationModel::getActivityHistorySet()
{
    return _activityHistorySet;
}

/**
 * @brief getActivityFutureSet
 * Le future pour le modèle d'activité
 */
VHistorySet& VApplicationModel::getActivityFutureSet()
{
    return _activityFutureSet;
}

/**
 * @brief getWorldModel
 * Get the world model of the application
 * @return A const reference to the world model of the application
 */
VWorldModel& VApplicationModel::getWorldModel()
{
    return _worldModel;
}

/**
 * @brief getWorldHistorySet
 * L'historique pour le modèle du monde
 */
VHistorySet& VApplicationModel::getWorldHistorySet()
{
    return _worldHistorySet;
}

/**
 * @brief getWorldFutureSet
 * Le future pour le modèle du monde
 */
VHistorySet& VApplicationModel::getWorldFutureSet()
{
    return _worldFutureSet;
}


VSettings& VApplicationModel::getSettings()
{
    return _settings;
}
