#include "vtaskrectitem.h"

#include <QWidget>
#include <QDrag>
#include <QGraphicsSceneMouseEvent>
#include <QPainter>
#include <QPen>
#include <QBrush>

#include "vtaskitem.h"
#include "vitemmimedata.h"
#include "vtaskconstructoritem.h"
#include "Model/VActivity/vtag.h"
#include "Controller/vtracecontroller.h"

/*!
 * \brief VTaskRectItem::VTaskRectItem
 * Constructeur
 * \param x La position sur l'axe des x
 * \param y La position sur l'axe des y
 * \param width La largueur
 * \param height La longueur
 * \param task La tache associée
 * \param parent L'objet parent
 */
VTaskRectItem::VTaskRectItem(qreal x, qreal y, qreal width, qreal height, VTask* task, QGraphicsItem* parent) :
    QGraphicsRectItem(x, y, width, height, parent), _task(task)
{
    VTraceController::get()->Debug("VTaskRectItem::VTaskRectItem()", "Begin");

    setFlags(ItemIsSelectable | ItemStacksBehindParent);
    setAcceptHoverEvents(true);
    setAcceptDrops(true);

    this->setPen(QPen (Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    this->setBrush(QColor(193, 231, 253));

    setToolTip(_task->getName());

    VTraceController::get()->Debug("VTaskRectItem::VTaskRectItem()", "End");
}

/*!
 * \brief VTaskRectItem::itemChange
 * Gère le changement de sélection
 * \param change Les informations sur l'événement
 * \param value Si sélectionné
 * \return value
 */
QVariant VTaskRectItem::itemChange(GraphicsItemChange change, const QVariant &value)
{
    VTraceController::get()->Debug("VTaskRectItem::itemChange()", "Begin");
    if (change == QGraphicsItem::ItemSelectedHasChanged)
    {
        VTraceController::get()->Info("VTaskRectItem::itemChange()",
                                      "Selected item has changed");
        if (value.toBool())
        {
            VTraceController::get()->Info("VTaskRectItem::itemChange()",
                                          "the item is now selected -> red outline");
            this->setPen(QPen (Qt::red, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        }
        else
        {
            VTraceController::get()->Info("VTaskRectItem::itemChange()",
                                          "the item is now unselected -> black outline");
            this->setPen(QPen (Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        }
    }

    QVariant result = QGraphicsRectItem::itemChange(change, value);

    VTraceController::get()->Debug("VTaskRectItem::itemChange()", "End");

    return result;
}

/*!
 * \brief VTaskRectItem::mouseMoveEvent
 * Gère l'événement souris du déplacement de la souris
 * \param event Les informations sur l'événement
 */
void VTaskRectItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    VTraceController::get()->Debug("VTaskRectItem::mouseMoveEvent()", "Begin");

    QDrag* drag = new QDrag(event->widget());

    VItemMimeData* mime = new VItemMimeData();
    drag->setMimeData(mime);
    mime->setItem(parentItem());

    drag->exec();

    VTraceController::get()->Debug("VTaskRectItem::mouseMoveEvent()", "End");
}

/*!
 * \brief VTaskRectItem::dragEnterEvent
 * Gère l'événement souris du glisser (du glisser/déposer)
 * \param event Les informations sur l'événement
 */
void VTaskRectItem::dragEnterEvent(QGraphicsSceneDragDropEvent* event)
{
    VTraceController::get()->Debug("VTaskRectItem::dragEnterEvent()", "Begin");
    const VItemMimeData* mimeData = qobject_cast<const VItemMimeData*>(event->mimeData());

    if (mimeData != NULL && mimeData->hasItem())
    {
        VTraceController::get()->Info("VTaskRectItem::dragEnterEvent()", "Drag allowed");
        event->accept();
    }
    else
    {
        VTraceController::get()->Info("VTaskRectItem::dragEnterEvent()", "Drag refused");
        event->ignore();
    }
    VTraceController::get()->Debug("VTaskRectItem::dragEnterEvent()", "End");
}

/*!
 * \brief VTaskRectItem::dropEvent
 * Gère l'événement souris déposer (du glisser/déposer)
 * \param event Les informations sur l'événement
 *
 * \todo Vérification du déplacement vers un noeud fils
 */
void VTaskRectItem::dropEvent(QGraphicsSceneDragDropEvent* event)
{
    VTraceController::get()->Debug("VTaskRectItem::dropEvent()", "Begin");
    const VItemMimeData* mimeData = qobject_cast<const VItemMimeData*>(event->mimeData());

    if (mimeData != NULL && mimeData->hasItem())
    {
        VTaskItem* thisParentItem = qgraphicsitem_cast<VTaskItem*>(this->parentItem());
        VTaskConstructorItem* taskConstructorItem = qgraphicsitem_cast<VTaskConstructorItem*>(mimeData->getItem());
        if(taskConstructorItem != NULL)
        {
            VTaskItem * oldParent = qgraphicsitem_cast<VTaskItem*>(taskConstructorItem->parentItem()); // Item parent des items à déplacer
            QList<VTaskItem *> subTaskItems = oldParent->getChildTaskItems(); // Liste des items à déplacer
            for(int i = 0; i < subTaskItems.count(); i++)
            {
                VTaskItem* taskItem = subTaskItems[i];
                VTask * task = taskItem->getTask(); // Récupère la tâche à déplacée

                if(task != _task && !task->IsAnscesterOf(_task)) // task est un ancètre de _taskItem->getTask() ?
                {
                    task->setParent(_task); // Change le parent sur le modèle
                    taskItem->setParentItem(thisParentItem); // Change le parent sur la vue
                    taskItem->updateSubitemsPositions();

                    if(oldParent != NULL)
                    {
                        oldParent->updateSubitemsPositions();
                    }
                    VTraceController::get()->Info("VTaskRectItem::dropEvent()",
                                                           _task->getId() + " is now parent of " + task->getId());
                }
            }
        }
        VTaskItem* taskItem = qgraphicsitem_cast<VTaskItem*>(mimeData->getItem());
        if(taskItem != NULL)
        {
            VTaskItem * oldParent = taskItem->getParentTaskItem(); // On conserve l'ancien parent pour mettre à jour ses enfants car on en retire un.
            VTask * task = taskItem->getTask(); // Récupère la tâche à déplacée

            if(task != _task && !task->IsAnscesterOf(_task)) // task est un ancètre de _taskItem->getTask() ?
            {
                task->setParent(_task); // Change le parent sur le modèle
                taskItem->setParentItem(thisParentItem); // Change le parent sur la vue
                taskItem->updateSubitemsPositions();

                if(oldParent != NULL)
                {
                    oldParent->updateSubitemsPositions();
                }
                VTraceController::get()->Info("VTaskRectItem::dropEvent()",
                                                       _task->getId() + " is now parent of " + task->getId());
            }
        }
    }

    VTraceController::get()->Debug("VTaskRectItem::dropEvent()", "End");
}

/*!
 * \brief VTaskRectItem::type
 * Obtient Type
 * \return Le type
 */
int VTaskRectItem::type() const
{
    return Type;
}

/*!
 * \brief VTaskRectItem::paint
 * Dessine le controle
 * \param painter
 * \param option
 * \param widget
 */
void VTaskRectItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    VTraceController::get()->Debug("VTaskRectItem::paint()", "Begin");
    QGraphicsRectItem::paint(painter, option, widget);

    // Drawing the rect text.
    if (_task != NULL)
    {
        VTraceController::get()->Info("VTaskRectItem::paint()", "Draw the task");

        if(_task->getCut())
        {
            painter->setPen(QPen(Qt::gray, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        }
        else
        {
            painter->setPen(QPen(Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        }
        QRectF textRect(this->rect().x() + 2, this->rect().y() + 2, this->rect().width() - 4, this->rect().height() - 4);
        QList<QPointer<VTag> > tags = _task->getRefTags().keys();
        if(tags.count() == 0)
        {
            // Draw the text in a smaller rect to have a margin.
            painter->drawText(textRect, Qt::TextWordWrap | Qt::AlignCenter, _task->getName());
        }
        else
        {
            qreal iniX = this->rect().x() + 3;
            qreal iniY = this->rect().y() + this->rect().height() / 2 + 3;
            qreal size = this->rect().height() / 2 - 6;
            int tagCounter = 0;
            for(int i = 0; i < tags.count() && tagCounter < 9; i++)
            {
                QPointer<VTag> tag = tags[i];
                if(tag != NULL && tag->getVisible())
                {
                    QRectF rect(iniX + tagCounter * (size + 3), iniY, size, size);
                    painter->setBrush(tag->getColor());
                    painter->drawEllipse(rect);
                    tagCounter++;
                }
            }
            if(tagCounter != 0)
            {
                textRect.setHeight(this->rect().height() / 2 - 2);
            }
            painter->drawText(textRect, Qt::TextWordWrap | Qt::AlignCenter, _task->getName());
        }
    }
    VTraceController::get()->Debug("VTaskRectItem::paint()", "End");
}
