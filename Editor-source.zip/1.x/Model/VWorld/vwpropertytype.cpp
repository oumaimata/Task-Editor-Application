#include "vwpropertytype.h"

#include "../../Model/vapplicationmodel.h"
#include "../../Model/VWorld/vworldmodel.h"

VWPropertyType::VWPropertyType(QObject *parent) :
    QObject(parent),
    _basicType(""),
    _componentType(NULL),
    _objectType(NULL),
    _edit(false)
{
}

void VWPropertyType::fromString(QString s)
{
    _basicType = "";
    _componentType = NULL;
    _objectType = NULL;
    qint64 uid = s.toLong();
    if(uid == -1 || s == "int") _basicType = "int";
    else if(uid == -2 || s == "string") _basicType = "string";
    else if(uid == -3 || s == "boolean") _basicType = "bool";
    else if(uid == -4 || s == "float") _basicType = "float";
    else if(uid == -5 || s == "date") _basicType = "Date";
    else if(uid == -6 || s == "dateTime") _basicType = "DateTime";
    else if(uid == -7 || s == "Boolean") _basicType = "domain:Boolean";
    else
    {
        VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();

        _componentType = worldModel->getComponentByUid(uid);
        _objectType = worldModel->getObjectByUid(uid);
        if(_componentType == NULL && _objectType == NULL)
        {
            _componentType = worldModel->getComponentByName(s);
            _objectType = worldModel->getObjectByName(s);
        }
    }
    onModified(tr("Type changed"));
}

QString VWPropertyType::toString() const
{
    if(_basicType != NULL) return _basicType;
    if(_componentType != NULL) return _componentType->getName();
    if(_objectType != NULL) return _objectType->getName();
    return "";
}

QString VWPropertyType::toXml() const
{
    QString RetVal;
    if(_basicType == "domain:Boolean")
        RetVal += "http://www.utc.fr/hds/ici/humans/domain#Boolean";
    else if(_basicType == "int" || _basicType == "float" || _basicType == "string")
        RetVal += "http://www.w3.org/2001/XMLSchema#" + _basicType;
    else if(_basicType == "Date")
        RetVal += "http://www.w3.org/2001/XMLSchema#date";
    else if(_basicType == "DateTime")
        RetVal += "http://www.w3.org/2001/XMLSchema#dateTime";
    else if(_basicType == "bool")
        RetVal += "http://www.w3.org/2001/XMLSchema#boolean";
    else
        RetVal += "#" + toString();
    return RetVal;
}

QPointer<VWComponentClass> VWPropertyType::getComponentClass() const
{
    return _componentType;
}

QPointer<VWObjectClass> VWPropertyType::getObjectClass() const
{
    return _objectType;
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 */
void VWPropertyType::onModified()
{
    onModified(NULL);
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 * @param object L'objet modifié
 */
void VWPropertyType::onModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    emit modified(message, (object == NULL) ? this : object);
}
