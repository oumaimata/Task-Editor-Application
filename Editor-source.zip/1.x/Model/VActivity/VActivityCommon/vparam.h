#pragma once
#ifndef VPARAM_H
#define VPARAM_H

#include <QtXml>

#include "vactivitymodelelement.h"

class VParam : public VActivityModelElement
{
    Q_OBJECT
private:

    QString _value;

    QString _predicate;

public:
    explicit VParam(QObject *parent = 0);

    VParam(const VParam& param, QObject *parent = 0);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setValue(QString value);

    QString getValue() const;

    void setPredicate(QString predicate);

    QString getPredicate() const;

    /**
     * @brief clone
     * @return Le clone
     */
    VParam * clone(QObject *parent = 0) const;
};

#endif // VPARAM_H
