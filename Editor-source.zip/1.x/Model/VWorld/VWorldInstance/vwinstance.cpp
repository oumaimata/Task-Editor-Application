#include "vwinstance.h"

#include "../vwparser.h"
#include "../vwproperty.h"
#include "../vwpropertytype.h"
#include "../vwpropertyvalue.h"
#include "../vworldmodel.h"
#include "../VWorldClass/vwobjectclass.h"
#include "../../vapplicationmodel.h"

VWInstance::VWInstance(QObject *parent) :
    VWorldModelElement(parent),
    _class(NULL)
{
}

/**
 * @brief VWInstance
 * @param o L'objet à copier
 */
VWInstance::VWInstance(const VWInstance& o):
    VWorldModelElement(o)
{
    _class = o._class;
}

VWInstance::~VWInstance()
{
    while(_valuedProperties.keys().count() > 0)
    {
        VWPropertyValue * propertyValue = _valuedProperties.values().first();
        QPointer<VWProperty> property = _valuedProperties.keys().first();
        _valuedProperties.remove(property);
        delete propertyValue;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWInstance::ParseDom(QDomElement elem)
{
    VWorldModelElement::ParseDom(elem);
}

void VWInstance::ParsePropertyValues(QDomElement elem)
{
    QDomNode node = elem.firstChild();

    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString prefix = VWParser::getPrefix(element.tagName());
            QString balise = VWParser::getBalise(element.tagName());
            if((prefix.isNull() ||  prefix.isEmpty()) && !balise.isNull() && !balise.isEmpty())
            {
                QString value = element.text();
                if(value.isNull() || value.isEmpty())
                {
                    value = VWParser::getBalise(element.attribute("rdf:resource", ""));
                }

                if(!value.isNull() && !value.isEmpty())
                {
                    addValuedProperty(balise, value);
                }
                else
                {
                    // Récupération des states properies
                    QDomNode subNode = element.firstChild();
                    // Lecture des noeuds inférieurs
                    while(!subNode.isNull())
                    {
                        QDomElement subSubElement = subNode.toElement();
                        if(!subSubElement.isNull())
                        {
                            QDomNode subSubNode = subSubElement.firstChild();
                            // Lecture des noeuds inférieurs
                            while(!subSubNode.isNull())
                            {
                                QDomElement subSubSubElement = subSubNode.toElement();
                                if(!subSubSubElement.isNull())
                                {
                                    prefix = VWParser::getPrefix(subSubSubElement.tagName());
                                    balise = VWParser::getBalise(subSubSubElement.tagName());
                                    if((prefix.isNull() ||  prefix.isEmpty()) && !balise.isNull() && !balise.isEmpty())
                                    {
                                        value = subSubSubElement.text();
                                        if(value.isNull() || value.isEmpty())
                                        {
                                            value = VWParser::getBalise(subSubSubElement.attribute("rdf:resource", ""));
                                        }
                                        addValuedProperty(balise, value);
                                    }
                                }
                                subSubNode = subSubNode.nextSibling();
                            }
                        }
                        subNode = subNode.nextSibling();
                    }
                }
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWInstance::ToXml(QString tabulation)
{
    if( _class == NULL ) return "";

    QString RetVal = tabulation + "<" + _class->getName() + " rdf:ID=\"" + getName() + "\">\n";

    QList<QPointer<VWProperty> > properties = _valuedProperties.keys();
    QList<VWPropertyValue *> values = _valuedProperties.values();
    for(int i = 0; i < properties.count(); i++)
    {
        QPointer<VWProperty> property = properties[i];
        VWPropertyValue * value = values[i];
        if(value->isValued(property))
        {
            QString stateBegin;
            QString stateEnd;
            if(property != NULL && property->getComponent() != NULL)
            {
                QString hasState = property->getComponent()->getHasState();;
                QString state = property->getComponent()->getState();
                stateBegin = tabulation + "\t<" + hasState + ">\n";
                stateBegin += tabulation + "\t\t<" + state + ">\n\t\t";
                stateEnd = tabulation + "\t\t</" + state + ">\n";
                stateEnd += tabulation + "\t</" + hasState + ">\n";
            }

            RetVal += stateBegin + value->toXml(tabulation + "\t", property) + stateEnd;
        }
    }

    RetVal += tabulation + "</" + _class->getName() + ">\n";
    return RetVal;
}

void VWInstance::setClass(VWObjectClass * cclass)
{
    if(cclass != _class)
    {
        if(_class != NULL)
        {
            _class->removeInstance(this); // On se retire de l'ancienne classe
            disconnect(_class, SIGNAL(classModified(QObject*)), this, SLOT(onClassModified(QObject*)));
        }
        _class = cclass;
        if(_class != NULL)
        {
            setName(_class->getName() + "_" + QString::number(getUid()));
            _class->addInstance(this); // On s'ajoute à la nouvelle classe
            connect(_class, SIGNAL(classModified(QObject*)), this, SLOT(onClassModified(QObject*)));
        }
        onClassModified();
        onModified(NULL);
    }
}

VWObjectClass * VWInstance::getClass() const
{
    return _class;
}

void VWInstance::addValuedProperty(QString propertyName, QString value)
{
    QPointer<VWProperty> property = getValuedPropertyByName(propertyName);
    if(property == NULL) return;
    VWPropertyValue * propertyValue = getValuedProperty(property);
    if(propertyValue == NULL) return;

    QString type = property->getType()->toString();
    if(type == "int")
    {
        propertyValue->setBasicType(QString::number(value.toInt()));
    }
    else if(type == "float")
    {
        propertyValue->setBasicType(QString::number(value.toFloat()));
    }
    else if(type == "string")
    {
        propertyValue->setBasicType(value);
    }
    else if(type == "domain:Boolean")
    {
        propertyValue->setBasicType("domain:" + value);
    }
    else if(type == "Date")
    {
        propertyValue->setDate(value);
    }
    else if(type == "DateTime")
    {
        propertyValue->setDateTime(value);
    }
    else if(type == "bool")
    {
        propertyValue->setBoolean(value);
    }
    else
    {
        VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
        VWInstance * instance = worldModel->getInstanceByName(value);
        if(instance != NULL)
        {
            propertyValue->setInstance(instance);
        }
    }
}

void VWInstance::addValuedProperty(VWProperty * property, VWPropertyValue * value)
{
    if(property != NULL && value != NULL)
    {
        if(property->getType() != NULL && property->getType()->toString() == "domain:Boolean")
            value->setBasicType("domain:Unknown");
        _valuedProperties.insert(property, value);
        connect(property, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        connect(value, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Property value changed"));
    }
}

void VWInstance::removeValuedProperty(VWProperty * property)
{
    if(_valuedProperties.contains(property))
    {
        disconnect(_valuedProperties.value(property), SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        _valuedProperties.remove(property);
        disconnect(property, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(NULL);
    }
}

QMap<QPointer<VWProperty>, VWPropertyValue *> VWInstance::getValuedProperties() const
{
    return _valuedProperties;
}

QPointer<VWProperty> VWInstance::getValuedPropertyByUid(qint64 uid) const
{
    QList<QPointer<VWProperty> > properties = _valuedProperties.keys();
    foreach(QPointer<VWProperty> property, properties)
    {
        if(property->getUid() == uid) return property;
    }
    return NULL;
}

QPointer<VWProperty> VWInstance::getValuedPropertyByName(QString name) const
{
    QList<QPointer<VWProperty> > properties = _valuedProperties.keys();
    foreach(QPointer<VWProperty> property, properties)
    {
        if(property != NULL && property->getName() == name) return property;
    }
    return NULL;
}

QPointer<VWProperty> VWInstance::getValuedPropertyByType(VWPropertyType * type) const
{
    QList<QPointer<VWProperty> > properties = _valuedProperties.keys();
    foreach(QPointer<VWProperty> property, properties)
    {
        if(property != NULL && property->getType() == type) return property;
    }
    return NULL;
}

VWPropertyValue * VWInstance::getValuedProperty(QPointer<VWProperty> property) const
{
   return _valuedProperties.value(property);
}

VWPropertyValue * VWInstance::getValuedProperty(VWPropertyType * type) const
{
    QPointer<VWProperty> property = getValuedPropertyByType(type);
    return property == NULL ? NULL : _valuedProperties.value(property);
}

/**
 * @brief onModified
 * Envoie le signal modified(QObject *)
 */
void VWInstance::onModified()
{
    onModified(NULL);
}

/**
 * @brief onModified
 * Envoie le signal modified(QObject *)
 * @param object L'object qui a été modifié
 */
void VWInstance::onModified(QString message, QObject * object)
{
    VWPropertyType * type = qobject_cast<VWPropertyType *>(object);
    if(type != NULL)
    {
        VWPropertyValue * value = getValuedProperty(type);
        value->reset();
        if(type->toString() == "domain:Boolean") value->setBasicType("domain:Unknown");
    }
    VWorldModelElement::onModified(message, object);
}

void VWInstance::onClassModified(QObject* object)
{
    if(object == this) return;
    if(_class == NULL)
    {
        // remove all properties
        QList<QPointer<VWProperty> > properties = _valuedProperties.keys();
        foreach(QPointer<VWProperty> property, properties)
        {
            removeValuedProperty(property);
        }
    }
    else
    {
        QList<QPointer<VWProperty> > oldProperties = _valuedProperties.keys();
        QList<QPointer<VWProperty> > newProperties = _class->getAllProperties();

        // Suppression des propriétés obsolètes
        foreach(QPointer<VWProperty> property, oldProperties)
        {
            if(!newProperties.contains(property))
            {
                removeValuedProperty(property);
            }
        }

        // Ajout des nouvelles propriétés
        foreach(QPointer<VWProperty> property, newProperties)
        {
            if(!_valuedProperties.keys().contains(property))
            {
                VWPropertyValue * value = new VWPropertyValue();
                addValuedProperty(property, value);
            }
        }
    }
}
