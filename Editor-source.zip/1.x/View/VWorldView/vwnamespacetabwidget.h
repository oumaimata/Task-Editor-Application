#pragma once
#ifndef VWNAMESPACETABWIDGET_H
#define VWNAMESPACETABWIDGET_H

#include <QWidget>

class VWorldModel;

namespace Ui {
class VWNamespaceTabWidget;
}

class VWNamespaceTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWNamespaceTabWidget *ui;

    bool _edit;

    /**
     * @brief _worldModel
     * Le modèle du monde en cours
     */
    VWorldModel * _worldModel;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    explicit VWNamespaceTabWidget(QWidget *parent = 0);

    ~VWNamespaceTabWidget();

    /**
     * @brief setWorldModel
     * Définit le modèle du monde en cours
     * @param activityModel Le modèle du monde en cours
     */
    void setWorldModel(VWorldModel * worldModel);

    void updateDisplay();

private slots:

    void on_namespaceLineEdit_editingFinished();
};

#endif // VWNAMESPACETABWIDGET_H
