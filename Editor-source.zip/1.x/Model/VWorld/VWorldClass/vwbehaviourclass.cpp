#include "vwbehaviourclass.h"

#include "vweventclass.h"
#include "../vwparser.h"
#include "../vwproperties.h"

VWBehaviourClass::VWBehaviourClass(QObject *parent) :
    VWEntityClass(parent),
  _isDurative(true),
  _isPunctual(false)
{
    setName("Behaviour" + QString::number(getUid()));
    _properties = new VWProperties();
    _properties->setType("action-behaviour-event");
    _properties->setWorldModelElement(this);
    _properties->setIsShared(true);
    connect(_properties, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
}

/**
 * @brief VWBehaviourClass
 * @param o L'objet à copier
 */
VWBehaviourClass::VWBehaviourClass(const VWBehaviourClass& o) :
    VWEntityClass(o.parent())
{
    _isDurative = o._isDurative;
    _isPunctual = o._isPunctual;
    _events = o._events;
    _properties = o._properties;
}

/**
 * @brief ~VWBehaviourClass
 * Destructeur
 */
VWBehaviourClass::~VWBehaviourClass()
{
    delete _properties;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWBehaviourClass::ParseDom(QDomElement elem)
{
    VWEntityClass::ParseDom(elem);
    QList<QString> domainSupClasses = VWParser::getDomainSupClasses(elem);
    foreach(QString domainSupClass, domainSupClasses)
    {
        if(domainSupClass == "durativebehaviour")
        {
            setIsDurative(true);
        }
        else if(domainSupClass == "punctualbehaviour")
        {
            setIsPunctual(true);
        }
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWBehaviourClass::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<owl:Class rdf:ID=\"" + getName() + "\">\n";
    RetVal += VWEntityClass::ToXml(tabulation + "\t");
    if(_isDurative) RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#DurativeBehaviour\"/>\n";
    if(_isPunctual) RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#PunctualBehaviour\"/>\n";
    RetVal += tabulation + "</owl:Class>\n";
    // liste d'event
    foreach(QPointer<VWEventClass> event, _events)
    {
        if(event != NULL)
        {
            RetVal += tabulation + "<owl:ObjectProperty rdf:about=\"" + "trigger-" + event->getName() + "-event\">\n";
            RetVal += tabulation + "\t" + "<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#trigger-event\"/>\n";
            RetVal += tabulation + "\t" + "<rdfs:domain rdf:resource=\"#" + getName() + "\"/>\n";
            RetVal += tabulation + "\t" + "<rdfs:range rdf:resource=\"#" + event->getName() + "\"/>\n";
            RetVal += tabulation + "</owl:ObjectProperty>\n";
        }
    }
    return RetVal;
}

void VWBehaviourClass::setIsDurative(bool isDurative)
{
    if(isDurative != _isDurative)
    {
        _isDurative = isDurative;
        _isPunctual = !_isDurative;
        onModified(_isDurative ? tr("Behaviour is durative") : tr("Behaviour is punctual"));
    }
}

bool VWBehaviourClass::getIsDurative() const
{
    return _isDurative;
}

void VWBehaviourClass::setIsPunctual(bool isPunctual)
{
    if(isPunctual != _isPunctual)
    {
        _isPunctual = isPunctual;
        _isDurative = !_isPunctual;
        onModified(_isDurative ? tr("Behaviour is durative") : tr("Behaviour is punctual"));
    }
}
bool VWBehaviourClass::getIsPunctual() const
{
    return _isPunctual;
}

void VWBehaviourClass::addEvent(VWEventClass * event)
{
    if(event != NULL)
    {
        _events.append(event);
        connect(event, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Event added"));
    }
}

void VWBehaviourClass::removeEvent(VWEventClass * event)
{
    if(_events.contains(event))
    {
        _events.removeAll(event);
        disconnect(event, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Event removed"));
    }
}

QList<QPointer<VWEventClass> > VWBehaviourClass::getEvents() const
{
    return _events;
}

QPointer<VWProperty> VWBehaviourClass::addProperty(QDomElement elem)
{
    if(_properties != NULL)  return _properties->addProperty(elem);
    return QPointer<VWProperty>();
}

VWProperties * VWBehaviourClass::getProperties() const
{
    return _properties;
}
