#include "vconstraint.h"

#include "../VActivityCommon/vtriple.h"

/**
 * @brief VConstraint
 * Constructeur du VConstraint
 * @param parent L'objet parent
 */
VConstraint::VConstraint(QObject *parent) :
    VActivityModelElement(parent)
{
}

/**
 * @brief VConstraint
 * Constructeur de recopie
 * @param constraint VConstraint à copier
 */
VConstraint::VConstraint(const VConstraint& constraint, QObject *parent):
    VActivityModelElement(parent)
{
    foreach(VTriple * triple, constraint._triples)
    {
        addTriple(triple->clone());
    }
}

/**
 * @brief ~VConstraint
 * Destructeur
 */
VConstraint::~VConstraint()
{
    while(_triples.count() > 0)
    {
        VTriple * triple = _triples.first();
        _triples.pop_front();
        delete triple;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VConstraint::parseDom(QDomElement elem)
{
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de triple
            if(element.tagName() == "triple")
            {
                VTriple * triple = new VTriple(this);
                triple->parseDom(element);
                addTriple(triple);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VConstraint::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<constraint>\n";

    // Ajouter les triples
    for(int i = 0; i < _triples.count(); i++)
    {
        RetVal += _triples[i]->ToXml(tabulation + "\t");
    }

    RetVal += tabulation + "</constraint>\n";
    return RetVal;
}

/**
 * @brief addTriple
 * Permet d'ajouter un VTriple
 * @param triple Un VTriple
 */
void VConstraint::addTriple(VTriple * triple)
{
    if(triple != NULL)
    {
        _triples.append(triple);
        connect(triple, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Triple added"));
    }
}

/**
 * @brief removeTriple
 * Permet de retirer un VTriple
 * @param triple Un VTriple
 */
void VConstraint::removeTriple(VTriple * triple)
{
    if(_triples.contains(triple))
    {
        _triples.removeAll(triple);
        disconnect(triple, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Triple removed"));
    }
}

/**
 * @brief getTriples
 * Obtient la liste des VTriple
 * @return La liste des VTriple
 */
QList<VTriple *> VConstraint::getTriples() const
{
    return _triples;
}

/**
 * @brief getTripleById
 * Obtient le triple correspondant à l'id
 * @param uid L'id du triple
 * @return Le triple correspondant à l'id
 */
VTriple * VConstraint::getTripleById(qint64 uid) const
{
    for(int i = 0; i < _triples.count(); i++)
    {
        if(_triples[i]->getUid() == uid)
        {
            return _triples[i];
        }
    }
    return NULL;
}

/**
 * @brief clone
 * @return Le clone
 */
VConstraint * VConstraint::clone(QObject *parent) const
{
    return new VConstraint(*this, parent);
}
