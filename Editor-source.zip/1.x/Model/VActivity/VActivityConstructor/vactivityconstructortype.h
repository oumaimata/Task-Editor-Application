#pragma once
#ifndef VACTIVITYCONSTRUCTORTYPE_H
#define VACTIVITYCONSTRUCTORTYPE_H

#include <QString>

/**
 * @brief The VActivityConstructorType enum
 * Enumération des différents type de constructeur
 */
enum VActivityConstructorType
{
    Ind = 0, // Indépendant
    Seq = 1, // Séquentiel
    SeqOrd = 2, // Séquentiel ordonné
    Par = 3, // Parallèle
    ParSim = 4, // Parallèle simultané
    ParStart = 5, // Parallèle synchonisé au début
    ParEnd = 6 ,// Parallèle synchronisé à la fin
    Ord = 7, //Ordonné
    SIZE_OF_VActivityConstructorType
};

/**
 * @brief VActivityConstructorTypeToString
 * Petmet de convertir un enum VActivityConstructorType en chaîne de caractère
 * @param type l'énumération
 * @return Une chaîne de caractère correspond au type de l'énumération
 */
static QString VActivityConstructorTypeToString(VActivityConstructorType type)
{
    switch(type)
    {
    case Ind:
        return "IND";
        break;
    case Seq:
        return "SEQ";
        break;
    case SeqOrd:
        return "SEQ-ORD";
        break;
    case Par:
        return "PAR";
        break;
    case ParSim:
        return "PAR-SIM";
        break;
    case ParStart:
        return "PAR-START";
        break;
    case ParEnd:
        return "PAR-END";
        break;
    case Ord:
        return "ORD";
        break;
    default:
        return "";
        break;
    }
}

/**
 * @brief VActivityConstructorTypeFromString
 * Obtient le VActivityConstructorType qui correspond à la chaîne de caractère passé en argument
 * @param type Une chaîne de caractère représentant un VActivityConstructorType
 * @return Le VActivityConstructorType correspondant
 */
static VActivityConstructorType VActivityConstructorTypeFromString(QString type)
{
    if(type.toUpper() == "IND")
    {
        return Ind;
    }
    else if(type.toUpper() == "SEQ")
    {
        return Seq;
    }
    else if(type.toUpper() == "SEQ-ORD")
    {
        return SeqOrd;
    }
    else if(type.toUpper() == "PAR")
    {
        return Par;
    }
    else if(type.toUpper() == "PAR-SIM")
    {
        return ParSim;
    }
    else if(type.toUpper() == "PAR-START")
    {
        return ParStart;
    }
    else if(type.toUpper() == "PAR-END")
    {
        return ParEnd;
    }
    else if(type.toUpper() == "ORD")
    {
        return Ord;
    }
    else
    {
        return SIZE_OF_VActivityConstructorType;
    }
}

#endif // VACTIVITYCONSTRUCTORTYPE_H
