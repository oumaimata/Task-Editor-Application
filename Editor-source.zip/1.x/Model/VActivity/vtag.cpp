#include "vtag.h"
#include "../../Controller/vtracecontroller.h"

/**
 * @brief initialized
 * Si la liste des couleurs est initialisée
 */
bool VTag::initialized = false;

/**
 * @brief defaultColor
 * Couleur par défaut des tag
 */
QColor VTag::defaultColor = Qt::transparent;
/**
 * @brief EmptyList
 * Utile pour l'initialisation de s_colors
 * @return Une liste vide de couleurs
 */
QList<QColor> VTag::EmptyList()
{
   QList<QColor> list;
   return list;
}

/**
 * @brief VTag
 * Constructeur
 * @param parent L'objet parent
 */
VTag::VTag(QObject *parent) :
    VActivityModelElement(parent),
    _valued(false),
    _visible(true),
    _color(defaultColor)
{
    _id = getUid();
    _name = "tag_" + QString::number(_id);
}

/**
 * @brief VTag
 * Constructeur de recopie
 * @param tag Tag à copier
 */
VTag::VTag(const VTag& tag, QObject *parent) :
    VActivityModelElement(parent)
{
    _id = tag._id;
    _name = tag._name;
    _valued = tag._valued;
    _visible = tag._visible;
    _color = tag._color;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VTag::parseDom(QDomElement elem)
{
    setId(elem.attribute("id",""));
    setName(elem.attribute("name",""));
    setValued(elem.attribute("valued",""));
    setVisible(elem.attribute("visible",""));
    QString colorName = elem.attribute("color", "");
    if(colorName.isEmpty())
        setColor(Qt::transparent);
    else
        setColor(colorName);

}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VTag::ToXml(QString tabulation)
{
    VTag* thisParent = (VTag*) this->parent();

    QString RetVal = tabulation + "<tag";
    RetVal += " id=\"" + QString::number(_id) + "\"";
    RetVal += " name=\"" + _name + "\"";
    if(thisParent != NULL) RetVal += " supertags=\"" + QString::number(thisParent->_id) + "\""; // Si le tag possède un parent, on l'ajoute
    if(_valued == true)
    {
        RetVal += " valued=\"true\"";
    }
    else
    {
        RetVal += " valued=\"false\"";
    }
    if(_visible == true){
        RetVal += " visible=\"true\"";
    }
    else{
        RetVal += " visible=\"false\"";
    }
    if(_color != Qt::transparent)
        RetVal += " color=\""+ _color.name() +"\"";
    RetVal += " />\n";
    return RetVal;
}

/**
 * @brief getTagById
 * Obtient le tag ayant l'id passé en argument
 * @param id L'id d'un tag
 * @return Le tag s'i elle'il existe sinon null
 */
VTag* VTag::getTagById(qint64 id)
{
    if(_id == id)
    {
        return this;
    }
    QList<VTag*> tags = getChildTags();
    for(int i = 0; i < tags.count(); i++)
    {
        VTag* tag = tags[i]->getTagById(id);
        if(tag != NULL)
        {
            return tag;
        }
    }
    return NULL;
}

/**
 * @brief getTagParentFromDom
 * Obtient l'id du tag père
 * @param elem Un élément du dom
 * @return L'id du tag père
 */
QString VTag::getTagParentFromDom(QDomElement elem)
{
    return elem.attribute("supertags", "");
}

/**
 * @brief setParent
 * Surcharge afin de suivre l'évolution de l'arborescence
 * @param object L'objet parent
 */
void VTag::setParent(QObject * object)
{
    if(object != parent())
    {
        QObject::setParent(object);
        onModified(NULL);
    }
}

/**
 * @brief setId
 * Définit l'Id
 * @param id L'id
 */
void VTag::setId(qint64 id)
{
    if(id != _id)
    {
        _id = id;
        onModified(tr("Id changed"));
    }
}

/**
 * @brief setId
 * Définit l'Id
 * @param id L'id
 */
void VTag::setId(QString id)
{
    setId(id.toInt());
}

/**
 * @brief getId
 * Obtient l'Id
 * @return L'id
 */
qint64 VTag::getId() const
{
    return _id;
}

/**
 * @brief setName
 * Définit le nom
 * @param name Le nom
 */
void VTag::setName(QString name)
{
    if(_name != name)
    {
        _name = name;
        onModified(tr("Name changed"));
    }
}

/**
 * @brief getName
 * Obtient le nom
 * @return Le nom
 */
QString VTag::getName() const
{
    return _name;
}

/**
 * @brief setValued
 * Définie si le tag possède une valeur
 * @param valued Si le tag possède une valeur
 */
void VTag::setValued(bool valued)
{
    if(_valued != valued)
    {
        _valued = valued;
        onModified(tr("Value changed"));
    }
}

/**
 * @brief setValued
 * Définie si le tag possède une valeur
 * @param valued Si le tag possède une valeur
 */
void VTag::setValued(QString valued)
{
    setValued(valued.toLower() == "true");
}

/**
 * @brief getValued
 * Obtient si le tag possède une valeur
 * @return Si le tag possède une valeur
 */
bool VTag::getValued() const
{
    return _valued;
}


/**
 * @brief setVisible
 * set l'attribut à partir d'un QString. Utile pour la conversion depuis XML.
 */
void VTag::setVisible(QString isVisible){
    setVisible(isVisible.toLower() == "true");
}

/**
 * @brief setVisible
 * Vrai si le tag doit être visible dans le graphisme d'une tâche
 * Faux sinon
 * @param visible si le tag doit être visible
 */
void VTag::setVisible(bool visible)
{
    _visible = (_visible != visible)?visible:_visible;
    onModified("Tag visibility changed");

//    // Si il n'y a plus de couleur dispo
//    if(s_colors.count() == 0 && visible)
//    {
//        onModified(NULL);
//        return;
//    }
//    if(_visible != visible)
//    {
//        _visible = visible;

//        // Affect a color if visible
//        if(_visible)
//        {
//            _color = s_colors.last();
//            s_colors.pop_back();
//        }
//        else
//        {
//            s_colors.push_front(_color);
//            _color = Qt::transparent;
//        }
//        onModified(NULL);
//    }
}

/**
 * @brief getVisible
 * Vrai si le tag doit être visible dans le graphisme d'une tâche
 * Faux sinon
 * @return si le tag doit être visible
 */
bool VTag::getVisible() const
{
    return _visible;
}

/**
 * @brief setColor
 * Définit la couleur associée au tag
 * @param color La couleur associée au tag
 */
void VTag::setColor(QColor color)
{
    if(_color != color)
    {
        _color = color;
        onModified(tr("Tag color changed"));
    }
}

/**
 * @brief getColor
 * Obtient la couleur associée au tag
 * @return La couleur associée au tag
 */
QColor VTag::getColor() const
{
    return _color;
}


/**
 * @brief childTagAdded
 * Notifie au Tag parent que le tag passé en paramètre a été ajouté
 * @param tag Le nouveau tag
 */
void VTag::childTagAdded(VTag* tag)
{
    VTraceController::get()->Debug("VTag::childTagAdded()", "Begin");
    VTag* thisParent = (VTag*) this->parent();
    if (thisParent == NULL)
    {
        emit tagAdded(tag);// Emet de signal d'ajout de tag
    }
    else
    {
        thisParent->childTagAdded(tag); // notifie le tag parent
    }
    VTraceController::get()->Debug("VTag::childTagAdded()", "End");
}

/**
 * @brief childTagRemoved
 * Notifie au Tag parent que le tag passé en paramètre a été supprimé
 * @param tag L'ancien tag
 */
void VTag::childTagRemoved(VTag* tag)
{
    VTraceController::get()->Debug("VTag::childTagRemoved()", "Begin");
    VTag* thisParent = (VTag*) this->parent();
    if (thisParent == NULL)
    {
        emit tagRemoved(tag);// Emet de signal de suppression de tag
    }
    else
    {
        thisParent->childTagRemoved(tag); // notifie le tag parent
    }
    VTraceController::get()->Debug("VTag::childTagRemoved()", "End");
}

/**
 * @brief getChildTags
 * Obtient une liste des tags fils
 * @return Une liste des tags fils
 */
QList<VTag *> VTag::getChildTags() const
{
    return _childs;
}

/**
 * @brief getAllChildTags
 * Obtient une liste des tags fils de toute l'arborescence
 * @return Une liste des tags fils de toute l'arborescence
 */
QList<VTag *> VTag::getAllChildTags() const
{
    QList<VTag *> childTags = getChildTags();
    QList<VTag *> allChildTags = getChildTags();
    foreach(VTag * childTag, childTags)
    {
        allChildTags.append(childTag->getAllChildTags());
    }
    return allChildTags;
}

/**
 * @brief addChildTag
 * Ajout un tag fils au tag courant
 * @param tag Le tag à ajouter
 */
void VTag::addChildTag(VTag* tag)
{
    VTraceController::get()->Debug("VTag::addChildTag", "Begin");
    if (tag == NULL)
    {
        tag = new VTag(this);
    }
    else
    {
        tag->setParent(this);
    }
    VTraceController::get()->Info("VTag::addChildTag", "Child tag added");
    if(!_childs.contains(tag)) _childs.append(tag);
    this->childTagAdded(tag);
    VTraceController::get()->Debug("VTag::addChildTag", "End");
}

/**
 * @brief removeChildTag
 * Retire un tag fils au tag courant
 * @param tag Le tag à ajouter
 */
void VTag::removeChildTag(VTag* tag)
{
    VTraceController::get()->Debug("VTag::removeChildTag", "Begin");
    if (_childs.contains(tag))
    {
        VTraceController::get()->Info("VTag::removeChildTag", "Notify tag removed");
         _childs.removeAll(tag);
        this->childTagRemoved(tag);

        VTraceController::get()->Info("VTag::removeChildTag", "Child tag removed");
        delete tag;
    }
    VTraceController::get()->Debug("VTag::removeChildTag", "End");
}
