#include "vwrequesttabwidget.h"
#include "ui_vwrequesttabwidget.h"

#include "Model/vapplicationmodel.h"

VWRequestTabWidget::VWRequestTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWRequestTabWidget)
{
    ui->setupUi(this);
}

VWRequestTabWidget::~VWRequestTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWRequestTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief on_executeButton_clicked
 * Gère le click sur le bouton execute
 */
void VWRequestTabWidget::on_executeButton_clicked()
{
    // Vider les anciens résultats de requète
    ui->outTextEdit->setPlainText("");

    // Récupérer la requète
    QString query = ui->requestTextEdit->toPlainText();

    // Envoyer la requète au VWorldModel
    QString result = VApplicationModel::getInstance()->getWorldModel().executeQuery(query);

    // Afficher le résultat de la requète
    ui->outTextEdit->setPlainText(result);
}
