#include "vstopconditionstabwidget.h"
#include "ui_vstopconditionstabwidget.h"

#include <QInputDialog>

#include "../VActivityToolsView/vtreewidgetitemdata.h"
#include "../VActivityToolsView/vtriplesubjectwidget.h"
#include "../VActivityToolsView/vtripleobjectwidget.h"
#include "../VActivityToolsView/vtripleobjectcheckbox.h"
#include "../VActivityToolsView/vstopconditioncombobox.h"
#include "../VActivityToolsView/vsatisfactioncombobox.h"
#include "../VActivityToolsView/vinstancecombobox.h"
#include "../VActivityToolsView/vstatementtypecombobox.h"
#include "../VActivityToolsView/vtriplepredicatecombobox.h"

#include "Model/VActivity/vtask.h"
#include "Model/VActivity/VActivityCondition/vstopcondition.h"
#include "Model/VActivity/VActivityCondition/vstopconditions.h"
#include "Model/VActivity/VActivityCondition/vstatement.h"
#include "Model/VActivity/VActivityCondition/vmacro.h"
#include "Model/VActivity/VActivityCondition/vvar.h"
#include "Model/VActivity/VActivityCondition/vnottriples.h"
#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Controller/vtracecontroller.h"

VStopConditionsTabWidget::VStopConditionsTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VStopConditionsTabWidget),
    _edit(false),
    _task(NULL),
    _stopConditions(NULL)
{
    ui->setupUi(this);
    blackFont = new QFont();
    blackFont->setWeight(QFont::Black);
}

VStopConditionsTabWidget::~VStopConditionsTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VStopConditionsTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setTask
 * Définit la tâche en cours d'édition
 * @param task La tâche en cours d'édition
 */
void VStopConditionsTabWidget::setTask(VTask *task)
{
    if (task != _task)
    {
        VTraceController::get()->Info("VStopConditionsTabWidget::setTask()", "Task defined");
        _task = task;
        _stopConditions = NULL;
    }
    updateDisplay();
}

/**
 * @brief getTask
 * Obitent la tâche en cours d'édition
 * @return La tâche en cours d'édition
 */
VTask * VStopConditionsTabWidget::getTask() const
{
    return _task;
}

/**
 * @brief setStopConditions
 * Définit les stop conditions en cours d'édition
 * @param condition Les stop conditions en cours d'édition
 */
void VStopConditionsTabWidget::setStopConditions(VStopConditions * stopConditions)
{
    if (stopConditions != _stopConditions)
    {
        _stopConditions = stopConditions;
    }
    updateDisplay();
}

/**
 * @brief getStopConditions
 * Obitent les stop conditions en cours d'édition
 * @return Les stop conditions en cours d'édition
 */
VStopConditions * VStopConditionsTabWidget::getStopConditions() const
{
    return _stopConditions;
}

/**
 * @brief updateDisplay
 * Met a jour les intefaces
 * en fonction de la tache sélectionnée
 */
void VStopConditionsTabWidget::updateDisplay()
{
    _edit = true;
    // Vide l'arbre
    int topLevelItemCount = ui->treeWidget->topLevelItemCount();
    for(int i = 0; i < topLevelItemCount; i++)
    {
        ui->treeWidget->takeTopLevelItem(0);
    }
    setEnabled(false);

    if(_stopConditions != NULL && _task != NULL)
    {
        foreach(VStopCondition * stopCondition, _stopConditions->getStopConditions())
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(ui->treeWidget);
            item->setExpanded(true);
            item->setText(0, "stop");
            item->setFlags(item->flags() | Qt::ItemIsEditable);
            item->setText(1, QString::number(stopCondition->getId()));
            item->setFont(0, *blackFont);
            item->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(stopCondition));
            setItemBackgroundColor(item, 2);

            if(stopCondition->getType() == "satisfaction")
            {
                addSatisfactionItem(item, stopCondition);
            }
            else if(stopCondition->getType() == "instance")
            {
                addInstanceItem(item, stopCondition);
            }
            else if(stopCondition->getType() == "statement")
            {
                addStatementItem(item, stopCondition);
            }
            else if(stopCondition->getType() == "duration")
            {
                addDurationItem(item, stopCondition);
            }
            else if(stopCondition->getType() == "iteration")
            {
                addIterationItem(item, stopCondition);
            }
        }
        ui->treeWidget->resizeColumnToContents(0);
        ui->treeWidget->setColumnWidth(0, ui->treeWidget->columnWidth(0) + 20);
        ui->treeWidget->resizeColumnToContents(1);
        ui->treeWidget->resizeColumnToContents(2);
        ui->treeWidget->resizeColumnToContents(3);
        setEnabled(true);
    }
    _edit = false;
}

/**
 * @brief addStatementItem
 * Retourne un item d'arbre correspondant à un statement
 * @param parent L'item parent
 * @param statement Le statemnt
 * @param stopConndition la stop condition
 * @return Un item d'arbre correspondant à un statement
 */
QTreeWidgetItem * VStopConditionsTabWidget::addStatementItem(QTreeWidgetItem * parent, VStopCondition * stopCondition)
{
    VStatement * statement = stopCondition->getStatement();
    QTreeWidgetItem * statementItem = new QTreeWidgetItem(parent);
    statementItem->setExpanded(true);
    statementItem->setFlags(statementItem->flags() | Qt::ItemIsEditable);
    statementItem->setText(0, "statement");
    statementItem->setFont(0, *blackFont);
    statementItem->setToolTip(1, "Type");
    QComboBox * typeComboBox = new VStatementTypeComboBox(statement);
    ui->treeWidget->setItemWidget(statementItem, 1, typeComboBox);

    statementItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(stopCondition, statement));
    setItemBackgroundColor(statementItem, 2);
    parent->addChild(statementItem);

    foreach(VNotTriples * notTriples, statement->getNotTriples())
    {
        QTreeWidgetItem * notTripleItem = new QTreeWidgetItem(statementItem);
        notTripleItem->setText(0, "NOT");
        notTripleItem->setFont(0, *blackFont);
        notTripleItem->setExpanded(true);
        notTripleItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, notTriples));
        setItemBackgroundColor(notTripleItem, 1);
        statementItem->addChild(notTripleItem);

        foreach(VTriple * triple, notTriples->getTriples())
        {
            addTripleItem(notTripleItem, triple, statement, notTriples);
        }
    }

    foreach(VTriple * triple, statement->getTriples())
    {
        addTripleItem(statementItem, triple, statement);
    }

    foreach(VMacro * macro, statement->getMacros())
    {
        QTreeWidgetItem * macroItem = new QTreeWidgetItem(statementItem);
        macroItem->setExpanded(true);
        macroItem->setFlags(macroItem->flags() | Qt::ItemIsEditable);
        macroItem->setText(0, "macro");
        macroItem->setFont(0, *blackFont);
        macroItem->setText(1, VActivityMacroTypeToString(macro->getOperator())); macroItem->setToolTip(1, "Operator");
        macroItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, NULL, NULL, macro));
        setItemBackgroundColor(macroItem, 2);
        statementItem->addChild(macroItem);

        foreach(VVar * var, macro->getVars())
        {
            QTreeWidgetItem * varItem = new QTreeWidgetItem(macroItem);
            varItem->setFlags(varItem->flags() | Qt::ItemIsEditable);
            varItem->setText(0, "var");
            varItem->setFont(0, *blackFont);
            varItem->setText(1, var->getN()); varItem->setToolTip(1, "n");
            varItem->setText(2, var->getId()); varItem->setToolTip(2, "id");
            varItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, NULL, NULL, macro, var));
            setItemBackgroundColor(varItem, 3);
            macroItem->addChild(varItem);
        }
    }
    return statementItem;
}

/**
 * @brief addTripleItem
 * Retourne et ajoute un item d'arbre correspondant à un triple
 * @param parent L'item parent
 * @param triple
 * @param statement
 * @param notTriples
 * @return Un item d'arbre correspondant à un triple
 */
QTreeWidgetItem * VStopConditionsTabWidget::addTripleItem(QTreeWidgetItem *parent, VTriple * triple, VStatement * statement, VNotTriples * notTriples)
{
    QTreeWidgetItem * tripleItem = new QTreeWidgetItem(parent);
    tripleItem->setFlags(tripleItem->flags() | Qt::ItemIsEditable);
    tripleItem->setText(0, "triple");
    tripleItem->setFont(0, *blackFont);
    tripleItem->setToolTip(1, "Subject");
    tripleItem->setToolTip(2, "Predicate");
    tripleItem->setToolTip(3, "Object");

    QComboBox * subjectComboBox = new VTripleSubjectWidget(statement, triple);
    ui->treeWidget->setItemWidget(tripleItem, 1, subjectComboBox);

    if(statement->getType() == domain)
    {
        QComboBox * predicateComboBox = new VTriplePredicateComboBox(statement, triple);
        ui->treeWidget->setItemWidget(tripleItem, 2, predicateComboBox);

        QComboBox * objectComboBox = new VTripleObjectWidget(statement, triple);
        ui->treeWidget->setItemWidget(tripleItem, 3, objectComboBox);
    }
    else if(statement->getType() == activity)
    {
        tripleItem->setText(2, triple->getPredicate());

        QCheckBox * objectCheckBox = new VTripleObjectCheckBox(statement, triple);
        ui->treeWidget->setItemWidget(tripleItem, 3, objectCheckBox);
    }

    tripleItem->setData(0, Qt::UserRole, VTreeWidgetItemData::getQVariant(statement, notTriples, triple));
    setItemBackgroundColor(tripleItem, 4);
    parent->addChild(tripleItem);
    return tripleItem;
}

QTreeWidgetItem * VStopConditionsTabWidget::addSatisfactionItem(QTreeWidgetItem *parent, VStopCondition * stopCondition)
{
    QTreeWidgetItem * item = new QTreeWidgetItem(parent);
    item->setFlags(item->flags() | Qt::ItemIsEditable);
    item->setText(0, "satisfaction");
    item->setFont(0, *blackFont);
    item->setData(0, Qt::UserRole, VTreeWidgetItemData::getOther("satisfaction", stopCondition));

    QComboBox * stopConditionComboBox = new VStopConditionComboBox(stopCondition);
    ui->treeWidget->setItemWidget(item, 0, stopConditionComboBox);

    QComboBox * satisfactionComboBox = new VSatisfactionComboBox(stopCondition);
    ui->treeWidget->setItemWidget(item, 1, satisfactionComboBox);

    parent->addChild(item);
    setItemBackgroundColor(item, 2);
    return item;
}

QTreeWidgetItem * VStopConditionsTabWidget::addInstanceItem(QTreeWidgetItem *parent, VStopCondition * stopCondition)
{
    QTreeWidgetItem * item = new QTreeWidgetItem(parent);
    item->setFlags(item->flags() | Qt::ItemIsEditable);
    item->setText(0, "instance");
    item->setFont(0, *blackFont);
    item->setData(0, Qt::UserRole, VTreeWidgetItemData::getOther("instance", stopCondition));

    QComboBox * stopConditionComboBox = new VStopConditionComboBox(stopCondition);
    ui->treeWidget->setItemWidget(item, 0, stopConditionComboBox);

    QComboBox * instanceComboBox = new VInstanceComboBox(stopCondition);
    ui->treeWidget->setItemWidget(item, 1, instanceComboBox);

    parent->addChild(item);
    setItemBackgroundColor(item, 2);
    return item;
}

QTreeWidgetItem * VStopConditionsTabWidget::addDurationItem(QTreeWidgetItem *parent, VStopCondition * stopCondition)
{
    QTreeWidgetItem * item = new QTreeWidgetItem(parent);
    item->setFlags(item->flags() | Qt::ItemIsEditable);
    item->setText(0, "duration");
    item->setText(1, stopCondition->getDuration().toString("hh")); item->setToolTip(1, "h");
    item->setText(2, stopCondition->getDuration().toString("mm")); item->setToolTip(2, "m");
    item->setText(3, stopCondition->getDuration().toString("ss")); item->setToolTip(3, "s");
    item->setFont(0, *blackFont);
    item->setData(0, Qt::UserRole, VTreeWidgetItemData::getOther("duration", stopCondition));

    QComboBox * stopConditionComboBox = new VStopConditionComboBox(stopCondition);
    ui->treeWidget->setItemWidget(item, 0, stopConditionComboBox);

    parent->addChild(item);
    setItemBackgroundColor(item, 4);
    return item;
}

QTreeWidgetItem * VStopConditionsTabWidget::addIterationItem(QTreeWidgetItem *parent, VStopCondition * stopCondition)
{
    QTreeWidgetItem * item = new QTreeWidgetItem(parent);
    item->setFlags(item->flags() | Qt::ItemIsEditable);
    item->setText(0, "iteration");
    item->setText(1, QString::number(stopCondition->getIteration()));
    item->setFont(0, *blackFont);
    item->setTextAlignment(1, Qt::AlignRight);
    item->setToolTip(1, "Number");
    item->setData(0, Qt::UserRole, VTreeWidgetItemData::getOther("iteration", stopCondition));

    QComboBox * stopConditionComboBox = new VStopConditionComboBox(stopCondition);
    ui->treeWidget->setItemWidget(item, 0, stopConditionComboBox);

    parent->addChild(item);
    setItemBackgroundColor(item, 2);
    return item;
}

/**
 * @brief setItemBackgroundColor
 * Définie le backgroundcolor de l'item de begin au nombre de colonne
 * @param item L'item à mettre à jour
 * @param beginIndex L'index de début
 */
void VStopConditionsTabWidget::setItemBackgroundColor(QTreeWidgetItem * item, int beginIndex)
{
    for(int i = beginIndex; i < 7; i++)
    {
        item->setBackgroundColor(i, QColor(230, 230, 230));
    }
}

void VStopConditionsTabWidget::on_addButton_clicked()
{
    if(ui->treeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedQTreeWidgetItem = ui->treeWidget->selectedItems().first();
        VTreeWidgetItemData * selectedItem = selectedQTreeWidgetItem->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

        if(selectedItem == NULL) return;

        // Déclaration :
        VStatement * statement = selectedItem->getStatement();
        VNotTriples * notTriples = selectedItem->getNotTriples();
        VTriple * triple = selectedItem->getTriple();
        VMacro * macro = selectedItem->getMacro();
        VVar * var = selectedItem->getVar();

        // Traitement des ajouts:
        if(macro != NULL)
        {
            var = new VVar(macro);
            macro->addVar(var);
        }
        else if(triple != NULL)
        {
            if(notTriples == NULL)
            {
                triple = new VTriple(statement);
                statement->addTriple(triple);
            }
            else
            {
                triple = new VTriple(notTriples);
                notTriples->addTriple(triple);
            }
        }
        else if(notTriples != NULL)
        {
            triple = new VTriple(notTriples);
            notTriples->addTriple(triple);
        }
        else if(statement != NULL)
        {
            // Demander soit nottriples soit triple soit macro -> IHM de demande à l'utilisateur
            bool ok = false;
            QString choice = QInputDialog::getText(this, tr("Add"), tr("Add a triple or a macro or a NOT ?"), QLineEdit::Normal, QString(), &ok);
            if(ok && !choice.isEmpty())
            {
                if(choice.toLower() == "triple")
                {
                    triple = new VTriple(statement);
                    statement->addTriple(triple);
                }
                else if(choice.toLower() == "not")
                {
                    notTriples = new VNotTriples(statement);
                    triple = new VTriple(notTriples);
                    notTriples->addTriple(triple);
                    statement->addNotTriples(notTriples);
                }
                else if(choice.toLower() == "macro")
                {
                    macro = new VMacro(statement);
                    statement->addMacro(macro);
                }
            }
        }
        else
        {
            VStopCondition * stopCondition = new VStopCondition(_stopConditions);
            _stopConditions->addStopCondition(stopCondition);
        }
    }
    else
    {
        VStopCondition * stopCondition = new VStopCondition(_stopConditions);
        _stopConditions->addStopCondition(stopCondition);
    }
}

void VStopConditionsTabWidget::on_treeWidget_itemChanged(QTreeWidgetItem *item, int column)
{
    if(_edit) return;
    VTreeWidgetItemData * selectedItem = item->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

    if(selectedItem == NULL) return;

    // Déclaration :
    VStopCondition * stopCondition = selectedItem->getStopCondition();
    VStatement * statement = selectedItem->getStatement();
    VTriple * triple = selectedItem->getTriple();
    VMacro * macro = selectedItem->getMacro();
    VVar * var = selectedItem->getVar();

    // Traitement des modifications:
    if(var != NULL)
    {
        if(column == 1)
        {
            var->setN(item->text(column));
            return;
        }
        else if(column == 2)
        {
            var->setId(item->text(column));
            return;
        }
    }
    else if(macro != NULL)
    {
        if(column == 1)
        {
            macro->setOperator(item->text(column));
        }
    }
    else if(triple != NULL)
    {
        if(column == 1)
        {
            triple->setSubject(item->text(column));
        }
        else if(column == 2)
        {
            triple->setPredicate(item->text(column));
        }
        else if(column == 3)
        {
            triple->setObject(item->text(column));
        }
    }
    else if(statement != NULL)
    {
        if(column == 1)
        {
            statement->setType(item->text(column));
        }
    }
    else if(stopCondition != NULL)
    {
        if(!selectedItem->getIsOther())
        {
            if(column == 1)
            {
                stopCondition->setId(item->text(column));
            }
            else if(column == 2)
            {
                stopCondition->setType(item->text(column));
            }
        }
        else
        {
            if(selectedItem->getType() == "duration")
            {
                stopCondition->setDuration(item->text(1).toInt(), item->text(2).toInt(), item->text(3).toInt());
            }
            else if(column == 1 && selectedItem->getType() == "iteration")
            {
                stopCondition->setIteration(item->text(column).toInt());
            }
        }

    }
    updateDisplay();
}

void VStopConditionsTabWidget::on_removeButton_clicked()
{
    if(_stopConditions != NULL && ui->treeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedQTreeWidgetItem = ui->treeWidget->selectedItems().first();
        VTreeWidgetItemData * selectedItem = selectedQTreeWidgetItem->data(0, Qt::UserRole).value<VTreeWidgetItemData *>();

        if(selectedItem == NULL) return;

        // Déclaration :
        VStopCondition * stopCondition = selectedItem->getStopCondition();
        VStatement * statement = selectedItem->getStatement();
        VNotTriples * notTriples = selectedItem->getNotTriples();
        VTriple * triple = selectedItem->getTriple();
        VMacro * macro = selectedItem->getMacro();
        VVar * var = selectedItem->getVar();

        // Traitement des suppressions:
        if(var != NULL)
        {
            macro->removeVar(var);
            delete var;
        }
        else if(macro != NULL)
        {
            statement->removeMacro(macro);
            delete macro;
        }
        else if(triple != NULL)
        {
            if(notTriples != NULL)
            {
                notTriples->removeTriple(triple);
            }
            else if(statement != NULL)
            {
                statement->removeTriple(triple);
            }
            delete triple;
        }
        else if(notTriples != NULL)
        {
            statement->removeNotTriples(notTriples);
            delete notTriples;
        }
        else if(stopCondition != NULL)
        {
            _stopConditions->removeStopCondition(stopCondition);
            delete stopCondition;
        }
    }
}

void VStopConditionsTabWidget::on_logicalOperatorComboBox_currentIndexChanged(int index)
{
    if(_stopConditions != NULL) _stopConditions->setLogicalOperator(ui->logicalOperatorComboBox->itemText(index));
}
