#pragma once
#ifndef VACTIVITYSTATEMENTTYPE_H
#define VACTIVITYSTATEMENTTYPE_H

#include <QString>

/**
 * @brief The VActivityStatementType enum
 * Enumération des différents type de statement
 */
enum VActivityStatementType
{
    domain = 0,
    activity = 1,
    SIZE_OF_VActivityStatementType
};

static QString VActivityStatementTypeToString(VActivityStatementType type)
{
    switch(type)
    {
    case domain:
        return "domain";
        break;
    case activity:
        return "activity";
        break;
    default:
        return "";
        break;
    }
}

static VActivityStatementType VActivityStatementTypeFromString(QString type)
{
    if(type.toLower() == "domain")
    {
        return domain;
    }
    else if(type.toLower() == "activity")
    {
        return activity;
    }
    else
    {
        return SIZE_OF_VActivityStatementType;
    }
}

#endif // VACTIVITYSTATEMENTTYPE_H
