#pragma once
#ifndef VCONSTRUCTOR_H
#define VCONSTRUCTOR_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"
#include "vactivityconstructortype.h"

class VTask;
class VRelation;

class VConstructor : public VActivityModelElement
{
    Q_OBJECT
private:
    VTask * _task;

    VActivityConstructorType _type;

    QList<VRelation *> _relations;

public:
    explicit VConstructor(QObject *parent = 0);

    VConstructor(const VConstructor& constructor, QObject *parent = 0);

    /**
     * @brief ~VConstructor
     * Destructeur
     */
    ~VConstructor();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    /**
     * @brief AfterTasksParsed
     * Définie les tâches des relations
     */
    void AfterTasksParsed();

    /**
     * @brief updateRelations
     * Met à jour les relations
     */
    void updateRelations(QList<VTask *> tasks);

    void setTask(VTask *task);

    void setType(QString type);

    void setType(VActivityConstructorType type);

    VActivityConstructorType getType();

    void addRelation(VRelation * relation);

    void removeRelation(VRelation * relation);

    QList<VRelation *> getRelations() const;

    /**
     * @brief getRefById
     * Obtient la relation correspondant à l'id
     * @return La relation correspondant à l'id
     */
    VRelation * getRelationById(qint64 uid) const;

    /**
     * @brief getTaskOrdered
     * Obtient les tâches dans l'ordre
     * @return La liste des tâches dans l'ordre
     */
    QList<VTask *> getTaskOrdered() const;

    /**
     * @brief removeRelationOf
     * Supprime les relations contenant la tâche passée en argument
     * @param task Une tâche
     */
    void removeRelationOf(VTask * task);

    /**
     * @brief clone
     * @return Le clone
     */
    VConstructor * clone(QObject *parent = 0) const;
};

#endif // VCONSTRUCTOR_H
