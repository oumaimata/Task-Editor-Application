#pragma once
#ifndef VONTOLOGYINTERPRETER_H
#define VONTOLOGYINTERPRETER_H

#include <QObject>
#include <QList>

#include "vjenabridge.h"

class VOntologyInterface : public QObject
{
    Q_OBJECT

private:
    static VOntologyInterface * _instance;

    VJenaBridge _jenaBridge;

    explicit VOntologyInterface(QObject* parent = NULL);

public:
    /**
     * @brief getInstance
     * Obtient l'instance de VOntologyInterface
     * @return L'instance
     */
    static VOntologyInterface* getInstance();

    bool loadOntology(const QString& file);

    QList<QString> getSubclassesOf(const QString& concept);

    QList<QString> getDirectSubclassesOf(const QString& concept);

    QList<QString> getRelatedOf(const QString& concept);

    QString getConcept(const QString& conceptName);

    /**
     * @brief executeQuery
     * Execute une requète SPARQL dans JENA
     * @param query La requète
     * @return Le résultat de la requète
     */
    QString executeQuery(const QString& query);
};

#endif // VONTOLOGYINTERPRETER_H
