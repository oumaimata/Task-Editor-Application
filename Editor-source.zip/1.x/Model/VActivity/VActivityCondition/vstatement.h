#pragma once
#ifndef VSTATEMENT_H
#define VSTATEMENT_H

#include <QtXml>
#include "../VActivityCommon/vactivitymodelelement.h"
#include "vactivitystatementtype.h"

class VTriple;
class VNotTriples;
class VMacro;

class VStatement : public VActivityModelElement
{
    Q_OBJECT
private:

    VActivityStatementType _type;

    QList<VTriple *> _triples;

    QList<VNotTriples *> _notTriples;

    QList<VMacro *> _macros;
public:
    explicit VStatement(QObject *parent = 0);

    VStatement(const VStatement& statement, QObject *parent = 0);

    /**
     * @brief ~VStatement
     * Destructeur
     */
    ~VStatement();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setType(VActivityStatementType type);
    void setType(QString type);
    VActivityStatementType getType() const;

    void addTriple(VTriple * triple);
    void removeTriple(VTriple * triple);
    QList<VTriple *> getTriples() const;
    VTriple * getTripleById(qint64 uid) const;

    void addNotTriples(VNotTriples * notTriple);
    void removeNotTriples(VNotTriples * notTriple);
    QList<VNotTriples *> getNotTriples() const;
    VNotTriples * getNotTriplesById(qint64 uid) const;

    void addMacro(VMacro * macro);
    void removeMacro(VMacro * macro);
    QList<VMacro *> getMacros() const;
    VMacro * getMacroById(qint64 uid) const;

    QString toString(QString tabulation = "") const;

    /**
     * @brief clone
     * @return Le clone
     */
    VStatement * clone(QObject *parent = 0) const;
    /**
     * @brief copyFrom
     * copie les valeurs des attributs de l'objet passé en paramètre dans l'objet courant
     */
    void copyFrom(const VStatement& statement);

    VStatement& operator=(const VStatement& statement);

};

#endif // VSTATEMENT_H
