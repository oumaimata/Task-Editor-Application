#include "vreftagstabwidget.h"
#include "ui_vreftagstabwidget.h"

#include "Model/VActivity/vtask.h"
#include "Model/VActivity/vtag.h"
#include "Model/VActivity/vactivitymodel.h"
#include "Controller/vtracecontroller.h"

/**
 * @brief VRefTagsTabWidget
 * Constructeur
 * @param parent L'objet parent
 */
VRefTagsTabWidget::VRefTagsTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VRefTagsTabWidget),
    _activityModel(NULL)
{
    ui->setupUi(this);
}

/**
 * @brief VRefTagsTabWidget::~VRefTagsTabWidget
 * Destructeur
 */
VRefTagsTabWidget::~VRefTagsTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VRefTagsTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setActivityModel
 * Définit le modèle d'activité en cours
 * @param activityModel Le modèle d'activité en cours
 */
void VRefTagsTabWidget::setActivityModel(VActivityModel * activityModel)
{
    if(_activityModel != activityModel)
    {
        _activityModel = activityModel;
    }
    updateDisplay();
}

/**
 * @brief setTask
 * Définit la tâche en cours d'édition
 * @param task La tâche en cours d'édition
 */
void VRefTagsTabWidget::setTask(VTask * task)
{
    if (task != _task)
    {
        VTraceController::get()->Info("VActionTabWidget::setTask()", "Task defined");
        _task = task;
    }
    updateDisplay();
}

/**
 * @brief getTask
 * Obitent la tâche en cours d'édition
 * @return La tâche en cours d'édition
 */
VTask * VRefTagsTabWidget::getTask() const
{
    return _task;
}

/**
 * @brief on_addTagButton_clicked
 * Gère le click sur le bouton ajouter
 */
void VRefTagsTabWidget::on_addTagButton_clicked()
{
    QString id = ui->tagComboBox->itemData(ui->tagComboBox->currentIndex()).toString();
    VTag * tag = _activityModel->getTagById(id.toInt());
    _task->addRefTag(tag);
}

/**
 * @brief on_removeTagButton_clicked
 * Gère le click sur le bouton supprimer
 */
void VRefTagsTabWidget::on_removeTagButton_clicked()
{
    if(_task == NULL || _activityModel == NULL) return;
    QList<QTableWidgetItem *> selectedItems = ui->tagValueWidget->selectedItems();
    if(selectedItems.count() == 2)
    {
        QString id = selectedItems.first()->data(Qt::UserRole).toString();
        VTag * tag = _activityModel->getTagById(id.toInt());
        if(tag != NULL) _task->removeRefTag(tag);
    }
}

/**
 * @brief update
 * Met a jour l'inteface en fonction de la tache sélectionnée
 */
void VRefTagsTabWidget::updateDisplay()
{
    // Vide la vue
    int RowCount = ui->tagValueWidget->rowCount();
    for(int i = 0; i < RowCount; i++)
    {
        ui->tagValueWidget->removeRow(0);
    }
    if(_task == NULL || _activityModel == NULL)
    {
        this->setEnabled(false);
        return;
    }
    // Met a jour la vue
    // update de la table
    QMap<QPointer<VTag>, QString> tagsValue = _task->getRefTags();
    for(int i = 0; i < tagsValue.count(); i++)
    {
        const VTag * tag = tagsValue.keys()[i];
        if(tag != NULL)
        {
            ui->tagValueWidget->insertRow(0);

            QString value = tagsValue.values()[i];

            QTableWidgetItem* itemTag = new QTableWidgetItem();
            itemTag->setText(tag->getName());
            itemTag->setFlags(itemTag->flags() & ~Qt::ItemIsEditable);
            itemTag->setData(Qt::UserRole, QString::number(tag->getId()));
            ui->tagValueWidget->setItem(0, 0, itemTag);

            QTableWidgetItem* itemValue = new QTableWidgetItem();
            itemValue->setText(value);
            if(!tag->getValued()) itemValue->setFlags(itemValue->flags() & ~Qt::ItemIsEditable);
            itemValue->setData(Qt::UserRole, QString::number(tag->getId()));
            ui->tagValueWidget->setItem(0, 1, itemValue);
        }
    }
    // Update de la combo
    ui->tagComboBox->clear();
    QList<QPointer<VTag> > tags = _activityModel->getTags();
    ui->tagComboBox->addItem("");
    for(int i = 0; i < tags.count(); i++)
    {
        bool alreadyTagOfTask = false;
        for(int j = 0; j < tagsValue.count(); j++)
        {
            alreadyTagOfTask = alreadyTagOfTask || tagsValue.keys()[j] == tags[i];
        }
        if(!alreadyTagOfTask)
        {
            ui->tagComboBox->addItem(tags[i]->getName(), QString::number(tags[i]->getId()));
        }
    }
    this->setEnabled(true);
}

void VRefTagsTabWidget::on_tagValueWidget_itemChanged(QTableWidgetItem *item)
{
    if(item != NULL && item->column() == 1)
    {
        QString id = item->data(Qt::UserRole).toString();
        QString value = item->text();
        VTag * tag = _activityModel->getTagById(id.toInt());
        if(tag->getValued() && _task->getRefTag(tag) != value) _task->setRefTagValue(tag, value);
    }
}
