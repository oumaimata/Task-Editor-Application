#pragma once
#ifndef VTRIPLEOBJECTCHECKBOX_H
#define VTRIPLEOBJECTCHECKBOX_H

#include <QCheckBox>

class VTriple;
class VStatement;

class VTripleObjectCheckBox : public QCheckBox
{
    Q_OBJECT
private:
    VTriple * _triple;
    VStatement * _statement;
public:
    explicit VTripleObjectCheckBox(VStatement * statement, VTriple * triple, QWidget *parent = 0);
public slots:
    void onToggled(bool value);
};

#endif // VTRIPLEOBJECTCHECKBOX_H
