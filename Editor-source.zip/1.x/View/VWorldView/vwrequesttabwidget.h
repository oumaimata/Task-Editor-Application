#pragma once
#ifndef VWREQUESTTABWIDGET_H
#define VWREQUESTTABWIDGET_H

#include <QWidget>

namespace Ui {
class VWRequestTabWidget;
}

class VWRequestTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWRequestTabWidget *ui;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    explicit VWRequestTabWidget(QWidget *parent = 0);
    ~VWRequestTabWidget();
    
private slots:

    /**
     * @brief on_executeButton_clicked
     * Gère le click sur le bouton execute
     */
    void on_executeButton_clicked();
};

#endif // VWREQUESTTABWIDGET_H
