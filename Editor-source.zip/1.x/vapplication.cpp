#include "vapplication.h"

#include <QMessageBox>
#include <stdexcept>

#include "View/vmainwindow.h"
#include "Model/vapplicationmodel.h"
#include "Controller/vapplicationcontroller.h"
#include "Controller/vactivitycontroller.h"
#include "Controller/vworldcontroller.h"
#include "Controller/vtracecontroller.h"

/*!
 * \brief VApplication
 * Constructeur
 * \param argc Nombre d'arguments
 * \param argv Tableau contenant les différents arguments
 */
VApplication::VApplication(int argc, char* argv[]) :
    QApplication(argc, argv)
{
    qApp->setOrganizationName("HUMANS");
    qApp->setApplicationName("EDITOR");
    _traceCtrler = VTraceController::get(this);

    // Utilisation des paramètres fournis par l'utilisateur
    if(argc == 3)
    {
        _traceCtrler->setFilePath(argv[1]);
        _traceCtrler->setMinLevelFromString(argv[2]);

    }
    // Utilisation de valeurs par défaut
    else
    {
        _traceCtrler->setFilePath(".");
        _traceCtrler->setMinLevelFromString("error");
    }
    _traceCtrler->Debug("VApplication::VApplication()", "Start");

    _mainWindow = new VMainWindow();
    _appCtrler = VApplicationController::getInstance(_mainWindow, this);
    _activityCtrler = new VActivityController(_mainWindow->getActivityWidget(),
                                              _mainWindow->getHistoryActivityWidget(),
                                              this);
    _worldCtrler = new VWorldController(_mainWindow->getWorldWidget(),
                                        _mainWindow->getHistoryWorldWidget(),
                                        this);
    _appCtrler->setActivityController(_activityCtrler);
    _appCtrler->setWorldController(_worldCtrler);

}

/*!
 * \brief ~VApplication
 *Destructeur
 */
VApplication::~VApplication()
{
    _traceCtrler->Debug("VApplication::~VApplication()", "End");
    delete _mainWindow;
    delete _appCtrler;
    delete _activityCtrler;
    delete _worldCtrler;
    delete VApplicationModel::getInstance();
    delete _traceCtrler;
}

/*!
 * \brief exec
 * Lance l'exécution de l'application
 * \return Le résultat de l'exécution
 */
int VApplication::exec()
{
    int result = EXIT_SUCCESS;

    try
    {
        _mainWindow->showMaximized();
        result = QApplication::exec();
    }
    catch (std::exception const& ex)
    {
        QString mess("Error during execution : ");
        mess.append(ex.what());
        QMessageBox::critical(_mainWindow, "Error", mess);
    }

    return result;
}
