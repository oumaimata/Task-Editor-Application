#include "vwpropertyvalue.h"

#include "vwpropertytype.h"
#include "vwproperty.h"

VWPropertyValue::VWPropertyValue(QObject *parent) :
    QObject(parent),
    _basicType(""),
    _date(QDate::currentDate()),
    _dateTime(QDateTime::currentDateTime()),
    _instance(NULL),
    _edit(false)
{
}

QString VWPropertyValue::toXml(QString tabulation, VWProperty *property) const
{
    VWPropertyType * propertyType = property->getType();
    if(propertyType == NULL) return "\n";
    QString balise = property->getName();
    QString type = propertyType->toString();
    QString boolValue = _boolean ? "true" : "false";

    QString RetVal = tabulation + "<" + balise;

    if(type == "int" || type == "string" || type == "float")
    {
        RetVal += " rdf:datatype=\"http://www.w3.org/2001/XMLSchema#" + type + "\">" +
                _basicType + "</" + balise + ">\n";
    }
    else if(type == "domain:Boolean")
    {
        QString value = _basicType;
        value.replace(':', '#');
        RetVal += " rdf:resource=\"http://www.utc.fr/hds/ici/humans/" + value + "\"/>\n";
    }
    else if(type == "Date")
    {
        RetVal += " rdf:datatype=\"http://www.w3.org/2001/XMLSchema#date\">" +
                _date.toString("yyyy-MM-dd") + "</" + balise + ">\n"; // Format: aaaa-mm-dd
    }
    else if(type == "DateTime")
    {
        RetVal += " rdf:datatype=\"http://www.w3.org/2001/XMLSchema#dateTime\">" +
                _dateTime.toString("yyyy-MM-ddThh:mm:ss.zzz") + "</" + balise + ">\n"; // Format: aaaa-mm-ddThh:mm:ss.ms
    }
    else if(type == "bool")
    {
        RetVal += " rdf:datatype=\"http://www.w3.org/2001/XMLSchema#boolean\">" +
                boolValue + "</" + balise + ">\n";
    }
    else if(_instance != NULL)
    {
        RetVal += " rdf:resource=\"#" + _instance->getName() + "\"/>\n";
    }
    else
    {
        RetVal += "/>\n";
    }

    return RetVal;
}

bool VWPropertyValue::isValued(VWProperty *property) const
{
    VWPropertyType * propertyType = property->getType();
    if(propertyType == NULL) return false;
    QString type = propertyType->toString();

    if(type == "int" || type == "string" || type == "float")
    {
        return _basicType != NULL && _basicType != "";
    }
    else if(type == "Date" || type == "DateTime" || type == "bool" || type == "domain:Boolean")
    {
        return true;
    }
    else if(_instance != NULL)
    {
        return _instance->getName() != NULL && _instance->getName() != "";
    }
    else
    {
        return false;
    }
}

void VWPropertyValue::reset()
{
    _basicType = "";
    _instance = NULL;
}

void VWPropertyValue::setBasicType(QString s)
{
    if(s != _basicType)
    {
        _basicType = s;
    }
    onModified(NULL);
}

QString VWPropertyValue::getBasicType() const
{
    return _basicType;
}

void VWPropertyValue::setBoolean(QString b)
{
    setBoolean(b.toLower() == "true");
}

void VWPropertyValue::setBoolean(bool b)
{
    if(b != _boolean)
    {
        _boolean = b;
        onModified(tr("Property value changed"));
    }
}

bool VWPropertyValue::getBoolean() const
{
    return _boolean;
}

void VWPropertyValue::setDate(QString date)
{
    setDate(QDate::fromString(date,"yyyy-MM-dd"));
}

void VWPropertyValue::setDate(QDate date)
{
    if(date != _date)
    {
        _date = date;
        onModified(tr("Property value changed"));
    }
}

QDate VWPropertyValue::getDate() const
{
    return _date;
}

void VWPropertyValue::setDateTime(QString dateTime)
{
    setDateTime(QDateTime::fromString(dateTime,"yyyy-MM-ddThh:mm:ss.zzz"));
}

void VWPropertyValue::setDateTime(QDateTime dateTime)
{
    if(dateTime != _dateTime)
    {
        _dateTime = dateTime;
        onModified(tr("Property value changed"));
    }
}

QDateTime VWPropertyValue::getDateTime() const
{
    return _dateTime;
}

void VWPropertyValue::setInstance(QPointer<VWInstance> instance)
{
    if(instance != _instance)
    {
        if(_instance != NULL) disconnect(_instance, SIGNAL(nameModified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        _instance = instance;
        if(_instance != NULL) connect(_instance, SIGNAL(nameModified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Property value changed"));
    }
}

QPointer<VWInstance> VWPropertyValue::getInstance() const
{
    return _instance;
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 */
void VWPropertyValue::onModified()
{
    onModified(NULL);
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 * @param object L'objet modifié
 */
void VWPropertyValue::onModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    emit modified(message, (object == NULL) ? this : object);
}
