#pragma once
#ifndef VINSTANCECOMBOBOX_H
#define VINSTANCECOMBOBOX_H

#include <QComboBox>

class VStopCondition;

class VInstanceComboBox : public QComboBox
{
    Q_OBJECT
private:
    VStopCondition * _stopCondition;
public:
    explicit VInstanceComboBox(VStopCondition * stopCondition, QWidget *parent = 0);
    
signals:
    
public slots:
    void instanceChanged(QString s);
    
};

#endif // VINSTANCECOMBOBOX_H
