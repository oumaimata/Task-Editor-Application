#pragma once
#ifndef VWINSTANCEEDITORWIDGET_H
#define VWINSTANCEEDITORWIDGET_H

#include <QWidget>
#include <QTableWidgetItem>
#include <QSignalMapper>

class VWProperty;
class VWPropertyValue;
class VWInstance;

namespace Ui {
class VWInstanceEditorWidget;
}

class VWInstanceEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWInstanceEditorWidget *ui;

    bool _edit;

    VWInstance * _instance;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    explicit VWInstanceEditorWidget(QWidget *parent = 0);
    ~VWInstanceEditorWidget();

    void setInstanceClass(VWInstance * instance);

    QWidget * getValueWidget(QSignalMapper* mapper, int index, VWProperty * property, VWPropertyValue * value);

private slots:
    void updateDisplay();
    void on_nameLineEdit_editingFinished();
    void on_removeButton_clicked();

    /**
     * @brief typeChanged
     * Gère les modifications des combos de type
     * @param position La position du widget dans la table
     */
    void valueChanged(const QString & position);

    void on_propertyTableWidget_itemChanged(QTableWidgetItem *item);

signals:
    void instanceRemoved();
};

#endif // VWINSTANCEEDITORWIDGET_H
