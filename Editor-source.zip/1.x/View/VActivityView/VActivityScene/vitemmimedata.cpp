#include "vitemmimedata.h"

/*!
 * \brief VItemMimeData::VItemMimeData
 * Constructeur
 */
VItemMimeData::VItemMimeData()
{
    _item = NULL;
}

/*!
 * \brief VItemMimeData::hasItem
 * Return if the VItemMimeData has an item
 * \return true if has an item; false else
 */
bool VItemMimeData::hasItem() const
{
    return !(_item == NULL);
}

/*!
 * \brief VItemMimeData::getItem
 * Obtient Item
 * \return Item de type QGraphicsItem
 */
QGraphicsItem* VItemMimeData::getItem() const
{
    return _item;
}

/*!
 * \brief VItemMimeData::setItem
 * Définie Item
 * \param item La nouvelle valeur d'Item
 */
void VItemMimeData::setItem(QGraphicsItem* item)
{
    _item = item;
}
