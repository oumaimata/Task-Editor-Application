#include "vstatement.h"

#include "../VActivityCommon/vtriple.h"
#include "vnottriples.h"
#include "vmacro.h"

VStatement::VStatement(QObject *parent) :
    VActivityModelElement(parent),
    _type(domain)
{
}

VStatement::VStatement(const VStatement& statement, QObject *parent) :
    VActivityModelElement(parent)
{
    copyFrom(statement);
}

/**
 * @brief ~VStatement
 * Destructeur
 */
VStatement::~VStatement()
{
    while(_triples.count() > 0)
    {
        VTriple * triple = _triples.first();
        _triples.pop_front();
        delete triple;
    }
    while(_notTriples.count() > 0)
    {
        VNotTriples * notTriples = _notTriples.first();
        _notTriples.pop_front();
        delete notTriples;
    }
    while(_macros.count() > 0)
    {
        VMacro * macro = _macros.first();
        _macros.pop_front();
        delete macro;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VStatement::parseDom(QDomElement elem)
{
    setType(elem.attribute("type","domain"));
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de triple
            if(element.tagName() == "triple")
            {
                VTriple * triple = new VTriple(this);
                triple->parseDom(element);
                addTriple(triple);
            }
            // Lecture de macro
            else if(element.tagName() == "macro")
            {
                VMacro * macro = new VMacro(this);
                macro->parseDom(element);
                addMacro(macro);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VStatement::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<statement";
    RetVal += " type=\"" + VActivityStatementTypeToString(_type) + "\"";
    RetVal += ">\n";

    for(int i = 0; i < _notTriples.count(); i++)
    {
        RetVal += _notTriples[i]->ToXml(tabulation + "\t");
    }

    for(int i = 0; i < _triples.count(); i++)
    {
        RetVal += _triples[i]->ToXml(tabulation + "\t");
    }

    for(int i = 0; i < _macros.count(); i++)
    {
        RetVal += _macros[i]->ToXml(tabulation + "\t");
    }

    RetVal += tabulation + "</statement>\n";
    return RetVal;
}

void VStatement::setType(VActivityStatementType type)
{
    if(type == SIZE_OF_VActivityStatementType)
    {
        onModified(tr("Type changed"));
        return;
    }
    if(_type != type)
    {
        _type = type;
        onModified(tr("Type changed"));
    }
}

void VStatement::setType(QString type)
{
    setType(VActivityStatementTypeFromString(type));
}

VActivityStatementType VStatement::getType() const
{
    return _type;
}

void VStatement::addTriple(VTriple * triple)
{
    if(triple != NULL)
    {
        _triples.append(triple);
        connect(triple, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Triple added"));
    }
}

void VStatement::removeTriple(VTriple * triple)
{
    if(_triples.contains(triple))
    {
        _triples.removeAll(triple);
        disconnect(triple, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Triple removed"));
    }
}

QList<VTriple *> VStatement::getTriples() const
{
    return _triples;
}

VTriple * VStatement::getTripleById(qint64 uid) const
{
    for(int i = 0; i < _triples.count(); i++)
    {
        if(_triples[i]->getUid() == uid) return _triples[i];
    }
    return NULL;
}

void VStatement::addNotTriples(VNotTriples * notTriple)
{
    if(notTriple != NULL)
    {
        _notTriples.append(notTriple);
        connect(notTriple, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("NOT triple added"));
    }
}

void VStatement::removeNotTriples(VNotTriples * notTriple)
{
    if(_notTriples.contains(notTriple))
    {
        _notTriples.removeAll(notTriple);
        disconnect(notTriple, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("NOT triple removed"));
    }
}

QList<VNotTriples *> VStatement::getNotTriples() const
{
    return _notTriples;
}

VNotTriples * VStatement::getNotTriplesById(qint64 uid) const
{
    for(int i = 0; i < _notTriples.count(); i++)
    {
        if(_notTriples[i]->getUid() == uid) return _notTriples[i];
    }
    return NULL;
}

void VStatement::addMacro(VMacro * macro)
{
    if(macro != NULL)
    {
        _macros.append(macro);
        connect(macro, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Macro added"));
    }
}

void VStatement::removeMacro(VMacro * macro)
{
    if(_macros.contains(macro))
    {
        _macros.removeAll(macro);
        disconnect(macro, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Macro removed"));
    }
}

QList<VMacro *> VStatement::getMacros() const
{
    return _macros;
}

VMacro * VStatement::getMacroById(qint64 uid) const
{
    for(int i = 0; i < _macros.count(); i++)
    {
        if(_macros[i]->getUid() == uid) return _macros[i];
    }
    return NULL;
}

QString VStatement::toString(QString tabulation) const
{
    QString RetVal = "";
    if(_triples.count() != 0 || _notTriples.count() != 0)
    {
        RetVal = "\n" + tabulation + "Statement";
        foreach(VTriple * triple, _triples)
        {
            RetVal += triple->toString(tabulation + "\t");
        }
        foreach(VNotTriples * notTriple, _notTriples)
        {
            RetVal += notTriple->toString(tabulation + "\t");
        }
    }
    return RetVal;
}


/**
 * @brief clone
 * @return Le clone
 */
VStatement * VStatement::clone(QObject *parent) const
{
    return new VStatement(*this, parent);
}

void VStatement::copyFrom(const VStatement& statement){
    _type = statement._type;
    foreach(VTriple * triple, statement._triples)
    {
        addTriple(triple->clone());
    }
    foreach(VNotTriples * notTriple, statement._notTriples)
    {
        addNotTriples(notTriple->clone());
    }
    foreach(VMacro * macro, statement._macros)
    {
        addMacro(macro->clone());
    }
}

VStatement& VStatement::operator=(const VStatement& statement){
    if(this != &statement){
        copyFrom(statement);
    }
    return *(this);
}
