#include "vconstructortabwidget.h"
#include "ui_vconstructortabwidget.h"

#include "Model/VActivity/vtask.h"
#include "Model/VActivity/VActivityConstructor/vrelation.h"
#include "Model/VActivity/VActivityConstructor/vconstructor.h"
#include "Controller/vtracecontroller.h"

/**
 * @brief VConstructorTabWidget
 * Constructeur
 * @param parent L'objet parent
 */
VConstructorTabWidget::VConstructorTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VConstructorTabWidget),
    _edit(false),
    _task(NULL),
    _constructor(NULL)
{
    ui->setupUi(this);
}

/**
 * @brief ~VConstructorTabWidget
 * Destructeur
 */
VConstructorTabWidget::~VConstructorTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VConstructorTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setTask
 * Définit la tâche en cours d'édition
 * @param task La tâche en cours d'édition
 */
void VConstructorTabWidget::setTask(VTask * task)
{
    if (task != _task)
    {
        VTraceController::get()->Info("VConstructorTabWidget::setTask()", "Task defined");
        _task = task;
    }
    _constructor = (_task == NULL) ? NULL : _task->getConstructor();
    updateDisplay();
}

/**
 * @brief getTask
 * Obitent la tâche en cours d'édition
 * @return La tâche en cours d'édition
 */
VTask * VConstructorTabWidget::getTask() const
{
    return _task;
}

/**
 * @brief updateDisplay
 * Met a jour les intefaces
 * en fonction de la tache sélectionnée
 */
void VConstructorTabWidget::updateDisplay()
{
    _edit = true;
    // Vide la vue relation
    int RowCountRefConcept = ui->relationsWidget->rowCount();
    for(int i = 0; i < RowCountRefConcept; i++)
    {
        ui->relationsWidget->removeRow(0);
    }
    // Vide la combo d'action
    ui->typeComboBox->clear();

    if(_task == NULL || _constructor == NULL)
    {
        this->setEnabled(false);
    }
    else
    {
        this->setEnabled(true);
        updateRelationDisplay();
        updateTypeDisplay();
    }
    _edit = false;
}

/**
 * @brief updateRelationDisplay
 * Met a jour l'inteface des relations
 * en fonction de la tache sélectionnée
 */
void VConstructorTabWidget::updateRelationDisplay()
{
    // Met a jour la vue
    QList<VRelation *> relations = _constructor->getRelations();
    QSignalMapper* comboSignalMapper = new QSignalMapper(this);
    for(int i = 0; i < relations.count(); i++)
    {
        ui->relationsWidget->insertRow(0);
    }
    for(int i = relations.count() - 1; i >= 0; i--)
    {
        // RH
        QTableWidgetItem* itemLh = new QTableWidgetItem();
        itemLh->setData(Qt::UserRole, QString::number(relations[i]->getUid()));
        if(_constructor->getType() == SeqOrd)
        {
            itemLh->setFlags(itemLh->flags() & ~Qt::ItemIsEditable);
            itemLh->setText((relations[i]->getTaskLh() != NULL) ? relations[i]->getTaskLh()->getName() : relations[i]->getLh());
        }
        else
        {
            QComboBox* taskCombo = getTaskCombo(relations[i]->getTaskLh());
            ui->relationsWidget->setCellWidget(i, 0, taskCombo);
            connect(taskCombo, SIGNAL(currentIndexChanged(int)), comboSignalMapper, SLOT(map()));
            comboSignalMapper->setMapping(taskCombo, QString("%1-%2").arg(i).arg(0));
        }
        ui->relationsWidget->setItem(i, 0, itemLh);

        // OPERATOR
        QTableWidgetItem* itemOperator = new QTableWidgetItem();
        itemOperator->setData(Qt::UserRole, QString::number(relations[i]->getUid()));
        QComboBox* operatorCombo = getOperatorCombo(relations[i]->getOperator());
        ui->relationsWidget->setCellWidget(i, 1, operatorCombo);
        connect(operatorCombo, SIGNAL(currentIndexChanged(int)), comboSignalMapper, SLOT(map()));
        comboSignalMapper->setMapping(operatorCombo, QString("%1-%2").arg(i).arg(1));
        ui->relationsWidget->setItem(i, 1, itemOperator);

        // RH
        QTableWidgetItem* itemRh = new QTableWidgetItem();
        itemRh->setData(Qt::UserRole, QString::number(relations[i]->getUid()));
        if(_constructor->getType() == SeqOrd)
        {
            itemRh->setFlags(itemRh->flags() & ~Qt::ItemIsEditable);
            itemRh->setText((relations[i]->getTaskRh() != NULL) ? relations[i]->getTaskRh()->getName() : relations[i]->getRh());
        }
        else
        {
            QComboBox* taskCombo = getTaskCombo(relations[i]->getTaskRh());
            ui->relationsWidget->setCellWidget(i, 2, taskCombo);
            connect(taskCombo, SIGNAL(currentIndexChanged(int)), comboSignalMapper, SLOT(map()));
            comboSignalMapper->setMapping(taskCombo, QString("%1-%2").arg(i).arg(2));
        }
        ui->relationsWidget->setItem(i, 2, itemRh);
    }
    connect(comboSignalMapper, SIGNAL(mapped(const QString &)), this, SLOT(relationChanged(const QString &)));
    ui->relationsWidget->resizeColumnsToContents();
}

/**
 * @brief getTaskCombo
 * Obtient une combo pour les tâches
 * @param selectedTask La tâche actuel
 * @return La combo
 */
QComboBox * VConstructorTabWidget::getTaskCombo(VTask * selectedTask)
{
    QComboBox * combo = new QComboBox();
    QList<VTask *> tasks = _task->getChildTasks();
    for(int i = 0; i < tasks.count(); i++)
    {
        combo->addItem(tasks[i]->getName());
        combo->setItemData(i, QString::number(tasks[i]->getUid()));
    }
    if(selectedTask == NULL)
    {
        combo->addItem("");
        combo->setCurrentText("");
    }
    else
    {
        combo->setCurrentText(selectedTask->getName());
    }
    return combo;
}

/**
 * @brief getOperatorCombo
 * Obtient une combo pour les opérateurs
 * @param selectedOperator L'opérateur actuel
 * @return La combo
 */
QComboBox * VConstructorTabWidget::getOperatorCombo(VActivityOperatorType selectedOperator)
{
    QComboBox * combo = new QComboBox();
    VActivityOperatorType ooperator;
    QList<VActivityOperatorType> operators = VActivityOperatorTypeFor(_constructor->getType());
    foreach(ooperator, operators)
    {
        combo->addItem(VActivityOperatorTypeToString(ooperator, true));
    }
    combo->setCurrentText(VActivityOperatorTypeToString(selectedOperator, true));
    return combo;
}

/**
 * @brief on_addButton_clicked
 * Gère l'ajout de Relation
 */
void VConstructorTabWidget::on_addButton_clicked()
{
    VRelation * relation = new VRelation(_constructor);
    relation->setOperator(VActivityOperatorDefaultTypeFor(_constructor->getType()));
    _constructor->addRelation(relation);

}

/**
 * @brief relationChanged
 * Gère les modifications des combos d'opérateurs
 * @param position La position de la combo dans la table
 */
void VConstructorTabWidget::relationChanged(const QString & position)
{
    if(_edit) return;
    QStringList coordinates = position.split("-");
    int row = coordinates[0].toInt();
    int col = coordinates[1].toInt();
    QComboBox* combo = (QComboBox*)ui->relationsWidget->cellWidget(row, col);
    QTableWidgetItem* item = ui->relationsWidget->item(row, col);

    if(item != NULL)
    {
        QString var = item->data(Qt::UserRole).toString();
        VRelation * relation = _constructor->getRelationById(var.toInt());
        if(relation == NULL) return;
        if(col == 0)
        {
            QString taskUid = combo->itemData(combo->currentIndex()).toString();
            VTask * task = _task->getTaskByUid(taskUid.toLong());
            if(task == NULL)
            {
                updateDisplay();
                return;
            }
            relation->setTaskLh(task);
        }
        else if(col == 1)
        {
            if(VActivityOperatorTypeToString(relation->getOperator()) != combo->currentText())
            {
                relation->setOperator(combo->currentText());
            }
        }
        else if(col == 2)
        {
            QString taskUid = combo->itemData(combo->currentIndex()).toString();
            VTask * task = _task->getTaskByUid(taskUid.toLong());
            if(task == NULL)
            {
                updateDisplay();
                return;
            }
            relation->setTaskRh(task);
        }
    }
}


/**
 * @brief on_removeButton_clicked
 * Gère la supression de Relation
 */
void VConstructorTabWidget::on_removeButton_clicked()
{
    QList<QTableWidgetItem *> selectedItems = ui->relationsWidget->selectedItems();
    if(selectedItems.count() == 3)
    {
        QString var = selectedItems.first()->data(Qt::UserRole).toString();
        VRelation * relation = _constructor->getRelationById(var.toInt());
        if(relation != NULL)
        {
            _constructor->removeRelation(relation);
            delete relation;
        }
    }
}

/**
 * @brief updateTypeDisplay
 * Met a jour l'inteface du type
 * en fonction de la tache sélectionnée
 */
void VConstructorTabWidget::updateTypeDisplay()
{
    // Update de la combo de type
    QString currentAction = VActivityConstructorTypeToString(_constructor->getType());
    for(int i = 0; i < SIZE_OF_VActivityConstructorType; i++)
    {
        ui->typeComboBox->addItem(VActivityConstructorTypeToString((VActivityConstructorType)i));
    }
    ui->typeComboBox->setCurrentText(currentAction);

    ui->addButton->setEnabled(_constructor->getType() != SeqOrd);
    ui->removeButton->setEnabled(_constructor->getType() != SeqOrd);
}

void VConstructorTabWidget::on_typeComboBox_currentIndexChanged(int index)
{
    if(_task == NULL || _constructor == NULL || _edit) return;
    _constructor->setType(ui->typeComboBox->itemText(index));

}
