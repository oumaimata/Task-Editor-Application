#pragma once
#ifndef VWEVENTCLASS_H
#define VWEVENTCLASS_H

#include "vwentityclass.h"

class VWBehaviourClass;

class VWEventClass : public VWEntityClass
{
    Q_OBJECT
private:
    /**
     * @brief _isDurative
     * Si le comportement dure dans le temps
     */
    bool _isDurative;

    /**
     * @brief _isPunctual
     * Si le comportement est situé dans le temps
     */
    bool _isPunctual;

    /**
     * @brief _isEndogenous
     * Si le comportement est endogène
     */
    bool _isEndogenous;

    /**
     * @brief _isExogenous
     * Si le comportement  est exogène
     */
    bool _isExogenous;

    /**
     * @brief _beginingEvent
     * Si l'événement dure dans le temps (_isDurative == TRUE),
     * On peut avoir un événement (ponctuel) de début
     */
    QPointer<VWEventClass> _beginingEvent;


    /**
     * @brief _beginingEvent
     * Si l'événement dure dans le temps (_isDurative == TRUE),
     * On peut avoir un événement (ponctuel) de fin
     */
    QPointer<VWEventClass> _endingEvent;

    /**
     * @brief _events
     * Liste des comportements activés par l'événement
     */
    QList<QPointer<VWBehaviourClass> > _behaviours;

    /**
     * @brief _properties
     * Liste des VWProperty
     */
    VWProperties * _properties;

public:
    /**
     * @brief VWEventClass
     * Constructeur par défaut
     * @param parent L'objet parent
     */
    explicit VWEventClass(QObject *parent = 0);

    /**
     * @brief VWEventClass
     * @param o L'objet à copier
     */
    VWEventClass(const VWEventClass& o);

    /**
     * @brief ~VWEventClass
     * Destructeur
     */
    ~VWEventClass();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setIsDurative(bool isDurative);
    bool getIsDurative() const;

    void setIsPunctual(bool isPunctual);
    bool getIsPunctual() const;

    void setIsEndogenous(bool isEndogenous);
    bool getIsEndogenous() const;

    void setIsExogenous(bool isExogenous);
    bool getIsExogenous() const;

    void setBeginingEvent(VWEventClass * event);
    VWEventClass * getBeginingEvent() const;

    void setEndingEvent(VWEventClass * event);
    VWEventClass * getEndingEvent() const;

    void addBehaviour(VWBehaviourClass * behaviourClass);
    void removeBehaviour(VWBehaviourClass * behaviourClass);
    QList<QPointer<VWBehaviourClass> > getBehaviours() const;

    QPointer<VWProperty> addProperty(QDomElement elem);
    VWProperties * getProperties() const;
    
};

#endif // VWEVENTCLASS_H
