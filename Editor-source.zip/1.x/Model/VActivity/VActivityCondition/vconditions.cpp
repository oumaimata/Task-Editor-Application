#include "vconditions.h"

#include "vcondition.h"
#include "vbasiscondition.h"

VConditions::VConditions(QObject *parent) :
    VActivityModelElement(parent)
{
}

VConditions::VConditions(const VConditions& conditions, QObject *parent) :
    VActivityModelElement(parent)
{
    _type = conditions._type;
    _logicalOperator = conditions._logicalOperator;
    foreach(VCondition * condition, conditions.getConditions())
    {
        addCondition(condition->clone(this));
    }
}

/**
 * @brief ~VConditions
 * Destructeur
 */
VConditions::~VConditions()
{
    while(_conditions.count() > 0)
    {
        VCondition * condition = _conditions.first();
        _conditions.pop_front();
        delete condition;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VConditions::parseDom(QDomElement elem)
{
    QDomNode node = elem.firstChild();
    setType(elem.tagName());
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString tagname = element.tagName().toUpper();
            // Lecture de context
            if(tagname == "AND" || tagname == "OR" ||
               tagname == "XOR"  || tagname == "NOT")
            {
                setLogicalOperator(element.tagName());
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        VCondition * condition = new VCondition(this);
                        condition->parseDom(subElement);
                        addCondition(condition);
                    }
                    subNode = subNode.nextSibling();
                }
            }
            else
            {
                VCondition * condition = new VCondition(this);
                condition->parseDom(element);
                addCondition(condition);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VConditions::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<" + _type + ">\n";
    if(_logicalOperator != NULL)
    {
        RetVal += tabulation + "\t" + "<" + _logicalOperator + ">\n";
        foreach(VCondition * condition, getConditions())
        {
            RetVal += condition->ToXml(tabulation + "\t\t");
        }
        RetVal += tabulation + "\t" + "</" + _logicalOperator + ">\n";
    }
    else
    {
        foreach(VCondition * condition, getConditions())
        {
            RetVal += condition->ToXml(tabulation + "\t");
        }
    }
    RetVal += tabulation + "</" + _type + ">\n";
    return RetVal;

}

void VConditions::setType(QString type)
{
    type = type.toLower();
    if(type != _type)
    {
        _type = type;
        onModified(NULL);
    }
}

QString VConditions::getType() const
{
    return _type;
}

void VConditions::setLogicalOperator(QString logicalOperator)
{
    logicalOperator = logicalOperator.toUpper();
    if(logicalOperator != _logicalOperator)
    {
        _logicalOperator = logicalOperator;
        onModified(NULL);
    }
}
QString VConditions::getLogicalOperator() const
{
    return _logicalOperator;
}

void VConditions::addCondition(VCondition * condition)
{
    if(condition != NULL)
    {
        condition->setType(_type);
        _conditions.append(condition);
        connect(condition, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Condition added"));
    }
}

void VConditions::removeCondition(VCondition * condition)
{
    if(condition != NULL && _conditions.contains(condition))
    {
        _conditions.removeAll(condition);
        disconnect(condition, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Condition removed"));
    }
}

QList<VCondition *> VConditions::getConditions() const
{
    return _conditions;
}

QList<VBasisCondition *> VConditions::getBasisConditions() const
{
    QList<VBasisCondition *> RetVal;
    foreach(VCondition * condition, _conditions)
    {
        RetVal.append(condition);
    }
    return RetVal;
}

VCondition * VConditions::getConditionByUid(qint64 uid) const
{
    for(int i = 0; i < _conditions.count(); i++)
    {
        if(_conditions[i]->getUid() == uid) return _conditions[i];
    }
    return NULL;
}

/**
 * @brief clone
 * @return Le clone
 */
VConditions * VConditions::clone(QObject * parent) const
{
    return new VConditions(*this, parent);
}
