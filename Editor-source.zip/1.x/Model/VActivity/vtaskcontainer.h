#pragma once
#ifndef VTASKCONTAINER_H
#define VTASKCONTAINER_H

#include <QObject>

#include "VActivityCommon/vactivitymodelelement.h"

class VTask;

/**
 * @brief The VTaskContainer class
 * Classe permettant de décrire l'arborescence des taches.
 * Utilise les parents de QObject pour créer l'arborescence.
 */
class VTaskContainer : public VActivityModelElement
{
    Q_OBJECT
    friend class VTask;

protected:

    /**
     * @brief onChildTaskAdded
     * Gère l'ajout des tâches filles
     * @param task La nouvelle tâche fille
     */
    void onChildTaskAdded(VTask * task);

    virtual void childTaskAdded(VTask* task) = 0; // L'appel récursif
    virtual void processChildTaskAdded(); // La gestion interne

    /**
     * @brief onChildTaskRemoved
     * Gère la suppression des tâches filles
     */
    void onChildTaskRemoved(VTask *task);

    virtual void childTaskRemoved(VTask* task) = 0; // L'appel récursif

    virtual void processChildTaskRemoved(VTask * task); // La gestion interne

    virtual void childTaskModified(VTask* task = NULL) = 0;

public:
    /**
     * @brief VTaskContainer
     * Constructeur de VTaskContainer
     * @param parent L'object parent
     */
    explicit VTaskContainer(QObject* parent = NULL);

    /**
     * @brief getChildTasks
     * Obtient une liste des taches filles
     * @return
     */
    virtual QList<VTask *> getChildTasks() const;

    /**
     * @brief getAllChildTasks
     * Obtient une liste des tâches filles de toute l'arborescence
     * @return
     */
    virtual QList<VTask *> getAllChildTasks() const;

    /**
     * @brief addChildTask
     * Ajout une tache fille à la tache courante
     * @param task La tache à ajouter
     */
    virtual void addChildTask(VTask* task = NULL);

    /**
     * @brief removeChildTask
     * Retire une tache fille à la tache courante
     * @param task La tache à ajouter
     */
    void removeChildTask(VTask* task);

    /**
     * @brief reorder
     * Met dans l'ordre les tâches selon l'ordre des tâches passé en argument
     * @param tasks La liste des tâches dans le nouvelle ordre
     */
    virtual void reorder(QList<VTask *> tasks);

    /**
     * @brief moveDown
     * Déplace les tâches passées en arguments vers le bas
     * @param tasks La liste des tâches à déplacer
     */
    virtual void moveDown(QList<QPointer<VTask> > tasks);

    /**
     * @brief moveUp
     * Déplace les tâches passées en arguments vers le haut
     * @param tasks La liste des tâches à déplacer
     */
    virtual void moveUp(QList<QPointer<VTask> > tasks);
};

#endif // VTASKCONTAINER_H
