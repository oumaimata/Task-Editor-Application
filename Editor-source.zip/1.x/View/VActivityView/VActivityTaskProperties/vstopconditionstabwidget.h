#pragma once
#ifndef VSTOPCONDITIONSTABWIDGET_H
#define VSTOPCONDITIONSTABWIDGET_H

#include <QWidget>
#include <QTreeWidgetItem>

class VTask;
class VTriple;
class VStatement;
class VNotTriples;
class VStopCondition;
class VStopConditions;

namespace Ui {
class VStopConditionsTabWidget;
}

class VStopConditionsTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VStopConditionsTabWidget *ui;

    QFont * blackFont;

    /**
     * @brief _edit
     * Si l'édition est en cours
     */
    bool _edit;

    /**
     * @brief task
     * Tâche en cours d'édition
     */
    VTask * _task;

    /**
     * @brief _stopConditions
     * Les stop conditions en cours d'édition
     */
    VStopConditions * _stopConditions;
    
public:
    /**
     * @brief VStopConditions
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VStopConditionsTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VStopConditions
     * Destructeur
     */
    ~VStopConditionsTabWidget();

    /**
     * @brief setTask
     * Définit la tâche en cours d'édition
     * @param task La tâche en cours d'édition
     */
    void setTask(VTask *task);

    /**
     * @brief getTask
     * Obitent la tâche en cours d'édition
     * @return La tâche en cours d'édition
     */
    VTask * getTask() const;

    /**
     * @brief setStopConditions
     * Définit les stop conditions en cours d'édition
     * @param condition Les stop conditions en cours d'édition
     */
    void setStopConditions(VStopConditions * stopConditions);

    /**
     * @brief getStopConditions
     * Obitent les stop conditions en cours d'édition
     * @return Les stop conditions en cours d'édition
     */
    VStopConditions * getStopConditions() const;

private:

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief updateDisplay
     * Met a jour l'inteface
     * en fonction de la tache sélectionnée
     */
    void updateDisplay();

    /**
     * @brief addStatementItem
     * Retourne et ajoute un item d'arbre correspondant à un statement
     * @param parent L'item parent
     * @param statement Le statemnt
     * @param stopCondition la condition
     * @return Un item d'arbre correspondant à un statement
     */
    QTreeWidgetItem * addStatementItem(QTreeWidgetItem *parent, VStopCondition * stopCondition = 0);

    /**
     * @brief addTripleItem
     * Retourne et ajoute un item d'arbre correspondant à un triple
     * @param parent L'item parent
     * @param triple
     * @param statement
     * @param notTriples
     * @return Un item d'arbre correspondant à un triple
     */
    QTreeWidgetItem * addTripleItem(QTreeWidgetItem *parent, VTriple * triple, VStatement * statement, VNotTriples * notTriples = 0);

    QTreeWidgetItem * addSatisfactionItem(QTreeWidgetItem *parent, VStopCondition * stopCondition);

    QTreeWidgetItem * addInstanceItem(QTreeWidgetItem *parent, VStopCondition * stopCondition);

    QTreeWidgetItem * addDurationItem(QTreeWidgetItem *parent, VStopCondition * stopCondition);

    QTreeWidgetItem * addIterationItem(QTreeWidgetItem *parent, VStopCondition * stopCondition);

    /**
     * @brief setItemBackgroundColor
     * Définie le backgroundcolor de l'item de begin au nombre de colonne
     * @param item L'item à mettre à jour
     * @param beginIndex L'index de début
     */
    void setItemBackgroundColor(QTreeWidgetItem * item, int beginIndex);
    
private slots:
    void on_addButton_clicked();

    void on_treeWidget_itemChanged(QTreeWidgetItem *item, int column);

    void on_removeButton_clicked();

    void on_logicalOperatorComboBox_currentIndexChanged(int index);
};

#endif // VSTOPCONDITIONSTABWIDGET_H
