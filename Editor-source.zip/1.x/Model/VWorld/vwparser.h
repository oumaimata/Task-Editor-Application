#pragma once
#ifndef VWPARSER_H
#define VWPARSER_H

#include <QtXml>

class VWParser
{
public:

    static QString getName(QDomElement elem);

    /**
     * @brief getDomainSupClasses
     * Trouve et retourne s'il existe toutes les classes supérieur appartenant au domain référence dans un rdfs:subClassOf
     * @param elem Un élément du dom
     * @return Toutes les classes supérieur trouvée
     */
    static QList<QString> getDomainSupClasses(QDomElement elem);

    static QPair<QList<QString>, QString> getDomaineAndRange(QDomElement elem);

    static QList<QString> getUnionOfClass(QDomElement elem);

    /**
     * @brief getDomainSupProperties
     * @param elem Un élément du dom
     * @return Toutes les propriétés supérieur trouvée
     */
    static QList<QString> getDomainSupProperties(QDomElement elem);

    /**
     * @brief getSupClasses
     * Trouve et retourne s'il existe toutes les classes supérieur appartenant au modèle du monde
     * @param elem Un élément du dom
     * @return Toutes les classes supérieur trouvée
     */
    static QList<QString> getSupClasses(QDomElement elem);

    static QString getPrefix(QString s);
    static QString getBalise(QString s);
};

#endif // VWPARSER_H
