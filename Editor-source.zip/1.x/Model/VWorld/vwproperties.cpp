#include "vwproperties.h"

#include "vwproperty.h"
#include "vworldmodelelement.h"

VWProperties::VWProperties(QObject *parent) :
    QObject(parent),
    _type(""),
    _isShared(false),
    _worldModelElement(NULL),
    _edit(false)
{
}

VWProperties::~VWProperties()
{
    while(_properties.count() > 0)
    {
        _properties.pop_front();
    }
}

void VWProperties::setWorldModelElement(QPointer<VWorldModelElement> worldModelElement)
{
    _worldModelElement = worldModelElement;
}

void VWProperties::setComponent(QPointer<VWComponentClass> component)
{
    _component = component;
}

void VWProperties::clear()
{
    _properties.clear();
    onModified(tr("All properties removed"));
}

void VWProperties::setIsShared(bool isShared)
{
    if(_isShared != isShared)
    {
        _isShared = isShared;
        foreach(VWProperty * property, _properties)
        {
            property->setIsShared(_type, _isShared);
        }
    }
}

bool VWProperties::getIsShared() const
{
    return _isShared;
}

void VWProperties::setType(QString type)
{
    _type = type;
}

QString VWProperties::getType() const
{
    return _type;
}

QPointer<VWProperty> VWProperties::addProperty(QDomElement elem)
{
    QPointer<VWProperty> property = new VWProperty();
    property->ParseDom(elem);
    addProperty(property);
    return property;
}

void VWProperties::addProperty(QPointer<VWProperty> property)
{
    if(property != NULL)
    {
        _properties.append(property);
        if(_isShared) property->addWorldModelElement(_worldModelElement);
        property->setIsShared(_type, _isShared);
        property->setComponent(_component);
        connect(property, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Property added"));
    }
}

void VWProperties::removeProperty(QPointer<VWProperty> property)
{
    if(_properties.contains(property))
    {
        _properties.removeAll(property);
        property->removeWorldModelElement(_worldModelElement);
        disconnect(property, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Property removed"));
    }
}

QList<QPointer<VWProperty> > VWProperties::getProperties() const
{
    return _properties;
}

QPointer<VWProperty> VWProperties::getPropertyByUid(qint64 uid) const
{
    foreach(QPointer<VWProperty> property, _properties)
    {
        if(property != NULL && property->getUid() == uid) return property;
    }
    return NULL;
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 */
void VWProperties::onModified()
{
    onModified(NULL);
}

/**
 * @brief onModified
 * Envoi le signal modified(QObject *)
 * @param object L'objet modifié
 */
void VWProperties::onModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    emit modified(message, (object == NULL) ? this : object);
}
