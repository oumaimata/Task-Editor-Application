#include "vtriplesubjectwidget.h"

#include "Model/vapplicationmodel.h"
#include "Model/VActivity/vtask.h"
#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivityCondition/vstatement.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"
#include "Model/VWorld/VWorldInstance/vwinstance.h"

VTripleSubjectWidget::VTripleSubjectWidget(VStatement * statement, VTriple * triple, QWidget *parent) :
    QComboBox(parent),
    _triple(triple),
    _statement(statement)
{
    this->setEditable(true);
    if(_statement->getType() == domain)
    {
        updateDomain();
    }
    else if(_statement->getType() == activity)
    {
        updateActivity();
    }
    connect(this, SIGNAL(currentIndexChanged(int)), this, SLOT(onCurrentIndexChanged(int)));
}

void VTripleSubjectWidget::updateDomain()
{
    VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
    QList<VWInstance *> instances = worldModel->getAllInstances();
    QList<VWComponentClass *> components = worldModel->getAllComponents();
    QList<VWObjectClass *> objects = worldModel->getObjects();

    addItem("");
    addItem("domain:Unkown");
    addItem("domain:True");
    addItem("domain:False");

    foreach(VWInstance * instance, instances)
    {
        addItem(instance->getName(), instance->getUid());
    }

    foreach(VWComponentClass * component, components)
    {
        addItem(component->getName(), component->getUid());
    }

    foreach(VWObjectClass * object, objects)
    {
        addItem(object->getName(), object->getUid());
    }
    setCurrentText(_triple->getSubject());
}

void VTripleSubjectWidget::updateActivity()
{
    VActivityModel * activityModel = &VApplicationModel::getInstance()->getActivityModel();
    QList<VTask *> tasks = activityModel->getAllChildTasks();

    addItem("");
    foreach(VTask * task, tasks)
    {
        addItem(task->getId(), task->getUid());
    }
    setCurrentText(_triple->getSubject());
}

void VTripleSubjectWidget::onCurrentIndexChanged(int index)
{
    QString value = this->itemText(index);
    QString uid = this->itemData(index).toString();
    VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VActivityModel * activityModel = &VApplicationModel::getInstance()->getActivityModel();
    VWInstance * instance = worldModel->getInstanceByUid(uid.toLong());
    VWComponentClass * component = worldModel->getComponentByUid(uid.toLong());
    VWObjectClass * object = worldModel->getObjectByUid(uid.toLong());
    VTask * task = activityModel->getTaskByUid(uid.toLong());
    if(_statement->getType() == domain)
    {
        if(instance != NULL)
        {
            _triple->setSubject(instance);
        }
        else if(component != NULL)
        {
            _triple->setSubject(component);
        }
        else if(object != NULL)
        {
            _triple->setSubject(object);
        }
        else
        {
            _triple->setSubject(value);
        }
    }
    else if(_statement->getType() == activity)
    {
        if(task != NULL)
        {
            _triple->setSubject(task);
        }
        else
        {
            _triple->setSubject(value);
        }
    }
}
