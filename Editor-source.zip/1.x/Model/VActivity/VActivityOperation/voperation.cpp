#include "voperation.h"

#include "../VActivityCommon/vrefconcept.h"
#include "../VActivityCommon/vparam.h"
#include "Model/VWorld/VWorldClass/vwactionclass.h"
#include "Model/vapplicationmodel.h"
#include "Controller/vtracecontroller.h"

/**
 * @brief VOperation
 *Constructeur
 */
VOperation::VOperation(QObject *parent) :
    VActivityModelElement(parent),
    _type(ACTION),
    _actionClass(NULL),
    _speechAct(NULL)
{
}

/**
 * @brief VOperation
 *Constructeur
 */
VOperation::VOperation(const VOperation& operation, QObject *parent) :
    VActivityModelElement(parent)
{
    _type = operation.getType();
    if(operation.getAction() != NULL) setAction(QPointer<VWActionClass>(operation.getAction().data()));
    if(operation.getSpeechAct() != NULL) setSpeechAct(QPointer<VSpeechAct>(operation.getSpeechAct().data()));
    foreach(VRefConcept * ref, operation._refs)
    {
        addRef(ref->clone());
    }
    foreach(VParam * param, operation._params)
    {
        addParam(param->clone());
    }
}

/**
 * @brief ~VOperation
 * Destructeur
 */
VOperation::~VOperation()
{
    VTraceController::get()->Debug("VTask::~VOperation()", "Begin");
    while(_refs.count() > 0)
    {
        VRefConcept * refConcept = _refs.first();
        _refs.pop_front();
        delete refConcept;
    }
    while(_params.count() > 0)
    {
        VParam * param = _params.first();
        _params.pop_front();
        delete param;
    }
    VTraceController::get()->Debug("VTask::~VOperation()", "End");
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 *
 * @todo actions
 */
void VOperation::parseDom(QDomElement elem)
{
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de action
            if(element.tagName() == "action")
            {
                VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
                QString actionName = element.attribute("id", "");
                _actionClass = worldModel->getActionByName(actionName);
                if(_actionClass == NULL && !actionName.isNull() && !actionName.isEmpty())
                {
                    _actionClass = new VWActionClass();
                    _actionClass->setName(actionName);
                    worldModel->addAction(_actionClass);
                }
            }
            // Lecture de resources
            else if(element.tagName() == "resources")
            {
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        // Lecture de ref-concept
                        if(subElement.tagName() == "ref-concept")
                        {
                            VRefConcept * refConcept = new VRefConcept(this);
                            refConcept->parseDom(subElement);
                            addRef(refConcept);
                        }
                        // Lecture de param
                        else if(subElement.tagName() == "param")
                        {
                            VParam * param = new VParam(this);
                            param->parseDom(subElement);
                            addParam(param);
                        }
                    }
                    subNode = subNode.nextSibling();
                }
            }
            else if(element.tagName() == "speechAct"){
                setSpeechAct(new VSpeechAct());
                _speechAct->parseDom(element);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 *
 * @todo actions
 */
QString VOperation::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<operation>\n";

    if(_type == ACTION){
        // Ajoute l'action
        RetVal += tabulation + "\t<action";
        if(_actionClass != NULL) RetVal += " id=\"" + _actionClass->getName() + "\"";
        RetVal += " />\n";

        RetVal += tabulation + "\t<resources>\n";

        // Ajouter les ref-concept
        for(int i = 0; i < _refs.count(); i++)
        {
            RetVal += _refs[i]->ToXml(tabulation + "\t\t");
        }
        // Ajouter les params
        for(int i = 0; i < _params.count(); i++)
        {
            RetVal += _params[i]->ToXml(tabulation + "\t\t");
        }
        RetVal += tabulation + "\t</resources>\n";
    }
    if(_type == SPEECHACT){
        if(_speechAct != NULL) RetVal += _speechAct->ToXml();
    }
    RetVal += tabulation + "</operation>\n";
    return RetVal;
}

VOperationType VOperation::getType() const
{
    return _type;
}

void VOperation::setType(const VOperationType &type)
{
    _type = type;
     onModified(tr("Operation type changed"));
}
/**
 * @brief getAction
 * Définit l'action de l'opération
 * @param actionClass L'action
 */
void VOperation::setAction(QPointer<VWActionClass> actionClass)
{
    if(actionClass != _actionClass)
    {
        if(_actionClass != NULL) disconnect(_actionClass, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        _actionClass = actionClass;
        if(_actionClass != NULL) connect(_actionClass, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Action changed"));
    }
}
/**
 * @brief getAction
 * Obtient l'action de l'opération
 * @return L'action de l'opération
 */
QPointer<VWActionClass> VOperation::getAction() const
{
    return _actionClass;
}

QPointer<VSpeechAct> VOperation::getSpeechAct() const
{
    return _speechAct;
}

void VOperation::setSpeechAct(QPointer<VSpeechAct> speechAct)
{
    if(_speechAct != NULL) disconnect(_speechAct, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    _speechAct = speechAct;
    if(_speechAct != NULL) connect(_speechAct, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    onModified(tr("Speech act changed"));

}


/**
 * @brief addRef
 * Permet d'ajouter un VRefConcept
 * @param ref Un VRefConcept
 */
void VOperation::addRef(VRefConcept * ref)
{
    if(ref != NULL)
    {
        _refs.append(ref);
        connect(ref, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified("", ref);
    }
}

/**
 * @brief removeRef
 * Permet de retirer un VRefConcept
 * @param ref Un VRefConcept
 */
void VOperation::removeRef(VRefConcept * ref)
{
    if(_refs.contains(ref))
    {
        _refs.removeAll(ref);
        disconnect(ref, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified("", ref);
    }
}

/**
 * @brief getRefs
 * Obtient la liste des VRefConcept
 * @return La liste des VRefConcept
 */
QList<VRefConcept *> VOperation::getRefs() const
{
    return _refs;
}

/**
 * @brief getRefById
 * Obtient le refconcept correspondant à l'id
 * @return Le refconcept correspondant à l'id
 */
VRefConcept * VOperation::getRefById(qint64 uid) const
{
    for(int i = 0; i < _refs.count(); i++)
    {
        if(_refs[i]->getUid() == uid)
        {
            return _refs[i];
        }
    }
    return NULL;
}

/**
 * @brief addParam
 * Permet d'ajouter un VParam
 * @param param Un VParam
 */
void VOperation::addParam(VParam * param)
{
    if(param != NULL)
    {
        _params.append(param);
        connect(param, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Param added"));
    }
}

/**
 * @brief removeParam
 * Permet de retirer un VParam
 * @param param Un VParam
 */
void VOperation::removeParam(VParam * param)
{
    if(_params.contains(param))
    {
        _params.removeAll(param);
        disconnect(param, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Param removed"));
    }
}

/**
 * @brief getParams
 * Obtient la liste des VParam
 * @return La liste des VParam
 */
QList<VParam *> VOperation::getParams() const
{
    return _params;
}

/**
 * @brief getParamById
 * Obtient le param correspondant à l'id
 * @param uid L'id du param
 * @return Le param correspondant à l'id
 */
VParam * VOperation::getParamById(qint64 uid) const
{
    for(int i = 0; i < _params.count(); i++)
    {
        if(_params[i]->getUid() == uid)
        {
            return _params[i];
        }
    }
    return NULL;
}

/**
 * @brief clone
 * @return Le clone
 */
VOperation * VOperation::clone(QObject* parent) const
{
    return new VOperation(*this, parent);
}


