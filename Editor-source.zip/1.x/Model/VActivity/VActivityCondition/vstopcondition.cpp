#include "vstopcondition.h"

#include "vstatement.h"
#include "vcondition.h"
#include "vconditions.h"
#include "../vtask.h"
#include "../../VWorld/vworldmodelelement.h"

VStopCondition::VStopCondition(QObject *parent) :
    VBasisCondition(parent),
    _type("satisfaction"),
    _iteration(0),
    _duration(),
    _statement(NULL),
    _satisfactionCondition(NULL)
{
    _duration.setHMS(0,0,0);
}

VStopCondition::VStopCondition(const VStopCondition& stopCondition, QObject *parent) :
    VBasisCondition(stopCondition, parent)
{
    this->setType(stopCondition.getType());
    this->setIteration(stopCondition.getIteration());
    this->setDuration(stopCondition.getDuration());
    if(stopCondition.getStatement() != NULL) this->setStatement(stopCondition.getStatement()->clone());
    this->setSatisfactionCondition(stopCondition.getSatisfactionCondition());
    // TODO : instance
}

/**
 * @brief ~VStopCondition
 * Destructeur
 */
VStopCondition::~VStopCondition()
{
    if(_statement != NULL) delete _statement;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VStopCondition::parseDom(QDomElement elem)
{
    this->setId(elem.attribute("id",""));
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            this->setType(element.tagName());
            if(_type == "satisfaction")
            {
                this->setSatisfactionConditionById(element.attribute("id","").toLong());
            }
            else if(_type == "instance")
            {
                // TODO
//                this->setInstance(element.attribute("refs",""));
            }
            else if(_type == "statement")
            {
                if(_statement != NULL) delete _statement;
                VStatement * statement = new VStatement(this);
                statement->parseDom(element);
                setStatement(statement);
            }
            else if(_type == "duration")
            {
                this->setDuration(element.attribute("time",""));
            }
            else if(_type == "iteration")
            {
                this->setIteration(element.attribute("number","").toInt());
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VStopCondition::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<stop id=\"" + QString::number(getId()) + "\">\n";
    if(_type == "satisfaction")
    {
        if(_satisfactionCondition != NULL) RetVal += tabulation + "\t" + "<satisfaction id=\"" + QString::number(_satisfactionCondition->getId()) + "\" />\n";
    }
    else if(_type == "instance")
    {
        if(_instance != NULL) RetVal += tabulation + "\t" + "<instances refs=\"" + _instance->getName() + "\" />\n"; // TODO
    }
    else if(_type == "statement")
    {
        if(_statement != NULL) RetVal += _statement->ToXml(tabulation + "\t");
    }
    else if(_type == "duration")
    {
        RetVal += tabulation + "\t" + "<duration time=\"" + _duration.toString("hh:mm:ss") + "\" />\n";
    }
    else if(_type == "iteration")
    {
        RetVal += tabulation + "\t" + "<iteration number=\"" + QString::number(_iteration) + "\" />\n";
    }
    RetVal += tabulation + "</stop>\n";
    return RetVal;

}

void VStopCondition::setType(QString type)
{
    type = type.toLower();
    if(type != _type)
    {
        _type = type;
        if(_type == "statement")
        {
            if(_statement != NULL) delete _statement;
            setStatement(new VStatement(this));
        }
        onModified(NULL);
    }
}

QString VStopCondition::getType() const
{
    return _type;
}

void VStopCondition::setIteration(int iteration)
{
    if(iteration != _iteration)
    {
        _iteration = iteration;
        onModified(tr("Iteration changed"));
    }
}

int VStopCondition::getIteration() const
{
    return _iteration;
}

void VStopCondition::setDuration(QString duration)
{
    setDuration(QTime::fromString(duration,"hh:mm:ss"));
}

void VStopCondition::setDuration(int h, int m, int s, int ms)
{
    s += ms / 1000;
    ms = ms % 1000;

    m += s / 60;
    s = s % 60;

    h += m / 60;
    m = m % 60;

    _duration.setHMS(h, m, s, ms);
    onModified(tr("Duration changed"));
}

void VStopCondition::setDuration(QTime duration)
{
    if(duration != _duration)
    {
        _duration = duration;
        onModified(tr("Duration changed"));
    }
}

QTime VStopCondition::getDuration() const
{
    return _duration;
}

void VStopCondition::setStatement(VStatement * statement)
{
    if(statement != _statement)
    {
        _statement = statement;
        connect(_statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Statement changed"));
    }
}

VStatement * VStopCondition::getStatement() const
{
    return _statement;
}

void VStopCondition::setSatisfactionConditionById(qint64 id)
{
    if(_task->getSatisfactionConditions() == NULL) return;
    QList<VCondition *> conditions = _task->getSatisfactionConditions()->getConditions();
    foreach(VCondition * condition, conditions)
    {
        if(condition->getId() == id)
        {
            setSatisfactionCondition(condition);
            return;
        }
    }
    setSatisfactionCondition(NULL);
}

void VStopCondition::setSatisfactionCondition(QPointer<VCondition> satisfactionCondition)
{
    if(satisfactionCondition != _satisfactionCondition)
    {
        _satisfactionCondition = satisfactionCondition;
        onModified(tr("Satisfaction condition changed"));
    }
}

QPointer<VCondition> VStopCondition::getSatisfactionCondition() const
{
    return _satisfactionCondition;
}

void VStopCondition::setInstance(qint64 id)
{

}

void VStopCondition::setInstance(QPointer<VWorldModelElement> instance)
{
    if(instance != _instance)
    {
        _instance = instance;
        onModified(tr("Instance changed"));
    }
}

QPointer<VWorldModelElement> VStopCondition::getInstance() const
{
    return _instance;
}

void VStopCondition::setTask(QPointer<VTask> task)
{
    _task = task;
}

QPointer<VTask> VStopCondition::getTask() const
{
    return _task;
}

/**
 * @brief clone
 * @return Le clone
 */
VStopCondition * VStopCondition::clone(QObject * parent) const
{
    return new VStopCondition(*this, parent);
}
