#include "vsubject.h"
#include "../../../../Controller/vtracecontroller.h"
#include <qdom.h>

VSubject::VSubject():
    _performative(NULL),
    _content(NULL)
{

}

VSubject::VSubject(const VSubject &subject, QObject* parent):
VActivityModelElement(parent),
  _performative(subject._performative)
{
    _content = subject._content->clone();
}

VSubject::~VSubject()
{
    if(_content != NULL)
        delete _content;
}

QString* VSubject::getPerformative() const
{
    return _performative;
}

void VSubject::setPerformative(QString* performative)
{
    _performative = performative;
    onModified(tr("Speech act subject modified"), this);
}
VSpeechActContent* VSubject::getContent() const
{
    return _content;
}

void VSubject::setContent(VSpeechActContent *content){
    _content = content;
    connect(content, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    onModified(tr("Speech act subject modified"));
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VSubject::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VSubject::parseDom()", "<" + elem.tagName() + ">");

    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture du Performatif
            if(element.tagName() == "Performative")
            {
                QString* myPerformative = new QString(element.text());
                setPerformative(myPerformative);
            }
            // Lecture du subject
            else if(element.tagName() == "Content")
            {
                setContent(new VSpeechActContent());
                _content->parseDom(element);
            }
        }
        node = node.nextSibling();
    }

    VTraceController::get()->Info("VSubject::parseDom()", "</" + elem.tagName() + ">");
}

QString VSubject::ToXml(QString tabulation)
{
    QString RetVal = tabulation;
    RetVal += "<Subject> \n";
    RetVal += tabulation + "\t" + "<Performative>" + *_performative + "</Performative>\n";
    VSpeechActContent* my_content = (this->getContent());
    QString content = my_content->ToXml(tabulation + "\t");
    RetVal += content;
    RetVal += tabulation + "</Subject>\n";

    return RetVal;
}


VSubject* VSubject::clone()const{
    return new VSubject(*this);
}


