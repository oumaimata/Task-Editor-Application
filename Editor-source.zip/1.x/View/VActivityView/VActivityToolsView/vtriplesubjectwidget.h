#pragma once
#ifndef VTRIPLESUBJECTWIDGET_H
#define VTRIPLESUBJECTWIDGET_H

#include <QComboBox>

class VTriple;
class VStatement;

class VTripleSubjectWidget : public QComboBox
{
    Q_OBJECT
private:
    VTriple * _triple;
    VStatement * _statement;
public:
    explicit VTripleSubjectWidget(VStatement * statement, VTriple * triple, QWidget *parent = 0);

    void updateDomain();

    void updateActivity();
    
signals:
    
public slots:
    void onCurrentIndexChanged(int index);
    
};

#endif // VTRIPLESUBJECTWIDGET_H
