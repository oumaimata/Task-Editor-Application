#pragma once
#ifndef VTRIPLEOBJECTWIDGET_H
#define VTRIPLEOBJECTWIDGET_H

#include <QComboBox>

class VTriple;
class VStatement;

class VTripleObjectWidget : public QComboBox
{
    Q_OBJECT
private:
    VTriple * _triple;
    VStatement * _statement;
public:
    explicit VTripleObjectWidget(VStatement * statement, VTriple * triple, QWidget *parent = 0);

public slots:
    void onCurrentIndexChanged(int index);
};

#endif // VTRIPLEOBJECTWIDGET_H
