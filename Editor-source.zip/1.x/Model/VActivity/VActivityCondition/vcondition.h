#pragma once
#ifndef VCONDITION_H
#define VCONDITION_H

#include <QtXml>

#include "vbasiscondition.h"

class VConditionLogicalOperator;
class VStatement;

class VCondition : public VBasisCondition
{
    Q_OBJECT
private:
    QString _type;

    QList<VConditionLogicalOperator *> _CLOs;

    QList<VStatement *> _statements;

public:
    explicit VCondition(QObject* parent = NULL);

    VCondition(const VCondition& condition, QObject *parent = 0);

    /**
     * @brief ~VCondition
     * Destructeur
     */
    ~VCondition();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setType(QString type);
    QString getType();

    void addCLO(VConditionLogicalOperator * cLO);
    void removeCLO(VConditionLogicalOperator * cLO);
    QList<VConditionLogicalOperator *> getCLOs() const;
    VConditionLogicalOperator * getCLOById(qint64 uid) const;

    void addStatement(VStatement * statement);
    void removeStatement(VStatement * statement);
    QList<VStatement *> getStatements() const;
    VStatement * getStatementById(qint64 uid) const;

    QString toString(QString tabulation = "") const;

    /**
     * @brief clone
     * @return Le clone
     */
    VCondition * clone(QObject *parent = 0) const;
};

#endif // VCONDITION_H
