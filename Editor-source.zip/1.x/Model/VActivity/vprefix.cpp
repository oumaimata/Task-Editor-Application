#include "vprefix.h"

#include "../../Controller/vtracecontroller.h"

/**
* @brief VPrefix
* @param parent L'objet parent
*/
VPrefix::VPrefix(QObject* parent) :
    VActivityModelElement(parent)
{
    _name = "prefix_" + QString::number(getUid());
}

/**
* @brief VPrefix
* @param name Le nom du préfix
* @param iri L'iri du préfix
* @param parent L'objet parent
*/
VPrefix::VPrefix(QString name, QString iri, QObject* parent) :
    VActivityModelElement(parent),
    _name(name),
    _iri(iri)
{
}

/**
 * @brief VPrefix
 * Constructeur de copie
 * @param prefix Préfix à copier
 */
VPrefix::VPrefix(const VPrefix& prefix, QObject *parent):
    VActivityModelElement(parent)
{
    _name = prefix._name;
    _iri = prefix._iri;
}

/**
* @brief setName
* Définit le nom du préfix
* @param name Le nom du préfix
*/
void VPrefix::setName(QString name)
{
    if(name != _name)
    {
        _name = name;
        onModified(tr("Name changed"));
    }
}

/**
* @brief getName
* Obtient le nom du préfix
* @return Le nom du préfix
*/
QString VPrefix::getName() const
{
    return _name;
}

/**
* @brief setIri
* Définit l'iri du préfix
* @param name L'iri du préfix
*/
void VPrefix::setIri(QString iri)
{
    if(iri != _iri)
    {
        _iri = iri;
        onModified(tr("Iri changed"));
    }
}

/**
* @brief getIri
* Obtient l'iri du préfix
* @return L'iri du préfix
*/
QString VPrefix::getIri() const
{
    return _iri;
}

/**
 * @brief operator ==
 * @param prefix Préfixe à comparer
 * @return Si les deux préfixe sont identiques
 */
bool VPrefix::operator==(const VPrefix& prefix) const
{
    return _name == prefix._name && _iri == prefix._iri;
}

/**
 * @brief parseDom Charge un élément du dom
 * @param elem Un élément du dom
 */
void VPrefix::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VPrefix::parseDom()", "<" + elem.tagName() + ">");

    setName(elem.attribute("name",""));
    setIri(elem.attribute("iri",""));

    VTraceController::get()->Info("VPrefix::parseDom()", "</" + elem.tagName() + ">");
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VPrefix::ToXml(QString tabulation)
{
    return tabulation + "<prefix name=\"" + _name + "\" iri=\"" + _iri + "\" />\n";
}
