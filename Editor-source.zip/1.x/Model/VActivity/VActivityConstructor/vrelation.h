#pragma once
#ifndef VRELATION_H
#define VRELATION_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"
#include "vactivityoperatortype.h"

class VConstructor;
class VTask;

class VRelation : public VActivityModelElement
{
    Q_OBJECT
private:

    QString _lh;

    QPointer<VTask> _taskLh;

    VActivityOperatorType _operator;

    QString _rh;

    QPointer<VTask> _taskRh;
public:
    explicit VRelation(QObject *parent = 0);

    VRelation(const VRelation& relation, QObject *parent = 0);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    /**
     * @brief AfterTasksParsed
     * Définie les tâches des relations
     * @param task La tâche du constructeur
     */
    void AfterTasksParsed(VTask *task);

    void setLh(QString lh);

    QString getLh();

    void setTaskLh(QPointer<VTask> taskLh);

    QPointer<VTask> getTaskLh() const;

    void setOperator(VActivityOperatorType ooperator);

    void setOperator(QString ooperator);

    VActivityOperatorType getOperator();

    void setRh(QString rh);

    QString getRh();

    void setTaskRh(QPointer<VTask>taskRh);

    QPointer<VTask> getTaskRh() const;

    /**
     * @brief clone
     * @return Le clone
     */
    VRelation * clone(QObject *parent = 0) const;
};

#endif // VRELATION_H
