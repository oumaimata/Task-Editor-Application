#include "vweventclass.h"

#include "../vwparser.h"
#include "../vwproperties.h"
#include "vwbehaviourclass.h"

VWEventClass::VWEventClass(QObject *parent) :
    VWEntityClass(parent),
    _isDurative(true),
    _isPunctual(false),
    _isEndogenous(false),
    _isExogenous(true),
    _beginingEvent(NULL),
    _endingEvent(NULL)
{
    setName("Event" + QString::number(getUid()));
    _properties = new VWProperties();
    _properties->setType("action-behaviour-event");
    _properties->setWorldModelElement(this);
    _properties->setIsShared(true);
    connect(_properties, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
}

/**
 * @brief VWEventClass
 * @param o L'objet à copier
 */
VWEventClass::VWEventClass(const VWEventClass& o) :
    VWEntityClass(o.parent())
{
    _isDurative = o._isDurative;
    _isPunctual = o._isPunctual;
    _isEndogenous = o._isEndogenous;
    _isExogenous = o._isExogenous;
    _beginingEvent = o._beginingEvent;
    _endingEvent = o._endingEvent;
    _behaviours = o._behaviours;
    _properties = o._properties;
}

/**
 * @brief ~VWEventClass
 * Destructeur
 */
VWEventClass::~VWEventClass()
{
    delete _properties;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWEventClass::ParseDom(QDomElement elem)
{
    VWEntityClass::ParseDom(elem);
    QList<QString> domainSupClasses = VWParser::getDomainSupClasses(elem);
    foreach(QString domainSupClass, domainSupClasses)
    {
        if(domainSupClass == "durativeevent")
        {
            setIsDurative(true);
        }
        else if(domainSupClass == "punctualevent")
        {
            setIsPunctual(true);
        }
        if(domainSupClass == "endogenousevent")
        {
            setIsEndogenous(true);
        }
        else if(domainSupClass == "exogenousevent")
        {
            setIsExogenous(true);
        }
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWEventClass::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<owl:Class rdf:ID=\"" + getName() + "\">\n";
    RetVal += VWEntityClass::ToXml(tabulation + "\t");
    if(_isDurative) RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#DurativeEvent\"/>\n";
    if(_isPunctual) RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#PunctualEvent\"/>\n";
    if(_isEndogenous) RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#EndogenousEvent\"/>\n";
    if(_isExogenous) RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#ExogenousEvent\"/>\n";
    RetVal += tabulation + "</owl:Class>\n";
    // liste de behaviour
    foreach(QPointer<VWBehaviourClass> behaviour, _behaviours)
    {
        if(behaviour != NULL)
        {
            if(behaviour->getIsDurative())
            {
                RetVal += tabulation + "<owl:ObjectProperty rdf:about=\"" + getName() + "-has-DurativeBehaviour-" + behaviour->getName() + "\">\n";
                RetVal += tabulation + "\t" + "<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#has-DurativeBehaviour\"/>\n";
                RetVal += tabulation + "\t" + "<rdfs:domain rdf:resource=\"#" + getName() + "\"/>\n";
                RetVal += tabulation + "\t" + "<rdfs:range rdf:resource=\"#" + behaviour->getName() + "\"/>\n";
            }
            else
            {
                RetVal += tabulation + "<owl:ObjectProperty rdf:about=\"" + getName() + "-has-PunctualBehaviour-" + behaviour->getName() + "\">\n";
                RetVal += tabulation + "\t" + "<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#has-PunctualBehaviour\"/>\n";
                RetVal += tabulation + "\t" + "<rdfs:domain rdf:resource=\"#" + getName() + "\"/>\n";
                RetVal += tabulation + "\t" + "<rdfs:range rdf:resource=\"#" + behaviour->getName() + "\"/>\n";
            }
            RetVal += tabulation + "</owl:ObjectProperty>\n";
        }
    }
    if(this->getIsDurative())
    {
        if(_beginingEvent != NULL)
        {
            RetVal += tabulation + "<owl:ObjectProperty rdf:about=\"" + getName() + "-begin-with-" + _beginingEvent->getName() + "\">\n";
            RetVal += tabulation + "\t" + "<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#begin-with-event\"/>\n";
            RetVal += tabulation + "\t" + "<rdfs:domain rdf:resource=\"#" + getName() + "\"/>\n";
            RetVal += tabulation + "\t" + "<rdfs:range rdf:resource=\"#" + _beginingEvent->getName() + "\"/>\n";
            RetVal += tabulation + "</owl:ObjectProperty>\n";
        }
        if(_endingEvent != NULL)
        {
            RetVal += tabulation + "<owl:ObjectProperty rdf:about=\"" + getName() + "-end-with-" + _endingEvent->getName() + "\">\n";
            RetVal += tabulation + "\t" + "<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#end-with-event\"/>\n";
            RetVal += tabulation + "\t" + "<rdfs:domain rdf:resource=\"#" + getName() + "\"/>\n";
            RetVal += tabulation + "\t" + "<rdfs:range rdf:resource=\"#" + _endingEvent->getName() + "\"/>\n";
            RetVal += tabulation + "</owl:ObjectProperty>\n";
        }
    }
    return RetVal;
}

void VWEventClass::setIsDurative(bool isDurative)
{
    if(isDurative != _isDurative)
    {
        _isDurative = isDurative;
        _isPunctual = !_isDurative;
        onModified(_isDurative ? tr("Event is durative") : tr("Event is punctual"));
    }
}

bool VWEventClass::getIsDurative() const
{
    return _isDurative;
}

void VWEventClass::setIsPunctual(bool isPunctual)
{
    if(isPunctual != _isPunctual)
    {
        _isPunctual = isPunctual;
        _isDurative = !_isPunctual;
        onModified(_isDurative ? tr("Event is durative") : tr("Event is punctual"));
    }
}
bool VWEventClass::getIsPunctual() const
{
    return _isPunctual;
}

void VWEventClass::setIsEndogenous(bool isEndogenous)
{
    if(isEndogenous != _isEndogenous)
    {
        _isEndogenous = isEndogenous;
        _isExogenous = !_isEndogenous;
        onModified(_isEndogenous ? tr("Event is endogenous") : tr("Event is exogenous"));
    }
}

bool VWEventClass::getIsEndogenous() const
{
    return _isEndogenous;
}

void VWEventClass::setIsExogenous(bool isExogenous)
{
    if(isExogenous != _isExogenous)
    {
        _isExogenous = isExogenous;
        _isEndogenous = !_isExogenous;
        onModified(_isEndogenous ? tr("Event is endogenous") : tr("Event is exogenous"));
    }
}
bool VWEventClass::getIsExogenous() const
{
    return _isExogenous;
}

void VWEventClass::setBeginingEvent(VWEventClass * event)
{
    if(event != _beginingEvent)
    {
        _beginingEvent = event;
        onModified(tr("Begining event changed"));
    }
}

VWEventClass * VWEventClass::getBeginingEvent() const
{
    return _beginingEvent;
}

void VWEventClass::setEndingEvent(VWEventClass * event)
{
    if(event != _endingEvent)
    {
        _endingEvent = event;
        onModified(tr("Ending event changed"));
    }
}

VWEventClass * VWEventClass::getEndingEvent() const
{
    return _endingEvent;
}

void VWEventClass::addBehaviour(VWBehaviourClass * behaviourClass)
{
    if(behaviourClass != NULL)
    {
        _behaviours.append(behaviourClass);
        connect(behaviourClass, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Behaviour added"));
    }
}

void VWEventClass::removeBehaviour(VWBehaviourClass * behaviourClass)
{
    if(_behaviours.contains(behaviourClass))
    {
        _behaviours.removeAll(behaviourClass);
        disconnect(behaviourClass, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Behaviour removed"));
    }
}

QList<QPointer<VWBehaviourClass> > VWEventClass::getBehaviours() const
{
    return _behaviours;
}


QPointer<VWProperty> VWEventClass::addProperty(QDomElement elem)
{
  if(_properties != NULL)  return _properties->addProperty(elem);
  return QPointer<VWProperty>();
}

VWProperties * VWEventClass::getProperties() const
{
  return _properties;
}
