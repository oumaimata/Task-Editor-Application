#include "vinstancecombobox.h"

#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldInstance/vwinstance.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"
#include "Model/VActivity/VActivityCondition/vstopcondition.h"

VInstanceComboBox::VInstanceComboBox(VStopCondition * stopCondition, QWidget *parent) :
    QComboBox(parent),
    _stopCondition(stopCondition)
{
    VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
    QList<VWInstance *> instances = worldModel->getAllInstances();
    QList<VWComponentClass *> components = worldModel->getAllComponents();
    QList<VWObjectClass *> objects = worldModel->getObjects();

    addItem("");
    addItem("domain:Unkown");
    addItem("domain:True");
    addItem("domain:False");

    foreach(VWInstance * instance, instances)
    {
        addItem(instance->getName(), instance->getUid());
    }

    foreach(VWComponentClass * component, components)
    {
        addItem(component->getName(), component->getUid());
    }

    foreach(VWObjectClass * object, objects)
    {
        addItem(object->getName(), object->getUid());
    }
    connect(this, SIGNAL(currentTextChanged(QString)), this, SLOT(instanceChanged(QString)));

    if(_stopCondition != NULL)
        if(_stopCondition->getInstance() != NULL) setCurrentText(_stopCondition->getInstance()->getName());
}

void VInstanceComboBox::instanceChanged(QString s)
{
    int index = currentIndex();
    QString uid = this->itemData(index).toString();
    VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWInstance * instance = worldModel->getInstanceByUid(uid.toLong());
    VWComponentClass * component = worldModel->getComponentByUid(uid.toLong());
    VWObjectClass * object = worldModel->getObjectByUid(uid.toLong());

    if(_stopCondition != NULL){
        if(instance != NULL)
        {
            _stopCondition->setInstance(instance);
        }
        else if(component != NULL)
        {
            _stopCondition->setInstance(component);
        }
        else if(object != NULL)
        {
            _stopCondition->setInstance(object);
        }
    }
}
