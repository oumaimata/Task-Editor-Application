#pragma once
#ifndef VWCOMPONENTNAVIGATORWIDGET_H
#define VWCOMPONENTNAVIGATORWIDGET_H

#include <QWidget>
#include <QTreeWidgetItem>

#include "../../Model/VWorld/vworldmodelelement.h"

class VWorldModel;
class VWComponentClass;

namespace Ui {
class VWComponentNavigatorWidget;
}

class VWComponentNavigatorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWComponentNavigatorWidget *ui;

    VWorldModel * _worldModel;

    bool _edit;

    VWorldModelElement * _currentEdit;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief createComponentItem
     * Crée un QTreeWidgetItem correspondant au composant passé en argument
     * Méthode appelée récursivement sur l'arbre des objets
     * @param parentItem Le QTreeWidgetItem parent
     * @param component Le composant
     * @return Le QTreeWidgetItem correspondant au composant passé en argument
     */
    QTreeWidgetItem *  createComponentItem(QTreeWidgetItem * parentItem, VWComponentClass * component);
    
public:
    explicit VWComponentNavigatorWidget(QWidget *parent = 0);
    ~VWComponentNavigatorWidget();

    void setWorldModel(VWorldModel * worldModel);

    void setCurrentEdit(VWorldModelElement * curentEdit);

private slots:

    void updateDisplay();
    void on_addButton_clicked();
    void on_removeButton_clicked();
    void on_componentTreeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column);
signals:
    void editComponentAsked(VWComponentClass * componentClass);

    void removeAsked(VWorldModelElement * removed = NULL);
};

#endif // VWCOMPONENTNAVIGATORWIDGET_H
