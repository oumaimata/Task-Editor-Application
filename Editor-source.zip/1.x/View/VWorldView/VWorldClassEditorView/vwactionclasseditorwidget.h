#pragma once
#ifndef VWACTIONCLASSEDITORWIDGET_H
#define VWACTIONCLASSEDITORWIDGET_H

#include <QWidget>

class VWActionClass;
class VElementCreator;

namespace Ui {
class VWActionClassEditorWidget;
}

class VWActionClassEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWActionClassEditorWidget *ui;

    bool _edit;

    VWActionClass * _actionClass;

    /**
     * @brief elementCreator
     * La fenêtre de création d'élément
     */
    VElementCreator * _elementCreator;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    void retranslate();
    
public:
    explicit VWActionClassEditorWidget(QWidget *parent = 0);
    ~VWActionClassEditorWidget();

    void setActionClass(VWActionClass * actionClass);
private slots:
    void updateDisplay();
    void on_nameLineEdit_editingFinished();
    void on_addBehaviourButton_clicked();
    void on_removeBehaviourButton_clicked();

    /**
     * @brief onElementCreatorClose
     * Gère la fermeture de la fenêtre d'ajout de behaviour
     */
    void onElementCreatorClose();
};

#endif // VWACTIONCLASSEDITORWIDGET_H
