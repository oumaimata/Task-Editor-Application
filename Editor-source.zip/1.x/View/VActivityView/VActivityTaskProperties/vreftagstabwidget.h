#pragma once
#ifndef VREFTAGSTABWIDGET_H
#define VREFTAGSTABWIDGET_H

#include <QWidget>
#include <QTableWidgetItem>

class VTask;
class VActivityModel;

namespace Ui {
class VRefTagsTabWidget;
}

class VRefTagsTabWidget : public QWidget
{
    Q_OBJECT
private:

    Ui::VRefTagsTabWidget *ui;

    /**
     * @brief task
     * Tâche en cours d'édition
     */
    VTask * _task;

    /**
     * @brief _activityModel
     * Le modèle d'activité en cours
     */
    VActivityModel * _activityModel;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    /**
     * @brief VRefTagsTabWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VRefTagsTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VRefTagsTabWidget
     * Destructeur
     */
    ~VRefTagsTabWidget();

    /**
     * @brief setActivityModel
     * Définit le modèle d'activité en cours
     * @param activityModel Le modèle d'activité en cours
     */
    void setActivityModel(VActivityModel * activityModel);

    /**
     * @brief setTask
     * Définit la tâche en cours d'édition
     * @param task La tâche en cours d'édition
     */
    void setTask(VTask *task);

    /**
     * @brief getTask
     * Obitent la tâche en cours d'édition
     * @return La tâche en cours d'édition
     */
    VTask * getTask() const;

private slots:

    /**
     * @brief on_addTagButton_clicked
     * Gère le click sur le bouton ajouter
     */
    void on_addTagButton_clicked();

    /**
     * @brief on_removeTagButton_clicked
     * Gère le click sur le bouton supprimer
     */
    void on_removeTagButton_clicked();

    /**
     * @brief updateDisplay
     * Met a jour l'inteface en fonction de la tache sélectionnée
     */
    void updateDisplay();
    void on_tagValueWidget_itemChanged(QTableWidgetItem *item);
};

#endif // VREFTAGSTABWIDGET_H
