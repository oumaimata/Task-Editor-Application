#include "vworldmodel.h"

#include <iostream>

#include "vwproperty.h"
#include "vwproperties.h"
#include "vwparser.h"
#include "VWorldInstance/vwinstance.h"
#include "VWorldClass/vwactionclass.h"
#include "VWorldClass/vwobjectclass.h"
#include "VWorldClass/vwcomponentclass.h"
#include "VWorldClass/vweventclass.h"
#include "VWorldClass/vwbehaviourclass.h"
#include "../VHistory/vhistoryset.h"
#include "../VOntologyInterface/vontologyinterface.h"
#include "../../Controller/vapplicationcontroller.h"
#include "../../Controller/vworldcontroller.h"
#include "../../Controller/vtracecontroller.h"

/**
 * @brief VWorldModel
 * Constructeur par défaut
 * @param parent L'objet parent
 */
VWorldModel::VWorldModel(QObject *parent) :
    VWorldModelElement(parent),
    _namespaceUri(""),
    _domainNamespaceUri("")
{
    _edit = true;
    setName("WorldModel");
    setDomainNamespace("http://www.utc.fr/hds/ici/humans/domain");
    addNamespace("xmlns:owl", "http://www.w3.org/2002/07/owl");
    addNamespace("xmlns:rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns");
    addNamespace("xmlns:rdfs", "http://www.w3.org/2000/01/rdf-schema");
    addNamespace("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
    _edit = false;
}

/**
 * @brief ~VWorldModel
 * Destructeur
 */
VWorldModel::~VWorldModel()
{
    resetModel();
}
/**
 * @brief newWorldModel
 * Crée un nouveau modèle du monde
 */
void VWorldModel::newWorldModel(){
    resetModel();
    onModified(tr("New world model created"));
}
/**
 * @brief resetModel
 * Vide le model
 */
void VWorldModel::resetModel()
{
    _edit = true;
    _namespaceUri = "";
    setDomainNamespace("http://www.utc.fr/hds/ici/humans/domain");
    addNamespace("xmlns:owl", "http://www.w3.org/2002/07/owl");
    addNamespace("xmlns:rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns");
    addNamespace("xmlns:rdfs", "http://www.w3.org/2000/01/rdf-schema");
    addNamespace("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
    while(_components.count() > 0)
    {
        VWComponentClass * component = _components.first();
        _components.pop_front();
        delete component;
    }
    while(_actions.count() > 0)
    {
        VWActionClass * action = _actions.first();
        _actions.pop_front();
        delete action;
    }
    while(_behaviours.count() > 0)
    {
        VWBehaviourClass * behaviour = _behaviours.first();
        _behaviours.pop_front();
        delete behaviour;
    }
    while(_objects.count() > 0)
    {
        VWObjectClass * object = _objects.first();
        _objects.pop_front();
        delete object;
    }
    while(_events.count() > 0)
    {
        VWEventClass * event = _events.first();
        _events.pop_front();
        delete event;
    }
    _edit = false;
    onModified();
}

/**
 * @brief loadModel
 * Permet de charger un model
 * @param xmlModel Le modèle en xml
 */
void VWorldModel::loadModel(QString xmlModel)
{
    resetModel();
    QDomDocument *dom = new QDomDocument("mon_xml");
    if(!dom->setContent(xmlModel))
    {
        return; // Erreur
    }
    QDomElement domElement = dom->documentElement();
    parseDom(domElement);
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWorldModel::parseDom(QDomElement elem)
{
    _edit = true;
    VTraceController::get()->Info("VWorldModel::parseDom()", "<" + elem.tagName() + ">");

    setNamespace(elem.attribute("xmlns", ""), elem.attribute("xml:base", ""));
    setDomainNamespace(elem.attribute("xmlns:domain", "http://www.utc.fr/hds/ici/humans/domain#"));
    addNamespace("xmlns:owl", elem.attribute("xmlns:owl", "http://www.w3.org/2002/07/owl#"));
    addNamespace("xmlns:rdf", elem.attribute("xmlns:rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#"));
    addNamespace("xmlns:rdfs", elem.attribute("xmlns:rdfs", "http://www.w3.org/2000/01/rdf-schema#"));
    addNamespace("xmlns:xsd", elem.attribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema#"));

    QMap<QString, QDomElement> classesOneSupToHandle;
    QList<QDomElement> classesMultiSupToHandle;
    QMap<QString, QDomElement> instancesToHandle;
    QMap<QString, QString> componentState;

    // Première lecture -> Import all direct subClass of domain
    QDomNode node = elem.firstChild();
    while(!node.isNull())// Lecture des noeuds inférieurs
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString prefix = VWParser::getPrefix(element.tagName()).toLower();
            QString balise = VWParser::getBalise(element.tagName()).toLower();
            if(prefix == "owl")
            {
                if(balise == "class")
                {
                    QList<QString> domainSupClasses = VWParser::getDomainSupClasses(element);
                    if(domainSupClasses.count() > 0)
                    {
                        QString domainSupClass = domainSupClasses.first();
                        if(domainSupClass == "action")
                        {
                            addAction(element);
                        }
                        else if(domainSupClass == "punctualbehaviour" || domainSupClass == "durativebehaviour")
                        {
                            addBehaviour(element);
                        }
                        else if(domainSupClass == "punctualevent" || domainSupClass == "durativeevent" ||
                                domainSupClass == "endogenousevent" || domainSupClass == "exogenousevent")
                        {
                            addEvent(element);
                        }
                        else if(domainSupClass == "concreteobject" || domainSupClass == "abstractobject" || domainSupClass == "agent")
                        {
                            addObject(element);
                        }
                        else if(domainSupClass == "component")
                        {
                            addComponent(element);
                        }
                    }
                    else
                    {
                        QList<QString> supClasses = VWParser::getSupClasses(element);
                        if(supClasses.count() == 1)
                        {
                            classesOneSupToHandle.insert(
                                        VWParser::getName(element) + " - " + supClasses.first(),
                                        element);
                        }
                        else
                        {
                            classesMultiSupToHandle.append(element);
                        }
                    }
                }
                else if(balise == "objectproperty")
                {
                    QPair<QList<QString>, QString> domaineAndRange = VWParser::getDomaineAndRange(element);
                    QString domaine = domaineAndRange.first.isEmpty() ? "" : domaineAndRange.first.first();
                    QString range = domaineAndRange.second;
                    QList<QString> domainSupClasses = VWParser::getDomainSupClasses(element);
                    if(domainSupClasses.count() > 0)
                    {
                        QString domainSupClass = domainSupClasses.first();
                        if(domainSupClass == "has-state")
                        {
                            componentState.insert(range, domaine);
                        }
                    }
                }
            }
            else if(prefix.isEmpty() || prefix.isNull())
            {
                instancesToHandle.insert(
                            VWParser::getName(element) + " - " + VWParser::getBalise(element.tagName()),
                            element);
            }
        }
        node = node.nextSibling();
    }
    // Gère les classes avec 1 référence subClassOf
    if(classesOneSupToHandle.keys().count() != 0)
    {
        int i = 0;
        bool hasRemoveOne = false;
        while(classesOneSupToHandle.keys().count() != 0)
        {
            QString key = classesOneSupToHandle.keys()[i];
            QString toSearch = key.split(" - ").last();
            QDomElement element = classesOneSupToHandle.values()[i];
            VWComponentClass * componentClass = getComponentByName(toSearch);
            if(componentClass != NULL)
            {
                VWComponentClass * subComponentClass = new VWComponentClass();
                subComponentClass->ParseDom(element);
                componentClass->addChild(subComponentClass);
                classesOneSupToHandle.remove(key);
                hasRemoveOne = true;
            }
            else
            {
                VWObjectClass * objectClass = getObjectByName(toSearch);
                if(objectClass != NULL)
                {
                    VWObjectClass * subObjectClass = new VWObjectClass();
                    subObjectClass->ParseDom(element);
                    objectClass->addChild(subObjectClass);
                    classesOneSupToHandle.remove(key);
                    hasRemoveOne = true;
                }
                else
                {
                    i++;
                }
            }
            if(i == classesOneSupToHandle.keys().count())
            {
                if(hasRemoveOne == true) // Gère le rebouclage pour recommencer au début
                {
                    i = 0;
                    hasRemoveOne = false; // Réinitialise l'indicateur de modifications
                }
                else break;// jusqu'a avoir fait un tour complet sans modifications
            }
        }
    }
     // Les classes non traitées par la méthode précédente seront traitées comme des multiSup
    classesMultiSupToHandle.append(classesOneSupToHandle.values());
    // Gère les classes avec * référence subClassOf
    if(classesMultiSupToHandle.count() != 0)
    {
        int i = 0;
        bool hasRemoveOne = false;
        QDomElement element;
        while(classesMultiSupToHandle.count() != 0)
        {
            bool currentHasBeenRemoved = false;
            element = classesMultiSupToHandle[i];
            QList<QString> classesToHandle = VWParser::getSupClasses(element);
            foreach(QString toSearch, classesToHandle)
            {
                VWObjectClass * objectClass = getObjectByName(toSearch);
                if(objectClass != NULL)
                {
                    VWObjectClass * subObjectClass = new VWObjectClass();
                    subObjectClass->ParseDom(element);
                    objectClass->addChild(subObjectClass);
                    classesMultiSupToHandle.removeAll(element);
                    currentHasBeenRemoved = true;
                    break;
                }
            }
            if(currentHasBeenRemoved == false) i++;
            hasRemoveOne = hasRemoveOne || currentHasBeenRemoved;
            if(i == classesMultiSupToHandle.count())
            {
                if(hasRemoveOne == true) // Gère le rebouclage pour recommencer au début
                {
                    i = 0;
                    hasRemoveOne = false; // Réinitialise l'indicateur de modifications
                }
                else break;// jusqu'a avoir fait un tour complet sans modifications
            }
        }
    }
    // Gère les instances d'objets
    for(int i = 0; i < instancesToHandle.keys().count(); i++)
    {
        QDomElement element = instancesToHandle.values()[i];
        QString objectName = instancesToHandle.keys()[i].split(" - ").last();
        VWObjectClass * objectClass = getObjectByName(objectName);
        if(objectClass != NULL)
        {
            VWInstance * instance = new VWInstance();
            objectClass->addInstance(instance);
            instance->ParseDom(element);
        }
    }
    // Deuxième lecture -> Import all direct subClass of domain
    node = elem.firstChild();
    while(!node.isNull())// Lecture des noeuds inférieurs
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString prefix = VWParser::getPrefix(element.tagName()).toLower();
            QString balise = VWParser::getBalise(element.tagName()).toLower();
            if(prefix == "owl")
            {
                if(balise == "class")
                {
                    QList<QString> domainSupClasses = VWParser::getDomainSupClasses(element);
                    if(domainSupClasses.count() > 0)
                    {
                        QString domainSupClass = domainSupClasses.first();
                        if(domainSupClass == "action")
                        {
                            VWActionClass * action = getActionByName(VWParser::getName(element));
                            action->ParseComponentDom(element);
                        }
                        else if(domainSupClass == "punctualbehaviour" || domainSupClass == "durativebehaviour")
                        {
                            VWBehaviourClass * behaviour = getBehaviourByName(VWParser::getName(element));
                            behaviour->ParseComponentDom(element);
                        }
                        else if(domainSupClass == "punctualevent" || domainSupClass == "durativeevent" ||
                                domainSupClass == "endogenousevent" || domainSupClass == "exogenousevent")
                        {
                            VWEventClass * event = getEventByName(VWParser::getName(element));
                            event->ParseComponentDom(element);
                        }
                        else if(domainSupClass == "concreteobject" || domainSupClass == "abstractobject" || domainSupClass == "agent")
                        {
                            VWObjectClass * object = getObjectByName(VWParser::getName(element));
                            object->ParseComponentDom(element);
                        }
                    }
                }
                else if(balise == "objectproperty")
                {
                    QPair<QList<QString>, QString> domaineAndRange = VWParser::getDomaineAndRange(element);
                    QString domaine = domaineAndRange.first.isEmpty() ? "" : domaineAndRange.first.first();
                    QString range = domaineAndRange.second;
                    QList<QString> domainSupClasses = VWParser::getDomainSupClasses(element);
                    QList<QString> domainSupProperties = VWParser::getDomainSupProperties(element);
                    if(domainSupClasses.count() > 0)
                    {
                        QString domainSupClass = domainSupClasses.first();
                        if(domainSupClass == "stateattribute")
                        {
                            QString componentName = componentState.value(domaine);
                            VWComponentClass * component = getComponentByName(componentName);
                            if(component != NULL) component->addStateProperty(element);
                        }
                    }
                    else if(domainSupProperties.count() > 0)
                    {
                        QString domainSupProperty = domainSupProperties.first();
                        if(domainSupProperty == "action-target" && range != "Agent")
                        {
                            VWActionClass * action = getActionByName(domaine);
                            if(action != NULL)
                            {
                                bool flag = false;
                                QPointer<VWProperty> property = action->addProperty(element);
                                foreach(domaine, domaineAndRange.first)
                                {
                                    if(!flag) flag = true;
                                    else
                                    {
                                        action = getActionByName(domaine);
                                        action->getProperties()->addProperty(property);
                                    }
                                }
                            }
                        }
                        else if(domainSupProperty == "trigger-event")
                        {
                            VWBehaviourClass * behaviour = getBehaviourByName(domaine);
                            VWEventClass * event = getEventByName(range);
                            behaviour->addEvent(event);
                        }
                        else if(domainSupProperty == "activate-behaviour")
                        {
                            VWActionClass * action = getActionByName(domaine);
                            VWBehaviourClass * behaviour = getBehaviourByName(range);
                            action->addBehaviour(behaviour);
                        }
                        else if(domainSupProperty == "has-punctualbehaviour" || domainSupProperty == "has-durativebehaviour")
                        {
                            VWEventClass * event = getEventByName(domaine);
                            VWBehaviourClass * behaviour = getBehaviourByName(range);
                            event->addBehaviour(behaviour);
                        }
                        else if(domainSupProperty == "begin-with-event")
                        {
                            VWEventClass * event = getEventByName(domaine);
                            VWEventClass * beginEvent = getEventByName(range);
                            event->setBeginingEvent(beginEvent);
                        }
                        else if(domainSupProperty == "end-with-event")
                        {
                            VWEventClass * event = getEventByName(domaine);
                            VWEventClass * endEvent = getEventByName(range);
                            event->setEndingEvent(endEvent);
                        }
                    }
                    else
                    {
                        VWComponentClass * component = getComponentByName(domaine);
                        VWObjectClass * object = getObjectByName(domaine);
                        VWEventClass * event = getEventByName(domaine);
                        VWBehaviourClass * behaviour = getBehaviourByName(domaine);
                        if(component != NULL)
                        {
                            bool flag = false;
                            QPointer<VWProperty> property = component->addProperty(element);
                            foreach(domaine, domaineAndRange.first)
                            {
                                if(!flag) flag = true;
                                else
                                {
                                    component = getComponentByName(domaine);
                                    component->getProperties()->addProperty(property);
                                }
                            }
                        }
                        else if(object != NULL)
                        {
                            bool flag = false;
                            QPointer<VWProperty> property = object->addProperty(element);
                            foreach(domaine, domaineAndRange.first)
                            {
                                if(!flag) flag = true;
                                else
                                {
                                    object = getObjectByName(domaine);
                                    object->getProperties()->addProperty(property);
                                }
                            }
                        }
                        else if(event != NULL)
                        {
                            bool flag = false;
                            QPointer<VWProperty> property = event->addProperty(element);
                            foreach(domaine, domaineAndRange.first)
                            {
                                if(!flag) flag = true;
                                else
                                {
                                    event = getEventByName(domaine);
                                    event->getProperties()->addProperty(property);
                                }
                            }
                        }
                        else if(behaviour != NULL)
                        {
                            bool flag = false;
                            QPointer<VWProperty> property = behaviour->addProperty(element);
                            foreach(domaine, domaineAndRange.first)
                            {
                                if(!flag) flag = true;
                                else
                                {
                                    behaviour = getBehaviourByName(domaine);
                                    behaviour->getProperties()->addProperty(property);
                                }
                            }
                        }
                    }
                }
            }
        }
        node = node.nextSibling();
    }
    // Gère les propriétés d'instances d'objets
    for(int i = 0; i < instancesToHandle.keys().count(); i++)
    {
        QDomElement element = instancesToHandle.values()[i];
        QString instanceName = instancesToHandle.keys()[i].split(" - ").first();
        VWInstance * instance = getInstanceByName(instanceName);
        if(instance != NULL)
        {
            instance->ParsePropertyValues(element);
        }
    }
    _edit = false;
    VTraceController::get()->Info("VWorldModel::parseDom()", "</" + elem.tagName() + ">");
}

/**
 * @brief ToXml
 * Export en xml
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWorldModel::ToXml()
{
    return ToXml(NULL);
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWorldModel::ToXml(QString tabulation)
{
    // propertyMap : list of Keys and list of properties
    QMap<VWorldModelElement *, QList<VWProperty *> > propertyMap;

    QString RetVal = tabulation + "<rdf:RDF \n";
    RetVal += tabulation + "\t" + "xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\n";
    RetVal += tabulation + "\t" + "xmlns:owl=\"http://www.w3.org/2002/07/owl#\"\n";
    RetVal += tabulation + "\t" + "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema#\"\n";
    RetVal += tabulation + "\t" + "xmlns:rdfs=\"http://www.w3.org/2000/01/rdf-schema#\"\n";
    RetVal += tabulation + "\t" + "xmlns:domain=\"" + _domainNamespaceUri + "#\"\n";
    RetVal += tabulation + "\t" + "xmlns=\"" + _namespaceUri + "#\"\n";
    RetVal += tabulation + "\t" + "xml:base=\"" + _namespaceUri + "\">\n";

    RetVal += tabulation + "\t" + "<owl:Ontology rdf:about=\"\">\n";
    RetVal += tabulation + "\t\t" + "<owl:imports rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain\"/>\n";
    RetVal += tabulation + "\t" + "</owl:Ontology>\n";

    foreach(VWComponentClass * component, getAllComponents())
    {
        RetVal += component->ToXml(tabulation + "\t");
    }

    foreach(VWActionClass * action, _actions)
    {
        RetVal += action->ToXml(tabulation + "\t");
    }

    foreach(VWBehaviourClass * behaviour, _behaviours)
    {
        RetVal += behaviour->ToXml(tabulation + "\t");
    }

    foreach(VWEventClass * event, _events)
    {
        RetVal += event->ToXml(tabulation + "\t");
    }
    foreach(VWObjectClass * object, getAllObjects())
    {
        RetVal += object->ToXml(tabulation + "\t");
    }

    foreach(VWInstance * instance, getAllInstances())
    {
        RetVal += instance->ToXml(tabulation + "\t");
    }


    RetVal += tabulation + "\t" + "<owl:ObjectProperty rdf:ID=\"agent\">\n";
    RetVal += tabulation + "\t\t" + "<rdfs:domain>\n";
    RetVal += tabulation + "\t\t\t" + "<owl:Class>\n";
    RetVal += tabulation + "\t\t\t\t" + "<owl:unionOf rdf:parseType=\"Collection\">\n";

    foreach(VWActionClass * action, _actions)
    {
        RetVal += tabulation + "\t\t\t\t\t" + "<owl:Class rdf:about=\"#" + action->getName() + "\"/>\n";
    }

    foreach(VWBehaviourClass * behaviour, _behaviours)
    {
        RetVal += tabulation + "\t\t\t\t\t" + "<owl:Class rdf:about=\"#" + behaviour->getName() + "\"/>\n";
    }

    RetVal += tabulation + "\t\t\t\t" + "</owl:unionOf>\n";
    RetVal += tabulation + "\t\t\t" + "</owl:Class>\n";
    RetVal += tabulation + "\t\t" + "</rdfs:domain>\n";
    RetVal += tabulation + "\t\t" + "<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#action-target\"/>\n";
    RetVal += tabulation + "\t\t" + "<rdfs:range rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#Agent\"/>\n";
    RetVal += tabulation + "\t" + "</owl:ObjectProperty>\n";

    foreach(VWProperty * property, VWProperty::getSharedProperties())
    {
        RetVal += property->ToXml(tabulation + "\t");
    }

    RetVal += tabulation + "</rdf:RDF>\n";
    return RetVal;
}

/**
 * @brief executeQuery
 * Execute une requète SPARQL dans JENA
 * @param query La requète
 * @return Le résultat de la requète
 */
QString VWorldModel::executeQuery(QString query)
{
    // Mettre à jour JENA d'après le model
    QString fileName = "tmp.owl";
    VApplicationController::getInstance()->exportWorldModel(fileName);
    bool error = VOntologyInterface::getInstance()->loadOntology(fileName);
    if(error) return tr("Error : Model invalid");

    // Executer la requète dans JENA
    QString result = VOntologyInterface::getInstance()->executeQuery(query);

    // Retourne le résultat de la requète
    return result;
}

void VWorldModel::setNamespace(QString ns)
{
    setNamespace(ns, NULL);
}

void VWorldModel::setNamespace(QString ns, QString otherNs)
{
    if(ns.isNull() || ns.isEmpty())
    {
        if(otherNs.isNull() || otherNs.isEmpty()) return;
        else setNamespace(otherNs);
    }
    ns = ns.replace("#", "");
    if(ns != _namespaceUri)
    {
        _namespaceUri = ns;
        onModified(tr("Namespace changed"));
    }
}
QString VWorldModel::getNamespace() const
{
    return _namespaceUri;
}
void VWorldModel::setDomainNamespace(QString ns)
{
    ns = ns.replace("#", "");
    if(ns != _domainNamespaceUri)
    {
        _domainNamespaceUri = ns;
        onModified(NULL);
    }
}
QString VWorldModel::getDomainNamespace() const
{
    return _domainNamespaceUri;
}
void VWorldModel::addNamespace(QString prefix, QString ns)
{
    if(prefix.isNull() || prefix.isEmpty()) return;
    ns = ns.replace("#", "");
    if(!prefix.isNull() && !prefix.isEmpty() && !ns.isNull() && !ns.isEmpty())
    {
        _otherNamespacesUri.insert(prefix, ns);
        onModified(NULL);
    }

}
void VWorldModel::removeNamespace(QString prefix)
{
    if(prefix.isNull() || prefix.isEmpty()) return;
    if(_otherNamespacesUri.contains(prefix))
    {
        _otherNamespacesUri.remove(prefix);
        onModified(NULL);
    }
}
QString VWorldModel::getNamespace(QString prefix) const
{
    return _otherNamespacesUri.value(prefix);
}
QMap<QString, QString> VWorldModel::getNamespaces() const
{
    return _otherNamespacesUri;
}

void VWorldModel::addComponent(VWComponentClass * component)
{
    if(component != NULL)
    {
        _components.append(component);
        connect(component, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Component added"));
    }
}

void VWorldModel::addComponent(QDomElement elem)
{
    VWComponentClass * component = new VWComponentClass();
    component->ParseDom(elem);
    addComponent(component);
}

void VWorldModel::removeComponent(VWComponentClass * component)
{
    if(_components.contains(component))
    {
        _components.removeAll(component);
        disconnect(component, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Component removed"));
    }
}

QList<VWComponentClass *> VWorldModel::getComponents() const
{
    return _components;
}

QList<VWComponentClass *> VWorldModel::getAllComponents() const
{
    VWComponentClass * component;
    QList<VWComponentClass *> RetVal;
    RetVal.append(getComponents());
    foreach(component, _components)
    {
        RetVal.append(component->getAllChilds());
    }
    return RetVal;
}

VWComponentClass * VWorldModel::getComponentByUid(qint64 uid) const
{
    VWComponentClass * component;
    foreach(component, _components)
    {
        if(component->getUid() == uid) return component;
        else
        {
            VWComponentClass * child = component->getChildByUid(uid);
            if(child != NULL) return child;
        }
    }
    return NULL;
}

VWComponentClass * VWorldModel::getComponentByName(QString name) const
{
    VWComponentClass * component;
    foreach(component, _components)
    {
        if(component->getName() == name) return component;
        else
        {
            VWComponentClass * child = component->getChildByName(name);
            if(child != NULL) return child;
        }
    }
    return NULL;
}


void VWorldModel::addAction(VWActionClass * action)
{
    if(action != NULL)
    {
        _actions.append(action);
        connect(action, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Action added"));
    }
}

void VWorldModel::addAction(QDomElement elem)
{
    VWActionClass * action = new VWActionClass();
    action->ParseDom(elem);
    addAction(action);
}

void VWorldModel::removeAction(VWActionClass * action)
{
    if(_actions.contains(action))
    {
        _actions.removeAll(action);
        disconnect(action, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Action removed"));
    }
}

QList<VWActionClass *> VWorldModel::getActions() const
{
    return _actions;
}

VWActionClass * VWorldModel::getActionByUid(qint64 uid) const
{
    VWActionClass * action;
    foreach(action, _actions)
    {
        if(action->getUid() == uid) return action;
    }
    return NULL;
}

VWActionClass * VWorldModel::getActionByName(QString name) const
{
    VWActionClass * action;
    foreach(action, _actions)
    {
        if(action->getName() == name) return action;
    }
    return NULL;
}


void VWorldModel::addBehaviour(VWBehaviourClass * behaviour)
{
    if(behaviour != NULL)
    {
        _behaviours.append(behaviour);
        connect(behaviour, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Behaviour added"));
    }
}

void VWorldModel::addBehaviour(QDomElement elem)
{
    VWBehaviourClass * behaviour = new VWBehaviourClass();
    behaviour->ParseDom(elem);
    addBehaviour(behaviour);
}

void VWorldModel::removeBehaviour(VWBehaviourClass * behaviour)
{
    if(_behaviours.contains(behaviour))
    {
        _behaviours.removeAll(behaviour);
        disconnect(behaviour, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Behaviour removed"));
    }
}

QList<VWBehaviourClass *> VWorldModel::getBehaviours() const
{
    return _behaviours;
}

VWBehaviourClass * VWorldModel::getBehaviourByUid(qint64 uid) const
{
    VWBehaviourClass * behaviour;
    foreach(behaviour, _behaviours)
    {
        if(behaviour->getUid() == uid) return behaviour;
    }
    return NULL;
}

VWBehaviourClass * VWorldModel::getBehaviourByName(QString name) const
{
    VWBehaviourClass * behaviour;
    foreach(behaviour, _behaviours)
    {
        if(behaviour->getName() == name) return behaviour;
    }
    return NULL;
}


void VWorldModel::addObject(VWObjectClass * object)
{
    if(object != NULL)
    {
        _objects.append(object);
        connect(object, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Object added"));
    }
}

void VWorldModel::addObject(QDomElement elem)
{
    VWObjectClass * object = new VWObjectClass();
    object->ParseDom(elem);
    addObject(object);
}

void VWorldModel::removeObject(VWObjectClass * object)
{
    if(_objects.contains(object))
    {
        _objects.removeAll(object);
        disconnect(object, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Object removed"));
    }
}

QList<VWObjectClass *> VWorldModel::getObjects() const
{
    return _objects;
}

QList<VWObjectClass *> VWorldModel::getAllObjects() const
{
    VWObjectClass * object;
    QList<VWObjectClass *> RetVal;
    RetVal.append(getObjects());
    foreach(object, _objects)
    {
        RetVal.append(object->getAllChilds());
    }
    return RetVal;
}

QList<VWObjectClass *> VWorldModel::getAllObjects(VWComponentClass * component) const
{
    QList<VWObjectClass *> RetVal;
    foreach(VWObjectClass * object, _objects)
    {
        if(object->getComponents().contains(component))
        {
            RetVal.append(object);
        }
        QList<VWObjectClass *> childs = object->getAllChilds(component);
        if(childs.count() > 0) RetVal.append(childs);
    }
    return RetVal;
}

VWObjectClass * VWorldModel::getObjectByUid(qint64 uid) const
{
    foreach(VWObjectClass * object, _objects)
    {
        if(object->getUid() == uid) return object;
        else
        {
            VWObjectClass * child = object->getChildByUid(uid);
            if(child != NULL) return child;
        }
    }
    return NULL;
}

VWObjectClass * VWorldModel::getObjectByName(QString name) const
{
    foreach(VWObjectClass * object, _objects)
    {
        if(object->getName() == name) return object;
        else
        {
            VWObjectClass * child = object->getChildByName(name);
            if(child != NULL) return child;
        }
    }
    return NULL;
}

QList<VWInstance *> VWorldModel::getAllInstances() const
{
    QList<VWInstance *> RetVal;
    foreach(VWObjectClass * object, _objects)
    {
        QList<VWInstance *> instances = object->getAllInstances();
        if(instances.count() != 0) RetVal.append(instances);
    }
    return RetVal;
}

VWInstance * VWorldModel::getInstanceByUid(qint64 uid) const
{
    foreach(VWObjectClass * object, _objects)
    {
        VWInstance * instance = object->getAllInstanceByUid(uid);
        if(instance != NULL) return instance;
    }
    return NULL;
}

VWInstance * VWorldModel::getInstanceByName(QString name) const
{
    foreach(VWObjectClass * object, _objects)
    {
        VWInstance * instance = object->getAllInstanceByName(name);
        if(instance != NULL) return instance;
    }
    return NULL;
}

void VWorldModel::addEvent(VWEventClass * event)
{
    if(event != NULL)
    {
        _events.append(event);
        connect(event, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Event added"));
    }
}

void VWorldModel::addEvent(QDomElement elem)
{
    VWEventClass * event = new VWEventClass();
    event->ParseDom(elem);
    addEvent(event);
}

void VWorldModel::removeEvent(VWEventClass * event)
{
    if(event != NULL)
    {
        _events.removeAll(event);
        disconnect(event, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Event removed"));
    }
}

QList<VWEventClass *> VWorldModel::getEvents() const
{
    return _events;
}

VWEventClass * VWorldModel::getEventByUid(qint64 uid) const
{
    VWEventClass * event;
    foreach(event, _events)
    {
        if(event->getUid() == uid) return event;
    }
    return NULL;
}

VWEventClass * VWorldModel::getEventByName(QString name) const
{
    VWEventClass * event;
    foreach(event, _events)
    {
        if(event->getName() == name) return event;
    }
    return NULL;
}

void VWorldModel::onModified()
{
    onModified(NULL);
}

void VWorldModel::onModified(QString message, QObject *object)
{
    if(!_edit && message != NULL)
    {
        VApplicationController * appCtrler = VApplicationController::getInstance();
        if(appCtrler == NULL) return;
        VWorldController * worldCtrler = appCtrler->getWorldController();
        if(worldCtrler == NULL) return;
        VHistorySet * historySet = worldCtrler->getWorldHistorySet();
        if(historySet == NULL) return;
        QString label = "";
        VWorldModelElement * elem = (object != NULL) ? qobject_cast<VWorldModelElement *>(object) : this;
        if(elem != NULL) label = elem->getName();
        historySet->push_back(label, message, ToXml());
    }
    VWorldModelElement::onModified(message, object);
}
