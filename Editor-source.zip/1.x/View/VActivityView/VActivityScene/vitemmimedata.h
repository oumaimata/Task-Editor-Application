#pragma once
#ifndef VITEMMIMEDATA_H
#define VITEMMIMEDATA_H

#include <QMimeData>
#include <QGraphicsItem>

/**
 * @brief The VItemMimeData class
 */
class VItemMimeData : public QMimeData
{
    Q_OBJECT

private:
    QGraphicsItem* _item;

public:

    /*!
     * \brief VItemMimeData::VItemMimeData
     * Constructeur
     */
    explicit VItemMimeData();

    /*!
     * \brief VItemMimeData::hasItem
     * Return if the VItemMimeData has an item
     * \return true if has an item; false else
     */
    bool hasItem() const;

    /*!
     * \brief VItemMimeData::getItem
     * Obtient Item
     * \return Item de type QGraphicsItem
     */
    QGraphicsItem* getItem() const;

    /*!
     * \brief VItemMimeData::setItem
     * Définie Item
     * \param item La nouvelle valeur d'Item
     */
    void setItem(QGraphicsItem* item);
};

#endif // VITEMMIMEDATA_H
