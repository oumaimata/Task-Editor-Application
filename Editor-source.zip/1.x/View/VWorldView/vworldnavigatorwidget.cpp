#include "vworldnavigatorwidget.h"
#include "ui_vworldnavigatorwidget.h"


#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwactionclass.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"
#include "Model/VWorld/VWorldClass/vweventclass.h"
#include "Model/VWorld/VWorldClass/vwbehaviourclass.h"

VWorldNavigatorWidget::VWorldNavigatorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWorldNavigatorWidget),
    _edit(false)
{
    ui->setupUi(this);
}

VWorldNavigatorWidget::~VWorldNavigatorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWorldNavigatorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWorldNavigatorWidget::setWorldModel(VWorldModel * worldModel)
{
    if(worldModel != _worldModel)
    {
        _worldModel = worldModel;
    }
    updateDisplay();
}

void VWorldNavigatorWidget::setCurrentEdit(VWorldModelElement * currentEdit)
{
    if(currentEdit != NULL) _currentEdit = currentEdit;
    updateDisplay();
}

void VWorldNavigatorWidget::updateDisplay()
{
    _edit = true;
    ui->navigatorTreeWidget->clear();

    QTreeWidgetItem * actionsItem = new QTreeWidgetItem(ui->navigatorTreeWidget);
    actionsItem->setText(0, "Actions");
    actionsItem->setExpanded(true);
    ui->navigatorTreeWidget->addTopLevelItem(actionsItem);

    QTreeWidgetItem * behavioursItem = new QTreeWidgetItem(ui->navigatorTreeWidget);
    behavioursItem->setText(0, "Behaviours");
    behavioursItem->setExpanded(true);
    ui->navigatorTreeWidget->addTopLevelItem(behavioursItem);

    QTreeWidgetItem * eventsItem = new QTreeWidgetItem(ui->navigatorTreeWidget);
    eventsItem->setText(0, "Events");
    eventsItem->setExpanded(true);
    ui->navigatorTreeWidget->addTopLevelItem(eventsItem);

    QTreeWidgetItem * objectsItem = new QTreeWidgetItem(ui->navigatorTreeWidget);
    objectsItem->setText(0, "Objects");
    objectsItem->setExpanded(true);
    ui->navigatorTreeWidget->addTopLevelItem(objectsItem);

    if(_worldModel == NULL) return;

    VWActionClass * action;
    QList<VWActionClass *> actions = _worldModel->getActions();
    foreach(action, actions)
    {
        QTreeWidgetItem * item = new QTreeWidgetItem(actionsItem);
        item->setText(0, action->getName());
        item->setData(0, Qt::UserRole, action->getUid());
        actionsItem->addChild(item);
        item->setSelected(action == _currentEdit);
    }

    VWBehaviourClass * behaviour;
    QList<VWBehaviourClass *> behaviours = _worldModel->getBehaviours();
    foreach(behaviour, behaviours)
    {
        QTreeWidgetItem * item = new QTreeWidgetItem(behavioursItem);
        item->setText(0, behaviour->getName());
        item->setData(0, Qt::UserRole, behaviour->getUid());
        behavioursItem->addChild(item);
        item->setSelected(behaviour == _currentEdit);
    }

    VWEventClass * event;
    QList<VWEventClass *> events = _worldModel->getEvents();
    foreach(event, events)
    {
        QTreeWidgetItem * item = new QTreeWidgetItem(eventsItem);
        item->setText(0, event->getName());
        item->setData(0, Qt::UserRole, event->getUid());
        eventsItem->addChild(item);
        item->setSelected(event == _currentEdit);
    }

    VWObjectClass * object;
    QList<VWObjectClass *> objects = _worldModel->getObjects();
    foreach(object, objects)
    {
        createObjectItem(objectsItem, object);
    }
    _edit = false;
}

QTreeWidgetItem *  VWorldNavigatorWidget::createObjectItem(QTreeWidgetItem * parentItem, VWObjectClass * object)
{
    int nbInstance =object->getInstances().count();
    QTreeWidgetItem * item = new QTreeWidgetItem(parentItem);
    if(nbInstance != 0) item->setText(0, object->getName() + " (" + QString::number(nbInstance) + ")");
    else item->setText(0, object->getName());
    item->setExpanded(true);
    item->setData(0, Qt::UserRole, object->getUid());
    parentItem->addChild(item);
    item->setSelected(object == _currentEdit);

    VWObjectClass * child;
    QList<VWObjectClass *> childs = object->getChilds();
    foreach(child, childs)
    {
        createObjectItem(item, child);
    }
    return item;
}

void VWorldNavigatorWidget::on_addButton_clicked()
{
    if(_worldModel == NULL || _edit || ui->navigatorTreeWidget->selectedItems().count() == 0) return;
    QTreeWidgetItem * selectedItem = ui->navigatorTreeWidget->selectedItems().first();
    QString selectedText = selectedItem->text(0);
    QString uid = selectedItem->data(0, Qt::UserRole).toString();

    VWActionClass * action = _worldModel->getActionByUid(uid.toLong());
    if(action != NULL || selectedText == "Actions")
    {
        // ajoute une action
        action = new VWActionClass(_worldModel);
        _currentEdit = action;
        _worldModel->addAction(action);
        return;
    }
    VWBehaviourClass * behaviour = _worldModel->getBehaviourByUid(uid.toLong());
    if(behaviour != NULL || selectedText == "Behaviours")
    {
        // ajoute un behaviour
        behaviour = new VWBehaviourClass(_worldModel);
        _currentEdit = behaviour;
        _worldModel->addBehaviour(behaviour);
        return;
    }
    VWEventClass * event = _worldModel->getEventByUid(uid.toLong());
    if(event != NULL || selectedText == "Events")
    {
        // ajoute un event
        event = new VWEventClass(_worldModel);
        _currentEdit = event;
        _worldModel->addEvent(event);
        return;
    }
    VWObjectClass * object = _worldModel->getObjectByUid(uid.toLong());
    if(selectedText == "Objects")
    {
        // ajoute un object
        object = new VWObjectClass(_worldModel);
        _currentEdit = object;
        _worldModel->addObject(object);
        return;
    }
    else if(object != NULL)
    {
        // ajoute un object à l'object sélectionné
        VWObjectClass * newObject = new VWObjectClass(object);
        _currentEdit = newObject;
        object->addChild(newObject);
        return;
    }
}

void VWorldNavigatorWidget::on_removeButton_clicked()
{
    if(_worldModel == NULL || _edit || ui->navigatorTreeWidget->selectedItems().count() == 0) return;
    QTreeWidgetItem * selectedItem = ui->navigatorTreeWidget->selectedItems().first();
    QString uid = selectedItem->data(0, Qt::UserRole).toString();

    VWActionClass * action = _worldModel->getActionByUid(uid.toLong());
    if(action != NULL)
    {
        // supprime une action
        _worldModel->removeAction(action);
        emit removeAsked(action);
        delete action;
        emit removeAsked();
        return;
    }
    VWBehaviourClass * behaviour = _worldModel->getBehaviourByUid(uid.toLong());
    if(behaviour != NULL)
    {
        // supprime un behaviour
        _worldModel->removeBehaviour(behaviour);
        emit removeAsked(behaviour);
        delete behaviour;
        emit removeAsked();
        return;
    }
    VWEventClass * event = _worldModel->getEventByUid(uid.toLong());
    if(event != NULL)
    {
        // supprime un event
        _worldModel->removeEvent(event);
        emit removeAsked(event);
        delete event;
        emit removeAsked();
        return;
    }
    VWObjectClass * object = _worldModel->getObjectByUid(uid.toLong());
    if(object != NULL)
    {
        VWObjectClass * parentObject = object->getParent();
        if(parentObject == NULL)
        {
            // supprime un object
            _worldModel->removeObject(object);
        }
        else
        {
            // supprime un object
            _currentEdit = parentObject;
            parentObject->removeChild(object);
        }
        emit removeAsked(object);
        delete object;
        emit removeAsked();
        return;
    }
}

void VWorldNavigatorWidget::on_navigatorTreeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column)
{
    if(_worldModel == NULL || _edit || column != 0) return;
    QString uid = item->data(0, Qt::UserRole).toString();

    VWActionClass * action = _worldModel->getActionByUid(uid.toLong());
    if(action != NULL)
    {
        emit editActionAsked(action);
        return;
    }
    VWBehaviourClass * behaviour = _worldModel->getBehaviourByUid(uid.toLong());
    if(behaviour != NULL)
    {
        emit editBehaviourAsked(behaviour);
        return;
    }
    VWEventClass * event = _worldModel->getEventByUid(uid.toLong());
    if(event != NULL)
    {
        emit editEventAsked(event);
        return;
    }
    VWObjectClass * object = _worldModel->getObjectByUid(uid.toLong());
    if(object != NULL)
    {
        emit editObjectAsked(object);
        return;
    }
}
