#include "vjenabridge.h"

#include <exception>
#include <stdexcept>

/**
 * @brief VJenaBridge
 * Constructeur :
 *  - Charge la JVM
 *  - Récupère la classe JenaBridge
 *  - Crée une instance de JenaBridge
 *  - Récupère les méthodes nécessaires
 * @param parent L'object parent
 * @throws std::runtime_error
 */
VJenaBridge::VJenaBridge(QObject* parent):
    QObject(parent),
    _hasOntologyLoaded(false)
{
    JavaVMInitArgs vm_args;

    /*
     * Configuring JVM options
     */
    JavaVMOption options[3];

    // Disable JIT
    options[0].optionString = "-Djava.compiler=NONE";
    // User classes
    options[1].optionString = "-Djava.class.path=../EDITOR/Java/;"
            "../EDITOR/Java/lib/aterm-java-1.6.jar;"
            "../EDITOR/Java/lib/pellet-cli.jar;"
            "../EDITOR/Java/lib/pellet-core.jar;"
            "../EDITOR/Java/lib/pellet-datatypes.jar;"
            "../EDITOR/Java/lib/pellet-dig.jar;"
            "../EDITOR/Java/lib/pellet-el.jar;"
            "../EDITOR/Java/lib/pellet-explanation.jar;"
            "../EDITOR/Java/lib/pellet-jena.jar;"
            "../EDITOR/Java/lib/pellet-modularity.jar;"
            "../EDITOR/Java/lib/pellet-owlapi.jar;"
            "../EDITOR/Java/lib/pellet-owlapiv3.jar;"
            "../EDITOR/Java/lib/pellet-pellint.jar;"
            "../EDITOR/Java/lib/pellet-query.jar;"
            "../EDITOR/Java/lib/pellet-rules.jar;"
            "../EDITOR/Java/lib/pellet-test.jar;"
            "../EDITOR/Java/lib/servlet.jar";
    // Print JNI-related messages (-verbose:jni)
    options[2].optionString = "";

    vm_args.version = JNI_VERSION_1_6;
    vm_args.nOptions = 3;
    vm_args.options = options;

    /*
     * Launching JVM
     */
    if (JNI_CreateJavaVM(&_JVM, (void**) &_JNIenv, &vm_args) != JNI_OK)
        throw std::runtime_error("JVM launch failure.");

    /*
     * Looking for the JavaClass in environment
     */
    _javaClass = _JNIenv->FindClass("JenaBridge");
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }
    if (_javaClass == NULL)
        throw std::runtime_error("Java class was not found.");

    /*
     * Looking for the constructor of the class
     */
    jmethodID constructorID = _JNIenv->GetMethodID(_javaClass, "<init>", "()V");
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }
    if (constructorID == NULL)
        throw std::runtime_error("Java class constructor was not found.");

    /*
     * Creating instance of the class
     */
    _javaObject = _JNIenv->NewObject(_javaClass, constructorID);
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }
    if (_javaObject == NULL)
        throw std::runtime_error("Instance of the Java class was not created.");

    /*
     * Getting methods of the class
     */
    _selectMethodID = _JNIenv->GetMethodID(_javaClass, "runSelectQuery", "(Ljava/lang/String;)Ljava/lang/String;");
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }
    if (_selectMethodID == NULL)
        throw std::runtime_error("Java class method runSelectQuery was not found.");

    _askMethodID = _JNIenv->GetMethodID(_javaClass, "runAskQuery", "(Ljava/lang/String;)Z");
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }
    if (_askMethodID==NULL)
        throw std::runtime_error("Java class method runAskQuery was not found.");

    _loadMethodID = _JNIenv->GetMethodID(_javaClass, "loadOntology", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }
    if (_loadMethodID == NULL)
        throw std::runtime_error("Java class method loadOntology was not found.");

    _prefixMethodID = _JNIenv->GetMethodID(_javaClass, "getPrefix", "()Ljava/lang/String;");
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }
    if (_prefixMethodID == NULL)
        throw std::runtime_error("Java class method getPrefix was not found.");
}

/**
 * @brief ~VJenaBridge
 * Destructeur : Destruction de la JVM.
 */
VJenaBridge::~VJenaBridge()
{
    _JVM->DestroyJavaVM();
}

/**
 * @brief hasOntologyLoaded
 * Obtient si une ontologie a été chargée.
 * @return Si une ontologie a été chargée.
 */
bool VJenaBridge::hasOntologyLoaded() const
{
    return _hasOntologyLoaded;
}

/**
 * @brief setPrefix
 * Définit le préfix
 * @param prefix Le nouveau préfix
 */
void VJenaBridge::setPrefix(QString prefix)
{
    _prefix = prefix;
}

/**
 * @brief getPrefix
 * Obtient le préfix
 * @return  Le préfix
 */
QString VJenaBridge::getPrefix() const
{
    return _prefix;
}

/**
 * @brief selectQuery
 * Appelle la méthode runSelectQuery
 * @param query La requète
 * @return Le résultat de la requête
 */
const char* VJenaBridge::selectQuery(QString query)
{
    jboolean isCopy;

    // Converti un QString en jstring
    jstring jStr = _JNIenv->NewStringUTF(query.toStdString().c_str());
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }

    // Appelle ma méthode runSelectQuery
    jstring jRes = (jstring) _JNIenv->CallObjectMethod(_javaObject, _selectMethodID, jStr);
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }

    if (jRes != NULL)
        return _JNIenv->GetStringUTFChars(jRes, &isCopy);
    else
        return NULL;
}

/**
 * @brief askQuery
 * Appelle la méthode runAskQuery
 * @param query La requête
 * @return Le résultat de la requête (Vrai / Faux)
 */
bool VJenaBridge::askQuery(QString query)
{
    // Converti un QString en jstring
    jstring jstringQuery = _JNIenv->NewStringUTF(query.toStdString().c_str());
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }

    // Appelle ma méthode runAskQuery
    jboolean jRes = _JNIenv->CallBooleanMethod(_javaObject, _askMethodID, jstringQuery);
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
    }

    return jRes != JNI_FALSE;
}

/**
 * @brief loadOntology
 * Appelle la méthode loadOntology pour charger l'ontologie
 * @param path Le chemin vers le fichier
 * @param prefix Le préfixe
 * @param type Le type de fichier
 * @return Si erreur
 * @throws std::runtime_error
 * @see VOntologyInterface::loadOntology
 */
bool VJenaBridge::loadOntology(QString path, QString prefix, QString type)
{
    bool RetVal = false;
    jboolean isCopy;
    _hasOntologyLoaded = false;

    // Converti path en jstring
    jstring jstringPath = _JNIenv->NewStringUTF(path.toStdString().c_str());
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
        RetVal = true;
    }

    // Converti prefix en jstring
    jstring jstringPrefix= _JNIenv->NewStringUTF(prefix.toStdString().c_str());
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
        RetVal = true;
    }

    // Converti type en jstring
    jstring jstringType = _JNIenv->NewStringUTF(type.toStdString().c_str());
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
        RetVal = true;
    }

    // Loading ontology
    _JNIenv->CallVoidMethod(_javaObject, _loadMethodID, jstringPath, jstringPrefix, jstringType);
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
        RetVal = true;
    }

    // Getting prefix
    jstring res = (jstring) _JNIenv->CallObjectMethod(_javaObject, _prefixMethodID);
    if (_JNIenv->ExceptionOccurred())
    {
        _JNIenv->ExceptionDescribe();
        _JNIenv->ExceptionClear();
        RetVal = true;
    }
    if (res == NULL) throw std::runtime_error("Could not load ontology prefix.");

    _prefix = _JNIenv->GetStringUTFChars(res, &isCopy);
    _hasOntologyLoaded = true;
    return RetVal;
}
