#include "vapplication.h"


#include "Controller/vtracecontroller.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"
#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivitySpeechAct/VAddressee/vaddressee.h"

#include "Model/VActivity/VActivitySpeechAct/vspeechact.h"

#include <iostream>

int main(int argc, char *argv[])
{
    if(true){
        VApplication app(argc, argv);
        return app.exec();
    }



    std::cout<< "cette partie est accessible si TEST = false " << std::endl;

//    VAddressee addressee;
//    VWInstance * instance = new VWInstance();
//    VWObjectClass* cclass = new VWObjectClass();
//    cclass->setType("Agent");
//    instance->setClass(cclass);

//    instance->setName("Jack");
//    addressee.addAgent(instance);

//    VTraceController::get()->Debug("main", addressee.getAgents().at(0)->getName());
//    instance->setName("No More Jack");


//    VTraceController::get()->Debug("main", addressee.getAgents().at(0)->getName());



       //std::cout<< "cette partie est accessible si TEST = false " << std::endl;

       QXmlStreamReader reader;
       QString fileName = "SpeechAct_v2.xml";
       QFile file(fileName);
       file.open(QFile::ReadOnly | QFile::Text);
       reader.setDevice(&file);
       QList<VSpeechAct*> listSA;
       QString perf;
       VSpeechActContent* content = new VSpeechActContent();
       VSpeechAct* SA = NULL;
       //QString my_xml = "";

       reader.readNext();
       int id = 0;
       while (!reader.atEnd())
       {
           reader.readNext();
           if (reader.isStartElement())
           {
               VSubject subject;
               if (reader.name() == "label")
               {
                   reader.readNext();
                   //std::cout << qPrintable(reader.text().toString()); //affiche le nom du performatif
                   //std::cout << std::endl;
                   perf = (reader.text().toString());

                   subject.setPerformative(&perf);

               }/*
               if (reader.name() == "Performative")
               {
                   std::cout << "Performative : ";
               }
               if (reader.name() == "SpeechAct")
               {
                   std::cout << qPrintable(reader.name().toString());
                   std::cout << " " << id << " :" << std::endl;
               }
               if (reader.name() == "ContentTypes")
               {
                   std::cout << "ContentType : ";
               }*/
               if (reader.name() == "ContentType")
               {

                   reader.readNext();
                   //std::cout << qPrintable(reader.text().toString()) << ", ";
                   content->setType(VSpeechActContentTypeFromString(reader.text().toString()));
                   SA = new VSpeechAct();
                   subject.setContent(content);
                   SA->setSubject(subject.clone());


                   listSA.append(SA);

                  std::cout << qPrintable(SA->getSubject()->ToXml("")) << std::endl;
               }

           }
          /* if (reader.isEndElement())
           {
               if (reader.name() == "ContentTypes")
               {
                   std::cout << std::endl;
               }
               if (reader.name() == "SpeechAct")
               {
                   id++;
                   std::cout << std::endl;
               }
           }*/

       }
       /*while (!listSA.isEmpty())
       {
           SA = listSA.takeFirst();
           std::cout << qPrintable(SA.getPerformative()) << "(" << qPrintable(VSpeechActContentTypeToString(SA.getContent().getType()));
           std::cout << ");" << std::endl;
       }*/
       file.close();



//    QXmlStreamReader reader;
//    QString fileName = "SpeechAct_v2.xml";
//    QFile file(fileName);
//    file.open(QFile::ReadOnly | QFile::Text);
//    reader.setDevice(&file);
//    QList<VSpeechAct> listSA;
//    QString perf;
//    VSpeechActContent content;
//    VSpeechAct SA;

//    reader.readNext();
//    int id = 0;
//    while (!reader.atEnd())
//    {
//        reader.readNext();
//        if (reader.isStartElement())
//        {
//            if (reader.name() == "label")
//            {
//                reader.readNext();
//                //std::cout << qPrintable(reader.text().toString()); //affiche le nom du performatif
//                //std::cout << std::endl;
//                perf = (reader.text().toString());
//                SA.setPerformative(perf);
//            }/*
//            if (reader.name() == "Performative")
//            {
//                std::cout << "Performative : ";
//            }
//            if (reader.name() == "SpeechAct")
//            {
//                std::cout << qPrintable(reader.name().toString());
//                std::cout << " " << id << " :" << std::endl;
//            }
//            if (reader.name() == "ContentTypes")
//            {
//                std::cout << "ContentType : ";
//            }*/
//            if (reader.name() == "ContentType")
//            {
//                reader.readNext();
//                //std::cout << qPrintable(reader.text().toString()) << ", ";
//                content.setType(VSpeechActContentTypeFromString(reader.text().toString()));
//                SA.setContent(content);
//                listSA.append(SA);
//            }
//        }
//       /* if (reader.isEndElement())
//        {
//            if (reader.name() == "ContentTypes")
//            {
//                std::cout << std::endl;
//            }
//            if (reader.name() == "SpeechAct")
//            {
//                id++;
//                std::cout << std::endl;
//            }
//        }*/
//    }
//    while (!listSA.isEmpty())
//    {
//        SA = listSA.takeFirst();
//        std::cout << qPrintable(SA.getPerformative()) << "(" << qPrintable(VSpeechActContentTypeToString(SA.getContent().getType()));
//        std::cout << ");" << std::endl;
//    }
//    file.close();

    return 0;
}
