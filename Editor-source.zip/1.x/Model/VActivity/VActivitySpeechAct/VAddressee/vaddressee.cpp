#include "vaddressee.h"
#include <qdom.h>

VAddressee::VAddressee()
{

}

VAddressee::VAddressee(const VAddressee& addressee, QObject* parent):
VActivityModelElement(parent)
{
    foreach(VWInstance * agent, addressee.getAgents() ){
       _agents.append(agent);
    }
    foreach(VStatement * statement, addressee.getStatements()){
        _statements.append(statement->clone());
    }
}

VAddressee::~VAddressee()
{
    while(_statements.count() > 0)
    {
        VStatement * statement = _statements.first();
        _statements.pop_front();
        delete statement;
    }
}

void VAddressee::addAgent(VWInstance *agent)
{
    if(agent != NULL)
    {
        if(!_agents.contains(agent)){
            _agents.append(agent);
            connect(agent, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
            onModified(tr("Agent added"));
        }
    }
}

void VAddressee::replaceAgent(int index, VWInstance *agent)
{
    if(agent != NULL)
    {
        if(!_agents.contains(agent)){
            _agents.replace(index, agent);
            connect(agent, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
            onModified(tr("Agent changed"));
        }
    }
}

void VAddressee::removeAgent(VWInstance *agent)
{
    if(_agents.contains(agent))
    {
        _agents.removeAll(agent);
        disconnect(agent, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("agent removed"));
    }
}

void VAddressee::addStatement(VStatement *statement)
{
    if(statement != NULL)
    {
        _statements.append(statement);
        connect(statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Statement added"));
    }
}

void VAddressee::removeStatement(VStatement * statement)
{
    if(_statements.contains(statement))
    {
        _statements.removeAll(statement);
        disconnect(statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Statement removed"));
    }
}

QList<VWInstance *> VAddressee::getAgents() const
{
    return _agents;
}

void VAddressee::setAgents(const QList<VWInstance *> &agents)
{
    _agents = agents;
}
QList<VStatement *> VAddressee::getStatements() const
{
    return _statements;
}

void VAddressee::setStatements(const QList<VStatement *> &statements)
{
    _statements = statements;
}

VAddressee *VAddressee::clone() const
{
    return new VAddressee(*this);
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VAddressee::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VAddressee::parseDom()", "<" + elem.tagName() + ">");
    VStatement* myStatement = new VStatement();
    VWInstance* myAgent = new VWInstance();
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de statement
            if(element.tagName() == "statement")
            {
                myStatement->parseDom(element);
                addStatement(myStatement);
            }
            // Lecture d'agents
            else
            {
                myAgent->ParseDom(element);
                addAgent(myAgent);
            }
        }
        node = node.nextSibling();
    }

    VTraceController::get()->Info("VAddressee::parseDom()", "</" + elem.tagName() + ">");
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VAddressee::ToXml(QString tabulation)
{
    QString RetVal = tabulation;
    RetVal += "<Addressees>\n";
    QString agentXml;
    QList<VWInstance*> agentlist = this->getAgents();
    while (!agentlist.isEmpty())
    {
        VWInstance * agent = agentlist.takeFirst();
        agentXml += agent->ToXml("\t"+tabulation) + "\n";
        // agentXml += "\t" + tabulation + "<" + (agent.getClass()).getName() + " rdf:ID=\"" + agent.getName() + "\">\n";
    };
    QString statementXml;
    QList<VStatement*> statementlist = this->getStatements();
    while (!statementlist.isEmpty())
    {
        VStatement * statement = statementlist.takeFirst();
        agentXml += statement->ToXml("\t"+tabulation);
    }
    RetVal += agentXml + statementXml;
    RetVal += tabulation +"</Addressees>\n";
    return RetVal;
}

