#include "vwpropertieseditorwidget.h"
#include "ui_vwpropertieseditorwidget.h"

#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vwproperties.h"
#include "Model/VWorld/vwproperty.h"
#include "Model/VWorld/vwpropertytype.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"

VWPropertiesEditorWidget::VWPropertiesEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWPropertiesEditorWidget),
    _edit(false),
    _properties(NULL)
{
    ui->setupUi(this);
}

VWPropertiesEditorWidget::~VWPropertiesEditorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWPropertiesEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setLabelCol
 * Définie le nom de la colonne
 * @param column Le numéro de la colonne à patir de 0
 * @param label Le nom de la colonne
 */
void VWPropertiesEditorWidget::setLabelCol(int column, QString label)
{
    if (column != 0 && column != 1) return;
    ui->propertyTableWidget->horizontalHeaderItem(column)->setText(label);
}

void VWPropertiesEditorWidget::setProperties(VWProperties * properties)
{
    if(properties != _properties)
    {
        _properties = properties;
        ui->sharedPropertyComboBox->setVisible(getIsShared());
    }
    updateDisplay();
}

QString VWPropertiesEditorWidget::getType() const
{
    return (_properties == NULL) ? "" : _properties->getType();
}

bool VWPropertiesEditorWidget::getIsShared() const
{
    return (_properties != NULL) ? _properties->getIsShared() : false;
}

void VWPropertiesEditorWidget::updateDisplay()
{
    _edit = true;
    QSignalMapper* comboSignalMapper = new QSignalMapper(this);

    ui->sharedPropertyComboBox->clear();
    while(ui->propertyTableWidget->rowCount() > 0)
    {
        ui->propertyTableWidget->removeRow(0);
    }
    if(_properties == NULL) return;
    QList<QPointer<VWProperty> > properties = _properties->getProperties();

    if(getIsShared())
    {
        QList<VWProperty *> sharedProperties = VWProperty::getSharedProperties(getType());
        ui->sharedPropertyComboBox->addItem("");
        foreach(VWProperty * sharedProperty, sharedProperties)
        {
            if(!properties.contains(sharedProperty))
            {
                ui->sharedPropertyComboBox->addItem(sharedProperty->getName(), sharedProperty->getUid());
            }
        }
    }

    for(int i = 0; i < properties.count(); i++)
    {
        ui->propertyTableWidget->insertRow(0);
    }
    for(int i = properties.count() - 1; i >= 0; i--)
    {
        VWProperty * property = properties[i];

        QTableWidgetItem* itemCol0 = new QTableWidgetItem();
        itemCol0->setText(property->getName());
        itemCol0->setData(Qt::UserRole, property->getUid());
        ui->propertyTableWidget->setItem(i, 0, itemCol0);

        QTableWidgetItem* itemCol1 = new QTableWidgetItem();
        itemCol1->setData(Qt::UserRole, property->getUid());

        QComboBox* typeCombo = getTypeCombo(property->getType());
        ui->propertyTableWidget->setCellWidget(i, 1, typeCombo);
        connect(typeCombo, SIGNAL(currentIndexChanged(int)), comboSignalMapper, SLOT(map()));
        comboSignalMapper->setMapping(typeCombo, QString("%1-%2").arg(i).arg(1));

        ui->propertyTableWidget->setItem(i, 1, itemCol1);
    }
    connect(comboSignalMapper, SIGNAL(mapped(const QString &)), this, SLOT(typeChanged(const QString &)));
    ui->propertyTableWidget->resizeColumnsToContents();
    _edit = false;
}

/**
 * @brief getTaskCombo
 * Obtient une combo pour les tâches
 * @param selectedTask La tâche actuel
 * @return La combo
 */
QComboBox * VWPropertiesEditorWidget::getTypeCombo(VWPropertyType * type)
{
    QComboBox * combo = new QComboBox();
    combo->addItem("");
    combo->addItem("int", "-1");
    combo->addItem("string", "-2");
    combo->addItem("bool", "-3");
    combo->addItem("float", "-4");
    combo->addItem("Date", "-5");
    combo->addItem("DateTime", "-6");
    combo->addItem("domain:Boolean", "-7");

    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();

    VWComponentClass * component;
    QList<VWComponentClass *> components = worldModel->getAllComponents();
    foreach(component, components)
    {
        combo->addItem(component->getName(), component->getUid());
    }

    VWObjectClass * object;
    QList<VWObjectClass *> objects = worldModel->getAllObjects();
    foreach(object, objects)
    {
        combo->addItem(object->getName(), object->getUid());
    }

    combo->setCurrentText(type->toString());

    return combo;
}

void VWPropertiesEditorWidget::on_addPropertyButton_clicked()
{
    QString uid = ui->sharedPropertyComboBox->itemData(ui->sharedPropertyComboBox->currentIndex()).toString();
    if(uid.isNull() || uid.isEmpty() || !getIsShared())
    {
        VWProperty * property = new VWProperty();
        _properties->addProperty(property);
    }
    else
    {
        VWProperty * property = VWProperty::getSharedPropertyByUid(getType(), uid.toLong());
        if(property != NULL) _properties->addProperty(property);
    }
}

void VWPropertiesEditorWidget::on_removePropertyButton_clicked()
{
    if(ui->propertyTableWidget->selectedItems().count() > 0)
    {
        QTableWidgetItem* item = ui->propertyTableWidget->selectedItems().first();
        VWProperty * property = _properties->getPropertyByUid(item->data(Qt::UserRole).toString().toLong());
        _properties->removeProperty(property);
        if(!getIsShared()) delete property;
    }
}

void VWPropertiesEditorWidget::on_propertyTableWidget_itemChanged(QTableWidgetItem *item)
{
    if(_edit) return;
    VWProperty * property = _properties->getPropertyByUid(item->data(Qt::UserRole).toString().toLong());
    QString s = item->text();
    if(item->column() == 0) property->setName(s);
}

/**
 * @brief typeChanged
 * Gère les modifications des combos de type
 * @param position La position de la combo dans la table
 */
void VWPropertiesEditorWidget::typeChanged(const QString & position)
{
    if(_edit) return;
    QStringList coordinates = position.split("-");
    int row = coordinates[0].toInt();
    int col = coordinates[1].toInt();
    QComboBox* combo = (QComboBox*)ui->propertyTableWidget->cellWidget(row, col);
    QTableWidgetItem* item = ui->propertyTableWidget->item(row, col);

    if(item != NULL)
    {
        qint64 uid = item->data(Qt::UserRole).toString().toInt();
        VWProperty *  property = _properties->getPropertyByUid(uid);

        QString var = combo->itemData(combo->currentIndex()).toString();
        property->getType()->fromString(var);
    }
}
