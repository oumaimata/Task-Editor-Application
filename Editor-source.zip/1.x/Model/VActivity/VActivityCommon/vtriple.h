#pragma once
#ifndef VTRIPLE_H
#define VTRIPLE_H

#include <QtXml>

#include "vactivitymodelelement.h"

class VTask;
class VWProperty;
class VWorldModelElement;

class VTriple : public VActivityModelElement
{
    Q_OBJECT
private:

    QString _predicate;
    VWProperty * _propertyPredicate;

    QString _subject;
    VWorldModelElement * _worldElementSubject;
    VTask * _taskSubject;

    QString _object;
    VWorldModelElement * _worldElementObject;
public:
    explicit VTriple(QObject *parent = 0);

    VTriple(const VTriple& triple, QObject *parent = 0);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setPredicate(VWProperty * property);
    void setPredicate(QString predicate);
    QString getPredicate() const;

    void setSubject(VWorldModelElement * worldModelElement);
    void setSubject(VTask * task);
    void setSubject(QString subject);
    QString getSubject() const;

    void setObject(VWorldModelElement * worldModelElement);
    void setObject(bool value);
    void setObject(QString object);
    QString getObject() const;

    QString toString(QString tabulation = "") const;

    /**
     * @brief clone
     * @return Le clone
     */
    VTriple * clone(QObject *parent = 0) const;
};

#endif // VTRIPLE_H
