#include "vconstructor.h"

#include "../vtask.h"
#include "vrelation.h"

VConstructor::VConstructor(QObject *parent) :
    VActivityModelElement(parent),
    _type(SeqOrd)
{
}

VConstructor::VConstructor(const VConstructor& constructor, QObject *parent):
    VActivityModelElement(parent)
{
    _type = constructor._type;
    foreach(VRelation * relation, _relations)
    {
        addRelation(relation->clone());
    }
}

/**
 * @brief ~VConstructor
 * Destructeur
 */
VConstructor::~VConstructor()
{
    while(_relations.count() > 0)
    {
        VRelation * relation = _relations.first();
        _relations.pop_front();
        delete relation;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VConstructor::parseDom(QDomElement elem)
{
    setType(elem.attribute("type",""));
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de relation
            if(element.tagName() == "relation")
            {
                VRelation * relation = new VRelation(this);
                relation->parseDom(element);
                addRelation(relation);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VConstructor::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<constructor";
    RetVal += " type=\"" + VActivityConstructorTypeToString(_type) + "\"";
    RetVal += ">\n";

    for(int i = 0; i < _relations.count(); i++)
    {
        RetVal += _relations[i]->ToXml(tabulation + "\t");
    }

    RetVal += tabulation + "</constructor>\n";
    return RetVal;
}

/**
 * @brief AfterTasksParsed
 * Définie les tâches des relations
 * @param task La tâche du constructeur
 */
void VConstructor::AfterTasksParsed()
{
    for(int i = 0; i < _relations.count(); i++)
    {
        _relations[i]->AfterTasksParsed(_task);
    }
}

void VConstructor::setTask(VTask * task)
{
    if(task != _task)
    {
        _task = task;
    }
}

void VConstructor::setType(QString type)
{
    setType(VActivityConstructorTypeFromString(type));
}

void VConstructor::setType(VActivityConstructorType type)
{
    if(type == SIZE_OF_VActivityConstructorType)
    {
        onModified(tr("Constructor type changed"));
        return;
    }
    if(_type != type)
    {
        _type = type;
        if(_type == SeqOrd)
        {
            QList<VTask *> tasks = _task->getChildTasks();
            // On supprime toutes les relations
            while(_relations.count() > 0)
            {
                VRelation * relation = _relations.last();
                _relations.pop_back();
                delete relation;
            }
            // On crée les relations normales
            for(int i = 0; i < tasks.count() - 1; i++)
            {
                VRelation * relation = new VRelation(this);
                relation->setTaskLh(tasks[i]);
                relation->setOperator(lt);
                relation->setTaskRh(tasks[i + 1]);
                _relations.append(relation);
            }
        }
        else
        {
            VRelation * relation;
            foreach(relation, _relations)
            {
                relation->setOperator(VActivityOperatorDefaultTypeFor(_type));
            }
        }
        onModified(tr("Constructor type changed"));
    }
}

/**
 * @brief updateRelations
 * Met à jour les relations
 */
void VConstructor::updateRelations(QList<VTask *> tasks)
{
    if(_type == SeqOrd)
    {
        // On supprime toutes les relations
        while(_relations.count() > 0)
        {
            VRelation * relation = _relations.last();
            _relations.pop_back();
            delete relation;
        }
        for(int i = 0; i < tasks.count() - 1; i++)
        {
            VRelation * relation = new VRelation(this);
            relation->setTaskLh(tasks[i]);
            relation->setOperator(lt);
            relation->setTaskRh(tasks[i + 1]);
            _relations.append(relation);
        }
    }
}

VActivityConstructorType VConstructor::getType()
{
    return _type;
}

void VConstructor::addRelation(VRelation * relation)
{
    if(relation != NULL)
    {
        _relations.append(relation);
        connect(relation, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Relation added"));
    }
}

void VConstructor::removeRelation(VRelation * relation)
{
    if(_relations.contains(relation))
    {
        _relations.removeAll(relation);
        disconnect(relation, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Relation removed"));
    }
}

QList<VRelation *> VConstructor::getRelations() const
{
    return _relations;
}

/**
 * @brief getRefById
 * Obtient la relation correspondant à l'id
 * @return La relation correspondant à l'id
 */
VRelation * VConstructor::getRelationById(qint64 uid) const
{
    for(int i = 0; i < _relations.count(); i++)
    {
        if(_relations[i]->getUid() == uid)
        {
            return _relations[i];
        }
    }
    return NULL;
}

/**
 * @brief getTaskOrdered
 * Obtient les tâches dans l'ordre
 * @return La liste des tâches dans l'ordre
 */
QList<VTask *> VConstructor::getTaskOrdered() const
{
    QList<VTask *> RetVal;
    QMap<QPointer<VTask>, QPointer<VTask> > relatedTasks;
    QList<QPointer<VTask> > lhTasks;
    VTask * task;
    for(int i = 0; i < _relations.count(); i++)
    {
        lhTasks.append(_relations[i]->getTaskLh());
        relatedTasks.insert(_relations[i]->getTaskLh(), _relations[i]->getTaskRh());
    }

    // Recherche du premier élément
    QList<QPointer<VTask> > rhTasks = relatedTasks.values();
    for(int i = 0; i < lhTasks.count(); i++)
    {
        if(!rhTasks.contains(lhTasks[i]))
        {
            task = lhTasks[i];
        }
    }
    // Création de la liste ordonnée
    while(lhTasks.count() != 0 && task != NULL)
    {
        RetVal.append(task);
        lhTasks.removeAll(task);
        task = relatedTasks.value(task);
    }
    RetVal.append(task);
    return RetVal;
}

/**
 * @brief removeRelationOf
 * Supprime les relations contenant la tâche passée en argument
 * @param task Une tâche
 */
void VConstructor::removeRelationOf(VTask * task)
{
    if(_type == SeqOrd)
    {
        VRelation * relation;
        VRelation * firstRelation = NULL;
        VRelation * secondRelation = NULL;
        foreach(relation, _relations)
        {
            if(relation->getTaskLh() == task)
            {
                firstRelation = relation;
            }
            else if(relation->getTaskRh() == task)
            {
                secondRelation = relation;
            }
        }
        if(firstRelation != NULL && secondRelation != NULL) // Tache au milieu
        {
            secondRelation->setTaskRh(firstRelation->getTaskRh());
            _relations.removeAll(firstRelation);
            delete firstRelation;
        }
        if(firstRelation != NULL && secondRelation == NULL) // Tache de début
        {
            _relations.removeAll(firstRelation);
            delete firstRelation;
        }
        if(firstRelation == NULL && secondRelation != NULL) // Tache de fin
        {
            _relations.removeAll(secondRelation);
            delete secondRelation;
        }
    }
    else
    {
        VRelation * relation;
        QList<VRelation *> relationsToRemove;
        foreach(relation, _relations)
        {
            if(relation->getTaskLh() == task || relation->getTaskRh() == task)
                relationsToRemove.append(relation);
        }
        foreach(relation, relationsToRemove)
        {
            _relations.removeAll(relation);
            delete relation;
        }
    }
}

/**
 * @brief clone
 * @return Le clone
 */
VConstructor * VConstructor::clone(QObject *parent) const
{
    return new VConstructor(*this, parent);
}
