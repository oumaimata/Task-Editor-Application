#include "vontologyrelation.h"

VOntologyRelation::VOntologyRelation(QString name, VOntologyConcept& range) :
    _name(name),
    _range(range)
{
}

const QString VOntologyRelation::getName() const
{
    return _name;
}

VOntologyConcept& VOntologyRelation::getRange()
{
    return _range;
}

bool VOntologyRelation::operator==(const VOntologyRelation& relation) const
{
    return (this->_name == relation._name);
}

bool VOntologyRelation::operator==(const QString relationName) const
{
    return (this->_name == relationName);
}
