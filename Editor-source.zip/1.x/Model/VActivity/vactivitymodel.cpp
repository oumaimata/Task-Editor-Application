#include "vactivitymodel.h"

#include "../../Controller/vtracecontroller.h"
#include "../../Controller/vapplicationcontroller.h"
#include "../../Controller/vactivitycontroller.h"
#include "../VHistory/vhistoryset.h"
#include "vtask.h"
#include "vprefix.h"
#include "vtag.h"
#include "VActivityCondition/vbasiscondition.h"
#include "VActivityCondition/vcondition.h"
#include "VActivityCondition/vconditions.h"
#include "VActivityCondition/vstopcondition.h"
#include "VActivityCondition/vstopconditions.h"


#include "Model/VActivity/VActivitySpeechAct/vspeechact.h"


/*!
 \brief Default constructor of the class, inherited from QObject.
 \param parent The parent of the object.
*/
VActivityModel::VActivityModel(QObject *parent) :
    VTaskContainer(parent)
{
    setDefaultActivityModel();

}
void VActivityModel::newActivityModel(){
    setDefaultActivityModel();
    onModified(tr("New activity model created"));
}

void VActivityModel::setDefaultActivityModel(){
    resetModel();

    /*add predefined tags*/
    _predifinedTags.insert("SECURITY", Qt::red);
    _predifinedTags.insert("HYGIENE", Qt::blue);
    QMapIterator<QString, QColor> i(_predifinedTags);
    while(i.hasNext()){
        i.next();
        VTag* tag = new VTag();
        tag->setName(i.key());
        tag->setColor(i.value());
        _tags.append(tag);
        connect(tag, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified();
    }
    /*add speech acts*/

    QXmlStreamReader reader;
    QString fileName = "SpeechAct_v2.xml";
    QFile file(fileName);
    file.open(QFile::ReadOnly | QFile::Text);
    reader.setDevice(&file);
    QString perf;
    VSpeechActContent content;
    QList<VSpeechActContentType> performativeContentTypes;

    reader.readNext();
    int id = 0;
    while (!reader.atEnd())
    {
        reader.readNext();
        if (reader.isStartElement())
        {
            VSubject subject;
            if (reader.name() == "label")
            {
                reader.readNext();
                //std::cout << qPrintable(reader.text().toString()); //affiche le nom du performatif
                //std::cout << std::endl;
                perf =  (reader.text().toString());

            }
            if(reader.name() == "ContentTypes")
                 performativeContentTypes.clear();
            if (reader.name() == "ContentType")
            {

                reader.readNext();
                //std::cout << qPrintable(reader.text().toString()) << ", ";
                performativeContentTypes.append(VSpeechActContentTypeFromString(reader.text().toString()));

            }

        }

         if (reader.isEndElement())
        {
            if (reader.name() == "SpeechAct")
            {
                _predefiniedPerformatives.insert(perf, performativeContentTypes);
            }
        }

    }

    file.close();



}

/**
 * @brief VActivityModel
 * Destructeur
 */
VActivityModel::~VActivityModel()
{
    resetModel();
}

/**
 * @brief resetModel
 * Vide le model
 */
void VActivityModel::resetModel()
{
    _edit = true;
    while(_tags.count() > 0)
    {
        QPointer<VTag> tag = _tags.last();
        _tags.pop_back();
        if(tag != NULL) delete tag;
    }
    while(_namespaces.count() > 0)
    {
        VPrefix * prefix = _namespaces.first();
        _namespaces.pop_front();
        delete prefix;
    }
    QList<VTask *> tasks = getChildTasks();
    foreach(VTask * task, tasks)
    {
        removeChildTask(task);
    }
    _edit = false;
    onModified();
}

/**
 * @brief loadModel
 * Permet de charger un model
 * @param xmlModel Le modèle en xml
 */
void VActivityModel::loadModel(QString xmlModel)
{
    resetModel();
    QDomDocument *dom = new QDomDocument("mon_xml");
    if(!dom->setContent(xmlModel))
    {
        return; // Erreur
    }
    QDomElement domElement = dom->documentElement();
    parseDom(domElement);
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VActivityModel::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VActivityModel::parseDom()", "<" + elem.tagName() + ">");
    _edit = true;
    setVersion(elem.attribute("version",""));

    QDomNode node = elem.firstChild();

    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // --- Lecture des namespaces ---
            if(element.tagName() == "namespaces")
            {
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        // Lecture de prefix
                        if(subElement.tagName() == "prefix")
                        {
                            VPrefix * prefix = new VPrefix();
                            prefix->parseDom(subElement);
                            this->addNamespace(prefix);
                        }
                    }
                    subNode = subNode.nextSibling();
                }
            }
            // --- Lecture des tags ---
            else if(element.tagName() == "tags")
            {
                QMap<int, int> treeOfTagsById;
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        // Lecture de prefix
                        if(subElement.tagName() == "tag")
                        {
                            QPointer<VTag> tag = new VTag();
                            tag->parseDom(subElement);
                            this->addTag(tag);
                            QString parentId = tag->getTagParentFromDom(subElement);
                            if(parentId != "")
                            {
                                treeOfTagsById.insert(tag->getId(), parentId.toInt());
                            }
                        }
                    }
                    subNode = subNode.nextSibling();
                }
                CreateTagTree(treeOfTagsById);
            }
            // --- Lecture des tasks ---
            else if(element.tagName() == "tasks")
            {
                QDomNode subNode = element.firstChild();
                QMap<VTask *, QList<QString> > treeOfTaskById;
                QMap<VTask *, QMap<QString, QString> > refTagOfTaskById;
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        // Lecture de task_m et task_f
                        if(subElement.tagName() == "task_m" ||subElement.tagName() == "task_f")
                        {
                            QDomNode subSubNode = subElement.firstChild();
                            // Lecture des noeuds inférieurs
                            while(!subSubNode.isNull())
                            {
                                QDomElement subSubElement = subSubNode.toElement();
                                if(!subSubElement.isNull())
                                {
                                    // Lecture de prefix
                                    if(subSubElement.tagName() == "task")
                                    {
                                        VTask *task = new VTask(this);
                                        task->parseDom(subSubElement);
                                        this->addChildTask(task); // Ajout de la tache au model
                                        VTraceController::get()->Info("VActivityModel::parseDom()",
                                                                               "Task added, Id :\"" + task->getId() + "\"");
                                        treeOfTaskById.insert(task, task->getTaskChildsFromDom(subSubElement)); // Conservation de l'arborescence des tâches
                                        refTagOfTaskById.insert(task, task->getRefTagsFromDom(subSubElement));
                                    }
                                }
                                subSubNode = subSubNode.nextSibling();
                            }
                        }
                    }
                    subNode = subNode.nextSibling();
                }
                VTraceController::get()->Info("VActivityModel::parseDom()", QString::number(getChildTasks().count()));
                CreateTaskTree(treeOfTaskById); // Création de l'arborescence par rapport aux id car toutes les taches on comme parent le model.
                CreateRefTagOfTasks(refTagOfTaskById);

                QList<VTask *> tasks = getChildTasks();
                for(int i = 0; i < tasks.count(); i++)
                {
                    tasks[i]->AfterTasksParsed();
                }
            }
        }
        node = node.nextSibling();
    }
    _edit = false;
    VTraceController::get()->Info("VActivityModel::parseDom()", "</" + elem.tagName() + ">");
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VActivityModel::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<model version=\"" + _version + "\">\n";
    // Ajouter les namespaces
    if(_namespaces.count() != 0)
    {
        RetVal += tabulation + "\t<namespaces>\n";
        for(int i = 0; i < _namespaces.count(); i++)
        {
            RetVal += _namespaces[i]->ToXml(tabulation + "\t\t");
        }
        RetVal += tabulation + "\t</namespaces>\n";
    }
    // Ajouter les tags
    if(_tags.count() != 0)
    {
        RetVal += tabulation + "\t<tags>\n";
        for(int i = 0; i < _tags.count(); i++)
        {
            RetVal += _tags[i]->ToXml(tabulation + "\t\t");
        }
        RetVal += tabulation + "\t</tags>\n";
    }
    // Ajouter les tâches
    QList<VTask *> childTasks = getAllChildTasks();
    if(childTasks.count() != 0)
    {
        RetVal += tabulation + "\t<tasks>\n";
        QString task_f = tabulation + "\t\t<task_f>\n";
        QString task_m = tabulation + "\t\t<task_m>\n";
        for(int i = 0; i < childTasks.count(); i++)
        {
            if(childTasks[i]->getChildTasks().count() == 0)
            {
                task_f += childTasks[i]->ToXml(tabulation + "\t\t\t");
            }
            else
            {
                task_m += childTasks[i]->ToXml(tabulation + "\t\t\t");
            }
        }
        task_f += tabulation + "\t\t</task_f>\n";
        task_m += tabulation + "\t\t</task_m>\n";
        RetVal += task_m + task_f + tabulation + "\t</tasks>\n";
    }
    RetVal += tabulation + "</model>";
    return RetVal;
}

/**
 * @brief CreateTaskTree
 * Creation de l'arborescence entre les taches car
 */
void VActivityModel::CreateTaskTree(QMap<VTask *, QList<QString> > treeOfTaskById)
{
    VTraceController::get()->Debug("VActivityModel::CreateTaskTree()", "Begin");
    VTask* parent;
    QString childId;
    VTask* child;
    for(int i = 0; i < treeOfTaskById.keys().count(); i++)
    {
        parent = treeOfTaskById.keys()[i];
        for(int j = 0; j < treeOfTaskById.values()[i].count(); j++)
        {
            childId = treeOfTaskById.values()[i][j];
            child = this->getTaskById(childId);
            if(child != NULL)
            {
                child->setParent(parent, true);
                VTraceController::get()->Info("VActivityModel::CreateTaskTree()", "setParent");
            }
        }
    }
    VTraceController::get()->Debug("VActivityModel::CreateTaskTree()", "End");
}

/**
 * @brief CreateRefTagOfTasks
 * Creation des références aux ref-tags des task
 * @param refTagOfTaskById liste de pair de (id tache, pair (id tag, value tag))
 */
void VActivityModel::CreateRefTagOfTasks(QMap<VTask *, QMap<QString, QString> > refTagOfTaskById)
{
    VTraceController::get()->Debug("VActivityModel::CreateTaskTree()", "Begin");
    VTask* task;
    QMap<QString, QString> taskTags;
    VTag * tag;
    QString tagId;
    QString tagValue;
    for(int i = 0; i < refTagOfTaskById.count(); i++)
    {
        task = refTagOfTaskById.keys()[i];
        taskTags = refTagOfTaskById.values()[i];
        for(int j = 0; j < taskTags.count(); j++)
        {
            tagId = taskTags.keys()[j];
            tagValue = taskTags.values()[j];
            tag = getTagById(tagId.toInt());
            task->addRefTag(tag, tagValue);
        }
    }
    VTraceController::get()->Debug("VActivityModel::CreateTaskTree()", "End");
}

/**
 * @brief CreateTagTree
 * Creation de l'arborescence entre les tags
 * @param treeOfTagsById Liste de pair (id fils, id père)
 */
void VActivityModel::CreateTagTree(QMap<int, int> treeOfTagsById)
{
    VTraceController::get()->Debug("VActivityModel::CreateTagTree()", "Begin");
    int parentId;
    VTag* parent;
    int childId;
    VTag* child;
    for(int i = 0; i < treeOfTagsById.keys().count(); i++)
    {
        parentId = treeOfTagsById.values()[i];
        parent = this->getTagById(parentId);

        childId = treeOfTagsById.keys()[i];
        child = this->getTagById(childId);
        if(child != NULL && parentId != childId)
        {
            child->setParent(parent);
            VTraceController::get()->Info("VActivityModel::CreateTagTree()", "setParent");
        }
    }
    VTraceController::get()->Debug("VActivityModel::CreateTagTree()", "End");
}

VTask * VActivityModel::getTaskByUid(qint64 uid) const
{
    QList<VTask*> tasks = getChildTasks();
    foreach (VTask * task, tasks)
    {
        if(task->getUid() == uid) return task;
        VTask* subTask = task->getTaskByUid(uid);
        if(subTask != NULL) return subTask;
    }
    return NULL;
}

/**
 * @brief getTaskById
 * Obtient la tâche ayant l'id passé en argument
 * @param id L'id d'un tâche
 * @return La tâche si elle existe sinon null
 */
VTask* VActivityModel::getTaskById(QString id) const
{
    QList<VTask*> tasks = getChildTasks();
    for(int i = 0; i < tasks.count(); i++)
    {
        VTask* task = tasks[i]->getTaskById(id);
        if(task != NULL)
        {
            VTraceController::get()->Info("VActivityModel::getTaskById()", "Task found");
            return task;
        }
    }
    return NULL;
}

/**
 * @brief getTagById
 * Obtient le tag ayant l'id passé en argument
 * @param id L'id d'un tag
 * @return Le tag s'i elle'il existe sinon null
 */
VTag* VActivityModel::getTagById(qint64 uid)
{
    for(int i = 0; i < _tags.count(); i++)
    {
        VTag* tag = _tags[i]->getTagById(uid);
        if(tag != NULL)
        {
            VTraceController::get()->Info("VActivityModel::getTagById()", "Tag found");
            return tag;
        }
    }
    return NULL;
}

void VActivityModel::setVersion(QString version)
{
    _version = version;
    onModified(tr("Version changed"));
}

QString VActivityModel::getVersion()
{
   return _version;
}

void VActivityModel::addNamespace(VPrefix * prefix)
{
    if(prefix != NULL)
    {
        _namespaces.append(prefix);
        connect(prefix, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Namespace added"));
    }
}

void VActivityModel::removeNamespace(VPrefix * prefix)
{
    if(_namespaces.contains(prefix))
    {
        _namespaces.removeAll(prefix);
        disconnect(prefix, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Namespace removed"));
    }
}

VPrefix * VActivityModel::getNamespace(QString prefix) const
{
    for(int i = 0; i < _namespaces.count(); i++)
    {
        if(_namespaces[i]->getName() == prefix)
        {
            return _namespaces[i];
        }
    }
    return NULL;
}

QList<VPrefix *> VActivityModel::getNamespaces()
{
   return _namespaces;
}

void VActivityModel::addTag(QPointer<VTag> tag)
{
    if(tag != NULL)
    {
        _tags.append(tag);
        connect(tag, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Tag added"));
    }
}

void VActivityModel::removeTag(QPointer<VTag> tag)
{
    if(_tags.contains(tag))
    {
        QList<VTag *> childTags = tag->getChildTags();
        for(int i = 0; i < childTags.count(); i++)
        {
            _tags.removeAll(childTags[i]);
        }
        _tags.removeAll(tag);
        disconnect(tag, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        tag->tagDestroyed(tag);
        delete tag;
        onModified(tr("Tag removed"));
    }
}

/*!
 Overrides VTaskContainer::childTaskAdded(VTask* parent)
*/
void VActivityModel::childTaskAdded(VTask* task)
{
    emit taskAdded(task);
    if(task != NULL) connect(task, SIGNAL(modified(QString,QObject*)), this, SLOT(onModified(QString,QObject*)));
    onModified(tr("Child task added"), task);
}

/*!
 Overrides VTaskContainer::childTaskRemoved(VTask* parent)
*/
void VActivityModel::childTaskRemoved(VTask* task)
{
    emit taskRemoved(task);
    if(task != NULL) disconnect(task, SIGNAL(modified(QString,QObject*)), this, SLOT(onModified(QString,QObject*)));
    onModified(tr("Child task removed"));
}

/*!
 Overrides VTaskContainer::childTaskModified(VTask* parent)
*/
void VActivityModel::childTaskModified(VTask* task)
{
    emit taskModified(task);
    onModified(tr("Child task modified"), task);
}

void VActivityModel::onModified()
{
    onModified(NULL);
}

void VActivityModel::onModified(QString message, QObject * object)
{
    if(!_edit && message != NULL)
    {
        VApplicationController * appCtrler = VApplicationController::getInstance();
        if(appCtrler == NULL) return;
        VActivityController * activityCtrler = appCtrler->getActivityController();
        if(activityCtrler == NULL) return;
        VHistorySet * historySet = activityCtrler->getActivityHistorySet();
        if(historySet == NULL) return;
        VTask * task = qobject_cast<VTask *>(object);
        VTag * tag = qobject_cast<VTag *>(object);
        QString label;
        if(tag == NULL && task == NULL) label = "";
        else if(tag != NULL) label = tag->getName();
        else if(task != NULL) label = task->getId();
        historySet->push_back("", message, ToXml());
    }
    VActivityModelElement::onModified(message, object);
}

QList<QPointer<VTag> > VActivityModel::getTags() const
{
    return _tags;
}


QList<VBasisCondition *> VActivityModel::getAllBasisConditions() const
{
    QList<VBasisCondition *> RetVal;
    foreach(VTask * task, getAllChildTasks())
    {
        RetVal.append(task->getContextualConditions()->getBasisConditions());
        RetVal.append(task->getFavorableConditions()->getBasisConditions());
        RetVal.append(task->getRegulatoryConditions()->getBasisConditions());
        RetVal.append(task->getNomologicalConditions()->getBasisConditions());
        RetVal.append(task->getSatisfactionConditions()->getBasisConditions());
        RetVal.append(task->getStopConditions()->getBasisConditions());
    }
    return RetVal;
}

QList<QPointer<VSpeechAct> > VActivityModel::getSpeechActs() const
{
    return _speechActs;
}

void VActivityModel::setSpeechActs(QList<QPointer<VSpeechAct> > speechActs)
{
    _speechActs = speechActs;
}


QMap<QString, QList<VSpeechActContentType> > VActivityModel::getPredefiniedPerformatives() const
{
    return _predefiniedPerformatives;
}

void VActivityModel::setPredefiniedPerformatives(QMap<QString, QList<VSpeechActContentType> > predefiniedPerformatives)
{
    _predefiniedPerformatives = predefiniedPerformatives;
}
