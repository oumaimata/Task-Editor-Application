#pragma once
#ifndef VWCOMPONENTCLASS_H
#define VWCOMPONENTCLASS_H

#include "../vworldmodelelement.h"

class VWProperty;
class VWProperties;

class VWComponentClass : public VWorldModelElement
{
    Q_OBJECT
private:
    /**
     * @brief _parent
     * Le composant parent
     */
    VWComponentClass * _parent;

    /**
     * @brief _childs
     * Les composants enfants
     */
    QList<VWComponentClass *> _childs;

    /**
     * @brief _properties
     * La listes des propriétées
     */
    VWProperties * _properties;

    /**
     * @brief _stateProperties
     * La listes des propriétées d'état
     */
    VWProperties * _stateProperties;
public:
    /**
     * @brief VWComponentClass
     * Constructeur par défaut
     * @param parent L'objet parent
     */
    explicit VWComponentClass(QObject *parent = 0);

    /**
     * @brief VWComponentClass
     * @param o L'objet à copier
     */
    VWComponentClass(const VWComponentClass& o);

    /**
     * @brief ~VWComponentClass
     * Destructeur
     */
    ~VWComponentClass();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");
    QString getState() const;
    QString getHasState() const;

    void setParent(VWComponentClass * parent);
    VWComponentClass * getParent() const;

    void addChild(VWComponentClass * child);
    void removeChild(VWComponentClass * child);
    QList<VWComponentClass *> getChilds() const;
    QList<VWComponentClass *> getAllChilds() const;
    VWComponentClass * getChildByUid(qint64 uid) const;
    VWComponentClass * getChildByName(QString name) const;

    QPointer<VWProperty> addProperty(QDomElement elem);
    void addStateProperty(QDomElement elem);
    VWProperties * getProperties() const;
    VWProperties * getStateProperties() const;
    QList<QPointer<VWProperty> > getAllProperties() const;

    void onComponentModified();
    void onComponentModified(QString message, QObject * object = NULL);

public slots:
    void onModified();
    void onModified(QString message, QObject * object = NULL);

signals:
    void componentModified();
    void componentModified(QString message, QObject * object = NULL);
};

#endif // VWCOMPONENTCLASS_H
