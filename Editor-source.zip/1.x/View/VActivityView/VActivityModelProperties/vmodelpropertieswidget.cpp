#include "vmodelpropertieswidget.h"
#include "ui_vmodelpropertieswidget.h"

#include "Model/VActivity/vactivitymodel.h"

VModelPropertiesWidget::VModelPropertiesWidget(QWidget *parent) :
    QTabWidget(parent),
    ui(new Ui::VModelPropertiesWidget),
    _activityModel(NULL)
{
    ui->setupUi(this);
}

VModelPropertiesWidget::~VModelPropertiesWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VModelPropertiesWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setActivityModel
 * Définit le modèle d'activité en cours
 * @param activityModel Le modèle d'activité en cours
 */
void VModelPropertiesWidget::setActivityModel(VActivityModel * activityModel)
{
    _activityModel = activityModel;
    ui->generalTab->setActivityModel(_activityModel);
    ui->tagTab->setActivityModel(_activityModel);
}
