# Site web de présentation Task-Editor 
Site de présentation du projet Task-Editor développé en NF28 à l'aide de Bootstrap.

## Usage
Lancer le fichier index.html pour lancer le logiciel

## Credits
1. Pierre-Louis Lacorte
2. Théo Judas
3. Camille Soetaert
4. Oumaima Talouka

## License
Aucun héhé!