#include "vwobjectclass.h"

#include "../vwparser.h"
#include "../vwproperties.h"
#include "../VWorldInstance/vwinstance.h"

VWObjectClass::VWObjectClass(QObject *parent) :
    VWEntityClass(parent),
    _parent(NULL),
    _type(""),
    _typeIsEditable(true)
{
    setName("Object" + QString::number(getUid()));
    _properties = new VWProperties();
    _properties->setType("object");
    _properties->setWorldModelElement(this);
    _properties->setIsShared(true);
    connect(_properties, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
}

/**
 * @brief VWObjectClass
 * @param o L'objet à copier
 */
VWObjectClass::VWObjectClass(const VWObjectClass& o):
    VWEntityClass(o)
{
    _parent = o._parent;
    _childs = o._childs;
    _type = o._type;
    _typeIsEditable = o._typeIsEditable;
    _properties = o._properties;
}

/**
 * @brief ~VWObjectClass
 * Destructeur
 */
VWObjectClass::~VWObjectClass()
{
    while(_childs.count() > 0)
    {
        VWObjectClass * child = _childs.first();
        _childs.pop_front();
        delete child;
    }
    while(_instances.count() > 0)
    {
        VWInstance * instance = _instances.first();
        _instances.pop_front();
        delete instance;
    }
    delete _properties;
}


/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWObjectClass::ParseDom(QDomElement elem)
{
    VWEntityClass::ParseDom(elem);
    QList<QString> domainSupClasses = VWParser::getDomainSupClasses(elem);
    foreach(QString domainSupClass, domainSupClasses)
    {
        if(domainSupClass == "concreteobject")
        {
            this->setType("concrete");
        }
        else if(domainSupClass == "abstractobject")
        {
            this->setType("abstract");
        }
        else if(domainSupClass == "agent")
        {
            this->setType("agent");
        }
    }
}


/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWObjectClass::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<owl:Class rdf:ID=\"" + getName() + "\">\n";
    RetVal += VWEntityClass::ToXml(tabulation + "\t");
    if(_parent != NULL) RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"#" + _parent->getName() + "\"/>\n";
    else if(getType() == "concrete")
        RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#ConcreteObject\"/>\n";
    else if(getType() == "abstract")
        RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#AbstractObject\"/>\n";
    else if(getType() == "agent")
        RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#Agent\"/>\n";
    RetVal += tabulation + "</owl:Class>\n";

    return RetVal;
}


void VWObjectClass::setParent(VWObjectClass * parent)
{
    if(parent != _parent)
    {
        _parent = parent;
        onModified(NULL);
    }
}

VWObjectClass * VWObjectClass::getParent() const
{
    return _parent;
}


void VWObjectClass::addChild(VWObjectClass * child)
{
    if(child != NULL)
    {
        child->setParent(this);
        child->setType(_type);
        child->setTypeIsEditable(false);
        _childs.append(child);
        connect(child, SIGNAL(modified(QString, QObject*)),this , SLOT(onModified(QString, QObject*)));
        onModified(tr("Child object added"));
    }
}

void VWObjectClass::removeChild(VWObjectClass * child)
{
    if(_childs.contains(child))
    {
        _childs.removeAll(child);
        disconnect(child, SIGNAL(modified(QString, QObject*)),this , SLOT(onModified(QString, QObject*)));
        onModified(tr("Child object removed"));
    }
}

QList<VWObjectClass *> VWObjectClass::getChilds() const
{
    return _childs;
}

QList<VWObjectClass *> VWObjectClass::getAllChilds() const
{
    QList<VWObjectClass *> RetVal;
    RetVal.append(getChilds());
    foreach(VWObjectClass * child, _childs)
    {
        RetVal.append(child->getAllChilds());
    }
    return RetVal;
}

QList<VWObjectClass *> VWObjectClass::getAllChilds(VWComponentClass * component) const
{
    QList<VWObjectClass *> RetVal;
    foreach(VWObjectClass * child, _childs)
    {
        if(child->getComponents().contains(component))
        {
            RetVal.append(child);
        }
        QList<VWObjectClass *> childs = child->getAllChilds(component);
        if(childs.count() > 0) RetVal.append(childs);
    }
    return RetVal;
}

VWObjectClass * VWObjectClass::getChildByUid(qint64 uid) const
{
    foreach(VWObjectClass * object, _childs)
    {
        if(object->getUid() == uid) return object;
        else
        {
            VWObjectClass * child = object->getChildByUid(uid);
            if(child != NULL) return child;
        }
    }
    return NULL;
}

VWObjectClass * VWObjectClass::getChildByName(QString name) const
{
    foreach(VWObjectClass * object, _childs)
    {
        if(object->getName() == name) return object;
        else
        {
            VWObjectClass * child = object->getChildByName(name);
            if(child != NULL) return child;
        }
    }
    return NULL;
}


void VWObjectClass::setType(QString type)
{
    if(type != _type)
    {
        _type = type;
        QList<VWObjectClass *> childs = getChilds();
        foreach(VWObjectClass * child, childs)
        {
            child->setType(_type);
        }
        onModified(tr("Type changed"));
    }
}

QString VWObjectClass::getType() const
{
    return _type;
}


void VWObjectClass::setTypeIsEditable(bool typeIsEditable)
{
    _typeIsEditable = typeIsEditable;
}

bool VWObjectClass::getTypeIsEditable() const
{
    return _typeIsEditable;
}

void VWObjectClass::addInstance(VWInstance * instance)
{
    if(instance != NULL && !_instances.contains(instance))
    {
        _instances.append(instance);
        instance->setClass(this);
        connect(instance, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Instance added"));
    }
}

void VWObjectClass::removeInstance(VWInstance * instance)
{
    if(_instances.contains(instance))
    {
        _instances.removeAll(instance);
        disconnect(instance, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Instance removed"));
    }
}

/**
 * @brief getInstances
 * Obtient la liste des instances directes de la classe
 */
QList<VWInstance *> VWObjectClass::getInstances() const
{
    return _instances;
}

/**
 * @brief getAllInstances
 * Obtient la liste des instances directes de la classe et des instances des sous-classes
 */
QList<VWInstance *> VWObjectClass::getAllInstances() const
{
    QList<VWInstance *> RetVal;
    RetVal.append(_instances);
    foreach(VWObjectClass * child, _childs)
    {
        RetVal.append(child->getAllInstances());
    }
    return RetVal;
}

/**
 * @brief getInstanceByUid
 * Obtient l'instance correspondant à l'uid passé en argument
 * parmis les instances directes
 */
VWInstance * VWObjectClass::getInstanceByUid(qint64 uid) const
{
   QList<VWInstance *> instances = getInstances();
   foreach(VWInstance * instance, instances)
   {
       if(instance->getUid() == uid) return instance;
   }
   return NULL;
}

/**
 * @brief getAllInstanceByUid
 * Obtient l'instance correspondant à l'uid passé en argument
 * parmis les instances directes et les instances des sous-classes
 */
VWInstance * VWObjectClass::getAllInstanceByUid(qint64 uid) const
{
    QList<VWInstance *> instances = getAllInstances();
    foreach(VWInstance * instance, instances)
    {
        if(instance->getUid() == uid) return instance;
    }
    return NULL;
}

VWInstance * VWObjectClass::getAllInstanceByName(QString name) const
{
    QList<VWInstance *> instances = getAllInstances();
    foreach(VWInstance * instance, instances)
    {
        if(instance->getName() == name) return instance;
    }
    return NULL;
}

QPointer<VWProperty> VWObjectClass::addProperty(QDomElement elem)
{
    if(_properties != NULL) return _properties->addProperty(elem);
    return QPointer<VWProperty>();
}

/**
 * @brief getProperties
 * Obtient la liste des propriétées
 * @return La liste des propriétées
 */
VWProperties * VWObjectClass::getProperties() const
{
    return _properties;
}

/**
 * @brief getAllProperties
 * Obtient la liste de toutes les propriétées
 * @return La liste de toutes les propriétées
 */
QList<QPointer<VWProperty> > VWObjectClass::getAllProperties() const
{
    QList<QPointer<VWProperty> > properties;
    properties.append(_properties->getProperties());
    if(_parent != NULL) properties.append(_parent->getAllProperties());
    foreach(QPointer<VWComponentClass> component, _components)
    {
        if(component != NULL)
        {
            properties.append(component->getAllProperties());
        }
    }
    return properties;
}

void VWObjectClass::onClassModified(QObject * object)
{
    classModified(object);
    foreach(VWObjectClass * child, _childs)
    {
        child->onClassModified(object);
    }
}

void VWObjectClass::onModified()
{
    onModified(NULL);
}

void VWObjectClass::onModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    VWorldModelElement::onModified(message, object);
    if(_parent == NULL) onClassModified(object); // On fait redescendre l'information à tous les objects enfants qui héritent.
}
