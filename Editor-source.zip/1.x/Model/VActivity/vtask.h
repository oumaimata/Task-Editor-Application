#pragma once
#ifndef VTASK_H
#define VTASK_H

#include <QVector>
#include <QtXml>

#include "vtaskcontainer.h"
#include "VActivityConstructor/vactivityconstructortype.h"

class VTag;
class VContext;
class VOperation;
class VConditions;
class VConstructor;
class VStopConditions;

/*!
 This class represents a task of the application.
 A task has several attributes that can be modified through
 methods provided by this class. A task is a task container
 and therefore can have multiple direct childs. A task also
 have a context that represents all the known objects for
 this task.
 \brief A task of the application.
*/
class VTask : public VTaskContainer
{
    Q_OBJECT

private :
    /**
     * @brief _id
     * identifiant unique de la tâche
     */
    QString _id;

    /**
     * @brief _name
     * Le nom de la tâche
     */
    QString _name;

    /**
     * @brief _iterative
     */
    bool _iterative;

    /**
     * @brief _optional
     */
    bool _optional;

    /**
     * @brief _interruptible
     */
    bool _interruptible;

    /**
     * @brief _freeText
     * Commentaire lié à la tâche
     */
    QString _freeText;

    /**
     * @brief _isCut
     */
    bool _isCut;

    /**
     * @brief _context
     * Context de la tâche
     */
    VContext * _context;

    /**
     * @brief _constructor
     * Constructeur de la tâche
     */
    VConstructor* _constructor;

    /**
     * @brief _operation
     * Opération de la tâche
     */
    VOperation* _operation;

    /**
     * @brief _Conditions
     * Liste de conditions Favorable de la tâche
     */
    VConditions * _favorableConditions;

    /**
     * @brief _regulatoryConditions
     * Liste de conditions Regulatory de la tâche
     */
    VConditions * _regulatoryConditions;

    /**
     * @brief _nomologicalConditions
     * Liste de conditions Nomological de la tâche
     */
    VConditions * _nomologicalConditions;

    /**
     * @brief _contextualConditions
     * Liste de conditions Contextual de la tâche
     */
    VConditions * _contextualConditions;

    /**
     * @brief _satisfactionConditions
     * Liste de conditions Statisfaction de la tâche
     */
    VConditions * _satisfactionConditions;

    /**
     * @brief _stopConditions
     * Liste de stop conditions de la tâche
     */
    VStopConditions * _stopConditions;

    /**
     * @brief _refTags
     * Liste des tags de la tache
     * avec leur valeur stocké dans une chaîne de caractère
     * alors qu'il s'agit d'un entier afin de simplifier les traitements
     */
    QMap<QPointer<VTag>, QString> _refTags;

protected:
    /*!
     Overrides VTaskContainer::childTaskAdded(VTask* parent)
    */
    void childTaskAdded(VTask* task);

    /**
     * @brief processChildTaskAdded
     * Override VTaskContainer::processChildTaskAdded
     * Gère La modification des tâches filles
     */
    void processChildTaskAdded();

    /**
     * @brief childTaskRemoved
     * Overrides VTaskContainer::childTaskRemoved(VTask* parent)
     * Fait remonter l'information jusqu'au VActivityModel
     * @param task la tâche qui est supprimée
     */
    void childTaskRemoved(VTask* task);

    /**
     * @brief processChildTaskRemoved
     * Override VTaskContainer::processChildTaskRemoved
     * Gère La suppression des tâches filles
     */
    void processChildTaskRemoved(VTask * task);

    /*!
     Overrides VTaskContainer::childTaskModified(VTask* parent)
    */
    void childTaskModified(VTask* task = NULL);

    /**
     * @brief moveDown
     * Déplace les tâches passées en arguments vers le bas
     * @param tasks La liste des tâches à déplacer
     */
    void moveDown(QList<QPointer<VTask> > tasks);

    /**
     * @brief moveUp
     * Déplace les tâches passées en arguments vers le haut
     * @param tasks La liste des tâches à déplacer
     */
    void moveUp(QList<QPointer<VTask> > tasks);

public:
    /*!
     \brief Default constructor of the class, inherited from QObject.
     \param parent The parent of the object.
    */
    explicit VTask(VTaskContainer* parent = NULL);

    /**
     * @brief ~VTask
     * Destructeur
     */
    ~VTask();

    /*!
     Overrides QObject::setParent(QObject* parent)
    */
    void setParent(VTaskContainer* parent, bool modelIsLoading = false);

// --- setter & getter : begin ---

    void setId(QString id);

    void setIdFromName(QString name);

    QString getId() const;

    void setName(QString name);

    QString getName() const;

    void setIterative(QString iterative);

    void setIterative(bool iterative);

    bool getIterative() const;

    void setOptional(QString optional);

    void setOptional(bool optional);

    bool getOptional() const;

    void setInterruptible(QString interruptible);

    void setInterruptible(bool interruptible);

    bool getInterruptible() const;

    void setCut(bool cut);

    bool getCut();

    VContext * getContext() const;

    void setConstructor(VConstructor* constructor = NULL);

    VConstructor* getConstructor() const;

    void setOperation(VOperation* operation = NULL);

    VOperation* getOperation() const;

    VConditions * getFavorableConditions() const;

    VConditions * getRegulatoryConditions() const;

    VConditions * getNomologicalConditions() const;

    VConditions * getContextualConditions() const;

    VConditions * getSatisfactionConditions() const;

    VStopConditions * getStopConditions() const;

    void setRefTagValue(VTag *const &tag);

    void setRefTagValue(VTag *const &tag, QString value);

    void addRefTag(VTag * const &tag);

    void addRefTag(VTag * const &tag, QString value);

    void removeRefTag(VTag *const &tag);

    QMap<QPointer<VTag>,QString> getRefTags() const;

    QString getRefTag(VTag * const &tag) const;

    QString getFreeText() const;

    void setFreeText(const QString &freeText);

// --- setter & getter : end ---

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    /**
     * @brief AfterTasksParsed
     * Définie les tâches des relations
     */
    void AfterTasksParsed();

    /**
     * @brief getTaskByUid
     * Obtient la tâche ayant l'uid passé en argument
     * @param uid L'uid d'une tâche
     * @return La tâche si elle existe sinon null
     */
    VTask* getTaskByUid(qint64 uid);

    /**
     * @brief getTaskById
     * Obtient la tâche ayant l'id passé en argument
     * @param id L'id d'une tâche
     * @return La tâche si elle existe sinon null
     */
    VTask *getTaskById(QString id);

    /**
     * @brief getTaskChildsFromDom
     * Obtient la liste des tâches filles d'une tâche
     * @param elem Un élément du dom
     * @return La liste des tâches filles d'une tâche
     */
    QList<QString> getTaskChildsFromDom(QDomElement elem);

    /**
     * @brief getRefTagsFromDom
     * Obtient la liste des tags référencés par la tâche
     * @param elem Un élément du dom
     * @return La liste des tags référencés
     */
    QMap<QString, QString> getRefTagsFromDom(QDomElement elem);

    /**
     * @brief IsAnscesterOf
     * Détermine si on est un ancètre de task
     * @param task Une tâche
     * @return Vrai si on est un ancètre de task
     *         Faux sinon
     */
    bool IsAnscesterOf(VTask * task) const;

    /**
     * @brief clone
     * Clone la tâche
     * @return Le clone de la tâche
     */
    VTask * clone() const;

public slots:
    /**
     * @brief onModified
     * Signal envoyé quand une tâche est modifiée
     */
    void onModified();

    /**
     * @brief onModified
     * Signal envoyé quand une tâche est modifiée
     */
    void onModified(QString message, QObject * object = NULL);

    /**
     * @brief tagModified
     * Gère les modifications d'un tag
     * -> si ne tag ne prend plus de valeur : retirer la valeur du tag
     */
    void tagModified();

    /**
     * @brief tagModified
     * Gère les modifications d'un tag
     * -> si ne tag ne prend plus de valeur : retirer la valeur du tag
     */
    void tagModified(QString message, QObject * object = NULL);
};

#endif // VTASK_H
