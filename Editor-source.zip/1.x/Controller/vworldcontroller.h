#pragma once
#ifndef VWORLDCONTROLLER_H
#define VWORLDCONTROLLER_H

#include <QObject>
#include <QPointer>
#include <QString>

#include "../Model/VHistory/vhistoryset.h"

class VWorldWidget;
class VHistoryWorldWidget;
class VWorldModelElement;

/*!
 * @brief The VActivityController class
 * Le controller du modèle du monde
 */
class VWorldController : public QObject
{
    Q_OBJECT

private:

    bool _edit;

    /*!
     * \brief _worldWidget
     * Pointeur vers le widget d'activité
     */
    VWorldWidget* _worldWidget;

    /**
     * @brief _historyWorldWidget
     * Pointeur vers le widget de l'historique
     */
    VHistoryWorldWidget* _historyWorldWidget;

    QString _worldFileName;

public:

    /*!
     * @brief VWorldController
     * Constructeur
     * @param worldWidget Le widget du monde
     * @param historyWorldWidget Le widget d'historique du monde
     * @param parent
     */
    VWorldController(VWorldWidget* worldWidget,
                    VHistoryWorldWidget* historyWorldWidget,
                    QObject* parent = NULL);

    /**
     * @brief getWorldHistorySet
     * Obtient l'historique du modèle d'activité
     */
    VHistorySet * getWorldHistorySet();

    /**
     * @brief getWorldFutureSet
     * Obtient le future du modèle d'activité
     */
    VHistorySet * getWorldFutureSet();

    void setCurrentEdit(QPointer<VWorldModelElement> currentEdit);

    void loadModel(QString fileName);

    void undo();

    void redo();

    QString getWorldFileName() const;

    void setWorldFileName(const QString value);

    bool isWorldModelSaved();
public slots :
    void historyHasChanged();
};

#endif // VWORLDCONTROLLER_H
