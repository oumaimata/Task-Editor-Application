<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>VActivityController</name>
    <message>
        <location filename="Controller/vactivitycontroller.cpp" line="71"/>
        <source>Activity model loaded</source>
        <translation>Modèle d&apos;activité chargé</translation>
    </message>
</context>
<context>
    <name>VActivityModel</name>
    <message>
        <location filename="Model/VActivity/vactivitymodel.cpp" line="398"/>
        <source>Version changed</source>
        <translation>Version modifiée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vactivitymodel.cpp" line="412"/>
        <source>Namespace added</source>
        <translation>Namespace ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vactivitymodel.cpp" line="422"/>
        <source>Namespace removed</source>
        <translation>Namespace supprimé</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vactivitymodel.cpp" line="449"/>
        <source>Tag added</source>
        <translation>Tag ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vactivitymodel.cpp" line="466"/>
        <source>Tag removed</source>
        <translation>Tag supprimé</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vactivitymodel.cpp" line="477"/>
        <source>Child task added</source>
        <translation>Tâche fille ajoutée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vactivitymodel.cpp" line="487"/>
        <source>Child task removed</source>
        <translation>Tâche fille supprimée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vactivitymodel.cpp" line="496"/>
        <source>Child task modified</source>
        <translation>Tâche fille modifiée</translation>
    </message>
</context>
<context>
    <name>VActivityWidget</name>
    <message>
        <location filename="View/VActivityView/vactivitywidget.ui" line="22"/>
        <source>Add child task</source>
        <translation>Ajouter une tâche fille</translation>
    </message>
    <message>
        <location filename="View/VActivityView/vactivitywidget.ui" line="39"/>
        <source>Remove task</source>
        <translation>Supprimer la tâche</translation>
    </message>
    <message>
        <location filename="View/VActivityView/vactivitywidget.ui" line="53"/>
        <source>Move task up</source>
        <translation>Déplacer vers le haut</translation>
    </message>
    <message>
        <location filename="View/VActivityView/vactivitywidget.ui" line="64"/>
        <source>Move task down</source>
        <translation>Déplacer vers le bas</translation>
    </message>
</context>
<context>
    <name>VApplicationController</name>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="108"/>
        <source>Import an activity model</source>
        <oldsource>Import an ontology</oldsource>
        <translation>Importer un modèle d&apos;activité</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="116"/>
        <source>Model importing success</source>
        <translation>Succès de l&apos;import du modèle</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="117"/>
        <location filename="Controller/vapplicationcontroller.cpp" line="189"/>
        <source>The model has been successfully imported.</source>
        <translation>Le modèle a été importé avec succès.</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="122"/>
        <source>Error during activity model importation</source>
        <translation>Erreur lors de l&apos;import du modèle d&apos;activité</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="151"/>
        <source>Export the activity model</source>
        <translation>Exporter le modèle d&apos;activité</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="180"/>
        <source>Import a world model</source>
        <translation>Importer un modèle du monde</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="188"/>
        <source>Model importation success</source>
        <translation>Succès de l&apos;import du modèle</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="195"/>
        <source>Error during world model importation</source>
        <translation>Erreur lors de l&apos;import du modèle du monde</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="227"/>
        <source>Export the world model</source>
        <translation>Export du modèle du monde</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="287"/>
        <source>- Activity model was not saved</source>
        <oldsource>- Activity model was not saved. 
</oldsource>
        <translation>Le modèle d&apos;activité n&apos;a pas été enregistré</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="289"/>
        <source>World model was not saved</source>
        <oldsource>- World model was not saved.</oldsource>
        <translation>Le modèle du monde n&apos;a pas été enregistré</translation>
    </message>
    <message>
        <location filename="Controller/vapplicationcontroller.cpp" line="293"/>
        <source>Are you sure you want to quit ?</source>
        <translation>Êtes-vous sûr de vouloir quitter ?</translation>
    </message>
</context>
<context>
    <name>VCondition</name>
    <message>
        <source>AND added</source>
        <translation>AND ajouté</translation>
    </message>
    <message>
        <source>AND removed</source>
        <translation>AND supprimé</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vcondition.cpp" line="132"/>
        <source>CLO added</source>
        <translation>CLO Ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vcondition.cpp" line="142"/>
        <source>CLO removed</source>
        <translation>CLO Supprimé</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vcondition.cpp" line="171"/>
        <source>Statement added</source>
        <translation>Statement ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vcondition.cpp" line="181"/>
        <source>Statement removed</source>
        <translation>Statement supprimé</translation>
    </message>
</context>
<context>
    <name>VConditionLogicalOperator</name>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vconditionlogicaloperator.cpp" line="122"/>
        <source>Statement added</source>
        <translation>Statement ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vconditionlogicaloperator.cpp" line="132"/>
        <source>Statement removed</source>
        <translation>Statement supprimé</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vconditionlogicaloperator.cpp" line="156"/>
        <source>Logical operator child added</source>
        <oldsource>Logical condition child added</oldsource>
        <translation>Opérateur logique enfant ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vconditionlogicaloperator.cpp" line="166"/>
        <source>Logical operator child removed</source>
        <oldsource>Logical condition child removed</oldsource>
        <translation>Opérateur logique enfant supprimé</translation>
    </message>
</context>
<context>
    <name>VConditionTabWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.ui" line="20"/>
        <source>Logical operator between conditions:</source>
        <translation>Opérateur logique entre les conditions:</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.ui" line="34"/>
        <source>Tree</source>
        <translation>Arbre</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.ui" line="70"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.cpp" line="390"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.cpp" line="416"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.cpp" line="436"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.ui" line="81"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.cpp" line="390"/>
        <source>Add a triple or a macro or a NOT ?</source>
        <translation>Ajouter un triple ou un macro ou un NOT?</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.cpp" line="416"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vconditiontabwidget.cpp" line="436"/>
        <source>Add a statement or a logical operator (AND, NOT, OR, XOR) ?</source>
        <translation>Ajouter un statement ou un opérateur logique (AND, NOT, OR, XOR) ?</translation>
    </message>
</context>
<context>
    <name>VConditions</name>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vconditions.cpp" line="148"/>
        <source>Condition added</source>
        <translation>Condition ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vconditions.cpp" line="158"/>
        <source>Condition removed</source>
        <translation>Condition supprimé</translation>
    </message>
</context>
<context>
    <name>VConstraint</name>
    <message>
        <location filename="Model/VActivity/VActivityContext/vconstraint.cpp" line="100"/>
        <source>Triple added</source>
        <translation>Triple ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityContext/vconstraint.cpp" line="115"/>
        <source>Triple removed</source>
        <translation>Triple supprimé</translation>
    </message>
</context>
<context>
    <name>VConstructor</name>
    <message>
        <location filename="Model/VActivity/VActivityConstructor/vconstructor.cpp" line="114"/>
        <location filename="Model/VActivity/VActivityConstructor/vconstructor.cpp" line="148"/>
        <source>Constructor type changed</source>
        <translation>Type du constructor modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityConstructor/vconstructor.cpp" line="189"/>
        <source>Relation added</source>
        <translation>Relation ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityConstructor/vconstructor.cpp" line="199"/>
        <source>Relation removed</source>
        <translation>Relatoin supprimé</translation>
    </message>
</context>
<context>
    <name>VConstructorTabWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconstructortabwidget.ui" line="35"/>
        <source>Type :</source>
        <translation></translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconstructortabwidget.ui" line="48"/>
        <source>Relation</source>
        <translation></translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconstructortabwidget.ui" line="57"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vconstructortabwidget.ui" line="68"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
</context>
<context>
    <name>VContextTabWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vcontexttabwidget.ui" line="89"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vcontexttabwidget.ui" line="121"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vcontexttabwidget.ui" line="193"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vcontexttabwidget.ui" line="100"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vcontexttabwidget.ui" line="132"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vcontexttabwidget.ui" line="204"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
</context>
<context>
    <name>VElementCreator</name>
    <message>
        <location filename="View/velementcreator.ui" line="48"/>
        <source>Create</source>
        <translation>Créer</translation>
    </message>
    <message>
        <location filename="View/velementcreator.ui" line="55"/>
        <source>Create and Edit</source>
        <translation>Créer et modifier</translation>
    </message>
    <message>
        <location filename="View/velementcreator.ui" line="62"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="View/velementcreator.ui" line="69"/>
        <source>Name:</source>
        <translation>Nom:</translation>
    </message>
</context>
<context>
    <name>VGeneralTabWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityModelProperties/vgeneraltabwidget.ui" line="26"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityModelProperties/vgeneraltabwidget.ui" line="37"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
</context>
<context>
    <name>VHistoryActivityWidget</name>
    <message>
        <location filename="View/VHistoryView/vhistoryactivitywidget.cpp" line="54"/>
        <source>Activity model history</source>
        <translation>Historique du modèle d&apos;activité</translation>
    </message>
</context>
<context>
    <name>VHistoryBasicWidget</name>
    <message>
        <location filename="View/VHistoryView/vhistorybasicwidget.cpp" line="114"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location filename="View/VHistoryView/vhistorybasicwidget.cpp" line="114"/>
        <source>Label</source>
        <translation>Libéllé</translation>
    </message>
    <message>
        <location filename="View/VHistoryView/vhistorybasicwidget.cpp" line="114"/>
        <source>Description</source>
        <translation>Description</translation>
    </message>
</context>
<context>
    <name>VHistoryWorldWidget</name>
    <message>
        <location filename="View/VHistoryView/vhistoryworldwidget.cpp" line="54"/>
        <source>World model history</source>
        <translation>Historique du modèle du monde</translation>
    </message>
</context>
<context>
    <name>VMacro</name>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vmacro.cpp" line="82"/>
        <location filename="Model/VActivity/VActivityCondition/vmacro.cpp" line="88"/>
        <source>Operator changed</source>
        <translation>Operateur modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vmacro.cpp" line="108"/>
        <source>Var added</source>
        <translation>Var ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vmacro.cpp" line="118"/>
        <source>Var removed</source>
        <translation>Var supprimé</translation>
    </message>
</context>
<context>
    <name>VMainWindow</name>
    <message>
        <location filename="View/vmainwindow.ui" line="67"/>
        <source>Activity Model</source>
        <translation>Modèle d&apos;activité</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="89"/>
        <source>World Model</source>
        <translation>Modèle du monde</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="111"/>
        <source>History</source>
        <translation>Historique</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="152"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="179"/>
        <source>&amp;Tools</source>
        <translation>&amp;Outils</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="183"/>
        <source>Language</source>
        <translation>Langue</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="196"/>
        <source>&amp;Display</source>
        <translation>&amp;Affichage</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="212"/>
        <source>New activity model</source>
        <translation>Nouveau modèle d&apos;activité</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="248"/>
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="263"/>
        <source>Undo</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="278"/>
        <location filename="View/vmainwindow.ui" line="281"/>
        <source>Redo</source>
        <translation>Rétablir</translation>
    </message>
    <message>
        <source>Export the activity model</source>
        <translation>Exporter le modèle d&apos;activité</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="166"/>
        <source>&amp;Edit</source>
        <translation>&amp;Éditer</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="224"/>
        <source>Import an activity model</source>
        <translation>Importer un modèle d&apos;activité</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="236"/>
        <source>Import a world model</source>
        <translation>Importer un modèle du monde</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="296"/>
        <location filename="View/vmainwindow.ui" line="299"/>
        <source>Cut</source>
        <translation>Couper</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="314"/>
        <source>Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="329"/>
        <source>Paste</source>
        <translation>Coller</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="337"/>
        <source>Project Properties</source>
        <translation>Propriétés du projet</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="349"/>
        <source>Find</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="366"/>
        <source>XML Editor</source>
        <translation>Editeur XML</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="380"/>
        <source>Activity XML view</source>
        <translation>Vue XML d&apos;activité</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="391"/>
        <source>Task Tree</source>
        <translation>Arbre des tâches</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="396"/>
        <source>Test query</source>
        <translation>Test requête</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="414"/>
        <source>English</source>
        <translation>Anglais</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="426"/>
        <source>French</source>
        <translation>Français</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="435"/>
        <location filename="View/vmainwindow.ui" line="438"/>
        <location filename="View/vmainwindow.ui" line="441"/>
        <source>Save the activity model as...</source>
        <translation>Enregistrer le modele d&apos;activité sous...</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="444"/>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="453"/>
        <location filename="View/vmainwindow.ui" line="456"/>
        <location filename="View/vmainwindow.ui" line="459"/>
        <source>Save the world model as...</source>
        <translation>Enregistrer le modèle du monde sous...</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="484"/>
        <source>Save the activity model</source>
        <translation>Enregistrer le modèle d&apos;activité</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="487"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="496"/>
        <source>Save the world model</source>
        <translation>Enregistrer le modèle du monde</translation>
    </message>
    <message>
        <source>Export the world model</source>
        <translation>Exporter le modèle du monde</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="470"/>
        <source>World XML view</source>
        <translation>Vue XML du monde</translation>
    </message>
    <message>
        <location filename="View/vmainwindow.ui" line="475"/>
        <source>New </source>
        <translation>Nouveau</translation>
    </message>
</context>
<context>
    <name>VModelPropertiesWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityModelProperties/vmodelpropertieswidget.ui" line="21"/>
        <source>General</source>
        <translation></translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityModelProperties/vmodelpropertieswidget.ui" line="26"/>
        <source>Tags</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>VNotTriples</name>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vnottriples.cpp" line="84"/>
        <source>Triple added</source>
        <translation>Triple ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vnottriples.cpp" line="94"/>
        <source>Triple removed</source>
        <translation>Triple supprimé</translation>
    </message>
</context>
<context>
    <name>VOntologyInterface</name>
    <message>
        <location filename="Model/VOntologyInterface/vontologyinterface.cpp" line="150"/>
        <source>Error : no world model loaded</source>
        <oldsource>Error : no ontology loaded</oldsource>
        <translation>Erreur : Aucun modèle du monde chargé</translation>
    </message>
    <message>
        <location filename="Model/VOntologyInterface/vontologyinterface.cpp" line="158"/>
        <source>Error : query invalid</source>
        <translation>Erreur : requête invalide</translation>
    </message>
    <message>
        <location filename="Model/VOntologyInterface/vontologyinterface.cpp" line="160"/>
        <source>No results</source>
        <translation>Aucun résultats</translation>
    </message>
</context>
<context>
    <name>VOperation</name>
    <message>
        <location filename="Model/VActivity/VActivityOperation/voperation.cpp" line="168"/>
        <source>Action changed</source>
        <translation>Action modifiée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityOperation/voperation.cpp" line="250"/>
        <source>Param added</source>
        <translation>Param ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityOperation/voperation.cpp" line="265"/>
        <source>Param removed</source>
        <translation>Param supprimé</translation>
    </message>
</context>
<context>
    <name>VOperationTabWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/voperationtabwidget.ui" line="52"/>
        <source>Add a new action</source>
        <translation>Ajouter une nouvelle action</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/voperationtabwidget.ui" line="105"/>
        <location filename="View/VActivityView/VActivityTaskProperties/voperationtabwidget.ui" line="137"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/voperationtabwidget.ui" line="116"/>
        <location filename="View/VActivityView/VActivityTaskProperties/voperationtabwidget.ui" line="148"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/voperationtabwidget.cpp" line="351"/>
        <source>Create an action</source>
        <translation>Créer une action</translation>
    </message>
</context>
<context>
    <name>VParam</name>
    <message>
        <location filename="Model/VActivity/VActivityCommon/vparam.cpp" line="48"/>
        <source>Value changed</source>
        <translation>Value modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCommon/vparam.cpp" line="62"/>
        <source>Predicate changed</source>
        <translation>Predicate modifié</translation>
    </message>
</context>
<context>
    <name>VPrefix</name>
    <message>
        <location filename="Model/VActivity/vprefix.cpp" line="50"/>
        <source>Name changed</source>
        <translation>Nom modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vprefix.cpp" line="74"/>
        <source>Iri changed</source>
        <oldsource>Uri changed</oldsource>
        <translation>Iri modifiée</translation>
    </message>
</context>
<context>
    <name>VRefConcept</name>
    <message>
        <location filename="Model/VActivity/VActivityCommon/vrefconcept.cpp" line="60"/>
        <source>Concept changed</source>
        <translation>Concept modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCommon/vrefconcept.cpp" line="74"/>
        <source>Ref changed</source>
        <translation>Ref modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCommon/vrefconcept.cpp" line="88"/>
        <source>Predicate changed</source>
        <translation>Predicate modifié</translation>
    </message>
</context>
<context>
    <name>VRefTagsTabWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vreftagstabwidget.ui" line="23"/>
        <source>Add Tag</source>
        <translation>Ajouter un tag</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vreftagstabwidget.ui" line="34"/>
        <source>Remove Tag</source>
        <translation>Supprimer un tag</translation>
    </message>
</context>
<context>
    <name>VRelation</name>
    <message>
        <location filename="Model/VActivity/VActivityConstructor/vrelation.cpp" line="83"/>
        <source>Lh task changed</source>
        <translation>Tâche lh modifiée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityConstructor/vrelation.cpp" line="96"/>
        <location filename="Model/VActivity/VActivityConstructor/vrelation.cpp" line="102"/>
        <source>Operator changed</source>
        <translation>Operateur modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityConstructor/vrelation.cpp" line="136"/>
        <source>Rh task changed</source>
        <translation>Tâche rh modifiée</translation>
    </message>
</context>
<context>
    <name>VStatement</name>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstatement.cpp" line="126"/>
        <location filename="Model/VActivity/VActivityCondition/vstatement.cpp" line="132"/>
        <source>Type changed</source>
        <translation>Type modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstatement.cpp" line="152"/>
        <source>Triple added</source>
        <translation>Triple ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstatement.cpp" line="162"/>
        <source>Triple removed</source>
        <translation>Triple supprimé</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstatement.cpp" line="186"/>
        <source>NOT triple added</source>
        <translation>NOT triple ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstatement.cpp" line="196"/>
        <source>NOT triple removed</source>
        <translation>Not triple supprimé</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstatement.cpp" line="220"/>
        <source>Macro added</source>
        <translation>Macro ajoutée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstatement.cpp" line="230"/>
        <source>Macro removed</source>
        <translation>Macro supprimée</translation>
    </message>
</context>
<context>
    <name>VStopCondition</name>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstopcondition.cpp" line="144"/>
        <source>Iteration changed</source>
        <translation>Itération modifiée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstopcondition.cpp" line="170"/>
        <location filename="Model/VActivity/VActivityCondition/vstopcondition.cpp" line="178"/>
        <source>Duration changed</source>
        <translation>Durée modifiée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstopcondition.cpp" line="193"/>
        <source>Statement changed</source>
        <translation>Statement modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstopcondition.cpp" line="222"/>
        <source>Satisfaction condition changed</source>
        <translation>Condition de satisfaction modifiée</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstopcondition.cpp" line="241"/>
        <source>Instance changed</source>
        <translation>Instance modifiée</translation>
    </message>
</context>
<context>
    <name>VStopConditions</name>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstopconditions.cpp" line="133"/>
        <source>Stop condition added</source>
        <translation>Stop condition ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vstopconditions.cpp" line="143"/>
        <source>Stop condition removed</source>
        <translation>Stop condition supprimé</translation>
    </message>
</context>
<context>
    <name>VStopConditionsTabWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vstopconditionstabwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vstopconditionstabwidget.ui" line="20"/>
        <source>Logical operator between stop conditions:</source>
        <translation>Opérateur logique entre les stop conditions:</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vstopconditionstabwidget.ui" line="69"/>
        <location filename="View/VActivityView/VActivityTaskProperties/vstopconditionstabwidget.cpp" line="423"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vstopconditionstabwidget.ui" line="80"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vstopconditionstabwidget.ui" line="98"/>
        <source>Tree</source>
        <translation>Arbre</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityTaskProperties/vstopconditionstabwidget.cpp" line="423"/>
        <source>Add a triple or a macro or a NOT ?</source>
        <translation>Ajouter un triple ou un macro ou un NOT?</translation>
    </message>
</context>
<context>
    <name>VTag</name>
    <message>
        <location filename="Model/VActivity/vtag.cpp" line="154"/>
        <source>Id changed</source>
        <translation>Id modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtag.cpp" line="188"/>
        <source>Name changed</source>
        <translation>Nom modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtag.cpp" line="212"/>
        <source>Value changed</source>
        <translation>Value modifié</translation>
    </message>
</context>
<context>
    <name>VTagTabWidget</name>
    <message>
        <location filename="View/VActivityView/VActivityModelProperties/vtagtabwidget.ui" line="51"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityModelProperties/vtagtabwidget.ui" line="65"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityModelProperties/vtagtabwidget.ui" line="102"/>
        <source>Visible</source>
        <translation></translation>
    </message>
    <message>
        <location filename="View/VActivityView/VActivityModelProperties/vtagtabwidget.ui" line="107"/>
        <source>Color</source>
        <translation>Couleur</translation>
    </message>
</context>
<context>
    <name>VTask</name>
    <message>
        <location filename="Model/VActivity/vtask.cpp" line="117"/>
        <source>Name changed</source>
        <translation>Nom modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtask.cpp" line="135"/>
        <source>Iterative changed</source>
        <translation>Iterative modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtask.cpp" line="154"/>
        <source>Optional changed</source>
        <translation>Optional modfié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtask.cpp" line="189"/>
        <source>Constructor changed</source>
        <translation>Constructor modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtask.cpp" line="253"/>
        <source>Ref-Tag value changed</source>
        <translation>Ret-Tag value modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtask.cpp" line="268"/>
        <source>Ref-Tag added</source>
        <translation>Ret-Tag ajouté</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtask.cpp" line="276"/>
        <source>Ref-Tag removed</source>
        <translation>Ref-Tag supprimé</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtask.cpp" line="835"/>
        <source>Parent task changed</source>
        <translation>Tâche parent modifiée</translation>
    </message>
</context>
<context>
    <name>VTaskContainer</name>
    <message>
        <location filename="Model/VActivity/vtaskcontainer.cpp" line="143"/>
        <source>Tasks reordered</source>
        <translation>Tâches réordonées</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtaskcontainer.cpp" line="178"/>
        <source>Tasks moved down</source>
        <translation>Tâches déplacées vers le bas</translation>
    </message>
    <message>
        <location filename="Model/VActivity/vtaskcontainer.cpp" line="212"/>
        <source>Tasks moved up</source>
        <translation>Tâches déplacées vers le haut</translation>
    </message>
</context>
<context>
    <name>VTriple</name>
    <message>
        <location filename="Model/VActivity/VActivityCommon/vtriple.cpp" line="65"/>
        <location filename="Model/VActivity/VActivityCommon/vtriple.cpp" line="74"/>
        <source>Predicate changed</source>
        <translation>Predicate modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCommon/vtriple.cpp" line="95"/>
        <location filename="Model/VActivity/VActivityCommon/vtriple.cpp" line="108"/>
        <location filename="Model/VActivity/VActivityCommon/vtriple.cpp" line="121"/>
        <source>Subject changed</source>
        <translation>Subject modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCommon/vtriple.cpp" line="143"/>
        <location filename="Model/VActivity/VActivityCommon/vtriple.cpp" line="161"/>
        <source>Object changed</source>
        <translation>Object modifié</translation>
    </message>
</context>
<context>
    <name>VVar</name>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vvar.cpp" line="48"/>
        <source>N changed</source>
        <translation>N modifié</translation>
    </message>
    <message>
        <location filename="Model/VActivity/VActivityCondition/vvar.cpp" line="62"/>
        <source>Id changed</source>
        <translation>Id modifié</translation>
    </message>
</context>
<context>
    <name>VWActionClass</name>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwactionclass.cpp" line="81"/>
        <source>Behaviour added</source>
        <translation>Behaviour ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwactionclass.cpp" line="91"/>
        <source>Behaviour removed</source>
        <translation>Behaviour supprimé</translation>
    </message>
</context>
<context>
    <name>VWActionClassEditorWidget</name>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwactionclasseditorwidget.ui" line="35"/>
        <source>Name :</source>
        <translation>Nom :</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwactionclasseditorwidget.ui" line="74"/>
        <source>Behaviour activated</source>
        <translation></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwactionclasseditorwidget.ui" line="93"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwactionclasseditorwidget.ui" line="82"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwactionclasseditorwidget.cpp" line="48"/>
        <source>Parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwactionclasseditorwidget.cpp" line="49"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwactionclasseditorwidget.cpp" line="124"/>
        <source>Create a behaviour</source>
        <translation>Créer un bahaviour</translation>
    </message>
</context>
<context>
    <name>VWBehaviourClass</name>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwbehaviourclass.cpp" line="98"/>
        <location filename="Model/VWorld/VWorldClass/vwbehaviourclass.cpp" line="113"/>
        <source>Behaviour is durative</source>
        <translation>Behaviour est durative</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwbehaviourclass.cpp" line="98"/>
        <location filename="Model/VWorld/VWorldClass/vwbehaviourclass.cpp" line="113"/>
        <source>Behaviour is punctual</source>
        <translation>Behaviour est punctual</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwbehaviourclass.cpp" line="127"/>
        <source>Event added</source>
        <translation>Event ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwbehaviourclass.cpp" line="137"/>
        <source>Event removed</source>
        <translation>Event supprimé</translation>
    </message>
</context>
<context>
    <name>VWBehaviourClassEditorWidget</name>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwbehaviourclasseditorwidget.ui" line="35"/>
        <source>Name :</source>
        <translation>Nom :</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwbehaviourclasseditorwidget.ui" line="55"/>
        <source>Durative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwbehaviourclasseditorwidget.ui" line="62"/>
        <source>Punctual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwbehaviourclasseditorwidget.ui" line="105"/>
        <source>Event triggered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwbehaviourclasseditorwidget.ui" line="126"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwbehaviourclasseditorwidget.ui" line="90"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwbehaviourclasseditorwidget.cpp" line="45"/>
        <source>Parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwbehaviourclasseditorwidget.cpp" line="46"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VWComponentClass</name>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwcomponentclass.cpp" line="139"/>
        <source>New component child</source>
        <translation>Nouveau component fils</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwcomponentclass.cpp" line="148"/>
        <source>Component child removed</source>
        <translation>Component fils supprimé</translation>
    </message>
</context>
<context>
    <name>VWComponentClassEditorWidget</name>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwcomponentclasseditorwidget.ui" line="32"/>
        <source>Name :</source>
        <translation>Nom :</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwcomponentclasseditorwidget.ui" line="48"/>
        <source>has-state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwcomponentclasseditorwidget.cpp" line="44"/>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwcomponentclasseditorwidget.cpp" line="45"/>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwcomponentclasseditorwidget.cpp" line="46"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwcomponentclasseditorwidget.cpp" line="47"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VWComponentNavigatorWidget</name>
    <message>
        <location filename="View/VWorldView/vwcomponentnavigatorwidget.ui" line="20"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VWorldView/vwcomponentnavigatorwidget.ui" line="31"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VWorldView/vwcomponentnavigatorwidget.ui" line="65"/>
        <source>Tree</source>
        <translation>Arbre</translation>
    </message>
</context>
<context>
    <name>VWCompoundOfEditorWidget</name>
    <message>
        <location filename="View/VWorldView/VWorldToolEditorWidget/vwcompoundofeditorwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldToolEditorWidget/vwcompoundofeditorwidget.ui" line="39"/>
        <source>Compound of</source>
        <translation>Composé de</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldToolEditorWidget/vwcompoundofeditorwidget.ui" line="70"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldToolEditorWidget/vwcompoundofeditorwidget.ui" line="81"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
</context>
<context>
    <name>VWEntityClass</name>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwentityclass.cpp" line="74"/>
        <source>Component added</source>
        <translation>Component ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwentityclass.cpp" line="84"/>
        <source>Component removed</source>
        <oldsource>Componen removed</oldsource>
        <translation>Component supprimé</translation>
    </message>
</context>
<context>
    <name>VWEventClass</name>
    <message>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="145"/>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="160"/>
        <source>Event is durative</source>
        <translation>Event est durative</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="145"/>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="160"/>
        <source>Event is punctual</source>
        <translation>Event est punctual</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="174"/>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="189"/>
        <source>Event is endogenous</source>
        <translation>Event est endogenous</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="174"/>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="189"/>
        <source>Event is exogenous</source>
        <translation>Event est exogenous</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="202"/>
        <source>Begining event changed</source>
        <translation>Event de début modfié</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="216"/>
        <source>Ending event changed</source>
        <translation>Event de fin modifié</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="231"/>
        <source>Behaviour added</source>
        <translation>Behaviour ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vweventclass.cpp" line="241"/>
        <source>Behaviour removed</source>
        <translation>Behaviour supprimé</translation>
    </message>
</context>
<context>
    <name>VWEventClassEditorWidget</name>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="39"/>
        <source>Name :</source>
        <translation>Nom :</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="107"/>
        <source>Exogenous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="46"/>
        <source>Begin with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="53"/>
        <source>End with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="87"/>
        <source>Durative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="94"/>
        <source>Punctual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="114"/>
        <source>Endogenous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="145"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="169"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.ui" line="184"/>
        <source>Behaviour activated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.cpp" line="45"/>
        <source>Parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vweventclasseditorwidget.cpp" line="46"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VWInstance</name>
    <message>
        <location filename="Model/VWorld/VWorldInstance/vwinstance.cpp" line="233"/>
        <source>Property value changed</source>
        <translation>Valeur de propriété modifiée</translation>
    </message>
</context>
<context>
    <name>VWInstanceEditorWidget</name>
    <message>
        <location filename="View/VWorldView/VWorldInstanceEditorView/vwinstanceeditorwidget.ui" line="35"/>
        <source>Name :</source>
        <translation>Nom :</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldInstanceEditorView/vwinstanceeditorwidget.ui" line="49"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldInstanceEditorView/vwinstanceeditorwidget.ui" line="82"/>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldInstanceEditorView/vwinstanceeditorwidget.ui" line="87"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldInstanceEditorView/vwinstanceeditorwidget.ui" line="92"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VWInstanceTabWidget</name>
    <message>
        <location filename="View/VWorldView/vwinstancetabwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/vwinstancetabwidget.ui" line="30"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/vwinstancetabwidget.ui" line="35"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VWNamespaceTabWidget</name>
    <message>
        <location filename="View/VWorldView/vwnamespacetabwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/vwnamespacetabwidget.ui" line="20"/>
        <source>Namespace:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VWObjectClass</name>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwobjectclass.cpp" line="131"/>
        <source>Child object added</source>
        <translation>Object fils ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwobjectclass.cpp" line="141"/>
        <source>Child object removed</source>
        <translation>Object fils supprimé</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwobjectclass.cpp" line="215"/>
        <source>Type changed</source>
        <translation>Type modifié</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwobjectclass.cpp" line="242"/>
        <source>Instance added</source>
        <translation>Instance ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/VWorldClass/vwobjectclass.cpp" line="252"/>
        <source>Instance removed</source>
        <translation>Instance supprimé</translation>
    </message>
</context>
<context>
    <name>VWObjectClassEditorWidget</name>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwobjectclasseditorwidget.ui" line="35"/>
        <source>Name :</source>
        <translation>Nom :</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwobjectclasseditorwidget.ui" line="65"/>
        <source>Concrete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwobjectclasseditorwidget.ui" line="82"/>
        <source>Create an instance</source>
        <translation>Créer une instance</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwobjectclasseditorwidget.ui" line="58"/>
        <source>Abstract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwobjectclasseditorwidget.ui" line="72"/>
        <source>Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwobjectclasseditorwidget.cpp" line="46"/>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldClassEditorView/vwobjectclasseditorwidget.cpp" line="47"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VWProperties</name>
    <message>
        <location filename="Model/VWorld/vwproperties.cpp" line="36"/>
        <source>All properties removed</source>
        <translation>Toutes les propriétés ont été retirées</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vwproperties.cpp" line="83"/>
        <source>Property added</source>
        <translation>Propriété ajoutée</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vwproperties.cpp" line="94"/>
        <source>Property removed</source>
        <translation>Propriété supprimée</translation>
    </message>
</context>
<context>
    <name>VWPropertiesEditorWidget</name>
    <message>
        <location filename="View/VWorldView/VWorldToolEditorWidget/vwpropertieseditorwidget.ui" line="83"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VWorldView/VWorldToolEditorWidget/vwpropertieseditorwidget.ui" line="32"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
</context>
<context>
    <name>VWProperty</name>
    <message>
        <location filename="Model/VWorld/vwproperty.cpp" line="91"/>
        <source>Name changed</source>
        <translation>Nom modifié</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vwproperty.cpp" line="143"/>
        <source>Type changed</source>
        <translation>Type modifié</translation>
    </message>
</context>
<context>
    <name>VWPropertyType</name>
    <message>
        <location filename="Model/VWorld/vwpropertytype.cpp" line="40"/>
        <source>Type changed</source>
        <translation>Type modifié</translation>
    </message>
</context>
<context>
    <name>VWPropertyValue</name>
    <message>
        <location filename="Model/VWorld/vwpropertyvalue.cpp" line="118"/>
        <location filename="Model/VWorld/vwpropertyvalue.cpp" line="137"/>
        <location filename="Model/VWorld/vwpropertyvalue.cpp" line="156"/>
        <location filename="Model/VWorld/vwpropertyvalue.cpp" line="172"/>
        <source>Property value changed</source>
        <translation>Valeur de propriété modifiée</translation>
    </message>
</context>
<context>
    <name>VWRequestTabWidget</name>
    <message>
        <location filename="View/VWorldView/vwrequesttabwidget.ui" line="52"/>
        <source>Execute</source>
        <translation>Exécuter</translation>
    </message>
</context>
<context>
    <name>VWorldController</name>
    <message>
        <location filename="Controller/vworldcontroller.cpp" line="63"/>
        <source>World model loaded</source>
        <oldsource>Activity model loaded</oldsource>
        <translation>Modèle du monde chargé</translation>
    </message>
</context>
<context>
    <name>VWorldModel</name>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="611"/>
        <source>Error : Model invalid</source>
        <translation>Erreur : modèle invalide</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="636"/>
        <source>Namespace changed</source>
        <translation>Namespace modifié</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="691"/>
        <source>Component added</source>
        <translation>Component ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="708"/>
        <source>Component removed</source>
        <translation>Component supprimé</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="766"/>
        <source>Action added</source>
        <translation>Action ajoutée</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="783"/>
        <source>Action removed</source>
        <translation>Action supprimée</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="819"/>
        <source>Behaviour added</source>
        <translation>Behaviour modifié</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="836"/>
        <source>Behaviour removed</source>
        <translation>Behaviour supprimé</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="872"/>
        <source>Object added</source>
        <translation>Object ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="889"/>
        <source>Object removed</source>
        <translation>Object supprimé</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="990"/>
        <source>Event added</source>
        <translation>Event ajouté</translation>
    </message>
    <message>
        <location filename="Model/VWorld/vworldmodel.cpp" line="1007"/>
        <source>Event removed</source>
        <translation>Event supprimé</translation>
    </message>
</context>
<context>
    <name>VWorldModelElement</name>
    <message>
        <location filename="Model/VWorld/vworldmodelelement.cpp" line="78"/>
        <source>Name changed</source>
        <translation>Nom modifié</translation>
    </message>
</context>
<context>
    <name>VWorldNavigatorWidget</name>
    <message>
        <location filename="View/VWorldView/vworldnavigatorwidget.ui" line="30"/>
        <source>Tree</source>
        <translation>Arbre</translation>
    </message>
    <message>
        <location filename="View/VWorldView/vworldnavigatorwidget.ui" line="51"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="View/VWorldView/vworldnavigatorwidget.ui" line="62"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
</context>
<context>
    <name>VWorldWidget</name>
    <message>
        <location filename="View/VWorldView/vworldwidget.ui" line="72"/>
        <source>XML view</source>
        <translation>Vue XML</translation>
    </message>
</context>
</TS>
