#pragma once
#ifndef VHISTORYBASICWIDGET_H
#define VHISTORYBASICWIDGET_H

#include <QWidget>

class VHistorySet;

namespace Ui {
class VHistoryBasicWidget;
}

/**
 * @brief The VHistoryBasicWidget class
 * Classe de base permettant l'affichage de l'historique
 */
class VHistoryBasicWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VHistoryBasicWidget *ui;
    
public:
    explicit VHistoryBasicWidget(QWidget *parent = 0);
    ~VHistoryBasicWidget();

    /**
     * @brief setTitle Définit le titre du widget
     * @param s Le titre
     */
    void setTitle(const QString s);

    /**
     * @brief setHistorySet
     * Définit le VHistorySet utilisé pour l'historique
     * @param historySet L'historique
     */
    void setHistorySet(VHistorySet* historySet);

    /**
     * @brief getTitle Obtient le titre du widget
     * @return Le titre
     */
    QString getTitle();

private:
    /**
     * @brief historySet
     * L'historique
     */
    VHistorySet* historySet;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief VTaskActionPickingDialog::retranslate
     * Traduction des widgets avec tr() hors du designer
     */
    void retranslate();

private slots:

    /**
     * @brief updateDisplay
     * Met a jour le tableau en fonction de historySet
     */
    void updateDisplay();
};

#endif // VHISTORYBASICWIDGET_H
