#include "vwcomponentclasseditorwidget.h"
#include "ui_vwcomponentclasseditorwidget.h"

#include "Model/VWorld/vwproperty.h"
#include "Model/VWorld/vwproperties.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"

VWComponentClassEditorWidget::VWComponentClassEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWComponentClassEditorWidget),
    _edit(false),
    _componentClass(NULL)
{
    ui->setupUi(this);
    retranslate();
}

VWComponentClassEditorWidget::~VWComponentClassEditorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWComponentClassEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWComponentClassEditorWidget::retranslate()
{
    ui->propertiesEditorWidget->setLabelCol(0, tr("Property"));
    ui->propertiesEditorWidget->setLabelCol(1, tr("Range"));
    ui->statePropertiesEditorWidget->setLabelCol(0, tr("Name"));
    ui->statePropertiesEditorWidget->setLabelCol(1, tr("Value"));
}

void VWComponentClassEditorWidget::setComponentClass(VWComponentClass * componentClass)
{
    if(componentClass != _componentClass)
    {
        _componentClass = componentClass;
    }
    updateDisplay();
}

void VWComponentClassEditorWidget::updateDisplay()
{
    _edit = true;
    ui->nameLineEdit->setText("");
    ui->hasStateCheckBox->setCheckState(Qt::Unchecked);
    ui->statePropertiesEditorWidget->setEnabled(false);
    if(_componentClass == NULL) return;
    ui->nameLineEdit->setText(_componentClass->getName());
    ui->propertiesEditorWidget->setProperties(_componentClass->getProperties());
    if(_componentClass->getStateProperties()->getProperties().count() != 0)
    {
        ui->hasStateCheckBox->setCheckState(Qt::Checked);
        ui->statePropertiesEditorWidget->setEnabled(true);
    }
    else
    {
        ui->hasStateCheckBox->setCheckState(Qt::Unchecked);
    }
    ui->statePropertiesEditorWidget->setProperties(_componentClass->getStateProperties());
    _edit = false;
}

void VWComponentClassEditorWidget::on_nameLineEdit_editingFinished()
{
    _componentClass->setName(ui->nameLineEdit->text());
}

void VWComponentClassEditorWidget::on_hasStateCheckBox_toggled(bool checked)
{
    if(_edit) return;
    if(checked)
    {
        VWProperty * property = new VWProperty();
        _componentClass->getStateProperties()->addProperty(property);
    }
    else
    {
        _componentClass->getStateProperties()->clear();
    }
}
