#pragma once
#ifndef VHISTORYWORLDWIDGET_H
#define VHISTORYWORLDWIDGET_H

#include <QWidget>

class VHistorySet;

namespace Ui {
class VHistoryWorldWidget;
}

/**
 * @brief The VHistoryWorldWidget class
 * Classe permettant d'afficher l'historique pour la partie monde
 */
class VHistoryWorldWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VHistoryWorldWidget *ui;
    
public:
    explicit VHistoryWorldWidget(QWidget *parent = 0);
    ~VHistoryWorldWidget();

    /**
     * @brief setHistorySet
     * Définit le VHistorySet utilisé pour l'historique
     * @param historySet L'historique
     */
    void setHistorySet(VHistorySet* historySet);
    
private:
    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief VHistoryWorldWidget::retranslate
     * Traduction des widgets avec tr() hors du designer
     */
    void retranslate();
};

#endif // VHISTORYWORLDWIDGET_H
