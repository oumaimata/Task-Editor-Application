#pragma once
#ifndef VWPROPERTIESEDITORWIDGET_H
#define VWPROPERTIESEDITORWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QComboBox>
#include <QSignalMapper>

class VWProperties;
class VWPropertyType;

namespace Ui {
class VWPropertiesEditorWidget;
}

/**
 * @brief The VWPropertiesEditorWidget class
 * Class permettant l'édition de VProperties
 * Pour component * 2
 *      object
 *      action
 */
class VWPropertiesEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWPropertiesEditorWidget *ui;

    bool _edit;

    QString _type;

    VWProperties * _properties;
    
public:
    explicit VWPropertiesEditorWidget(QWidget *parent = 0);
    ~VWPropertiesEditorWidget();

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent* event);

    /**
     * @brief setLabelCol
     * Définie le nom de la colonne
     * @param column Le numéro de la colonne à patir de 0
     * @param label Le nom de la colonne
     */
    void setLabelCol(int column, QString label);

    void setProperties(VWProperties * properties);

    QString getType() const;

    bool getIsShared() const;

    void updateDisplay();

    QComboBox * getTypeCombo(VWPropertyType * type);
    
private slots:
    void on_addPropertyButton_clicked();

    void on_removePropertyButton_clicked();

    void on_propertyTableWidget_itemChanged(QTableWidgetItem *item);

    /**
     * @brief typeChanged
     * Gère les modifications des combos de type
     * @param position La position de la combo dans la table
     */
    void typeChanged(const QString & position);
};

#endif // VWPROPERTIESEDITORWIDGET_H
