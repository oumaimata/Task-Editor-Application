#include "vspeechact.h"
#include "../../../Controller/vtracecontroller.h"
#include <qdom.h>

VSpeechAct::VSpeechAct(QObject *parent):
    VActivityModelElement(parent),
    _addressee(NULL),
    _subject(NULL)
{

}
VSpeechAct::VSpeechAct(const VSpeechAct& speechAct, QObject* parent):
VActivityModelElement(parent)
{
    _addressee = speechAct._addressee->clone();
    _subject = speechAct._subject->clone();
}

VSpeechAct::~VSpeechAct()
{
    if (_addressee != NULL)delete _addressee;
    if(_subject != NULL) delete _subject;

}
VAddressee *VSpeechAct::getAddressee() const
{
    return _addressee;
}

void VSpeechAct::setAddressee(VAddressee *addressee)
{
    _addressee = addressee;
    connect(addressee, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    onModified(tr("Speech act modified"));

}
VSubject* VSpeechAct::getSubject() const
{
    return _subject;
}

void VSpeechAct::setSubject(VSubject *subject)
{
    _subject = subject;
    connect(subject, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    onModified(tr("Speech act modified"));
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VSpeechAct::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VSpeechAct::parseDom()", "<" + elem.tagName() + ">");

    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture des addressees
            if(element.tagName() == "Addressees")
            {
                setAddressee(new VAddressee());
                _addressee->parseDom(element);
            }
            // Lecture du subject
            else if(element.tagName() == "Subject")
            {
                setSubject(new VSubject());
                _subject->parseDom(element);
            }
        }
        node = node.nextSibling();
    }

    VTraceController::get()->Info("VSpeechAct::parseDom()", "</" + elem.tagName() + ">");
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VSpeechAct::ToXml(QString tabulation)
{
    QString RetVal = tabulation;
    RetVal += "<speechAct>\n";
    QString addresseeXml = (getAddressee()->ToXml("\t" + tabulation));
    RetVal += addresseeXml;
    QString subjectXml = _subject->ToXml("\t" + tabulation);
    RetVal += subjectXml + tabulation +"</speechAct>";
    return RetVal;
}


VSpeechAct *VSpeechAct::clone() const
{
    return new VSpeechAct(*this);
}
