#pragma once
#ifndef VWCOMPOUNDOFEDITORWIDGET_H
#define VWCOMPOUNDOFEDITORWIDGET_H

#include <QWidget>

class VWEntityClass;

namespace Ui {
class VWCompoundOfEditorWidget;
}

class VWCompoundOfEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWCompoundOfEditorWidget *ui;

    bool _edit;

    VWEntityClass * _entity;
    
public:
    explicit VWCompoundOfEditorWidget(QWidget *parent = 0);
    ~VWCompoundOfEditorWidget();

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent* event);

    void setEntity(VWEntityClass * entity);

    void updateDisplay();
    
private slots:
    void on_addComponentButton_clicked();

    void on_removeComponentButton_clicked();
};

#endif // VWCOMPOUNDOFEDITORWIDGET_H
