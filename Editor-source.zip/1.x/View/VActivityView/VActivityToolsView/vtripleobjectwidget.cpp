#include "vtripleobjectwidget.h"

#include "Model/vapplicationmodel.h"
#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivityCondition/vstatement.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"
#include "Model/VWorld/VWorldInstance/vwinstance.h"

VTripleObjectWidget::VTripleObjectWidget(VStatement * statement, VTriple * triple, QWidget *parent) :
    QComboBox(parent),
    _triple(triple),
    _statement(statement)
{
    this->setEditable(true);
    if(_statement->getType() == domain)
    {
        VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
        QList<VWInstance *> instances = worldModel->getAllInstances();
        QList<VWComponentClass *> components = worldModel->getAllComponents();
        QList<VWObjectClass *> objects = worldModel->getObjects();

        addItem("");
        addItem("domain:Unkown");
        addItem("domain:True");
        addItem("domain:False");

        foreach(VWInstance * instance, instances)
        {
            addItem(instance->getName(), instance->getUid());
        }

        foreach(VWComponentClass * component, components)
        {
            addItem(component->getName(), component->getUid());
        }

        foreach(VWObjectClass * object, objects)
        {
            addItem(object->getName(), object->getUid());
        }
        setCurrentText(_triple->getObject());
    }
    connect(this, SIGNAL(currentIndexChanged(int)), this, SLOT(onCurrentIndexChanged(int)));
}

void VTripleObjectWidget::onCurrentIndexChanged(int index)
{
    QString value = this->itemText(index);
    QString uid = this->itemData(index).toString();
    VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWInstance * instance = worldModel->getInstanceByUid(uid.toLong());
    VWComponentClass * component = worldModel->getComponentByUid(uid.toLong());
    VWObjectClass * object = worldModel->getObjectByUid(uid.toLong());
    if(_statement->getType() == domain)
    {
        if(instance != NULL)
        {
            _triple->setObject(instance);
        }
        else if(component != NULL)
        {
            _triple->setObject(component);
        }
        else if(object != NULL)
        {
            _triple->setObject(object);
        }
        else
        {
            _triple->setObject(value);
        }
    }
}
