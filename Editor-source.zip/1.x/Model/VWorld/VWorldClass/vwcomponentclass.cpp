#include "vwcomponentclass.h"

#include "../vwproperty.h"
#include "../vwproperties.h"
#include "../vwpropertytype.h"

VWComponentClass::VWComponentClass(QObject *parent) :
    VWorldModelElement(parent),
    _parent(NULL)
{
    setName("Component" + QString::number(getUid()));
    _properties = new VWProperties();
    _properties->setType("component");
    _properties->setWorldModelElement(this);
    _properties->setIsShared(true);
    connect(_properties, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    _stateProperties = new VWProperties();
    _stateProperties->setIsShared(false);
    _stateProperties->setWorldModelElement(this);
    _stateProperties->setComponent(this);
    connect(_stateProperties, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

}

/**
 * @brief VWComponentClass
 * @param o L'objet à copier
 */
VWComponentClass::VWComponentClass(const VWComponentClass& o) :
    VWorldModelElement(o),
    _parent(o._parent)
{
    _childs = o._childs;
    _properties = o._properties;
    _stateProperties = o._stateProperties;
}

/**
 * @brief ~VWComponentClass
 * Destructeur
 */
VWComponentClass::~VWComponentClass()
{
    while(_childs.count() > 0)
    {
        VWComponentClass * child = _childs.first();
        _childs.pop_front();
        delete child;
    }
    delete _properties;
    delete _stateProperties;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWComponentClass::ParseDom(QDomElement elem)
{
    VWorldModelElement::ParseDom(elem);
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWComponentClass::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<owl:Class rdf:ID=\"" + getName() + "\">\n";
    if(_parent == NULL) RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#Component\"/>\n";
    else RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"#" + _parent->getName() + "\"/>\n";
    RetVal += tabulation + "</owl:Class>\n";

    // liste des states properties
    if(_stateProperties != NULL && _stateProperties->getProperties().count() != 0)
    {
        // Création du state
        RetVal += tabulation+ "<owl:Class rdf:ID=\"" + getState() + "\">\n";
        RetVal += tabulation + "\t" + "<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#State\"/>\n";
        RetVal += tabulation + "</owl:Class>\n";

        // Création du has-state
        RetVal += tabulation+ "<owl:ObjectProperty rdf:ID=\"" + getHasState() + "\">\n";
        RetVal += tabulation + "\t" + "<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#has-state\"/>\n";
        RetVal += tabulation + "\t" + "<rdfs:domain rdf:resource=\"#" + getName() + "\"/>\n";
        RetVal += tabulation + "\t" + "<rdfs:range rdf:resource=\"#" + getState() + "\"/>\n";
        RetVal += tabulation + "</owl:ObjectProperty>\n";

        foreach(VWProperty * property, _stateProperties->getProperties())
        {
            if(property != NULL)
            {
                RetVal += tabulation + "<owl:ObjectProperty rdf:ID=\"" + property->getName() + "\">\n";
                RetVal += tabulation + "\t" + "<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#StateAttribute\"/>\n";
                RetVal += tabulation + "\t" + "<rdfs:domain rdf:resource=\"#" + getState() + "\"/>\n";
                RetVal += tabulation + "\t" + "<rdfs:range rdf:resource=\"" + property->getType()->toXml() + "\"/>\n";
                RetVal += tabulation + "</owl:ObjectProperty>\n";
            }
        }
    }

    return RetVal;
}

QString VWComponentClass::getState() const
{
    return getName() + "State";
}

QString VWComponentClass::getHasState() const
{
    return "has-" + getName() + "-state";
}

void VWComponentClass::setParent(VWComponentClass * parent)
{
    if(parent != _parent)
    {
        _parent = parent;
        onModified(NULL);
    }
}
VWComponentClass * VWComponentClass::getParent() const
{
    return _parent;
}

void VWComponentClass::addChild(VWComponentClass * child)
{
    if(child != NULL)
    {
        _childs.append(child);
        child->setParent(this);
        connect(child, SIGNAL(modified(QString, QObject*)),this, SLOT(onModified(QString, QObject*)));
        onModified(tr("New component child"));
    }
}
void VWComponentClass::removeChild(VWComponentClass * child)
{
    if(_childs.contains(child))
    {
        _childs.removeAll(child);
        disconnect(child, SIGNAL(modified(QString, QObject*)),this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Component child removed"));
    }
}
QList<VWComponentClass *> VWComponentClass::getChilds() const
{
    return _childs;
}

QList<VWComponentClass *> VWComponentClass::getAllChilds() const
{
    VWComponentClass * child;
    QList<VWComponentClass *> RetVal;
    RetVal.append(getChilds());
    foreach(child, _childs)
    {
        RetVal.append(child->getAllChilds());
    }
    return RetVal;
}

VWComponentClass * VWComponentClass::getChildByUid(qint64 uid) const
{
    VWComponentClass * component;
    foreach(component, _childs)
    {
        if(component->getUid() == uid) return component;
        else
        {
            VWComponentClass * child = component->getChildByUid(uid);
            if(child != NULL) return child;
        }
    }
    return NULL;
}

VWComponentClass * VWComponentClass::getChildByName(QString name) const
{
    VWComponentClass * component;
    foreach(component, _childs)
    {
        if(component->getName() == name) return component;
        else
        {
            VWComponentClass * child = component->getChildByName(name);
            if(child != NULL) return child;
        }
    }
    return NULL;
}

QPointer<VWProperty> VWComponentClass::addProperty(QDomElement elem)
{
    if(_properties != NULL) return _properties->addProperty(elem);
    return QPointer<VWProperty>();
}

void VWComponentClass::addStateProperty(QDomElement elem)
{
    if(_stateProperties != NULL) _stateProperties->addProperty(elem);
}

VWProperties * VWComponentClass::getProperties() const
{
    return _properties;
}

VWProperties * VWComponentClass::getStateProperties() const
{
    return _stateProperties;
}

QList<QPointer<VWProperty> > VWComponentClass::getAllProperties() const
{
    QList<QPointer<VWProperty> > properties;
    properties.append(_properties->getProperties());
    properties.append(_stateProperties->getProperties());
    if(_parent != NULL) properties.append(_parent->getAllProperties());
    return properties;
}

void VWComponentClass::onComponentModified()
{
    onComponentModified(NULL);
}

void VWComponentClass::onComponentModified(QString message, QObject * object)
{
    // componentModified(message, object); // TODO check if error ???
    foreach(VWComponentClass * child, _childs)
    {
        child->onComponentModified(message, object);
    }
}

void VWComponentClass::onModified()
{
    onModified(NULL);
}

void VWComponentClass::onModified(QString message, QObject * object)
{
    if(_edit || object == this) return; // Evite de boucler
    VWorldModelElement::onModified(message, object);
    if(_parent == NULL) onComponentModified(message, object); // On fait redescendre l'information à tous les objects enfants qui héritent.
}
