#include "vactivitycontroller.h"

#include <iostream>

#include "vtracecontroller.h"
#include "View/VActivityView/vactivitywidget.h"
#include "View/VActivityView/VActivityScene/vtaskitem.h"
#include "View/VHistoryView/vhistoryactivitywidget.h"
#include "Model/vapplicationmodel.h"
#include "Model/VActivity/VActivityCondition/vbasiscondition.h"

/*!
 * @brief VActivityController
 * Constructeur
 * @param activityWidget le widget d'activité
 * @param parent
 */

VActivityController::VActivityController(VActivityWidget* activityWidget,
                                         VHistoryActivityWidget* historyActivityWidget,
                                         QObject* parent) :
    QObject(parent),
    _edit(false),
    _isCut(false),
    _activityWidget(activityWidget),
    _historyActivityWidget(historyActivityWidget),
    _activityFileName("")
{
    VTraceController::get()->Debug("VActivityController::VActivityController()", "Begin");

    connect(_activityWidget, SIGNAL(taskAddingAsked(VTask*)), this, SLOT(addTask(VTask*)));
    connect(_activityWidget, SIGNAL(taskRemovalAsked(QPointer<VTask>)), this, SLOT(removeTask(QPointer<VTask>)));
    connect(getActivityHistorySet(), SIGNAL(hasChanged()), this, SLOT(historyHasChanged()));

    _historyActivityWidget->setHistorySet(getActivityHistorySet());

    VTraceController::get()->Debug("VActivityController::VActivityController()", "End");
}

/**
 * @brief getActivityHistorySet
 * Obtient l'historique du modèle d'activité
 */
VHistorySet * VActivityController::getActivityHistorySet()
{
    return &VApplicationModel::getInstance()->getActivityHistorySet();
}

/**
 * @brief getActivityFutureSet
 * Obtient le future du modèle d'activité
 */
VHistorySet * VActivityController::getActivityFutureSet()
{
    return &VApplicationModel::getInstance()->getActivityFutureSet();
}

void VActivityController::loadModel(QString fileName)
{
    QFile xml_doc(fileName);// On choisit le fichier contenant les informations XML.
    if(!xml_doc.open(QIODevice::ReadOnly))// Si l'on n'arrive pas à ouvrir le fichier XML.
    {
        return;
    }
    QTextStream flux(&xml_doc);
    QString xml_model = flux.readAll();
    xml_doc.close(); // Dans tous les cas, on doit fermer le document XML : on n'en a plus besoin, tout est compris dans xml_model

    VActivityModel * model = &VApplicationModel::getInstance()->getActivityModel();
    model->loadModel(xml_model);
    model->onModified(tr("Activity model loaded"));
}

void VActivityController::undo()
{
    _edit = true;
    VActivityModel * model = &VApplicationModel::getInstance()->getActivityModel();
    if(getActivityHistorySet()->size() > 0)
    {
        VHistoryState historyState = getActivityHistorySet()->pop_back();
        getActivityFutureSet()->push_back(historyState.getLabel(), historyState.getDesc(), historyState.getValue());
        if(getActivityHistorySet()->size() > 0)
        {
            QString xml_model = getActivityHistorySet()->lastValue();
            model->loadModel(xml_model);
        }
        else
        {
            model->resetModel();
            model->setDefaultActivityModel();
        }
        model->onModified(NULL);
    }
    _edit = false;
}

void VActivityController::redo()
{
    _edit = true;
    VActivityModel * model = &VApplicationModel::getInstance()->getActivityModel();
    if(getActivityFutureSet()->size() > 0)
    {
        VHistoryState historyState = getActivityFutureSet()->pop_back();
        getActivityHistorySet()->push_back(historyState.getLabel(), historyState.getDesc(), historyState.getValue());
        model->loadModel(historyState.getValue());
        model->onModified(NULL);
    }
    _edit = false;
}

void VActivityController::cut()
{
    VTraceController::get()->Debug("VActivityController::cut()", "Begin");
    foreach(QPointer<VTask> task, _taskClipboard)
    {
        task->setCut(false);
    }
    _taskClipboard.clear();
    foreach(QPointer<VTask> task, _activityWidget->getSelectedTasks())
    {
        task->setCut(true);
        _taskClipboard.append(task);
        VTraceController::get()->Info("VActivityController::cut()", "Task added to clipboard " + task->getId());
    }
    _isCut = true;
    VTraceController::get()->Debug("VActivityController::cut()", "End");
}

void VActivityController::copy()
{
    VTraceController::get()->Debug("VActivityController::copy()", "Begin");
    _taskClipboard.clear();
    foreach(QPointer<VTask> task, _activityWidget->getSelectedTasks())
    {
        VTraceController::get()->Info("VActivityController::copy()", "Task added to clipboard " + task->getId());
        _taskClipboard.append(task->clone());
        VTraceController::get()->Info("VActivityController::copy()", "Task added to clipboard " + task->getId());
    }
    _isCut = false;
    VTraceController::get()->Debug("VActivityController::copy()", "End");
}

void VActivityController::paste()
{
    VTraceController::get()->Debug("VActivityController::paste()", "Begin");
    QList<QPointer<VTask> > selectedTasks = _activityWidget->getSelectedTasks();
    if(selectedTasks.length() == 1)
    {
        QPointer<VTask> selectedTask = selectedTasks[0];
        foreach(QPointer<VTask> task, _taskClipboard)
        {
            if(!task->IsAnscesterOf(selectedTask))
            {
                if(_isCut)
                {
                    task->setCut(false);
                    task->setParent(selectedTask);
                    VTraceController::get()->Info("VActivityController::paste()", "Task pasted " + task->getId());
                    VTaskItem * selectedTaskItem = _activityWidget->getTaskItem(task);
                    VTaskItem * taskItem = _activityWidget->getTaskItem(selectedTask);
                    if(taskItem != NULL && selectedTaskItem != NULL && selectedTaskItem != taskItem)
                    {
                        VTaskItem * oldParent = taskItem->getParentTaskItem();
                        taskItem->updateSubitemsPositions();
                        if(oldParent != NULL)
                        {
                            oldParent->updateSubitemsPositions();
                        }
                    }
                }
                else
                {
                    addChildTask(selectedTask, task);
                    VTraceController::get()->Info("VActivityController::paste()", "Task pasted " + task->getId());
                }
            }
        }
        _taskClipboard.clear();
    }
    VTraceController::get()->Debug("VActivityController::paste()", "End");
}

QString VActivityController::getNextValidTaskId(VTask * task, QString id) const
{
    int max = 0;
    QRegExp regExp = QRegExp("^" + id + "(_\\((\\d*)\\))?$");
    QList<VTask *> tasks = VApplicationModel::getInstance()->getActivityModel().getAllChildTasks();
    foreach(VTask * t, tasks)
    {
        if(t != task && regExp.indexIn(t->getId()) != -1)
        {
            QString index =  regExp.cap(2);
            if(index != NULL)
            {
                max = qMax(max, index.toInt() + 1);
            }
            else
            {
                max = qMax(max, 1);
            }
        }
    }
    return max == 0 ? id : id + "_(" + QString::number(max) + ")";
}

qint64 VActivityController::getNextValidConditionId(VBasisCondition * basisCondition, qint64 id) const
{
    QList<VBasisCondition *> basisConditions = VApplicationModel::getInstance()->getActivityModel().getAllBasisConditions();
    foreach(VBasisCondition * c, basisConditions)
    {
        if(c != basisCondition && c->getId() == id)
        {
            return basisCondition->getId();
        }
    }
    return id;
}

void VActivityController::addChildTask(VTask * parent, VTask * task)
{
    parent->beginEdit();
    parent->addChildTask(task);
    foreach(VTask * childTask, task->getChildTasks())
    {
        addChildTask(task, childTask);
    }
    parent->endEdit();
}

void VActivityController::historyHasChanged()
{
    if(!_edit) getActivityFutureSet()->clear();
}

/*!
 * @brief addTask Permet l'ajout d'une tache
 * @param parentTask La tache parente
 */
void VActivityController::addTask(VTask* parentTask)
{
    VTraceController::get()->Debug("VActivityController::addTask()", "Begin");
    // If no parent, add a task to the activity model.
    if (parentTask == NULL)
    {
        VTraceController::get()->Info("VActivityController::addTask()", "add task to the activity model");
        VActivityModel& tmp = VApplicationModel::getInstance()->getActivityModel();
        tmp.addChildTask();
    }
    // Else, add a task to the parent.
    else
    {
        VTraceController::get()->Info("VActivityController::addTask()", "add task to the parentTask given in argument");
        parentTask->addChildTask();
    }
    VTraceController::get()->Debug("VActivityController::addTask()", "End");
}

/*!
 * @brief removeTask Permet la suppression d'une tache
 * @param task La tache
 */
void VActivityController::removeTask(QPointer<VTask> task)
{
    VTraceController::get()->Debug("VActivityController::removeTask()", "Begin");

    if(task != NULL)
    {
        VTaskContainer* parent = qobject_cast<VTaskContainer *>(task->parent());
        if (parent != NULL)
        {
            VTraceController::get()->Info("VActivityController::removeTask()", "call removeChildTask on the parent task");
            parent->removeChildTask(task);
        }
    }
    VTraceController::get()->Debug("VActivityController::removeTask()", "End");
}



QString VActivityController::getActivityFileName() const
{
    return _activityFileName;
}

void VActivityController::setActivityFileName(const QString &activityFileName)
{
    _activityFileName = activityFileName;
}

bool VActivityController::isActivityModelSaved()
{
    VHistorySet* activityHistorySet = getActivityHistorySet();
    if(activityHistorySet->size() == 0)
        return true;
    return activityHistorySet->last() == activityHistorySet->getLastHistoryStateSaved();
}
