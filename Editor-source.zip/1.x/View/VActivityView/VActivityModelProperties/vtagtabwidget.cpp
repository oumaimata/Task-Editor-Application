#include "vtagtabwidget.h"
#include "ui_vtagtabwidget.h"

#include "Model/VActivity/vtag.h"
#include "Model/VActivity/vactivitymodel.h"

VTagTabWidget::VTagTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VTagTabWidget),
    _activityModel(NULL)
{
    ui->setupUi(this);
}

VTagTabWidget::~VTagTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VTagTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setActivityModel
 * Définit le modèle d'activité en cours
 * @param activityModel Le modèle d'activité en cours
 */
void VTagTabWidget::setActivityModel(VActivityModel * activityModel)
{
    if(activityModel != NULL)
    {
        _activityModel = activityModel;
    }
    updateDisplay();
}

/**
 * @brief updateDisplay
 * Met à jour l'affichage
 */
void VTagTabWidget::updateDisplay()
{
    // Vide l'arbre
    int topLevelItemCount = ui->treeWidget->topLevelItemCount();
    for(int i = 0; i < topLevelItemCount; i++)
    {
        ui->treeWidget->takeTopLevelItem(0);
    }

    // Création des items
    QList<QPointer<VTag> > tags = _activityModel->getTags();
    QList<QTreeWidgetItem *> items;
    for(int i = 0; i< tags.count(); i++)
    {
        QTreeWidgetItem * item = new QTreeWidgetItem();
        item->setFlags(item->flags() | Qt::ItemIsEditable | Qt::ItemIsUserCheckable);
        item->setText(0, tags[i]->getName());
        item->setCheckState(1, tags[i]->getValued() ? Qt::Checked : Qt::Unchecked);
        item->setCheckState(2, tags[i]->getVisible() ? Qt::Checked : Qt::Unchecked);
        item->setBackgroundColor(3, tags[i]->getColor());

        item->setData(0, Qt::UserRole, tags[i]->getId());

        items.append(item);
    }

    // Création de l'arborescence
    for(int i = 0; i< items.count(); i++)
    {
        if(tags[i]->parent() == NULL)
        {
            ui->treeWidget->addTopLevelItem(items[i]);
            items[i]->setExpanded(true);
        }
        else
        {
            QTreeWidgetItem * parentItem = items.at(tags.indexOf(qobject_cast<VTag *>(tags[i]->parent())));
            parentItem->addChild(items[i]);
        }
    }
}

/**
 * @brief on_treeWidget_itemChanged
 * Gère les modifications des items
 * @param item L'item modifié
 * @param column La colonne concernée
 */
void VTagTabWidget::on_treeWidget_itemChanged(QTreeWidgetItem *item, int column)
{
    QString id = item->data(0, Qt::UserRole).toString();
    if(id == "") return;
    VTag * tag = _activityModel->getTagById(id.toInt());
    if(tag != NULL)
    {
        if(column == 0)
        {
            if(tag->getName() != item->text(0))
            {
                tag->setName(item->text(0));
            }
        }
        else if(column == 1)
        {
            if(tag->getValued() != (item->checkState(1) == Qt::Checked))
            {
                tag->setValued(item->checkState(1) == Qt::Checked);
            }
        }
        else if(column == 2)
        {
            if(tag->getVisible() != (item->checkState(2) == Qt::Checked))
            {
                tag->setVisible(item->checkState(2) == Qt::Checked);
            }
        }
    }
}

 void VTagTabWidget::on_treeWidget_itemClicked(QTreeWidgetItem *item, int column){
     if(column == 3){ // colonne de la couleur du tag
        QColor color = QColorDialog::getColor();
        if(color.isValid()){
            QString id = item->data(0, Qt::UserRole).toString();
            if(id == "") return;
            VTag * tag = _activityModel->getTagById(id.toInt());
            tag->setColor(color);
        }
     }
 }

/**
 * @brief on_addButton_clicked
 * Gère le click sur le bouton pour ajouter un tag
 */
void VTagTabWidget::on_addButton_clicked()
{
    if(ui->treeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedItem = ui->treeWidget->selectedItems().first();
        QString id = selectedItem->data(0, Qt::UserRole).toString();
        if(id == "") return;
        VTag * parentTag = _activityModel->getTagById(id.toInt());

        VTag * tag = new VTag(parentTag);
        _activityModel->addTag(tag);

    }
    else
    {
        VTag * tag = new VTag();
        _activityModel->addTag(tag);
    }
}

/**
 * @brief on_removeButton_clicked
 * Gère le click sur le bouton pour supprimer un tag
 */
void VTagTabWidget::on_removeButton_clicked()
{
    if(ui->treeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedItem = ui->treeWidget->selectedItems().first();
        QString id = selectedItem->data(0, Qt::UserRole).toString();
        if(id == "") return;
        VTag * tag = _activityModel->getTagById(id.toInt());
        if(tag != NULL) _activityModel->removeTag(tag);
    }
}

/**
 * @brief on_treeWidget_itemSelectionChanged
 * Gère le changement de sélection
 * Pour le bouton de suppression
 */
void VTagTabWidget::on_treeWidget_itemSelectionChanged()
{
    ui->removeButton->setEnabled(ui->treeWidget->selectedItems().count() != 0);
}
