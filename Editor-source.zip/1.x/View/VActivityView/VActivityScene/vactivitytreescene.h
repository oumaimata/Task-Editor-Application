#pragma once
#ifndef VACTIVITYTREESCENE_H
#define VACTIVITYTREESCENE_H

#include <QGraphicsScene>
#include <QList>

#include "Model/VActivity/vtask.h"

class VTaskItem;

class VActivityTreeScene : public QGraphicsScene
{
    Q_OBJECT

public:
    /*!
     * \brief VActivityTreeScene::VActivityTreeScene
     * Constructeur
     * \param parent L'objet parent
     */
    VActivityTreeScene(QObject* parent = NULL);

    /*!
     * \brief VActivityTreeScene::getRootTasksItems
     * Obtient les items racines
     * \return Une liste d'item racine
     */
    QList<VTaskItem*> getRootTasksItems();

    /*!
     * \brief VActivityTreeScene::getTaskItem
     * Trouve le TaskItem correspondant à task
     * \param task La tache recherchée
     * \return Le takItem correspondant s'il existe, null sinon
     */
    VTaskItem* getTaskItem(VTask* task);

    /*!
     * \brief VActivityTreeScene::getSelectedTaskItems
     * Obtient la liste des items sélectionnés
     * \return La liste des items sélectionné
     */
    QList<VTaskItem*> getSelectedTaskItems();

    /*!
     * \brief VActivityTreeScene::getSelectedTasks
     * Obtient la liste des tâches sélectionnées
     * \return La liste des tâches sélectionnées
     */
    QList<QPointer<VTask> > getSelectedTasks();

public slots:

    /*!
     * \brief VActivityTreeScene::updateItemsPositions
     * Met a jour la position des items
     */
    void updateItemsPositions();

    /*!
     * \brief VActivityTreeScene::updateTaskItem
     * \param task
     */
    void updateTaskItem(VTask* task);

    /*!
     * \brief VActivityTreeScene::addTaskItem
     * Ajoute un TaskItem avec pour tache Task
     * \param task La tache du TaskItem
     */
    void addTaskItem(VTask* task);

    /*!
     * \brief VActivityTreeScene::removeTaskItem
     * Supprime un TaskItem correspondant à la tache task
     * \param task La tache du TaskItem
     */
    void removeTaskItem(VTask* task);
};

#endif // VACTIVITYTREESCENE_H
