#include "vwactionclass.h"

#include "vwbehaviourclass.h"
#include "../vwproperties.h"

VWActionClass::VWActionClass(QObject *parent) :
    VWEntityClass(parent)
{
    setName("Action" + QString::number(getUid()));
    _properties = new VWProperties();
    _properties->setType("action-behaviour-event");
    _properties->setWorldModelElement(this);
    _properties->setIsShared(true);
    connect(_properties, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
}

/**
 * @brief VWActionClass
 * @param o L'objet à copier
 */
VWActionClass::VWActionClass(const VWActionClass& o):
    VWEntityClass(o)
{
    _behaviours = o._behaviours;
    _properties = o._properties;
}

/**
 * @brief ~VWActionClass
 * Destructeur
 */
VWActionClass::~VWActionClass()
{
    delete _properties;
}


/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWActionClass::ParseDom(QDomElement elem)
{
    VWEntityClass::ParseDom(elem);
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWActionClass::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<owl:Class rdf:ID=\"" + getName() + "\">\n";
    RetVal += VWEntityClass::ToXml(tabulation + "\t");
    RetVal += tabulation + "\t<rdfs:subClassOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#Action\"/>\n";
    RetVal += tabulation + "</owl:Class>\n";
    // liste de behaviour
    foreach(QPointer<VWBehaviourClass> behaviour, _behaviours)
    {
        if(behaviour != NULL)
        {
            RetVal += tabulation + "<owl:ObjectProperty rdf:about=\"" + "activate-" + behaviour->getName() + "\">\n";
            RetVal += tabulation + "\t" + "<rdfs:subPropertyOf rdf:resource=\"http://www.utc.fr/hds/ici/humans/domain#activate-behaviour\"/>\n";
            RetVal += tabulation + "\t" + "<rdfs:domain rdf:resource=\"#" + getName() + "\"/>\n";
            RetVal += tabulation + "\t" + "<rdfs:range rdf:resource=\"#" + behaviour->getName() + "\"/>\n";
            RetVal += tabulation + "</owl:ObjectProperty>\n";
        }
    }
    return RetVal;
}

void VWActionClass::addBehaviour(VWBehaviourClass * behaviourClass)
{
    if(behaviourClass != NULL)
    {
        _behaviours.append(behaviourClass);
        connect(behaviourClass, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Behaviour added"));
    }
}

void VWActionClass::removeBehaviour(VWBehaviourClass * behaviourClass)
{
    if(_behaviours.contains(behaviourClass))
    {
        _behaviours.removeAll(behaviourClass);
        disconnect(behaviourClass, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Behaviour removed"));
    }
}

QList<QPointer<VWBehaviourClass> > VWActionClass::getBehaviours() const
{
    return _behaviours;
}

QPointer<VWProperty> VWActionClass::addProperty(QDomElement elem)
{
    if(_properties != NULL)  return _properties->addProperty(elem);
    return QPointer<VWProperty>();
}

VWProperties * VWActionClass::getProperties() const
{
    return _properties;
}
