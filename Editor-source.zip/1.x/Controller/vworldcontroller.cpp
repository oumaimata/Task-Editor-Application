#include "vworldcontroller.h"
#include "vtracecontroller.h"

#include "../Model/vapplicationmodel.h"
#include "../View/VWorldView/vworldwidget.h"
#include "../View/VHistoryView/vhistoryworldwidget.h"



VWorldController::VWorldController(VWorldWidget* worldWidget,
                                   VHistoryWorldWidget* historyWorldWidget,
                                   QObject* parent):
    QObject(parent),
    _edit(false),
    _worldWidget(worldWidget),
    _historyWorldWidget(historyWorldWidget),
    _worldFileName("")
{
    VTraceController::get()->Debug("VWorldController::VWorldController()", "Begin");

    _historyWorldWidget->setHistorySet(getWorldHistorySet());
    connect(getWorldHistorySet(), SIGNAL(hasChanged()), this, SLOT(historyHasChanged()));

    VTraceController::get()->Debug("VWorldController::VWorldController()", "End");
}

/**
 * @brief getWorldHistorySet
 * Obtient l'historique du modèle di monde
 */
VHistorySet * VWorldController::getWorldHistorySet()
{
    return &VApplicationModel::getInstance()->getWorldHistorySet();
}

/**
 * @brief getWorldFutureSet
 * Obtient le future du modèle di monde
 */
VHistorySet * VWorldController::getWorldFutureSet()
{
    return &VApplicationModel::getInstance()->getWorldFutureSet();
}

void VWorldController::setCurrentEdit(QPointer<VWorldModelElement> currentEdit)
{
    _worldWidget->setCurrentEdit(currentEdit);
}

void VWorldController::loadModel(QString fileName)
{
    QFile xml_doc(fileName);// On choisit le fichier contenant les informations XML.
    if(!xml_doc.open(QIODevice::ReadOnly))// Si l'on n'arrive pas à ouvrir le fichier XML.
    {
        return;
    }
    QTextStream flux(&xml_doc);
    QString xml_model = flux.readAll();
    xml_doc.close(); // Dans tous les cas, on doit fermer le document XML : on n'en a plus besoin, tout est compris dans xml_model

    VWorldModel * model = &VApplicationModel::getInstance()->getWorldModel();
    model->loadModel(xml_model);
    model->onModified(tr("World model loaded"));
}

void VWorldController::undo()
{
    _edit = true;
    VWorldModel * model = &VApplicationModel::getInstance()->getWorldModel();
    if(getWorldHistorySet()->size() > 0)
    {
        VHistoryState historyState = getWorldHistorySet()->pop_back();
        getWorldFutureSet()->push_back(historyState.getLabel(), historyState.getDesc(), historyState.getValue());
        if(getWorldHistorySet()->size() > 0)
        {
            QString xml_model = getWorldHistorySet()->lastValue();
            model->loadModel(xml_model);
        }
        else
        {
            model->resetModel();
        }
        model->onModified(NULL);
    }
    _edit = false;
}

void VWorldController::redo()
{
    _edit = true;
    VWorldModel * model = &VApplicationModel::getInstance()->getWorldModel();
    if(getWorldFutureSet()->size() > 0)
    {
        VHistoryState historyState = getWorldFutureSet()->pop_back();
        getWorldHistorySet()->push_back(historyState.getLabel(), historyState.getDesc(), historyState.getValue());
        model->loadModel(historyState.getValue());
        model->onModified(NULL);
    }
    _edit = false;
}

void VWorldController::historyHasChanged()
{
    if(!_edit) getWorldFutureSet()->clear();
}


QString VWorldController::getWorldFileName() const
{
    return _worldFileName;
}

void VWorldController::setWorldFileName(const QString value)
{
    _worldFileName = value;
}

bool VWorldController::isWorldModelSaved()
{
    VHistorySet* worldHistorySet = getWorldHistorySet();
    if(worldHistorySet->size() == 0)
        return true;
    return  worldHistorySet->last() == worldHistorySet->getLastHistoryStateSaved();
}
