#include "vwobjectclasseditorwidget.h"
#include "ui_vwobjectclasseditorwidget.h"

#include "Model/VWorld/VWorldInstance/vwinstance.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"

VWObjectClassEditorWidget::VWObjectClassEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWObjectClassEditorWidget),
    _edit(false),
    _objectClass(NULL)
{
    ui->setupUi(this);
    retranslate();
    connect(ui->abstractRadioButton, SIGNAL(toggled(bool)), this, SLOT(typeToggled(bool)));
    connect(ui->concreteRadioButton, SIGNAL(toggled(bool)), this, SLOT(typeToggled(bool)));
    connect(ui->agentRadioButton, SIGNAL(toggled(bool)), this, SLOT(typeToggled(bool)));
}

VWObjectClassEditorWidget::~VWObjectClassEditorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWObjectClassEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWObjectClassEditorWidget::retranslate()
{
    ui->propertiesEditorWidget->setLabelCol(0, tr("Property"));
    ui->propertiesEditorWidget->setLabelCol(1, tr("Type"));
}

void VWObjectClassEditorWidget::setObjectClass(VWObjectClass * objectClass)
{
    if(objectClass != _objectClass)
    {
        _objectClass = objectClass;
    }
    updateDisplay();
}

void VWObjectClassEditorWidget::updateDisplay()
{
    _edit = true;
    ui->nameLineEdit->setText("");

    ui->abstractRadioButton->setAutoExclusive(false);
    ui->concreteRadioButton->setAutoExclusive(false);
    ui->agentRadioButton->setAutoExclusive(false);
    ui->abstractRadioButton->setChecked(false);
    ui->concreteRadioButton->setChecked(false);
    ui->agentRadioButton->setChecked(false);
    ui->abstractRadioButton->setAutoExclusive(true);
    ui->concreteRadioButton->setAutoExclusive(true);
    ui->agentRadioButton->setAutoExclusive(true);
    ui->radioButtonWidget->setEnabled(false);

    if(_objectClass == NULL) return;

    // Nom
    ui->nameLineEdit->setText(_objectClass->getName());

    // radiobuttons
    ui->radioButtonWidget->setEnabled(_objectClass->getTypeIsEditable());
    if(_objectClass->getType() == "abstract") ui->abstractRadioButton->setChecked(true);
    else if(_objectClass->getType() == "concrete") ui->concreteRadioButton->setChecked(true);
    else if(_objectClass->getType() == "agent") ui->agentRadioButton->setChecked(true);

    // Properties
    ui->propertiesEditorWidget->setProperties(_objectClass->getProperties());

    // Component
    ui->componentEditorWidget->setEntity(_objectClass);
    _edit = false;
}

void VWObjectClassEditorWidget::on_nameLineEdit_editingFinished()
{
    _objectClass->setName(ui->nameLineEdit->text());
}

void VWObjectClassEditorWidget::on_addInstanceButton_clicked()
{
    if(_objectClass == NULL) return;
    VWInstance * instance = new VWInstance(_objectClass);
    _objectClass->addInstance(instance);
}

void VWObjectClassEditorWidget::typeToggled(bool)
{
    if(_edit) return;
    if(ui->abstractRadioButton->isChecked()) _objectClass->setType("abstract");
    else if(ui->concreteRadioButton->isChecked()) _objectClass->setType("concrete");
    else if(ui->agentRadioButton->isChecked()) _objectClass->setType("agent");
}
