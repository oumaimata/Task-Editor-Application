#pragma once
#ifndef VWORLDMODELELEMENT_H
#define VWORLDMODELELEMENT_H

#include <QObject>
#include <QtXml>

/**
 * @brief The VWorldModelElement class
 * Classe de base de tous les éléments du modèle du monde
 * _uid est unique
 */
class VWorldModelElement : public QObject
{
    Q_OBJECT
private:

    /**
     * @brief _currentUid
     * Compteur automatique d'identifiant
     */
    static qint64 currentUid;

    /**
     * @brief _uid
     * Identifiant unique de l'élément
     */
    qint64 _uid;

    /**
     * @brief _name
     * Le nom de l'élément
     */
    QString _name;
protected:
    bool _edit;
public:
    /**
     * @brief VWorldModelElement
     * Constructeur
     * @param parent L'object parent
     */
    explicit VWorldModelElement(QObject *parent = 0);

    /**
     * @brief VWorldModelElement
     * Constructeur de copie
     * @param worldModelElement L'élément à copier
     */
    VWorldModelElement(const VWorldModelElement& worldModelElement);

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void ParseDom(QDomElement elem);

    /**
     * @brief getUid
     * Obtient l'Uid
     * @return L'uid
     */
    qint64 getUid() const;

    /**
     * @brief getCurrentUid
     * Obtient l'uid courant
     * @return L'uid courant
     */
    static qint64 getCurrentUid();

    /**
     * @brief setName
     * Définit le nom de l'élément
     * @param name Le nom de l'élément
     */
    void setName(QString name);

    /**
     * @brief getName
     * Obtient le nom de l'élément
     * @return Le nom de l'élément
     */
    QString getName() const;

    /**
     * @brief operator ==
     * Opérateur de comparaison
     * @param worldModelElement L'élément à comparer
     * @return Si les deux object sont éguaux
     */
    bool operator==(const VWorldModelElement& worldModelElement) const;

protected slots:

    /**
     * @brief onModified
     * Envoie le signal modified(QString, QObject *)
     */
     virtual void onModified();

    /**
     * @brief onModified
     * Envoie le signal modified(QString, QObject *)
     * @param object L'object qui a été modifié
     */
     virtual void onModified(QString message, QObject * object = NULL);

    /**
     * @brief onNameModified
     * Envoie le signal nameModified(QString, QObject *)
     * @param object L'object qui a été modifié
     */
     virtual void onNameModified(QString message, QObject * object = NULL);

signals:

    /**
     * @brief modified
     * Signal envoyé lors de modification sur un VWorldModelElement
     * @param object L'object qui a été modifié
     */
    void modified(QString message, QObject * object);

    /**
     * @brief nameModified
     * Signal envoyé lors de modification sur le nom d'un VWorldModelElement
     * @param object L'object qui a été modifié
     */
    void nameModified(QString message, QObject * object);

};
#endif // VWORLDMODELELEMENT_H
