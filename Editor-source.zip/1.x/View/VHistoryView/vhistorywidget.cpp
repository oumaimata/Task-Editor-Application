#include "vhistorywidget.h"
#include "ui_vhistorywidget.h"

#include "vhistoryactivitywidget.h"
#include "vhistoryworldwidget.h"

VHistoryWidget::VHistoryWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VHistoryWidget)
{
    ui->setupUi(this);
}

VHistoryActivityWidget* VHistoryWidget::getHistoryActivityWidget()
{
    return ui->historyActivityWidget;
}

VHistoryWorldWidget* VHistoryWidget::getHistoryWorldWidget()
{
    return ui->historyWorldWidget;
}

VHistoryWidget::~VHistoryWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VHistoryWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}
