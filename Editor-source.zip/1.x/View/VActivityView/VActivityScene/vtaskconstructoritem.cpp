#include "vtaskconstructoritem.h"

#include <QGraphicsSceneMouseEvent>
#include <QPen>
#include <QDrag>
#include <QPainter>
#include <QWidget>

#include "vitemmimedata.h"
#include "vtaskitem.h"
#include "Controller/vtracecontroller.h"

/*!
 * \brief VTaskConstructorItem::VTaskConstructorItem
 * Constructeur
 * \param x La position sur l'axe des x
 * \param y La position sur l'axe des y
 * \param width La largueur
 * \param height La longueur
 * \param expanded Si déplié
 * \param parent L'objet parent
 */
VTaskConstructorItem::VTaskConstructorItem(qreal x, qreal y, qreal width, qreal height,
                                           bool expanded, VTaskItem* parent) :
    QGraphicsEllipseItem(x, y, width, height, parent),
    _taskItem(parent)
{
    VTraceController::get()->Debug("VTaskConstructorItem::VTaskConstructorItem()", "Begin");

    setFlags(ItemIsSelectable);
    setAcceptDrops(true);
    _expanded = expanded;
    this->setPen(QPen (Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    this->setBrush(Qt::lightGray);

    VTraceController::get()->Debug("VTaskConstructorItem::VTaskConstructorItem()", "End");
}

/*!
 * \brief VTaskConstructorItem::mouseDoubleClickEvent
 * Gère l'événement souris du double click
 * \param event Les informations sur l'événement
 */
void VTaskConstructorItem::mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event)
{
    VTraceController::get()->Debug("VTaskConstructorItem::mouseDoubleClickEvent()", "Begin");
    if (event->button() == Qt::LeftButton)
    {
        VTraceController::get()->Info("VTaskConstructorItem::mouseDoubleClickEvent()", "LeftButton -> Expand the item");
        _taskItem->setExpanded(!_expanded);
        _expanded = !_expanded;
        update();
    }
    VTraceController::get()->Debug("VTaskConstructorItem::mouseDoubleClickEvent()", "End");
}

/*!
 * \brief VTaskConstructorItem::mouseMoveEvent
 * Gère l'événement souris du déplacement de la souris
 * \param event Les informations sur l'événement
 */
void VTaskConstructorItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    VTraceController::get()->Debug("VTaskConstructorItem::mouseMoveEvent()", "Begin");

    QDrag* drag = new QDrag(event->widget());

    VItemMimeData* mime = new VItemMimeData();
    drag->setMimeData(mime);
    mime->setItem(this);

    drag->exec();

    VTraceController::get()->Debug("VTaskConstructorItem::mouseMoveEvent()", "End");
}

/*!
 * \brief VTaskConstructorItem::dragEnterEvent
 * Gère l'événement souris du glisser (du glisser/déposer)
 * \param event Les informations sur l'événement
 */
void VTaskConstructorItem::dragEnterEvent(QGraphicsSceneDragDropEvent* event)
{
    VTraceController::get()->Debug("VTaskConstructorItem::dragEnterEvent()", "Begin");

    const VItemMimeData* mimeData = qobject_cast<const VItemMimeData*>(event->mimeData());

    if (mimeData != NULL && mimeData->hasItem())
    {
        VTraceController::get()->Info("VTaskConstructorItem::dragEnterEvent()", "Drag allowed");
        event->accept();
    }
    else
    {
        VTraceController::get()->Info("VTaskConstructorItem::dragEnterEvent()", "Drag refused");
        event->ignore();
    }
    VTraceController::get()->Debug("VTaskConstructorItem::dragEnterEvent()", "End");
}

/*!
 * \brief VTaskConstructorItem::dropEvent
 * Gère l'événement souris déposer (du glisser/déposer)
 * \param event Les informations sur l'événement
 */
void VTaskConstructorItem::dropEvent(QGraphicsSceneDragDropEvent* event)
{
    VTraceController::get()->Debug("VTaskConstructorItem::dropEvent()", "Begin");

    const VItemMimeData* mimeData = qobject_cast<const VItemMimeData*>(event->mimeData());
    if (mimeData != NULL && mimeData->hasItem())
    {
        VTaskConstructorItem* taskConstructorItem = qgraphicsitem_cast<VTaskConstructorItem*>(mimeData->getItem());
        if(taskConstructorItem != NULL)
        {
            VTaskItem * oldParent = taskConstructorItem->_taskItem; // Item parent des items à déplacer
            QList<VTaskItem *> subTaskItems = oldParent->getChildTaskItems(); // Liste des items à déplacer
            for(int i = 0; i < subTaskItems.count(); i++)
            {
                VTaskItem* taskItem = subTaskItems[i];
                VTask * task = taskItem->getTask(); // Récupère la tâche à déplacée

                if(!task->IsAnscesterOf(_taskItem->getTask())) // task est un ancètre de _taskItem->getTask() ?
                {
                    task->setParent(_taskItem->getTask()); // Change le parent sur le modèle
                    taskItem->setParentItem(_taskItem); // Change le parent sur la vue
                    taskItem->updateSubitemsPositions();

                    if(oldParent != NULL)
                    {
                        oldParent->updateSubitemsPositions();
                    }
                    VTraceController::get()->Info("VTaskConstructorItem::dropEvent()",
                                                           _taskItem->getTask()->getId() + " is now parent of " + task->getId());
                }
            }
        }
        VTaskItem* taskItem = qgraphicsitem_cast<VTaskItem*>(mimeData->getItem());
        if(taskItem != NULL)
        {
            VTaskItem * oldParent = taskItem->getParentTaskItem(); // On conserve l'ancien parent pour mettre à jour ses enfants car on en retire un.
            VTask * task = taskItem->getTask(); // Récupère la tâche à déplacée

            if(!task->IsAnscesterOf(_taskItem->getTask())) // task est un ancètre de _taskItem->getTask() ?
            {
                task->setParent(_taskItem->getTask()); // Change le parent sur le modèle
                taskItem->setParentItem(_taskItem); // Change le parent sur la vue
                taskItem->updateSubitemsPositions();

                if(oldParent != NULL)
                {
                    oldParent->updateSubitemsPositions();
                }
                VTraceController::get()->Info("VTaskConstructorItem::dropEvent()",
                                                       _taskItem->getTask()->getId() + " is now parent of " + task->getId());
            }
        }
    }

    VTraceController::get()->Debug("VTaskConstructorItem::dropEvent()", "End");
}

/*!
 * \brief VTaskConstructorItem::itemChange
 * Gère le changement de sélection
 * \param change Les informations sur l'événement
 * \param value Si sélectionné
 * \return value
 */
QVariant VTaskConstructorItem::itemChange(GraphicsItemChange change, const QVariant &value)
{
    VTraceController::get()->Debug("VTaskConstructorItem::itemChange()", "Begin");
    if (change == QGraphicsItem::ItemSelectedHasChanged)
    {
        VTraceController::get()->Info("VTaskConstructorItem::itemChange()", "Selected item has changed");
        if (value.toBool())
        {
            VTraceController::get()->Info("VTaskConstructorItem::itemChange()", "the item is now selected -> red outline");
            this->setPen(QPen (Qt::red, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        }
        else
        {
            VTraceController::get()->Info("VTaskConstructorItem::itemChange()", "the item isn't' selected -> black outline");
            this->setPen(QPen (Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        }
    }

    QVariant result = QGraphicsEllipseItem::itemChange(change, value);

    VTraceController::get()->Debug("VTaskConstructorItem::itemChange()", "End");

    return result;
}

/*!
 * \brief VTaskConstructorItem::type
 * Obtient Type
 * \return Le type
 */
int VTaskConstructorItem::type() const
{
    return Type;
}

/*!
 * \brief VTaskConstructorItem::paint
 * Dessine le controle
 * \param painter
 * \param option
 * \param widget
 */
void VTaskConstructorItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    VTraceController::get()->Debug("VTaskConstructorItem::paint()", "Begin");

    QGraphicsEllipseItem::paint(painter, option, widget);

    QRectF rect = this->rect();
    qreal crossWidth = 0.5 * rect.width();
    qreal crossHeight = 0.5 * rect.height();

    painter->setPen(QPen (Qt::black, 1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));

    // Drawing cross' horizontal line.
    painter->drawLine(rect.x() + 0.5 * rect.width() - 0.5 * crossWidth,
                      rect.y() + 0.5 * rect.height(),
                      rect.x() + 0.5 * rect.width() + 0.5 * crossWidth,
                      rect.y() + 0.5 * rect.height());

    // Drawing cross' vertical line if task item is not expanded.
    if (!_expanded && this->isVisible())
    {
        painter->drawLine(rect.x() + 0.5 * rect.width(),
                          rect.y() + 0.5 * rect.height() - 0.5 * crossHeight,
                          rect.x() + 0.5 * rect.width(),
                          rect.y() + 0.5 * rect.height() + 0.5 * crossHeight);
    }

    VTraceController::get()->Debug("VTaskConstructorItem::paint()", "End");
}
