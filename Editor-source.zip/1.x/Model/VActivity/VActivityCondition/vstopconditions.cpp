#include "vstopconditions.h"

#include "vstopcondition.h"
#include "vbasiscondition.h"
#include "../vtask.h"

VStopConditions::VStopConditions(VTask *task) :
    VActivityModelElement(task),
    _task(task)
{
}

VStopConditions::VStopConditions(const VStopConditions& stopConditions, QObject *parent) :
    VActivityModelElement(parent)
{
    _logicalOperator = stopConditions._logicalOperator;
    foreach(VStopCondition * stopCondition, stopConditions.getStopConditions())
    {
        addStopCondition(stopCondition->clone(this));
    }
}

/**
 * @brief ~VStopConditions
 * Destructeur
 */
VStopConditions::~VStopConditions()
{
    while(_stopConditions.count() > 0)
    {
        VStopCondition * stopCondition = _stopConditions.first();
        _stopConditions.pop_front();
        delete stopCondition;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VStopConditions::parseDom(QDomElement elem)
{
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString tagname = element.tagName().toUpper();
            // Lecture de context
            if(tagname == "AND" || tagname == "OR" ||
               tagname == "XOR"  || tagname == "NOT")
            {
                setLogicalOperator(element.tagName());
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        VStopCondition * stopCondition = new VStopCondition(this);
                        stopCondition->parseDom(subElement);
                        addStopCondition(stopCondition);
                    }
                    subNode = subNode.nextSibling();
                }
            }
            else
            {
                VStopCondition * stopCondition = new VStopCondition(this);
                stopCondition->parseDom(element);
                addStopCondition(stopCondition);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VStopConditions::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<stops>\n";
    if(_logicalOperator != NULL)
    {
        RetVal += tabulation + "\t" + "<" + _logicalOperator + ">\n";
        foreach(VStopCondition * stopCondition, getStopConditions())
        {
            RetVal += stopCondition->ToXml(tabulation + "\t\t");
        }
        RetVal += tabulation + "\t" + "</" + _logicalOperator + ">\n";
    }
    else
    {
        foreach(VStopCondition * stopCondition, getStopConditions())
        {
            RetVal += stopCondition->ToXml(tabulation + "\t");
        }
    }
    RetVal += tabulation + "</stops>\n";
    return RetVal;

}

void VStopConditions::setLogicalOperator(QString logicalOperator)
{
    logicalOperator = logicalOperator.toUpper();
    if(logicalOperator != _logicalOperator)
    {
        _logicalOperator = logicalOperator;
        onModified(NULL);
    }
}
QString VStopConditions::getLogicalOperator() const
{
    return _logicalOperator;
}

void VStopConditions::addStopCondition(VStopCondition * stopCondition)
{
    if(stopCondition != NULL)
    {
        stopCondition->setTask(_task);
        _stopConditions.append(stopCondition);
        connect(stopCondition, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Stop condition added"));
    }
}

void VStopConditions::removeStopCondition(VStopCondition * stopCondition)
{
    if(stopCondition != NULL && _stopConditions.contains(stopCondition))
    {
        _stopConditions.removeAll(stopCondition);
        disconnect(stopCondition, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Stop condition removed"));
    }
}

QList<VStopCondition *> VStopConditions::getStopConditions() const
{
    return _stopConditions;
}

QList<VBasisCondition *> VStopConditions::getBasisConditions() const
{
    QList<VBasisCondition *> RetVal;
    foreach(VStopCondition * condition, _stopConditions)
    {
        RetVal.append(condition);
    }
    return RetVal;
}

VStopCondition * VStopConditions::getStopConditionByUid(qint64 uid) const
{
    for(int i = 0; i < _stopConditions.count(); i++)
    {
        if(_stopConditions[i]->getUid() == uid) return _stopConditions[i];
    }
    return NULL;
}

/**
 * @brief clone
 * @return Le clone
 */
VStopConditions * VStopConditions::clone(QObject * parent) const
{
    return new VStopConditions(*this, parent);
}
