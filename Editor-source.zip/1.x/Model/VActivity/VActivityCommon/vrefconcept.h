#pragma once
#ifndef VREFCONCEPT_H
#define VREFCONCEPT_H

#include <QtXml>

#include "vactivitymodelelement.h"

class VRefConcept : public VActivityModelElement
{
    Q_OBJECT
private:

    static QList<VRefConcept *> s_refConcepts;

    QString _concept;

    QString _ref;

    QString _predicate;
public:

    explicit VRefConcept(QObject *parent = 0);

    VRefConcept(const VRefConcept& refconcept, QObject *parent = 0);

    ~VRefConcept();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setConcept(QString concept);

    QString getConcept() const;

    void setRef(QString ref);

    QString getRef() const;

    void setPredicate(QString predicate);

    QString getPredicate() const;

    static VRefConcept * getRefConcept(qint64 uid);

    static QList<VRefConcept *> getAllRefConcepts();

    /**
     * @brief clone
     * @return Le clone
     */
    VRefConcept * clone(QObject *parent = 0) const;
};

#endif // VREFCONCEPT_H
