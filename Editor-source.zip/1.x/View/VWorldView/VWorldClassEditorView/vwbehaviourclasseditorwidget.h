#pragma once
#ifndef VWBEHAVIOURCLASSEDITORWIDGET_H
#define VWBEHAVIOURCLASSEDITORWIDGET_H

#include <QWidget>

class VWBehaviourClass;

namespace Ui {
class VWBehaviourClassEditorWidget;
}

class VWBehaviourClassEditorWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VWBehaviourClassEditorWidget *ui;

    bool _edit;

    VWBehaviourClass * _behaviourClass;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    void retranslate();
    
public:
    explicit VWBehaviourClassEditorWidget(QWidget *parent = 0);
    ~VWBehaviourClassEditorWidget();

    void setBehaviourClass(VWBehaviourClass * behaviourClass);

private slots:
    void updateDisplay();
    void on_nameLineEdit_editingFinished();
    void on_addEventButton_clicked();
    void on_removeEventButton_clicked();
    void on_durativeRadioButton_toggled(bool checked);
    void on_punctualRadioButton_toggled(bool checked);
};

#endif // VWBEHAVIOURCLASSEDITORWIDGET_H
