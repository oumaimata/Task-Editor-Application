#include "vwparser.h"

QString VWParser::getName(QDomElement elem)
{
    QString RetVal = getBalise(elem.attribute("rdf:ID", ""));
    if(RetVal.isNull() || RetVal.isEmpty()) RetVal = getBalise(elem.attribute("rdf:about", ""));
    return RetVal;
}

/**
 * @brief getDomainSupClasses
 * Trouve et retourne s'il existe toutes les classes supérieur appartenant au domain référence dans un rdfs:subClassOf
 * @param elem Un élément du dom
 * @return Toutes les classes supérieur trouvée
 */
QList<QString> VWParser::getDomainSupClasses(QDomElement elem)
{
    QList<QString> RetVal;

    QDomNode node = elem.firstChild();

    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString prefix = getPrefix(element.tagName()).toLower();
            QString balise = getBalise(element.tagName()).toLower();
            if(prefix == "rdfs")
            {
                if(balise == "subclassof")
                {
                    QString ressource = element.attribute("rdf:resource", "");
                    QString prefixRessource = getPrefix(ressource).toLower();
                    if(prefixRessource == "http://www.utc.fr/hds/ici/humans/domain")
                    {
                        RetVal.append(getBalise(ressource).toLower());
                    }
                }
            }
        }
        node = node.nextSibling();
    }
    return RetVal;
}

/**
 * @brief getDomainSupProperties
 * @param elem Un élément du dom
 * @return Toutes les propriétés supérieur trouvée
 */
QList<QString> VWParser::getDomainSupProperties(QDomElement elem)
{
    QList<QString> RetVal;

    QDomNode node = elem.firstChild();

    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString prefix = getPrefix(element.tagName()).toLower();
            QString balise = getBalise(element.tagName()).toLower();
            if(prefix == "rdfs")
            {
                if(balise == "subpropertyof")
                {
                    QString ressource = element.attribute("rdf:resource", "");
                    QString prefixRessource = getPrefix(ressource).toLower();
                    if(prefixRessource == "http://www.utc.fr/hds/ici/humans/domain")
                    {
                        RetVal.append(getBalise(ressource).toLower());
                    }
                }
            }
        }
        node = node.nextSibling();
    }
    return RetVal;
}

QPair<QList<QString>, QString> VWParser::getDomaineAndRange(QDomElement elem)
{
    QPair<QList<QString>, QString> result;

    QDomNode node = elem.firstChild();

    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString prefix = getPrefix(element.tagName()).toLower();
            QString balise = getBalise(element.tagName()).toLower();
            if(prefix == "rdfs")
            {
                if(balise == "domain")
                {
                    QDomNode subNode = element.firstChild();
                    if(!subNode.isNull() && !subNode.toElement().isNull() && subNode.toElement().tagName() == "owl:Class")
                    {
                        result.first.append(getUnionOfClass(subNode.toElement()));
                    }
                    else
                    {
                        QString ressource = element.attribute("rdf:resource", "");
                        QString prefixRessource = getPrefix(ressource).toLower();
                        if(prefixRessource.isNull() || prefixRessource.isEmpty())
                        {
                            result.first.append(getBalise(ressource));
                        }
                    }
                }
                else if(balise == "range")
                {
                    QString ressource = element.attribute("rdf:resource", "");
                    result.second = getBalise(ressource);
                }
            }
        }
        node = node.nextSibling();
    }
    return result;
}

QList<QString> VWParser::getUnionOfClass(QDomElement elem)
{
    QList<QString> result;
    QDomNode node = elem.firstChild();
    if(!node.isNull() && !node.toElement().isNull() && node.toElement().tagName() == "owl:unionOf")
    {
        QDomNode subNode = node.toElement().firstChild();

        // Lecture des noeuds inférieurs
        while(!subNode.isNull())
        {
            QDomElement subElement = subNode.toElement();
            if(!subElement.isNull())
            {
                result.append(getBalise(subElement.attribute("rdf:about", "")));
            }
            subNode = subNode.nextSibling();
        }
    }
    return result;
}

/**
 * @brief getSupClasses
 * Trouve et retourne s'il existe toutes les classes supérieur appartenant au modèle du monde
 * @param elem Un élément du dom
 * @return Toutes les classes supérieur trouvée
 */
QList<QString> VWParser::getSupClasses(QDomElement elem)
{
    QList<QString> RetVal;

    QDomNode node = elem.firstChild();

    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            QString prefix = getPrefix(element.tagName()).toLower();
            QString balise = getBalise(element.tagName()).toLower();
            if(prefix == "rdfs")
            {
                if(balise == "subclassof")
                {
                    QString ressource = element.attribute("rdf:resource", "");
                    QString prefixRessource = getPrefix(ressource).toLower();
                    if(prefixRessource.isNull() || prefixRessource.isEmpty())
                    {
                        RetVal.append(getBalise(ressource));
                    }
                }
            }
        }
        node = node.nextSibling();
    }
    return RetVal;
}

QString VWParser::getPrefix(QString s)
{
    if(s.contains("#")) return s.split("#").first();
    else if(s.contains(":")) return s.split(":").first();
    else return NULL;
}
QString VWParser::getBalise(QString s)
{
    if(s.contains("#")) return s.split("#").last();
    else if(s.contains(":")) return s.split(":").last();
    else return s;
}

