#include "vnottriples.h"

#include "../VActivityCommon/vtriple.h"

VNotTriples::VNotTriples(QObject *parent) :
    VActivityModelElement(parent)
{
}

VNotTriples::VNotTriples(const VNotTriples& notTriples, QObject *parent) :
    VActivityModelElement(parent)
{
    foreach(VTriple * triple, notTriples._triples)
    {
        addTriple(triple->clone());
    }
}

/**
 * @brief ~VNotTriples
 * Destructeur
 */
VNotTriples::~VNotTriples()
{
    while(_triples.count() > 0)
    {
        VTriple * triple = _triples.first();
        _triples.pop_front();
        delete triple;
    }
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VNotTriples::parseDom(QDomElement elem)
{
    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de triple
            if(element.tagName() == "triple")
            {
                VTriple * triple = new VTriple(this);
                triple->parseDom(element);
                addTriple(triple);
            }
        }
        node = node.nextSibling();
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VNotTriples::ToXml(QString tabulation) const
{
    QString RetVal = tabulation + "<NOT>\n";

    for(int i = 0; i < _triples.count(); i++)
    {
        RetVal += _triples[i]->ToXml(tabulation + "\t");
    }

    RetVal += tabulation + "</NOT>\n";
    return RetVal;
}

void VNotTriples::addTriple(VTriple * triple)
{
    if(triple != NULL)
    {
        _triples.append(triple);
        connect(triple, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Triple added"));
    }
}

void VNotTriples::removeTriple(VTriple * triple)
{
    if(_triples.contains(triple))
    {
        _triples.removeAll(triple);
        disconnect(triple, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Triple removed"));
    }
}

QList<VTriple *> VNotTriples::getTriples() const
{
    return _triples;
}

VTriple * VNotTriples::getTripleById(qint64 uid) const
{
    for(int i = 0; i < _triples.count(); i++)
    {
        if(_triples[i]->getUid() == uid) return _triples[i];
    }
    return NULL;
}

QString VNotTriples::toString(QString tabulation) const
{
    QString RetVal = "";
    if(_triples.count() != 0)
    {
        RetVal += "\n" + tabulation + "NOT";
        foreach(VTriple * triple, _triples)
        {
            RetVal += triple->toString(tabulation + "\t");
        }
    }
    return RetVal;
}

/**
 * @brief clone
 * @return Le clone
 */
VNotTriples * VNotTriples::clone(QObject *parent) const
{
    return new VNotTriples(*this, parent);
}
