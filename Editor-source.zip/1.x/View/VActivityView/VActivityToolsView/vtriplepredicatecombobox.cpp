#include "vtriplepredicatecombobox.h"

#include "Model/vapplicationmodel.h"
#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivityCondition/vstatement.h"
#include "Model/VWorld/vwproperty.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"
#include "Model/VWorld/VWorldClass/vwobjectclass.h"

VTriplePredicateComboBox::VTriplePredicateComboBox(VStatement * statement, VTriple * triple, QWidget *parent) :
    QComboBox(parent),
    _triple(triple),
    _statement(statement)
{
    this->setEditable(true);

    addItem("");
    addItem("domain:has-state");
    addItem("domain:has-delay");
    addItem("domain:has-duration");
    addItem("domain:has-random-state");
    addItem("domain:has-significance");
    addItem("domain:has-timestamp");
    addItem("domain:Active");
    addItem("domain:ConstanteAttribute");
    addItem("domain:Delay");
    addItem("domain:Duration");
    addItem("domain:Probability");
    addItem("domain:Timestamp");

    VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
    QList<VWComponentClass *> components = worldModel->getAllComponents();
    QList<VWObjectClass *> objects = worldModel->getObjects();
    QSet<VWProperty *> propertySet;

    foreach(VWComponentClass * component, components)
        foreach(QPointer<VWProperty> property, component->getAllProperties())
            propertySet.insert(property);

    foreach(VWObjectClass * object, objects)
        foreach(QPointer<VWProperty> property, object->getAllProperties())
            propertySet.insert(property);

    foreach(QPointer<VWProperty> property, propertySet)
    {
        addItem(property->getName(), property->getUid());
    }
    connect(this, SIGNAL(currentIndexChanged(int)), this, SLOT(onCurrentIndexChanged(int)));

    setCurrentText(_triple->getPredicate());
}

void VTriplePredicateComboBox::onCurrentIndexChanged(int index)
{
    QString value = this->itemText(index);
    QString data = this->itemData(index).toString();
    qint64 uid = data.toLong();

    VWorldModel * worldModel = &VApplicationModel::getInstance()->getWorldModel();
    QList<VWComponentClass *> components = worldModel->getAllComponents();
    QList<VWObjectClass *> objects = worldModel->getObjects();
    QList<QPointer<VWProperty> > properties;

    foreach(VWComponentClass * component, components)
    {
        properties.append(component->getAllProperties());
    }

    foreach(VWObjectClass * object, objects)
    {
        properties.append(object->getAllProperties());
    }
    foreach(VWProperty * property, properties)
    {
        if(property->getUid() == uid)
        {
            _triple->setPredicate(property);
            return;
        }
    }
    _triple->setPredicate(value);
}
