#include "vspeechactcontent.h"
#include "../../../../../Controller/vtracecontroller.h"
#include <qdom.h>

VSpeechActContent::VSpeechActContent():
    _type(UNDEFINED_SPEECH_ACT_TYPE),
    _plainText(NULL),
    _statement(NULL),
    _query(NULL)
{

}

VSpeechActContent::VSpeechActContent(const VSpeechActContent& content):
    VActivityModelElement(),
    _type(content._type),
    _plainText(content._plainText)
{
    if (_plainText != NULL )_plainText = content._plainText->clone();
    if (_statement != NULL) _statement = content._statement->clone();
    if(_query != NULL) _query = content._query->clone();
}

VSpeechActContent::VSpeechActContent(VPlainText* plainText){
    setPlainText(plainText);
    setType(VSpeechActContentType::PLAIN_TEXT);
}
VSpeechActContent::VSpeechActContent(VStatement *statement){
    setStatement(statement);
    setType(VSpeechActContentType::STATEMENT);
}
VSpeechActContent::VSpeechActContent(VQuery* query){
    setQuery(query);
    setType(VSpeechActContentType::QUERY);
}

VSpeechActContent::~VSpeechActContent()
{
    if (_plainText != NULL ) delete _plainText;
    if (_statement != NULL) delete _statement;
    if(_query != NULL) delete _query;

}

void VSpeechActContent::setType(VSpeechActContentType type){
    if(_type != type)
        _type = type;
}
void VSpeechActContent::setPlainText(VPlainText* plainText){
    _plainText = plainText;
    setType(VSpeechActContentType::PLAIN_TEXT);

    connect(plainText, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    onModified("", plainText);
}
void VSpeechActContent::setStatement(VStatement *statement){
    if(statement == NULL)
        return;

    _statement = statement;
    setType(VSpeechActContentType::STATEMENT);

    connect(statement, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    onModified("", statement);
}
void VSpeechActContent::setQuery(VQuery *query){
    _query = query;
    setType(VSpeechActContentType::QUERY);

    connect(query, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
    onModified("", query);
}

VSpeechActContentType VSpeechActContent::getType()const{
    return _type;
}
VPlainText *VSpeechActContent::getPlainText()const{
    return _plainText;
}
VStatement *VSpeechActContent::getStatement()const{
    return _statement;
}
VQuery *VSpeechActContent::getQuery()const{
    return _query;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VSpeechActContent::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VSpeechActContent::parseDom()", "<" + elem.tagName() + ">");

    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture du Type de contenu
            if(element.tagName() == "plainText")
            {
                setPlainText(new VPlainText());
                _plainText->parseDom(element);
            }
            else if(element.tagName() == "statement")
            {
                setStatement(new VStatement());
                _statement->parseDom(element);
            }
            else if(element.tagName() == "query")
            {
                setQuery(new VQuery());
                _query->parseDom(element);
            }
        }
        node = node.nextSibling();
    }

    VTraceController::get()->Info("VSpeechActContent::parseDom()", "</" + elem.tagName() + ">");
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VSpeechActContent::ToXml(QString tabulation)
{
    QString RetVal = tabulation;
    QString tab = tabulation;
    VSpeechActContentType my_type = _type;

    RetVal += "<Content>\n";
    tab += "\t";
    QString contenu;
    switch(my_type) {
        case VSpeechActContentType::PLAIN_TEXT:
            {VPlainText* my_content1 = (this->getPlainText());
            contenu = (my_content1->ToXml(tab));}
            break;
        case  VSpeechActContentType::STATEMENT:
            {VStatement* my_content2 = (this->getStatement());
            contenu = (my_content2->ToXml(tab));}
            break;
        case VSpeechActContentType::QUERY:
            {VQuery* my_content3 = (this->getQuery());
            contenu = (my_content3->ToXml(tab));}
            break;
        default: break;
    }
    RetVal += contenu;
    RetVal += tabulation + "</Content>\n";
    return RetVal;
}

VSpeechActContent *VSpeechActContent::clone()
{
    return new VSpeechActContent(*this);
}
