#include "vcontexttabwidget.h"
#include "ui_vcontexttabwidget.h"

#include "Model/VActivity/vtask.h"
#include "Model/VActivity/VActivityCommon/vparam.h"
#include "Model/VActivity/VActivityCommon/vtriple.h"
#include "Model/VActivity/VActivityContext/vcontext.h"
#include "Model/VActivity/VActivityCommon/vrefconcept.h"
#include "Model/VActivity/VActivityContext/vconstraint.h"
#include "Controller/vtracecontroller.h"

/**
 * @brief VContextTabWidget
 * Constructeur
 * @param parent L'objet parent
 */
VContextTabWidget::VContextTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VContextTabWidget),
    _task(NULL),
    _context(NULL)
{
    ui->setupUi(this);
    blackFont = new QFont();
    blackFont->setWeight(QFont::Black);
}

/**
 * @brief ~VContextTabWidget
 * Destructeur
 */
VContextTabWidget::~VContextTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VContextTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setTask
 * Définit la tâche en cours d'édition
 * @param task La tâche en cours d'édition
 */
void VContextTabWidget::setTask(VTask * task)
{
    if (task != _task)
    {
        VTraceController::get()->Info("VContextTabWidget::setTask()", "Task defined");
        _task = task;
    }
    _context = (_task == NULL) ? NULL : _task->getContext();
    updateDisplay();
}

/**
 * @brief getTask
 * Obitent la tâche en cours d'édition
 * @return La tâche en cours d'édition
 */
VTask * VContextTabWidget::getTask() const
{
    return _task;
}

/**
 * @brief updateDisplay
 * Met a jour les intefaces
 * en fonction de la tache sélectionnée
 */
void VContextTabWidget::updateDisplay()
{
    // Vide la vue refconcept
    int RowCountRefConcept = ui->refConceptWidget->rowCount();
    for(int i = 0; i < RowCountRefConcept; i++)
    {
        ui->refConceptWidget->removeRow(0);
    }
    // Vide la vue param
    int RowCountParam = ui->paramWidget->rowCount();
    for(int i = 0; i < RowCountParam; i++)
    {
        ui->paramWidget->removeRow(0);
    }
    // Vide l'arbre des constraints
    int topLevelItemCount = ui->constraintWidget->topLevelItemCount();
    for(int i = 0; i < topLevelItemCount; i++)
    {
        ui->constraintWidget->takeTopLevelItem(0);
    }
    if(_task == NULL || _context == NULL)
    {
        this->setEnabled(false);
    }
    else
    {
        this->setEnabled(true);
        updateRefConceptDisplay();
        updateParamDisplay();
        updateConstraintDisplay();
    }
}

/**
 * @brief updateRefConceptDisplay
 * Met a jour l'inteface des ref concepts
 * en fonction de la tache sélectionnée
 */
void VContextTabWidget::updateRefConceptDisplay()
{
    // Met a jour la vue
    QList<VRefConcept *> refs = _context->getRefs();
    for(int i = 0; i < refs.count(); i++)
    {
        ui->refConceptWidget->insertRow(0);

        QTableWidgetItem* itemPredicate = new QTableWidgetItem();
        itemPredicate->setText(refs[i]->getPredicate());
        itemPredicate->setData(Qt::UserRole, QString::number(refs[i]->getUid()));
        ui->refConceptWidget->setItem(0, 0, itemPredicate);

        QTableWidgetItem* itemRef = new QTableWidgetItem();
        itemRef->setText(refs[i]->getRef());
        itemRef->setData(Qt::UserRole, QString::number(refs[i]->getUid()));
        ui->refConceptWidget->setItem(0, 1, itemRef);

        QTableWidgetItem* itemConcept = new QTableWidgetItem();
        itemConcept->setText(refs[i]->getConcept());
        itemConcept->setData(Qt::UserRole, QString::number(refs[i]->getUid()));
        ui->refConceptWidget->setItem(0, 2, itemConcept);
    }
    // Update de la combo
    ui->refConceptComboBox->clear();
    ui->refConceptComboBox->addItem("");
    QList<VRefConcept *> refConcepts = VRefConcept::getAllRefConcepts();
    for(int i = 0; i < refConcepts.count(); i++)
    {
        ui->refConceptComboBox->addItem(refConcepts[i]->getPredicate() + " - " +
                                        refConcepts[i]->getRef() + " - " +
                                        refConcepts[i]->getConcept(), QString::number(refConcepts[i]->getUid()));
    }
    ui->refConceptWidget->resizeColumnsToContents();
}

/**
 * @brief on_addRefConceptButton_clicked
 * Gère l'ajout de RefConcept
 */
void VContextTabWidget::on_addRefConceptButton_clicked()
{
    VRefConcept * newRefConcept = new VRefConcept();

    QString id = ui->refConceptComboBox->itemData(ui->refConceptComboBox->currentIndex()).toString();
    if(!id.isNull() && !id.isEmpty())
    {
        VRefConcept * refConcept = VRefConcept::getRefConcept(id.toLong());
        newRefConcept->setPredicate(refConcept->getPredicate());
        newRefConcept->setRef(refConcept->getRef());
        newRefConcept->setConcept(refConcept->getConcept());
    }
    _context->addRef(newRefConcept);
}

/**
 * @brief on_refConceptWidget_itemChanged
 * Gère les modifications de RefConcept
 * @param item
 */
void VContextTabWidget::on_refConceptWidget_itemChanged(QTableWidgetItem *item)
{
    if(item != NULL)
    {
        QString var = item->data(Qt::UserRole).toString();
        VRefConcept * refConcept = _context->getRefById(var.toInt());
        if(refConcept == NULL) return;
        if(item->column() == 0)
        {
            if(refConcept->getPredicate() != item->text())
            {
                refConcept->setPredicate(item->text());
            }
        }
        else if(item->column() == 1)
        {
            if(refConcept->getRef() != item->text())
            {
                refConcept->setRef(item->text());
            }
        }
        else if(item->column() == 2)
        {
            if(refConcept->getConcept() != item->text())
            {
                refConcept->setConcept(item->text());
            }
        }
    }
}

/**
 * @brief on_removeRefConceptButton_clicked
 * Gère la supression de RefConcept
 */
void VContextTabWidget::on_removeRefConceptButton_clicked()
{
    QList<QTableWidgetItem *> selectedItems = ui->refConceptWidget->selectedItems();
    if(selectedItems.count() == 3)
    {
        QString var = selectedItems.first()->data(Qt::UserRole).toString();
        VRefConcept * refConcept = _context->getRefById(var.toInt());
        if(refConcept != NULL)
        {
            _context->removeRef(refConcept);
            delete refConcept;
            updateDisplay();
        }
    }
}

/**
 * @brief updateParamDisplay
 * Met a jour l'inteface des params
 * en fonction de la tache sélectionnée
 */
void VContextTabWidget::updateParamDisplay()
{
    // Met a jour la vue
    QList<VParam *> params = _context->getParams();
    for(int i = 0; i < params.count(); i++)
    {
        ui->paramWidget->insertRow(0);

        QTableWidgetItem* itemPredicate = new QTableWidgetItem();
        itemPredicate->setText(params[i]->getPredicate());
        itemPredicate->setData(Qt::UserRole, QString::number(params[i]->getUid()));
        ui->paramWidget->setItem(0, 0, itemPredicate);

        QTableWidgetItem* itemValue = new QTableWidgetItem();
        itemValue->setText(params[i]->getValue());
        itemValue->setData(Qt::UserRole, QString::number(params[i]->getUid()));
        ui->paramWidget->setItem(0, 1, itemValue);
    }
    ui->paramWidget->resizeColumnsToContents();
}

/**
 * @brief on_addRefConceptButton_clicked
 * Gère l'ajout de RefConcept
 */
void VContextTabWidget::on_addParamButton_clicked()
{
    VParam * param = new VParam();
    _context->addParam(param);
}

/**
 * @brief on_refConceptWidget_itemChanged
 * Gère les modifications de RefConcept
 * @param item
 */
void VContextTabWidget::on_paramWidget_itemChanged(QTableWidgetItem *item)
{
    if(item != NULL)
    {
        QString var = item->data(Qt::UserRole).toString();
        VParam * param = _context->getParamById(var.toInt());
        if(param == NULL) return;
        if(item->column() == 0)
        {
            if(param->getPredicate() != item->text())
            {
                param->setPredicate(item->text());
            }
        }
        else if(item->column() == 1)
        {
            if(param->getValue() != item->text())
            {
                param->setValue(item->text());
            }
        }
    }
}

/**
 * @brief on_removeRefConceptButton_clicked
 * Gère la supression de RefConcept
 */
void VContextTabWidget::on_removeParamButton_clicked()
{
    QList<QTableWidgetItem *> selectedItems = ui->paramWidget->selectedItems();
    if(selectedItems.count() == 2)
    {
        QString var = selectedItems.first()->data(Qt::UserRole).toString();
        VParam * param = _context->getParamById(var.toInt());
        if(param != NULL)
        {
            _context->removeParam(param);
            delete param;
        }
    }
}

/**
 * @brief updateConstraintDisplay
 * Met a jour l'inteface des constraints
 * en fonction de la tache sélectionnée
 */
void VContextTabWidget::updateConstraintDisplay()
{
    // Met a jour la vue
    QList<VConstraint *> constraints = _context->getConstraints();
    for(int i = 0; i < constraints.count(); i++)
    {
        QTreeWidgetItem * item = new QTreeWidgetItem(ui->constraintWidget);
        // L'id de constraint est dans la colonne 0
        item->setData(0, Qt::UserRole, constraints[i]->getUid());
        item->setExpanded(true);
        setItemBackgroundColor(item, 0);

        QList<VTriple *> triples = constraints[i]->getTriples();
        for(int j = 0; j < triples.count(); j++)
        {
            QTreeWidgetItem* itemTriple = new QTreeWidgetItem();
            itemTriple->setFlags(itemTriple->flags() | Qt::ItemIsEditable);
            // L'id de constraint est dans la colonne 0
            itemTriple->setData(0, Qt::UserRole, constraints[i]->getUid());
            // L'id de triple est dans la colonne 1
            itemTriple->setData(1, Qt::UserRole, triples[j]->getUid());
            itemTriple->setText(0, "triple");
            itemTriple->setFont(0, *blackFont);
            itemTriple->setText(1, triples[j]->getSubject());
            itemTriple->setText(2, triples[j]->getPredicate());
            itemTriple->setText(3, triples[j]->getObject());
            item->addChild(itemTriple);
        }
    }
    ui->constraintWidget->resizeColumnToContents(1);
    ui->constraintWidget->resizeColumnToContents(2);
    ui->constraintWidget->resizeColumnToContents(3);
}

/**
 * @brief setItemBackgroundColor
 * Définie le backgroundcolor de l'item de begin au nombre de colonne
 * @param item L'item à mettre à jour
 * @param beginIndex L'index de début
 */
void VContextTabWidget::setItemBackgroundColor(QTreeWidgetItem * item, int beginIndex)
{
    for(int i = beginIndex; i < 7; i++)
    {
        item->setBackgroundColor(i, QColor(230, 230, 230));
    }
}

/**
 * @brief on_addConstraintButton_clicked
 * Gère l'ajout de constraint
 */
void VContextTabWidget::on_addConstraintButton_clicked()
{
    if(ui->constraintWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedItem = ui->constraintWidget->selectedItems().first();
        QString constraintId = selectedItem->data(0, Qt::UserRole).toString();
        if(constraintId == "") return;
        VConstraint * constraint = _context->getConstraintById(constraintId.toInt());
        VTriple * triple = new VTriple();
        constraint->addTriple(triple);
    }
    else
    {
        VConstraint * constraint = new VConstraint();
        VTriple * triple = new VTriple();
        constraint->addTriple(triple);
        _context->addConstraint(constraint);
    }
}

/**
 * @brief on_constraintWidget_itemChanged
 * Gère les modifications de constraint
 * @param item
 */
void VContextTabWidget::on_constraintWidget_itemChanged(QTreeWidgetItem *item, int column)
{
    QString constraintId = item->data(0, Qt::UserRole).toString();
    QString tripleId = item->data(1, Qt::UserRole).toString();
    if(tripleId == "" || constraintId == "") return;

    VConstraint * constraint = _context->getConstraintById(constraintId.toInt());
    if(constraint == NULL) return;

    VTriple * triple = constraint->getTripleById(tripleId.toInt());
    if(triple == NULL) return;

    if(column == 1)
    {
        if(triple->getSubject() != item->text(1))
        {
            triple->setSubject(item->text(1));
        }
    }
    else if(column == 2)
    {
        if(triple->getPredicate() != item->text(2))
        {
            triple->setPredicate(item->text(2));
        }
    }
    else if(column == 3)
    {
        if(triple->getObject() != item->text(3))
        {
            triple->setObject(item->text(3));
        }
    }
    else
    {
        item->setText(column, "");
    }
}

/**
 * @brief on_removeConstraintButton_clicked
 * Gère la supression de constraint
 */
void VContextTabWidget::on_removeConstraintButton_clicked()
{
    if(ui->constraintWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedItem = ui->constraintWidget->selectedItems().first();
        QString constraintId = selectedItem->data(0, Qt::UserRole).toString();
        QString tripleId = selectedItem->data(1, Qt::UserRole).toString();
        if(tripleId != "" && constraintId != "")
        {
            VConstraint * constraint = _context->getConstraintById(constraintId.toInt());
            if(constraint == NULL) return;
            VTriple * triple = constraint->getTripleById(tripleId.toInt());
            if(triple == NULL) return;
            constraint->removeTriple(triple);
            delete triple;
        }
        else if(constraintId != "")
        {
            VConstraint * constraint = _context->getConstraintById(constraintId.toInt());
            _context->removeConstraint(constraint);
            delete constraint;
        }
    }
}
