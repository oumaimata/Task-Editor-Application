#pragma once
#ifndef VJENABRIDGE_H
#define VJENABRIDGE_H

#include <QObject>
#include <QString>

#include <jni.h>

/**
 * @brief The VJenaBridge class
 * Classe fournissant l'accès à différentes fonctions de la librairie Jena.
 * Via un pont JNI.
 */
class VJenaBridge : public QObject
{
    Q_OBJECT

private:

    /**
     * @brief _JNIenv
     * Fournit l'accès à l'environement.
     */
    JNIEnv* _JNIenv;

    /**
     * @brief _JVM
     * Fournit l'accès à la Java Virtual Machine (JVM).
     */
    JavaVM* _JVM;

    /**
     * @brief _javaClass
     * Pointeur vers la classe JenaBridge.
     */
    jclass _javaClass;

    /**
     * @brief _javaObject
     * Pointeur vers une instance de la classe JenaBridge (cf _javaClass).
     */
    jobject _javaObject;

    /**
     * @brief _selectMethodID
     * Pointeur vers la méthode runSelectQuery
     * java/lang/String JenaBridge.runSelectQuery(java/lang/String)
     */
    jmethodID _selectMethodID;

    /**
     * @brief _askMethodID
     * Pointeur vers la méthode runAskQuery
     * JenaBridge.runAskQuery(java/lang/String)
     */
    jmethodID _askMethodID;

    /**
     * @brief _loadMethodID
     * Pointeur vers la méthode loadOntology
     * JenaBridge.loadOntology(java/lang/String, java/lang/String, java/lang/String)
     */
    jmethodID _loadMethodID;

    /**
     * @brief _prefixMethodID
     * Pointeur vers la méthode getPrefix
     * java/lang/String JenaBridge.getPrefix()
     */
    jmethodID _prefixMethodID;

    /**
     * @brief _prefix
     * Le préfixe
     */
    QString _prefix;

    /**
     * @brief _hasOntologyLoaded
     * Boolean permettant de savoir si une ontologie est chargée.
     */
    bool _hasOntologyLoaded;

public:

    /**
     * @brief VJenaBridge
     * Constructeur :
     *  - Charge la JVM
     *  - Récupère la classe JenaBridge
     *  - Crée une instance de JenaBridge
     *  - Récupère les méthodes nécessaires
     * @param parent L'object parent
     * @throws std::runtime_error
     */
    explicit VJenaBridge(QObject* parent = NULL);

    /**
     * @brief ~VJenaBridge
     * Destructeur : Destruction de la JVM.
     */
    ~VJenaBridge();

    /**
     * @brief hasOntologyLoaded
     * Obtient si une ontologie a été chargée.
     * @return Si une ontologie a été chargée.
     */
    bool hasOntologyLoaded() const;

    /**
     * @brief setPrefix
     * Définit le préfixe
     * @param prefix Le nouveau préfixe
     */
    void setPrefix(QString prefix);

    /**
     * @brief getPrefix
     * Obtient le préfixe
     * @return  Le préfixe
     */
    QString getPrefix() const;

    /**
     * @brief selectQuery
     * Appelle la méthode runSelectQuery
     * @param query La requète
     * @return Le résultat de la requête
     */
    const char* selectQuery(QString query);

    /**
     * @brief askQuery
     * Appelle la méthode runAskQuery
     * @param query La requête
     * @return Le résultat de la requête (Vrai / Faux)
     */
    bool askQuery(QString query);

    /**
     * @brief loadOntology
     * Appelle la méthode loadOntology pour charger l'ontologie
     * @param path Le chemin vers le fichier
     * @param prefix Le préfixe
     * @param type Le type de fichier
     * @return Si erreur
     * @throws std::runtime_error
     * @see VOntologyInterface::loadOntology
     */
    bool loadOntology(QString path, QString prefix, QString type);
};

#endif // VJENABRIDGE_H
