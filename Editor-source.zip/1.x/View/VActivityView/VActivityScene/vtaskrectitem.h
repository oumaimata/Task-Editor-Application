#pragma once
#ifndef VTASKRECTITEM_H
#define VTASKRECTITEM_H

#include <QGraphicsRectItem>

#include "Model/VActivity/vtask.h"

class VTaskRectItem : public QGraphicsRectItem
{
private:
    QPointer<VTask> _task;

protected:

    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);

    void dragEnterEvent(QGraphicsSceneDragDropEvent* event);

    void dropEvent(QGraphicsSceneDragDropEvent* event);

    QVariant itemChange(GraphicsItemChange change, const QVariant &value);

public:

    enum {Type = UserType + 3};

    VTaskRectItem(qreal x, qreal y, qreal width, qreal height, VTask* task, QGraphicsItem* parent = NULL);

    virtual int type() const;

    virtual void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget);
};

#endif // VTASKRECTITEM_H
