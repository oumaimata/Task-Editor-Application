#include "vwentityclass.h"

#include "../vwparser.h"
#include "../../vapplicationmodel.h"

VWEntityClass::VWEntityClass(QObject *parent) :
    VWorldModelElement(parent)
{
}

/**
 * @brief VWEntityClass
 * @param o L'objet à copier
 */
VWEntityClass::VWEntityClass(const VWEntityClass& o) :
    VWorldModelElement(o)
{
    _components = o._components;
}

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VWEntityClass::ParseDom(QDomElement elem)
{
    VWorldModelElement::ParseDom(elem);
}

/**
 * @brief ParseComponentDom
 * Permet de parser les components
 * @param elem Un élément du dom
 */
void VWEntityClass::ParseComponentDom(QDomElement elem)
{
    QList<QString> supClasses = VWParser::getSupClasses(elem);
    foreach(QString supClass, supClasses)
    {
        this->addComponent(supClass);
    }
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VWEntityClass::ToXml(QString tabulation)
{
    QString RetVal;
    foreach(VWComponentClass * component, _components)
    {
        RetVal += tabulation + "<rdfs:subClassOf rdf:resource=\"#" + component->getName() + "\"/>\n";
    }

    return RetVal;
}

void VWEntityClass::addComponent(QString componentName)
{
    VWComponentClass * component = VApplicationModel::getInstance()->getWorldModel().getComponentByName(componentName);
    if(component != NULL) addComponent(component);
}

void VWEntityClass::addComponent(VWComponentClass * component)
{
    if(component != NULL)
    {
        _components.append(component);
        connect(component, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Component added"));
    }
}

void VWEntityClass::removeComponent(VWComponentClass * component)
{
    if(_components.contains(component))
    {
        _components.removeAll(component);
        disconnect(component, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Component removed"));
    }
}

QList<QPointer<VWComponentClass> > VWEntityClass::getComponents() const
{
    return _components;
}

QPointer<VWComponentClass> VWEntityClass::getComponentByUid(qint64 uid) const
{
    QPointer<VWComponentClass> component = NULL;
    foreach(component, _components)
    {
        if(component->getUid() == uid) return component;
    }
    return NULL;
}
