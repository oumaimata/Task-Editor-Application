# EDITOR

## Compilation

### Outils nécessaires:
* le JDK pour le pont JNI.
* QtLinguist pour faire une release du fichier de traduction (EDITOR_fr.ts).
* QtCreator/Qt5 en 32bits (pour la compatibilité JNI/JENA).
* Compilateur : MinGW (Windows) et G++ (Linux).

* Compiler le projet avec QtCreator.
* Compiler les traductions avec QTLinguist et les recopier dans le dossier contenant l'executable.

### Linux
Après exécution de qmake, le makefile peut contenir "-lGL" à la ligne LIBS.
Si c'est le cas, il faut le retirer.

## Déploiement

Il faut copier la liste des bibliothèques suivante dans le répertoire de EDITOR.

### Windows
* JVM.DLL
* LIBGCC_S_DW2-1.DLL
* LIBSTDC++-6.DLL
* QT5CORE.DLL
* QT5GUI.DLL
* QT5WIDGETS.DLL
* QT5XML.DLL


## Installation

Ajouter une variable d'environement:
```
export JAVA_HOME = /chemin/vers/java_32bit
```
Redémarrer pour que le changement prenne effet.

### Windows
Copier le fichier jvm.dll depuis le répertoire java_32bit vers le répertoire de EDITOR.

### Linux
Copier le fichier libjvm.so depuis le répertoire java_32bit vers le répertoire de EDITOR.

## Ajouter une langue (Le programme est en anglais par défaut)

* Editer le fichier EDITOR.pro, ajouter une ligne à TRANSLATIONS par exemple EDITOR_es.ts pour l'espagnol.
* Dans la console faire "lupdate EDITOR.pro" dans le répertoire du projet, ce qui va créer/mettre à jour les fichiers de traduction.
* Traduire les fichiers .ts avec QtLinguist.
* Compiler les traductions avec QTLinguist et les recopier dans le dossier contenant l'executable.
* Pour charger une nouvelle traduction dans le programme, faire de même que pour la traduction en français.
