#include "vwcomponentnavigatorwidget.h"
#include "ui_vwcomponentnavigatorwidget.h"

#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwcomponentclass.h"

VWComponentNavigatorWidget::VWComponentNavigatorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWComponentNavigatorWidget),
    _edit(false),
    _currentEdit(NULL)
{
    ui->setupUi(this);
}

VWComponentNavigatorWidget::~VWComponentNavigatorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWComponentNavigatorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWComponentNavigatorWidget::setWorldModel(VWorldModel * worldModel)
{
    if(worldModel != _worldModel)
    {
        _worldModel = worldModel;
    }
    updateDisplay();
}

void VWComponentNavigatorWidget::setCurrentEdit(VWorldModelElement * currentEdit)
{
    if(currentEdit != NULL) _currentEdit = currentEdit;
    updateDisplay();
}


void VWComponentNavigatorWidget::updateDisplay()
{
    _edit = true;
    ui->componentTreeWidget->clear();

    QTreeWidgetItem * componentsItem = new QTreeWidgetItem(ui->componentTreeWidget);
    componentsItem->setText(0, "Components");
    componentsItem->setExpanded(true);
    ui->componentTreeWidget->addTopLevelItem(componentsItem);

    if(_worldModel == NULL) return;

    VWComponentClass * component;
    QList<VWComponentClass *> components = _worldModel->getComponents();
    foreach(component, components)
    {
        createComponentItem(componentsItem, component);
    }
    _edit = false;
}

QTreeWidgetItem *  VWComponentNavigatorWidget::createComponentItem(QTreeWidgetItem * parentItem, VWComponentClass * component)
{
    QTreeWidgetItem * item = new QTreeWidgetItem(parentItem);
    item->setText(0, component->getName());
    item->setExpanded(true);
    item->setData(0, Qt::UserRole, component->getUid());
    parentItem->addChild(item);
    item->setSelected(_currentEdit == component);

    VWComponentClass * child;
    QList<VWComponentClass *> childs = component->getChilds();
    foreach(child, childs)
    {
        createComponentItem(item, child);
    }
    return item;
}

void VWComponentNavigatorWidget::on_addButton_clicked()
{
    if(_worldModel == NULL || _edit) return;
    VWComponentClass * component = NULL;
    if(ui->componentTreeWidget->selectedItems().count() != 0)
    {
        QTreeWidgetItem * selectedItem = ui->componentTreeWidget->selectedItems().first();
        QString uid = selectedItem->data(0, Qt::UserRole).toString();

        component = _worldModel->getComponentByUid(uid.toLong());
        if(component != NULL)
        {
            // ajoute un object à l'object sélectionné
            VWComponentClass * newComponent = new VWComponentClass(component);
            _currentEdit = newComponent;
            component->addChild(newComponent);
            return;
        }
    }

    // ajoute un object
    component = new VWComponentClass(_worldModel);
    _currentEdit = component;
    _worldModel->addComponent(component);
    return;
}

void VWComponentNavigatorWidget::on_removeButton_clicked()
{
    if(_worldModel == NULL || _edit || ui->componentTreeWidget->selectedItems().count() == 0) return;
    QTreeWidgetItem * selectedItem = ui->componentTreeWidget->selectedItems().first();
    QString uid = selectedItem->data(0, Qt::UserRole).toString();

    VWComponentClass * component = _worldModel->getComponentByUid(uid.toLong());
    if(component != NULL)
    {
        VWComponentClass * parentComponent = component->getParent();
        if(parentComponent == NULL)
        {
            // supprime un object
            _worldModel->removeComponent(component);
        }
        else
        {
            // supprime un object
            _currentEdit = parentComponent;
            parentComponent->removeChild(component);
        }
        emit removeAsked(component);
        delete component;
        emit removeAsked();
        return;
    }
}

void VWComponentNavigatorWidget::on_componentTreeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column)
{
    if(_worldModel == NULL || _edit || column != 0) return;
    QString uid = item->data(0, Qt::UserRole).toString();

    VWComponentClass * component = _worldModel->getComponentByUid(uid.toLong());
    if(component != NULL)
    {
        emit editComponentAsked(component);
    }
}
