#include "vapplicationcontroller.h"
#include <iostream>
#include <stdexcept>
#include <QFileDialog>
#include <QMessageBox>
#include <QApplication>

#include "vtracecontroller.h"
#include "../View/vmainwindow.h"
#include "../Model/vapplicationmodel.h"

VApplicationController* VApplicationController::_instance;

/*!
 * @brief VApplicationController::VApplicationController
 * Constructeur
 * @param mainWindow Widget de la fenêtre principale
 * @param parent
 */
VApplicationController::VApplicationController(VMainWindow* mainWindow, QObject* parent) :
    QObject(parent),
    _mainWindow(mainWindow)
{

    VTraceController::get()->Debug("VApplicationController::VApplicationController()", "Begin");
    connect(_mainWindow, SIGNAL(newActivityModelAsked()), this, SLOT(newActivityModel()));
    connect(_mainWindow, SIGNAL(activityModelImportAsked(QString)), this, SLOT(importActivityModel(QString)));
    connect(_mainWindow, SIGNAL(activityModelSaveAsked()), this, SLOT(saveActivityModel()));
    connect(_mainWindow, SIGNAL(activityModelExportAsked(QString)), this, SLOT(exportActivityModel(QString)));
    connect(_mainWindow, SIGNAL(newWorldModelAsked()), this, SLOT(newWorldModel()));
    connect(_mainWindow, SIGNAL(worldModelImportAsked(QString)), this, SLOT(importWorldModel(QString)));
    connect(_mainWindow, SIGNAL(worldModelSaveAsked()), this, SLOT(saveWorldModel()));
    connect(_mainWindow, SIGNAL(worldModelExportAsked(QString)), this, SLOT(exportWorldModel(QString)));
    connect(_mainWindow, SIGNAL(cutAsked()), this, SLOT(activityCut()));
    connect(_mainWindow, SIGNAL(copyAsked()), this, SLOT(activityCopy()));
    connect(_mainWindow, SIGNAL(pasteAsked()), this, SLOT(activityPaste()));
    connect(_mainWindow, SIGNAL(quitAsked()), this, SLOT(quit()));
    connect(_mainWindow, SIGNAL(frenchLanguageAsked()), this, SLOT(frenchLanguage()));
    connect(_mainWindow, SIGNAL(englishLanguageAsked()), this, SLOT(englishLanguage()));

    connect(_activityCtrler->getActivityHistorySet(),SIGNAL(hasChanged()), _mainWindow, SLOT(updateState()));
    connect(_worldCtrler->getWorldHistorySet(),SIGNAL(hasChanged()), _mainWindow, SLOT(updateState()));

    connect(this, SIGNAL(newStatus(QString)), _mainWindow, SLOT(changeStatus(QString)));

    VSettings& settings = VApplicationModel::getInstance()->getSettings();
    connect(&settings, SIGNAL(activityImportedFilesChanged(QList<QAction*>)), _mainWindow, SLOT(updateActivityRecentImportedFiles(QList<QAction*>)));
    connect(&settings, SIGNAL(worldImportedFilesChanged(QList<QAction*>)), _mainWindow, SLOT(updateWorldRecentImportedFiles(QList<QAction*>)));
    settings.load();

    frenchTranslator = NULL;
    autoLanguage();

    VTraceController::get()->Debug("VApplicationController::VApplicationController()", "End");
}


VApplicationController* VApplicationController::getInstance(VMainWindow* mainWindow, QObject* parent)
{
    if (_instance == NULL && mainWindow != NULL)
        _instance = new VApplicationController(mainWindow, parent);
    return _instance;
}

/**
 * @brief autoLanguage Choisie la langue de l'application automatiquement
 */
void VApplicationController::autoLanguage()
{
    VTraceController::get()->Debug("VApplicationController::autoLanguage()", "Begin");
    QString locale = QLocale::system().name().section('_', 0, 0);
    if(locale == "fr")
    {
        VTraceController::get()->Info("VApplicationController::autoLanguage()", "Change for french");
        _mainWindow->updateLanguageMenu("fr");
        frenchLanguage();
    }
    VTraceController::get()->Debug("VApplicationController::autoLanguage()", "End");
}

void VApplicationController::switchToActivity()
{
    _mainWindow->switchToActivity();
}

void VApplicationController::switchToWorld()
{
    _mainWindow->switchToWorld();
}

void VApplicationController::switchToHistory()
{
    _mainWindow->switchToHistory();
}

void VApplicationController::setActivityController(VActivityController *  activityCtrler)
{
    _activityCtrler = activityCtrler;
}
VActivityController * VApplicationController::getActivityController() const
{
    return _activityCtrler;
}

void VApplicationController::setWorldController(VWorldController * worldCtrler)
{
    _worldCtrler = worldCtrler;
}
VWorldController * VApplicationController::getWorldController() const
{
    return _worldCtrler;
}


/*!
 * @brief VApplicationController::newActivityModel
 * slot connecté au signal _mainWindow->newActivityModelAsked()
 * Permet la création d'un nouveau modèle d'activité
 */
void VApplicationController::newActivityModel(){
    VApplicationModel::getInstance()->getActivityModel().newActivityModel();
    emit newStatus(tr("New activity model created"));
}
/*!
 * @brief VApplicationController::importActivityModel
 * slot connecté au signal _mainWindow->activityModelImportAsked()
 * Permet l'import d'un modèle d'activité
 */
void VApplicationController::importActivityModel(QString fileName)
{
    VTraceController::get()->Debug("VApplicationController::importActivityModel()", "Begin");

    if(fileName.isNull() || fileName.isEmpty())
        fileName = QFileDialog::getOpenFileName(_mainWindow, tr("Import an activity model"), "./", "*.xml");

    if (!fileName.isNull() && !fileName.isEmpty())
    {
        try
        {
            VApplicationController::getInstance()->getActivityController()->loadModel(fileName);
            VApplicationModel::getInstance()->getSettings().addImportedFile(fileName, VSettings::ACTIVITY);
            VTraceController::get()->Info("VApplicationController::importActivityModel()", "Openning success");
            _activityCtrler->setActivityFileName(fileName);
            emit newStatus(tr("Activity model successfully imported"));

//            QMessageBox::information(NULL, tr("Model importing success"),
//                                           tr("The model has been successfully imported."));
        }
        catch (const std::exception& ex)
        {
            VTraceController::get()->Error("VApplicationController::importActivityModel()", QString("Exception : ").append(ex.what()));
            QMessageBox::warning(NULL, tr("Error during activity model importation"), ex.what());
        }
    }
    VTraceController::get()->Debug("VApplicationController::importActivityModel()", "End");
}



/*!
 * @brief VApplicationController::saveActivityModel
 * slot connecté au signal _mainWindow->activityModelSaveAsked()
 * Permet l'enregistrement d'un modèle d'activité
 */
void VApplicationController::saveActivityModel()
{
    QString fileName = _activityCtrler->getActivityFileName();
    exportActivityModel(fileName);
}

/*!
 * @brief VApplicationController::exportActivityModel
 * slot connecté au signal _mainWindow->activityModelExportAsked()
 * Permet l'export d'un modèle d'activité
 */
void VApplicationController::exportActivityModel(QString fileName)
{
    VTraceController::get()->Debug("VApplicationController::exportActivityModel()", "Begin");

    if(fileName.isNull() || fileName.isEmpty())
        fileName = QFileDialog::getSaveFileName(_mainWindow, tr("Export the activity model"), "./", "*.xml");

    if(!fileName.isNull() && !fileName.isEmpty()){
        if(fileName.section('.', -1) != "xml") fileName += ".xml";
        QFile fichier(fileName);
        fichier.open(QIODevice::WriteOnly | QIODevice::Text);
        fichier.write("\xEF\xBB\xBF"); // Ajoute le BOM pour être en UTF-8 et non UTF-8 sans BOM
        QTextStream flux(&fichier);
        flux.setCodec("UTF-8");
        flux << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + VApplicationModel::getInstance()->getActivityModel().ToXml();
        fichier.close();

        _activityCtrler->setActivityFileName(fileName);
        VHistorySet* activityHistorySet = _activityCtrler->getActivityHistorySet();
        if (activityHistorySet->size() != 0){
            VHistoryState lastActivityHistoryStateSaved = activityHistorySet->last();
             activityHistorySet->setLastHistoryStateSaved(lastActivityHistoryStateSaved);
        }
        _mainWindow->updateState();
        emit newStatus(tr("Activity model successfully saved"));
    }
        VTraceController::get()->Debug("VApplicationController::exportActivityModel()", "End");
}

/*!
 * @brief VApplicationController::newWorldModel
 * slot connecté au signal _mainWindow->newWorldModelAsked()
 * Permet la création d'un nouveau modèle du monde
 */
void VApplicationController::newWorldModel(){
    VApplicationModel::getInstance()->getWorldModel().newWorldModel();
    emit newStatus(tr("New world model created"));
}
/*!
 * @brief VApplicationController::importWorldModel
 * slot connecté au signal _mainWindow->worldModelImportAsked()
 * Permet l'import d'un modèle du monde
 */
void VApplicationController::importWorldModel(QString fileName)
{
    VTraceController::get()->Debug("VApplicationController::importWorldModel()", "Begin");
    if( fileName.isNull() || fileName.isEmpty())
        fileName = QFileDialog::getOpenFileName(_mainWindow, tr("Import a world model"), "./", "*.owl");

    if (!fileName.isNull() && !fileName.isEmpty())
    {
        try
        {
            VApplicationController::getInstance()->getWorldController()->loadModel(fileName);
            VTraceController::get()->Info("VApplicationController::importWorldModel()", "Import success");
            _worldCtrler->setWorldFileName(fileName);
            VApplicationModel::getInstance()->getSettings().addImportedFile(fileName, VSettings::WORLD);
            emit newStatus(tr("World model successfully imported."));
//            QMessageBox::information(NULL, tr("Model importation success"),
//                                           tr("The model has been successfully imported."));

        }
        catch (const std::exception& ex)
        {
            VTraceController::get()->Error("VApplicationController::importWorldModel()", QString("Exception : ").append(ex.what()));
            QMessageBox::warning(NULL, tr("Error during world model importation"), ex.what());
        }
    }
    VTraceController::get()->Debug("VApplicationController::importWorldModel()", "End");
}


void VApplicationController::saveWorldModel(){
    QString fileName = _worldCtrler->getWorldFileName();
    exportWorldModel(fileName);
}

/**
 * @brief exportWorldModel
 * slot connecté au signal _mainWindow->worldModelExportAsked()
 * Permet l'export d'un modèle du monde
 */
void VApplicationController::exportWorldModel()
{
    exportWorldModel(NULL);
}

/*!
 * @brief VApplicationController::exportWorldModel
 * slot connecté au signal _mainWindow->worldModelExportAsked()
 * Permet l'export d'un modèle du monde
 */
void VApplicationController::exportWorldModel(QString fileName)
{
    VTraceController::get()->Debug("VApplicationController::exportWorldModel()", "Begin");

    if(fileName.isNull() || fileName.isEmpty())
        fileName = QFileDialog::getSaveFileName(_mainWindow, tr("Export the world model"), "./", "*.owl");
    if(!fileName.isNull() && !fileName.isEmpty()){
        if(fileName.section('.', -1) != "owl") fileName += ".owl";
        QFile fichier(fileName);
        fichier.open(QIODevice::WriteOnly | QIODevice::Text);
        fichier.write("\xEF\xBB\xBF"); // Ajoute le BOM pour être en UTF-8 et non UTF-8 sans BOM
        QTextStream flux(&fichier);
        flux.setCodec("UTF-8");
        flux << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + VApplicationModel::getInstance()->getWorldModel().ToXml(NULL);
        fichier.close();
        _worldCtrler->setWorldFileName(fileName);

        VHistorySet* worldHistorySet = _worldCtrler->getWorldHistorySet();
        if (worldHistorySet->size() != 0){
            VHistoryState lastWordHistoryStateSaved = worldHistorySet->last();
             worldHistorySet->setLastHistoryStateSaved(lastWordHistoryStateSaved);
        }
        _mainWindow->updateState();
        emit newStatus(tr("World model successfully saved"));
    }
    VTraceController::get()->Debug("VApplicationController::exportWorldModel()", "End");
}

/**
 * @brief activityCut
 * Slot connecté au signal _mainWindow->cutAsked()
 * Permet de couper une partie de l'arbre d'activité
 */
void VApplicationController::activityCut()
{
    _activityCtrler->cut();
    emit newStatus(tr("cut done"));
}

/**
 * @brief activityCopy
 * Slot connecté au signal _mainWindow->copyAsked()
 * Permet de copier une partie de l'arbe d'activité
*/
void VApplicationController::activityCopy()
{
    _activityCtrler->copy();
    emit newStatus(tr("copy done"));
}

/**
 * @brief activityPaste
 * Slot connecté au signal _mainWindow->pasteAsked()
 * Permet de coller une partie de l'arbre d'activité
 */
void VApplicationController::activityPaste()
{
    _activityCtrler->paste();
    emit newStatus(tr("paste done"));
}

/**
 * @brief quit
 * Slot connecté au signal _mainWindow->quitAsked()
 * Permet quitter le programme
 */
void VApplicationController::quit(){

    QString msgBoxText = "";
    if(!(_activityCtrler->isActivityModelSaved()))
        msgBoxText.append("- " + tr("Activity model was not saved") + ".\n");
    if(!(_worldCtrler->isWorldModelSaved()))
        msgBoxText.append("- " + tr("World model was not saved") + ".");
    if(!msgBoxText.isEmpty()){
        QMessageBox msgBox;
        msgBox.setText(msgBoxText);
        msgBox.setInformativeText(tr("Are you sure you want to quit ?"));
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        msgBox.setDefaultButton(QMessageBox::No);
        int ret = msgBox.exec();
        if(ret == QMessageBox::No )
            return;
    }
    saveSettings();
    qApp->quit();

}

/**
 * @brief frenchLanguage
 * Slot connecté au signal _mainWindow->frenchLanguageAsked()
 * Permet le passage au français
 */
void VApplicationController::frenchLanguage()
{
    QApplication* app = qobject_cast<QApplication*>(parent());
    if(app != NULL)
    {
        if(frenchTranslator ==  NULL)
        {
            // Chargement de la traduction
            frenchTranslator = new QTranslator();
            if(frenchTranslator->load(app->applicationDirPath() + "/EDITOR_fr.qm"))
                VTraceController::get()->Info("VApplicationController::frenchLanguage()", "Traduction chargée");
            else
                VTraceController::get()->Error("VApplicationController::frenchLanguage()", "Echec chargement de traduction");
        }
        if(app->installTranslator(frenchTranslator))
            VTraceController::get()->Info("VApplicationController::frenchLanguage()", "Traduction installée");
        else
            VTraceController::get()->Error("VApplicationController::frenchLanguage()", "Echec installation de traduction");
    }
    else
    {
        VTraceController::get()->Error("VApplicationController::frenchLanguage()", "Echec de qobject_cast<QApplication*>()");
    }
}

/**
 * @brief englishLanguage
 * Slot connecté au signal _mainWindow->englishLanguageAsked()
 * Permet le passage a l'anglais
 */
void VApplicationController::englishLanguage()
{
    if(frenchTranslator != NULL)
    {
        QApplication* app = qobject_cast<QApplication*>(parent());
        if(app != NULL)
        {
            if(app->removeTranslator(frenchTranslator))
            {
                VTraceController::get()->Info("VApplicationController::englishLanguage()", "Traduction installée");
            }
            else
            {
                VTraceController::get()->Error("VApplicationController::englishLanguage()", "Echec installation de traduction");
            }
        }
        else
        {
            VTraceController::get()->Error("VApplicationController::englishLanguage()", "Echec de qobject_cast<QApplication*>()");
        }
    }
}


bool VApplicationController::isApplicationSaved(){
    return _activityCtrler->isActivityModelSaved() && _worldCtrler->isWorldModelSaved();
}

void VApplicationController::saveSettings(){
    VApplicationModel::getInstance()->getSettings().save();
}
