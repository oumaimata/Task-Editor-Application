#pragma once
#ifndef VOPERATIONTABWIDGET_H
#define VOPERATIONTABWIDGET_H

#include <QWidget>
#include <QTableWidgetItem>
#include <QTreeWidgetItem>
#include <QButtonGroup>



class VTask;
class VTriple;
class VNotTriples;
class VOperation;
class VElementCreator;
class VAddressee;
class VStatement;

namespace Ui {
class VOperationTabWidget;
}

class VOperationTabWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VOperationTabWidget *ui;

    /**
     * @brief _actionComboBoxEdit
     * Si ui->actionComboBox est en cours d'édition
     */
    bool _actionComboBoxEdit;

    /**
     * @brief _performativeComboBoxEdit
     * Si ui->_performativeComboBoxEdit est en cours d'édition
     */
    bool _performativeComboBoxEdit;

    bool _contentTypeGroupEdit;

    /**
     * @brief task
     * Tâche en cours d'édition
     */
    VTask * _task;

    /**
     * @brief _operation
     * L'opération en cours d'édition
     */
    VOperation * _operation;

    /**
     * @brief elementCreator
     * La fenêtre de création d'élément
     */
    VElementCreator * _elementCreator;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);
    
public:
    /**
     * @brief VOperationTabWidget
     * Constructeur
     * @param parent L'objet parent
     */
    explicit VOperationTabWidget(QWidget *parent = 0);

    /**
     * @brief ~VOperationTabWidget
     * Destructeur
     */
    ~VOperationTabWidget();

    /**
     * @brief setTask
     * Définit la tâche en cours d'édition
     * @param task La tâche en cours d'édition
     */
    void setTask(VTask *task);

    /**
     * @brief getTask
     * Obitent la tâche en cours d'édition
     * @return La tâche en cours d'édition
     */
    VTask * getTask() const;

private:

    /**
     * @brief updateDisplay
     * Met a jour les intefaces
     * en fonction de la tache sélectionnée
     */
    void updateDisplay();

    /**
     * @brief updateRefConceptDisplay
     * Met a jour l'inteface des ref concepts
     * en fonction de la tache sélectionnée
     */
    void updateRefConceptDisplay();

    /**
     * @brief updateParamDisplay
     * Met a jour l'inteface des params
     * en fonction de la tache sélectionnée
     */
    void updateParamDisplay();

    /**
     * @brief updateActionDisplay
     * Met a jour l'inteface de l'action
     * en fonction de la tache sélectionnée
     */
    void updateActionDisplay();

    void updateSpeechActDisplay();

    /**
     * @brief addAddresseeItem
     * Retourne et ajoute un item d'arbre correspondant à un addAddresseeItem
     */
    QTreeWidgetItem * addAddresseeItem(QTreeWidget * parent, VAddressee * addressee);

    QTreeWidgetItem * addAgentItem(QTreeWidget * tree, QTreeWidgetItem* parent, VAddressee *addressee, int agentIndex);

    QTreeWidgetItem * addStatementItem(QTreeWidget * tree, QTreeWidgetItem* parent, VStatement * statement);

    QTreeWidgetItem * addTripleItem(QTreeWidget* tree, QTreeWidgetItem *parent, VTriple * triple, VStatement * statement, VNotTriples * notTriples);


private slots:
    /**
     * @brief on_addRefConceptButton_clicked
     * Gère l'ajout de RefConcept
     */
    void on_addRefConceptButton_clicked();

    /**
     * @brief on_refConceptWidget_itemChanged
     * Gère les modifications de RefConcept
     * @param item
     */
    void on_refConceptWidget_itemChanged(QTableWidgetItem *item);

    /**
     * @brief on_removeRefConceptButton_clicked
     * Gère la supression de RefConcept
     */
    void on_removeRefConceptButton_clicked();

    /**
     * @brief on_addRefConceptButton_clicked
     * Gère l'ajout de Param
     */
    void on_addParamButton_clicked();

    /**
     * @brief on_refConceptWidget_itemChanged
     * Gère les modifications de Param
     * @param item
     */
    void on_paramWidget_itemChanged(QTableWidgetItem *item);

    /**
     * @brief on_removeRefConceptButton_clicked
     * Gère la supression de Param
     */
    void on_removeParamButton_clicked();

    /**
     * @brief on_actionComboBox_currentIndexChanged
     * Gère la modification de l'action
     * @param index Index du nouvel item sémectioné
     */
    void on_actionComboBox_currentIndexChanged(int index);

    /**
     * @brief VOperationTabWidget::on_addNewAction_clicked
     * Gère la demande d'ajout d'une nouvelle action
     */
    void on_addNewAction_clicked();

    /**
     * @brief onElementCreatorClose
     * Gère la fermeture de la fenêtre d'ajout d'action
     */
    void onElementCreatorClose();

    void on_operationTypeGroup_buttonClicked(QAbstractButton* button);

    void on_contentTypeGroup_buttonToggled(QAbstractButton* button, bool checked);

    /**
     * @brief on_actionComboBox_currentIndexChanged
     * Gère la modification du performatif
     * @param index Index du nouvel item sélectioné
     */
    void on_performativeComboBox_currentIndexChanged(int index);

    void on_addContentStatementButton_clicked();

    void on_targetLineEdit_editingFinished();

    void on_removeContentStatementButton_clicked();

    void on_addAddresseeStatementButton_clicked();

    void on_removeAddresseeStatementButton_clicked();

};

#endif // VOPERATIONTABWIDGET_H
