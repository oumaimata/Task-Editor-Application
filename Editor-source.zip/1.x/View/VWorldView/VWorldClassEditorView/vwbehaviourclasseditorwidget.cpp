#include "vwbehaviourclasseditorwidget.h"
#include "ui_vwbehaviourclasseditorwidget.h"

#include "Model/vapplicationmodel.h"
#include "Model/VWorld/vworldmodel.h"
#include "Model/VWorld/VWorldClass/vwbehaviourclass.h"
#include "Model/VWorld/VWorldClass/vweventclass.h"

VWBehaviourClassEditorWidget::VWBehaviourClassEditorWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWBehaviourClassEditorWidget),
    _edit(false),
    _behaviourClass(NULL)
{
    ui->setupUi(this);
    retranslate();
}

VWBehaviourClassEditorWidget::~VWBehaviourClassEditorWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWBehaviourClassEditorWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

void VWBehaviourClassEditorWidget::retranslate()
{
    ui->propertiesEditorWidget->setLabelCol(0, tr("Parameter"));
    ui->propertiesEditorWidget->setLabelCol(1, tr("Type"));
}

void VWBehaviourClassEditorWidget::setBehaviourClass(VWBehaviourClass * behaviourClass)
{
    if(behaviourClass != _behaviourClass)
    {
        _behaviourClass = behaviourClass;
    }
    updateDisplay();
}

void VWBehaviourClassEditorWidget::updateDisplay()
{
    _edit = true;
    ui->nameLineEdit->setText("");
    ui->eventComboBox->clear();
    while(ui->eventTableWidget->rowCount() > 0)
    {
        ui->eventTableWidget->removeRow(0);
    }

    if(_behaviourClass == NULL) return;
    ui->nameLineEdit->setText(_behaviourClass->getName());

    ui->durativeRadioButton->setChecked(_behaviourClass->getIsDurative());
    ui->punctualRadioButton->setChecked(_behaviourClass->getIsPunctual());

    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();

    QPointer<VWEventClass> qEvent;
    QList<QPointer<VWEventClass> > qEvents = _behaviourClass->getEvents();
    foreach(qEvent, qEvents)
    {
        if(qEvent != NULL)
        {
            ui->eventTableWidget->insertRow(0);
            QTableWidgetItem* item = new QTableWidgetItem();
            item->setText(qEvent->getName());
            item->setData(Qt::UserRole, qEvent->getUid());
            ui->eventTableWidget->setItem(0, 0, item);
        }
    }

    VWEventClass * event;
    QList<VWEventClass * > events = worldModel->getEvents();
    foreach(event, events)
    {
        if(!_behaviourClass->getEvents().contains(event))
        {
            ui->eventComboBox->addItem(event->getName(), event->getUid());
        }
    }
    ui->eventTableWidget->resizeColumnsToContents();

    ui->propertiesEditorWidget->setProperties(_behaviourClass->getProperties());

    // Component
    ui->componentEditorWidget->setEntity(_behaviourClass);
    _edit = false;
}

void VWBehaviourClassEditorWidget::on_nameLineEdit_editingFinished()
{
    if(_edit) return;
    _behaviourClass->setName(ui->nameLineEdit->text());
}

void VWBehaviourClassEditorWidget::on_addEventButton_clicked()
{
    QString uid = ui->eventComboBox->itemData(ui->eventComboBox->currentIndex()).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWEventClass * event = worldModel->getEventByUid(uid.toLong());
    if(event != NULL) _behaviourClass->addEvent(event);
}

void VWBehaviourClassEditorWidget::on_removeEventButton_clicked()
{
    if(ui->eventTableWidget->selectedItems().count() == 0) return;
    QTableWidgetItem * item = ui->eventTableWidget->selectedItems().first();
    QString uid = item->data(Qt::UserRole).toString();
    VWorldModel* worldModel = &VApplicationModel::getInstance()->getWorldModel();
    VWEventClass * event = worldModel->getEventByUid(uid.toLong());
    if(event != NULL) _behaviourClass->removeEvent(event);
}

void VWBehaviourClassEditorWidget::on_durativeRadioButton_toggled(bool checked)
{
    if(_edit) return;
    _behaviourClass->setIsDurative(checked);
}

void VWBehaviourClassEditorWidget::on_punctualRadioButton_toggled(bool checked)
{
    if(_edit) return;
    _behaviourClass->setIsPunctual(checked);
}
