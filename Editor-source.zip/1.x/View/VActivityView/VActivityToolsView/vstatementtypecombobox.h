#pragma once
#ifndef VSTATEMENTTYPECOMBOBOX_H
#define VSTATEMENTTYPECOMBOBOX_H

#include <QComboBox>

class VStatement;

class VStatementTypeComboBox : public QComboBox
{
    Q_OBJECT
private:
    VStatement * _statement;
public:
    explicit VStatementTypeComboBox(VStatement * statement, QWidget *parent = 0);
    
signals:
    
public slots:
    void statementTypeChanged(QString s);
    
};

#endif // VSTATEMENTTYPECOMBOBOX_H
