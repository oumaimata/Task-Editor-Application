#pragma once
#ifndef VHISTORYSTATE_H
#define VHISTORYSTATE_H

#include <QObject>
#include <QDateTime>

/**
 * @brief The VHistoryState class
 * Classe décrivant un état du programme pour l'historique
 */
class VHistoryState : public QObject
{
    Q_OBJECT

private:
     /**
      * @brief Time Temps d'occurence du changement
      */
     QDateTime Time;

     /**
      * @brief Label Libellé du changement
      */
     QString Label;

     /**
      * @brief Desc Description du changement
      */
     QString Desc;

     /**
      * @brief Value Valeur du changement
      */
     QString Value;

public:
    /**
     * @brief VHistoryState
     * Constructeur par défaut
     * @param parent
     */
    explicit VHistoryState(QObject *parent = 0);

    /**
     * @brief VHistoryState
     * Constructeur par copie
     * @param original L'original
     */
    VHistoryState(const VHistoryState &original);

    VHistoryState& operator=(const VHistoryState &original);

    /**
     * @brief VHistoryState
     * Constructeur définissant tous les attributs
     * et Time est définit au temps actuel
     * @param label le libellé du changement
     * @param desc La descritption du changement
     */
    explicit VHistoryState(QString label, QString desc);

    /**
     * @brief VHistoryState
     * Constructeur définissant tous les attributs
     * et Time est définit au temps actuel
     * @param label le libellé du changement
     * @param desc La descritption du changement
     * @param parent
     */
    explicit VHistoryState(QString label, QString desc, QString value, QObject *parent = 0);

    /**
     * @brief getTime
     * Obtient le temps d'occurence du changement
     * @return Le temps d'occurence du changement
     */
    QDateTime getTime() const;

    /**
     * @brief setTime
     * Définit le temps d'occurence du changement
     * @param time Le temps d'occurence du changement
     */
     void setTime(QDateTime time);

     /**
      * @brief getLabel
      * Obtient le libellé du changement
      * @return Le libellé du changement
      */
     QString getLabel() const;

     /**
      * @brief setLabel
      * Définit le libellé du changement
      * @param time Le libellé du changement
      */
      void setLabel(QString label);

      /**
       * @brief getDesc
       * Obtient la descritption du changement
       * @return La descritption du changement
       */
      QString getDesc() const;

      /**
      * @brief setDesc
      * Définit la descritption du changement
      * @param desc La descritption du changement
      */
       void setDesc(QString desc);

       /**
       * @brief getValue
       * Obtient la valeur du changement
       * @return La valeur du changement
       */
       QString getValue() const;

       /**
       * @brief setValue
       * Définit la valeur du changement
       * @param desc La valeur du changement
       */
       void setValue(QString value);

       /**
        * @brief operator ==
        * Opérateur de comparaison
        * @param historyState L'élément à comparer
        * @return Si les deux object sont éguaux
        */
       bool operator==(const VHistoryState& historyState) const;
};

#endif // VHISTORYSTATE_H
