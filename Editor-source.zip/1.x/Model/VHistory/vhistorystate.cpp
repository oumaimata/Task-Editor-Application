#include "vhistorystate.h"

/**
* @brief VHistoryState
* Constructeur par défaut
* @param parent
*/
VHistoryState::VHistoryState(QObject* parent) :
    QObject(parent)
{
}

/**
 * @brief VHistoryState
 * Constructeur par copie
 * @param original L'original
 */
VHistoryState::VHistoryState(const VHistoryState &original) :
    QObject(original.parent())
{
    setTime(original.Time);
    setLabel(original.Label);
    setDesc(original.Desc);
    setValue(original.Value);
}

VHistoryState& VHistoryState::operator=(const VHistoryState &original)
{
    setTime(original.Time);
    setLabel(original.Label);
    setDesc(original.Desc);
    setValue(original.Value);
    return *this;
}

/**
 * @brief VHistoryState
 * Constructeur définissant tous les attributs
 * et Time est définit au temps actuel
 * @param label le libellé du changement
 * @param desc La descritption du changement
 */
VHistoryState::VHistoryState(QString label, QString desc) :
    QObject(NULL)
{
    setTime(QDateTime::currentDateTime());
    setLabel(label);
    setDesc(desc);
    setValue(NULL);
}

/**
 * @brief VHistoryState
 * Constructeur définissant tous les attributs
 * et Time est définit au temps actuel
 * @param label le libellé du changement
 * @param desc La descritption du changement
 * @param parent
 */
VHistoryState::VHistoryState(QString label, QString desc, QString value, QObject *parent) :
    QObject(parent)
{
    setTime(QDateTime::currentDateTime());
    setLabel(label);
    setDesc(desc);
    setValue(value);
}


/**
* @brief getTime
* Obtient le temps d'occurence du changement
* @return Le temps d'occurence du changement
*/
QDateTime VHistoryState::getTime() const
{
    return Time;
}

/**
* @brief setTime
* Définit le temps d'occurence du changement
* @param time Le temps d'occurence du changement
*/
void VHistoryState::setTime(QDateTime time)
{
    Time = time;
}

/**
* @brief getLabel
* Obtient le libellé du changement
* @return Le libellé du changement
*/
QString VHistoryState::getLabel() const
{
    return Label;
}

/**
* @brief setLabel
* Définit le libellé du changement
* @param time Le libellé du changement
*/
void VHistoryState::setLabel(QString label)
{
    Label = label;
}

/**
* @brief getDesc
* Obtient la descritption du changement
* @return La descritption du changement
*/
QString VHistoryState::getDesc() const
{
    return Desc;
}

/**
* @brief setDesc
* Définit la descritption du changement
* @param desc La descritption du changement
*/
void VHistoryState::setDesc(QString desc)
{
    Desc = desc;
}

/**
* @brief getValue
* Obtient la valeur du changement
* @return La valeur du changement
*/
QString VHistoryState::getValue() const
{
    return Value;
}

/**
* @brief setValue
* Définit la valeur du changement
* @param desc La valeur du changement
*/
void VHistoryState::setValue(QString value)
{
    Value = value;
}

/**
 * @brief operator ==
 * Opérateur de comparaison
 * @param historyState L'élément à comparer
 * @return Si les deux object sont éguaux
 */
bool VHistoryState::operator==(const VHistoryState& historyState) const
{
    return Time == historyState.Time &&
           Desc == historyState.Desc &&
           Desc == historyState.Desc &&
           Value == historyState.Value;
}
