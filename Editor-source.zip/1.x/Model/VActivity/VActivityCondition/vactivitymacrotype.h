#pragma once
#ifndef VACTIVITYMACROTYPE_H
#define VACTIVITYMACROTYPE_H

#include <QString>

/**
 * @brief The VActivityMacroType enum
 * Enumération des différents type de macro
 */
enum VActivityMacroType
{
    notEqual = 0,
    lessThan = 1,
    greaterThan = 2,
    SIZE_OF_VActivityMacroType
};

static QString VActivityMacroTypeToString(VActivityMacroType type)
{
    switch(type)
    {
    case notEqual:
        return "notEqual";
        break;
    case lessThan:
        return "lessThan";
        break;
    case greaterThan:
        return "greaterThan";
        break;
    default:
        return "";
        break;
    }
}

static VActivityMacroType VActivityMacroTypeFromString(QString type)
{
    if(type.toLower() == "notequal")
    {
        return notEqual;
    }
    else if(type.toLower() == "lessthan")
    {
        return lessThan;
    }
    else if(type.toLower() == "greaterthan")
    {
        return greaterThan;
    }
    else
    {
        return SIZE_OF_VActivityMacroType;
    }
}

#endif // VACTIVITYMACROTYPE_H
