#pragma once
#ifndef VACTIVITYOPERATORTYPE_H
#define VACTIVITYOPERATORTYPE_H

#include <QString>
#include <QList>

#include "vactivityconstructortype.h"

/**
 * @brief The VActivityOperatorType enum
 * Enumération des différents type d'opérateur
 */
enum VActivityOperatorType
{
    lt = 0,
    gt = 1,
    m = 2,
    mi = 3,
    o = 4,
    oi = 5,
    s = 6,
    si = 7,
    d = 8,
    di = 9,
    f = 10,
    fi = 11,
    equal = 12,
    SIZE_OF_VActivityOperatorType
};

static QString VActivityOperatorTypeToString(VActivityOperatorType type, bool forDisplay = false)
{
    switch(type)
    {
    case lt:
        return forDisplay ? "<" : "&lt;";
        break;
    case gt:
        return forDisplay ? ">" : "&gt;";
        break;
    case m:
        return "m";
        break;
    case mi:
        return "mi";
        break;
    case o:
        return "o";
        break;
    case oi:
        return "oi";
        break;
    case s:
        return "s";
        break;
    case si:
        return "si";
        break;
    case d:
        return "d";
        break;
    case di:
        return "di";
        break;
    case f:
        return "f";
        break;
    case fi:
        return "fi";
        break;
    case equal:
        return "=";
        break;
    default:
        return "";
        break;
    }
}

static VActivityOperatorType VActivityOperatorTypeFromString(QString type)
{
    if(type.toLower() == "<" || type.toLower() == "&lt;")
    {
        return lt;
    }
    else if(type.toLower() == ">" || type.toLower() == "&gt;")
    {
        return gt;
    }
    else if(type.toLower() == "m")
    {
        return m;
    }
    else if(type.toLower() == "mi")
    {
        return mi;
    }
    else if(type.toLower() == "o")
    {
        return o;
    }
    else if(type.toLower() == "oi")
    {
        return oi;
    }
    else if(type.toLower() == "s")
    {
        return s;
    }
    else if(type.toLower() == "si")
    {
        return si;
    }
    else if(type.toLower() == "d")
    {
        return d;
    }
    else if(type.toLower() == "di")
    {
        return di;
    }
    else if(type.toLower() == "f")
    {
        return f;
    }
    else if(type.toLower() == "fi")
    {
        return fi;
    }
    else if(type.toLower() == "=")
    {
        return equal;
    }
    else
    {
        return SIZE_OF_VActivityOperatorType;
    }
}

static QList<VActivityOperatorType> VActivityOperatorTypeFor(VActivityConstructorType type)
{
    QList<VActivityOperatorType> RetVal;
    switch(type)
    {
    case Ind:
        RetVal.append(lt); // <
        RetVal.append(gt); // >
        RetVal.append(m);
        RetVal.append(mi);
        RetVal.append(o);
        RetVal.append(oi);
        RetVal.append(s);
        RetVal.append(si);
        RetVal.append(d);
        RetVal.append(di);
        RetVal.append(f);
        RetVal.append(fi);
        RetVal.append(equal);
        return RetVal;
        break;
    case Seq:
        RetVal.append(lt); // <
        RetVal.append(gt); // >
        RetVal.append(m);
        RetVal.append(mi);
        return RetVal;
        break;
    case SeqOrd:
        RetVal.append(lt); // <
        RetVal.append(m);
        return RetVal;
        break;
    case Par:
        RetVal.append(o);
        RetVal.append(oi);
        RetVal.append(s);
        RetVal.append(si);
        RetVal.append(d);
        RetVal.append(di);
        RetVal.append(f);
        RetVal.append(fi);
        RetVal.append(equal);
        return RetVal;
        break;
    case ParSim:
        RetVal.append(equal);
        return RetVal;
        break;
    case ParStart:
        RetVal.append(s);
        RetVal.append(si);
        RetVal.append(equal);
        return RetVal;
        break;
    case ParEnd:
        RetVal.append(f);
        RetVal.append(fi);
        RetVal.append(equal);
        return RetVal;
        break;
    default:
        return RetVal;
        break;
    }
}

static VActivityOperatorType VActivityOperatorDefaultTypeFor(VActivityConstructorType type)
{
    switch(type)
    {
    case Ind:
        return lt; // <
        break;
    case Seq:
        return lt; // <
        break;
    case SeqOrd:
        return lt; // <
        break;
    case Par:
        return equal;
        break;
    case ParSim:
        return equal;
        break;
    case ParStart:
        return equal;
        break;
    case ParEnd:
        return equal;
        break;
    default:
        return SIZE_OF_VActivityOperatorType;
        break;
    }
}

#endif // VACTIVITYOPERATORTYPE_H
