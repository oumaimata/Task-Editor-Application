#pragma once
#ifndef VQUERY_H
#define VQUERY_H
#include "../../../VActivityCondition/vstatement.h"

class VQuery : public VActivityModelElement
{
    Q_OBJECT
public:
    VQuery();
    VQuery(const VQuery& query, QObject* parent = 0);
    ~VQuery();
    void setStatement(VStatement* statement);
    void setTarget(const QString& target);
    VStatement *getStatement()const;
    QString getTarget()const;
   
    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);
    
    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");
    VQuery* clone() const;

private:
    VStatement* _statement;
    QString _target;

};

#endif // VQUERY_H
