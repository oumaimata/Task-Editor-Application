#pragma once
#ifndef VWPROPERTYVALUE_H
#define VWPROPERTYVALUE_H

#include <QObject>
#include <QDate>
#include <QDateTime>

#include "VWorldInstance/vwinstance.h"

class VWProperty;

class VWPropertyValue : public QObject
{
    Q_OBJECT
private:

    /**
     * @brief _basicType
     * Pour les types de base
     */
    QString _basicType;

    bool _boolean;

    /**
     * @brief _date
     * Pour stocker les dates
     */
    QDate _date;

    /**
     * @brief _dateTime
     * Pour stocker les dates et les heures
     */
    QDateTime _dateTime;

    /**
     * @brief _objectType
     * Pour le type object
     */
    QPointer<VWInstance> _instance;
protected:
    bool _edit;
public:
    explicit VWPropertyValue(QObject *parent = 0);

    QString toXml(QString tabulation, VWProperty *property) const;

    bool isValued(VWProperty * property) const;

    void reset();

    void setBasicType(QString s);
    QString getBasicType() const;

    void setBoolean(QString b);
    void setBoolean(bool b);
    bool getBoolean() const;

    void setDate(QString date);
    void setDate(QDate date);
    QDate getDate() const;

    void setDateTime(QString dateTime);
    void setDateTime(QDateTime dateTime);
    QDateTime getDateTime() const;

    void setInstance(QPointer<VWInstance> instance);
    QPointer<VWInstance> getInstance() const;

protected slots:

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     */
    void onModified();

    /**
     * @brief onModified
     * Envoie le signal modified(QObject *)
     * @param object L'object qui a été modifié
     */
    void onModified(QString message, QObject * object = NULL);
signals:

    /**
     * @brief modified
     * Signal envoyé lors de modification sur un VWorldModelElement
     * @param object L'object qui a été modifié
     */
    void modified(QString message, QObject * object);
    
};

#endif // VWPROPERTYVALUE_H
