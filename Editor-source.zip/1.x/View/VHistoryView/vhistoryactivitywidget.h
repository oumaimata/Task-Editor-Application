#pragma once
#ifndef VHISTORYACTIVITYWIDGET_H
#define VHISTORYACTIVITYWIDGET_H

#include <QWidget>

class VHistorySet;

namespace Ui {
class VHistoryActivityWidget;
}

/**
 * @brief The VHistoryActivityWidget class
 * Classe permettant d'afficher l'historique pour la partie activité
 */
class VHistoryActivityWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VHistoryActivityWidget *ui;
    
public:
    explicit VHistoryActivityWidget(QWidget *parent = 0);
    ~VHistoryActivityWidget();

    /**
     * @brief setHistorySet
     * Définit le VHistorySet utilisé pour l'historique
     * @param historySet L'historique
     */
    void setHistorySet(VHistorySet* historySet);
    
private:
    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

    /**
     * @brief VHistoryWorldWidget::retranslate
     * Traduction des widgets avec tr() hors du designer
     */
    void retranslate();
};

#endif // VHISTORYACTIVITYWIDGET_H
