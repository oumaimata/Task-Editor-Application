import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import org.mindswap.pellet.jena.PelletReasonerFactory;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFormatter;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class JenaBridge
{
  private Model model;
  private String prefixOnto = "";
  private String thePrefix = "";
  
  public JenaBridge()
  {
    model = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC);
  }

  public void loadOntology(String path, String prefix, String type)
  {    
    try
    {
      /*
       * Reading file
       */
      FileInputStream fis = new FileInputStream(path);
      model.removeAll();
      model.read(fis, prefix, type);
      fis.close();
    
      /*
       * Processing prefix
       */
      Map<String,String> map = model.getNsPrefixMap();
      Set<String> keys = map.keySet();
      ArrayList<String> keysTab = new ArrayList<String>(keys);
      String s = "";
      for(int i = 1; i < keysTab.size(); ++i)
      {
        String prefixI = keysTab.get(i);
        if (!(prefixI.equals("owl") | prefixI.equals("rdf") |
              prefixI.equals("rdfs") | prefixI.equals("xsd") |
              prefixI.equals("owl")))
          setPrefix(prefixI);
        s += "PREFIX " + prefixI + ": <" + map.get(prefixI) + "> ";
      }
      prefixOnto += s;
    }
    catch(Exception ex)
    {
      System.out.println(ex);
    }
  }
  
  public String getPrefix()
  {
    return thePrefix;
  }
  
  public void setPrefix(String s)
  {
    thePrefix = s;
  }
  
  public String runSelectQuery(String qString)
  {
    /*
     * Creating query
     */
    Query query = QueryFactory.create(prefixOnto + qString);
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    QueryExecution queryExecution =  QueryExecutionFactory.create(query, model);
    
    /*
     * Executing query
     */
    ResultSet r = queryExecution.execSelect();
    ResultSetFormatter.outputAsXML(baos, r);
    queryExecution.close();
    
    return baos.toString();
  }

  public boolean runAskQuery(String qString)
  {
    /*
     * Creating query
     */
    Query query = QueryFactory.create(prefixOnto + qString);
    QueryExecution queryExecution = QueryExecutionFactory.create(query, model);
    
    /*
     * Executing query
     */
    boolean b = queryExecution.execAsk();
    queryExecution.close();
    
    return b;
  }
}
