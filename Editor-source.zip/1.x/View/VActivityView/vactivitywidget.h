#pragma once
#ifndef VACTIVITYWIDGET_H
#define VACTIVITYWIDGET_H

#include <QtWidgets>
#include <QVector>

#include "Model/VActivity/vtask.h"

class VActivityTreeScene;
class VTaskItem;

namespace Ui {
class VActivityWidget;
}

class VActivityWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::VActivityWidget *ui;

    VActivityTreeScene * _activityTreeScene;

    /**
     * @brief changeEvent
     * Permet de traduire dynamiquement l'interface
     */
    void changeEvent(QEvent *event);

public:

    /*!
     * \brief VActivityWidget::VActivityWidget
     * Constructeur
     * \param parent objet parent
     */
    explicit VActivityWidget(QWidget* parent = NULL);

    /*!
     * \brief getSelectedTasks
     * Obtient la liste des tâches sélectionnées
     * \return La liste des tâches sélectionnées
     */
    QList<QPointer<VTask> > getSelectedTasks();

    VTaskItem * getTaskItem(VTask * task) const;

private slots:

    /**
     * @brief on_addChildNodeButton_clicked
     * Gère le click sur le bouton d'ajout d'un noeud
     */
    void on_addChildNodeButton_clicked();

    /**
     * @brief on_removeNodeButton_clicked
     * Gère le click sur le bouton de suppression d'un noeud
     */
    void on_removeNodeButton_clicked();

    /**
     * @brief on_moveDownButton_clicked
     * Gère le click sur le bouton de décalage vers le bas d'une tâche
     */
    void on_moveDownButton_clicked();

    /**
     * @brief on_moveUpButton_clicked
     * Gère le click sur le bouton de décalage vers le haut d'une tâche
     */
    void on_moveUpButton_clicked();

public slots:

    void onModelModified();

    void onModelModified(QString message, QObject * object = NULL);

    /**
     * @brief setXmlViewVisible
     * Définie l'attribut Visible de xmlView à enabled
     * @param enabled enabled si activé
     */
    void setXmlViewVisible(bool enabled = true);

    /**
     * @brief updateXmlView
     * Met a jour le widget xmlView
     * @param task La tâche qui a été modifiée
     */
    void updateXmlView(VTask *task = NULL);

    /**
     * @brief updateProperties
     * Met à jour les widgets VTaskPropertiesWidget
     */
    void updateProperties();

signals:

    void taskAddingAsked(VTask* parentTask);

    void taskRemovalAsked(QPointer<VTask>);
};

#endif // VACTIVITYWIDGET_H
