#include "vtask.h"

#include <QtCore/qcoreevent.h>

#include "vtag.h"
#include "VActivityContext/vcontext.h"
#include "VActivityConstructor/vrelation.h"
#include "VActivityOperation/voperation.h"
#include "VActivityCondition/vconditions.h"
#include "VActivityConstructor/vconstructor.h"
#include "VActivityCondition/vstopconditions.h"
#include "../../Controller/vtracecontroller.h"
#include "../../Controller/vactivitycontroller.h"
#include "../../Controller/vapplicationcontroller.h"

VTask::VTask(VTaskContainer* parent) :
    VTaskContainer(parent),
    _id(""),
    _name(""),
    _iterative(false),
    _optional(false),
    _interruptible(true),
    _freeText(""),
    _isCut(false),
    _context(NULL),
    _constructor(NULL),
    _operation(NULL),
    _favorableConditions(NULL),
    _regulatoryConditions(NULL),
    _nomologicalConditions(NULL),
    _contextualConditions(NULL),
    _satisfactionConditions(NULL),
    _stopConditions(NULL)
{
    VTraceController::get()->Debug("VTask::VTask()", "Begin");

    // Setting object name.
    _name = "Task " + QString::number(getUid());
    setIdFromName(_name);
    setObjectName("Task " + _id);

    _context = new VContext(this);
    connect(_context, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    // Par défaut au tache est une tache feuille
    _operation = new VOperation(this);
    connect(_operation, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    _favorableConditions = new VConditions(this);
    _favorableConditions->setType("favorables");
    connect(_favorableConditions, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    _regulatoryConditions = new VConditions(this);
    _regulatoryConditions->setType("regulatorys");
    connect(_regulatoryConditions, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    _nomologicalConditions = new VConditions(this);
    _nomologicalConditions->setType("nomologicals");
    connect(_nomologicalConditions, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    _contextualConditions = new VConditions(this);
    _contextualConditions->setType("contextuals");
    connect(_contextualConditions, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    _satisfactionConditions = new VConditions(this);
    _satisfactionConditions->setType("satisfactions");
    connect(_satisfactionConditions, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    _stopConditions = new VStopConditions(this);
    connect(_stopConditions, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));

    VTraceController::get()->Debug("VTask::VTask()", "End");
}

/**
 * @brief ~VTask
 * Destructeur
 */
VTask::~VTask()
{
    VTraceController::get()->Debug("VTask::~VTask()", "Begin " + _id);

    if(_context != NULL) delete _context;
    if(_constructor != NULL) delete _constructor;
    if(_operation != NULL) delete _operation;
    if(_favorableConditions != NULL) delete _favorableConditions;
    if(_regulatoryConditions != NULL) delete _regulatoryConditions;
    if(_nomologicalConditions != NULL) delete _nomologicalConditions;
    if(_contextualConditions != NULL) delete _contextualConditions;
    if(_satisfactionConditions != NULL) delete _satisfactionConditions;
    if(_stopConditions != NULL) delete _stopConditions;

    VTraceController::get()->Debug("VTask::~VTask()", "End");
}

// --- setter & getter : begin ---

void VTask::setId(QString id)
{
    _id = VApplicationController::getInstance()->getActivityController()->getNextValidTaskId(this, id);
}

void VTask::setIdFromName(QString name)
{
    name = name.toLower().trimmed();
    if(name == "") return;
    QString id = name.replace(QRegExp("[ _]+"), "_"); // Supprime les blancs
    setId("t_" + id);
}

QString VTask::getId() const
{
    return _id;
}

void VTask::setName(QString name)
{
    _name = name;
    onModified(tr("Name changed"));
}

QString VTask::getName() const
{
    return _name;
}

void VTask::setIterative(QString iterative)
{
    setIterative(iterative.toLower() == "true");
}

void VTask::setIterative(bool iterative)
{
    if(iterative != _iterative)
    {
        _iterative = iterative;
        onModified(tr("Iterative changed"));
    }
}

bool VTask::getIterative() const
{
    return _iterative;
}

void VTask::setOptional(QString optional)
{
    setOptional(optional.toLower() == "true");
}

void VTask::setOptional(bool optional)
{
    if(optional != _optional)
    {
        _optional = optional;
        onModified(tr("Optional changed"));
    }
}

bool VTask::getOptional() const
{
    return _optional;
}

void VTask::setInterruptible(QString interruptible)
{
    setInterruptible(interruptible.toLower() == "true");
}

void VTask::setInterruptible(bool interruptible)
{
    if(interruptible != _interruptible)
    {
        _interruptible = interruptible;
        onModified(tr("interruptible changed"));
    }
}

bool VTask::getInterruptible() const
{
    return _interruptible;
}

void VTask::setCut(bool cut)
{
    if(_isCut != cut)
    {
        _isCut = cut;
        onModified();
    }
}

bool VTask::getCut()
{
    return _isCut;
}

VContext * VTask::getContext() const
{
    return _context;
}

void VTask::setConstructor(VConstructor* constructor)
{
    if(_constructor != constructor)
    {
        disconnect(_constructor, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        _constructor = constructor;
        connect(_constructor, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        onModified(tr("Constructor changed"));
    }
}

VConstructor* VTask::getConstructor() const
{
    return _constructor;
}

void VTask::setOperation(VOperation* operation)
{
    if(operation != _operation)
    {
        _operation = operation;
        onModified(NULL);
    }
}

VOperation* VTask::getOperation() const
{
    return _operation;
}

VConditions * VTask::getFavorableConditions() const
{
    return _favorableConditions;
}

VConditions * VTask::getRegulatoryConditions() const
{
    return _regulatoryConditions;
}

VConditions * VTask::getNomologicalConditions() const
{
    return _nomologicalConditions;
}

VConditions * VTask::getContextualConditions() const
{
    return _contextualConditions;
}

VConditions * VTask::getSatisfactionConditions() const
{
    return _satisfactionConditions;
}

VStopConditions *VTask::getStopConditions() const
{
    return _stopConditions;
}

void VTask::setRefTagValue(VTag *const &tag)
{
    setRefTagValue(tag, NULL);
}

void VTask::setRefTagValue(VTag *const &tag, QString value)
{
    if(tag != NULL)
    {
        _refTags.remove(tag);
        _refTags.insert(tag, value);
        onModified(tr("Ref-Tag value changed"));
    }
}

void VTask::addRefTag(VTag *const &tag)
{
    addRefTag(tag, NULL);
}

void VTask::addRefTag(VTag *const &tag, QString value)
{
    if(tag != NULL)
    {
        _refTags.insert(tag, value);
        connect(tag, SIGNAL(modified(QString, QObject*)), this, SLOT(tagModified(QString,QObject*)));
        onModified(tr("Ref-Tag added"));
    }
}

void VTask::removeRefTag(VTag * const &tag)
{
    _refTags.remove(tag);
    disconnect(tag, SIGNAL(modified(QString,QObject*)), this, SLOT(tagModified(QString,QObject*)));
    onModified(tr("Ref-Tag removed"));
}

QMap<QPointer<VTag>, QString> VTask::getRefTags() const
{
    return _refTags;
}

QString VTask::getRefTag(VTag * const &tag) const
{
    return _refTags.value(tag);
}

QString VTask::getFreeText() const
{
    return _freeText;
}

void VTask::setFreeText(const QString &freeText)
{
    _freeText = freeText;
    onModified(tr("Free text modified"));
}


// --- setter & getter : end ---

/**
 * @brief parseDom
 * Permet de parser le model
 * @param elem Un élément du dom
 */
void VTask::parseDom(QDomElement elem)
{
    VTraceController::get()->Info("VTask::parseDom()", "<" + elem.tagName() + ">");

    setId(elem.attribute("id",""));
    setName(elem.attribute("name",""));
    setIterative(elem.attribute("iterative",""));
    setOptional(elem.attribute("optional",""));
    setInterruptible(elem.attribute("interruptible",""));

    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture du freeText
            if(element.tagName() == "freeText"){
                setFreeText(element.text());
            }

            // Lecture de context
            if(element.tagName() == "context")
            {
                _context->parseDom(element);
            }
            // Lecture de constructor
            else if(element.tagName() == "constructor")
            {
                if(_constructor == NULL)
                {
                    _constructor = new VConstructor(this);
                    _constructor->setTask(this);
                    connect(_constructor, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
                    if(_operation != NULL)
                    {
                        disconnect(_operation, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
                        delete _operation;
                        _operation = NULL;
                    }
                }

                _constructor->parseDom(element);
            }
            // Lecture de operation
            else if(element.tagName() == "operation")
            {
                if(_operation == NULL)
                {
                    _operation = new VOperation(this);
                    connect(_operation, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
                }

                _operation->parseDom(element);
            }
            // Lecture de conditions
            else if(element.tagName() == "conditions")
            {
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        if(subElement.tagName() == "favorables")
                        {
                            _favorableConditions->parseDom(subElement);
                        }
                        else if(subElement.tagName() == "regulatorys")
                        {
                            _regulatoryConditions->parseDom(subElement);
                        }
                        else if(subElement.tagName() == "nomologicals")
                        {
                            _nomologicalConditions->parseDom(subElement);
                        }
                        else if(subElement.tagName() == "contextuals")
                        {
                            _contextualConditions->parseDom(subElement);
                        }
                        else if(subElement.tagName() == "satisfactions")
                        {
                            _satisfactionConditions->parseDom(subElement);
                        }
                        else if(subElement.tagName() == "stops")
                        {
                            _stopConditions->parseDom(subElement);
                        }
                    }
                    subNode = subNode.nextSibling();
                }
            }
        }
        node = node.nextSibling();
    }

    VTraceController::get()->Info("VTask::parseDom()", "</" + elem.tagName() + ">");
}

/**
 * @brief ToXml
 * Export en xml
 * @param tabulation La tabulation actuelle
 * @return Une chaîne de caractère représentant le modèle en xml
 */
QString VTask::ToXml(QString tabulation)
{
    QString RetVal = tabulation + "<task id=\"" + _id + "\" name=\"" + _name + "\"";
    RetVal += _iterative ? " iterative=\"true\"" : " iterative=\"false\"";
    RetVal += _optional ? " optional=\"true\"" : " optional=\"false\"";
    RetVal += _interruptible ? " interruptible=\"true\"" : " interruptible=\"false\"";
    RetVal += ">\n";

    RetVal += tabulation +"<freeText>";
    RetVal +=_freeText;
    RetVal +="</freeText>";
    RetVal += "\n";

    // Context
    if(_context != NULL) RetVal += _context->ToXml(tabulation + "\t");

    QList<VTask *> childTasks = this->getChildTasks();
    if(childTasks.count() != 0)
    {
        // subtasks if any
        RetVal += tabulation + "\t<subtasks>\n";
        for(int i = 0; i < childTasks.count(); i++)
        {
            RetVal += tabulation + "\t\t<subtask id=\"" + childTasks[i]->getId() + "\"/>\n";
        }
        RetVal += tabulation + "\t</subtasks>\n";

        // constructor if subtask
        if(_constructor != NULL) RetVal += _constructor->ToXml(tabulation + "\t");
    }
    else
    {
        // operation if no subtask
        if(_operation != NULL) RetVal += _operation->ToXml(tabulation + "\t");
    }
    // conditions
    RetVal += tabulation + "\t" + "<conditions>\n";
    if(_favorableConditions != NULL) RetVal += _favorableConditions->ToXml(tabulation + "\t\t");
    if(_regulatoryConditions != NULL) RetVal += _regulatoryConditions->ToXml(tabulation + "\t\t");
    if(_nomologicalConditions != NULL) RetVal += _nomologicalConditions->ToXml(tabulation + "\t\t");
    if(_contextualConditions != NULL) RetVal += _contextualConditions->ToXml(tabulation + "\t\t");
    if(_satisfactionConditions != NULL) RetVal += _satisfactionConditions->ToXml(tabulation + "\t\t");
    if(_stopConditions != NULL) RetVal += _stopConditions->ToXml(tabulation + "\t\t");
    RetVal += tabulation + "\t" + "</conditions>\n";

    // ref-tags
    if(_refTags.count() != 0)
    {
        RetVal += tabulation + "\t<ref-tags>\n";
        for(int i = 0; i < _refTags.count(); i++)
        {
            if(_refTags.keys()[i] != NULL)
            {
                RetVal += tabulation + "\t\t<ref-tag";
                RetVal += " id=\"" + QString::number(_refTags.keys()[i]->getId()) + "\"";
                if(_refTags.keys()[i]->getValued()) RetVal += " value=\"" + _refTags.values()[i] + "\"";
                RetVal += " />\n";
            }
        }
        RetVal += tabulation + "\t</ref-tags>\n";
    }

    RetVal += tabulation + "</task>\n";
    return RetVal;
}

/**
 * @brief AfterTasksParsed
 * Définie les tâches des relations
 */
void VTask::AfterTasksParsed()
{
    if(_constructor != NULL)
    {
        _constructor->AfterTasksParsed();
        if(_constructor->getType() == SeqOrd)
        {
            reorder(_constructor->getTaskOrdered());
        }
    }
    QList<VTask *> childTasks = getChildTasks();
    foreach(VTask * task, childTasks)
    {
        task->AfterTasksParsed();
    }
    onModified(NULL);
}

/**
 * @brief getTaskByUid
 * Obtient la tâche ayant l'uid passé en argument
 * @param uid L'uid d'une tâche
 * @return La tâche si elle existe sinon null
 */
VTask* VTask::getTaskByUid(qint64 uid)
{
    QList<VTask*> tasks = getChildTasks();
    for(int i = 0; i < tasks.count(); i++)
    {
        if(tasks[i]->getUid() == uid) return tasks[i];
    }
    return NULL;
}

/**
 * @brief getTaskById
 * Obtient la tâche ayant l'id passé en argument
 * @param id L'id d'une tâche
 * @return La tâche si elle existe sinon null
 */
VTask* VTask::getTaskById(QString id)
{
    if(_id == id)
    {
        return this;
    }
    QList<VTask*> tasks = getChildTasks();
    for(int i = 0; i < tasks.count(); i++)
    {
        VTask* task = tasks[i]->getTaskById(id);
        if(task != NULL)
        {
            return task;
        }
    }
    return NULL;
}

/**
 * @brief getTaskChildsFromDom
 * Obtient la liste des tâches filles d'une tâche passé en argument
 * @param elem Un élément du dom
 * @return La liste des tâches filles d'une tâche
 */
QList<QString> VTask::getTaskChildsFromDom(QDomElement elem)
{
    QList<QString> RetVal;

    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de subtasks
            if(element.tagName() == "subtasks")
            {
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        // Lecture de subtasks
                        if(subElement.tagName() == "subtask")
                        {
                            RetVal.append(subElement.attribute("id",0));
                        }
                    }
                    subNode = subNode.nextSibling();
                }
            }
        }
        node = node.nextSibling();
    }

    return RetVal;
}

/**
 * @brief getRefTagsFromDom
 * Obtient la liste des tags référencés par la tâche
 * @param elem Un élément du dom
 * @return La liste des tags référencés
 */
QMap<QString, QString> VTask::getRefTagsFromDom(QDomElement elem)
{
    QMap<QString, QString> RetVal;

    QDomNode node = elem.firstChild();
    // Lecture des noeuds inférieurs
    while(!node.isNull())
    {
        QDomElement element = node.toElement();
        if(!element.isNull())
        {
            // Lecture de subtasks
            if(element.tagName() == "ref-tags")
            {
                QDomNode subNode = element.firstChild();
                // Lecture des noeuds inférieurs
                while(!subNode.isNull())
                {
                    QDomElement subElement = subNode.toElement();
                    if(!subElement.isNull())
                    {
                        // Lecture de subtasks
                        if(subElement.tagName() == "ref-tag")
                        {
                            RetVal.insert(subElement.attribute("id", ""), subElement.attribute("value", NULL));
                        }
                    }
                    subNode = subNode.nextSibling();
                }
            }
        }
        node = node.nextSibling();
    }

    return RetVal;
}

/**
 * @brief IsAnscesterOf
 * Détermine si on est un ancètre de task
 * @param task Une tâche
 * @return Vrai si on est un ancètre de task
 *         Faux sinon
 */
bool VTask::IsAnscesterOf(VTask * task) const
{
    if(task == NULL) return false;
    QList<VTask *> childTasks = getChildTasks();
    for(int i = 0; i < childTasks.count(); i++)
    {
        if(childTasks[i] == task) return true;
        if(childTasks[i]->IsAnscesterOf(task)) return true;
    }
     return false;
}

/**
 * @brief clone
 * Clone la tâche
 * @return Le clone de la tâche
 */
VTask * VTask::clone() const
{
    VTraceController::get()->Debug("VTask::clone()", "Begin");
    VTask * task = new VTask();
    task->_edit = true;
    task->setName(this->getName() + " (" + QString::number(task->getUid()) + ")");
    task->setIdFromName(task->getName());
    task->setIterative(this->getIterative());
    task->setOptional(this->getOptional());
    task->setInterruptible(this->getInterruptible());
    task->_context = this->_context->clone(task);

    QList<VTask *> childTasks = this->getChildTasks();
    if(childTasks.count() == 0)
    {
        task->setOperation(this->getOperation()->clone(task));
    }
    else
    {
        QMap<VTask *, VTask*> * tasksCloned = new QMap<VTask *, VTask*>();
        task->setOperation(NULL);
        task->setConstructor(new VConstructor());
        task->getConstructor()->setTask(task);
        task->getConstructor()->setType(this->getConstructor()->getType());
        foreach(VTask * childTask, childTasks)
        {
            VTask * childTaskCloned = childTask->clone();
            tasksCloned->insert(childTask, childTaskCloned);
            task->addChildTask(childTaskCloned);
            VTraceController::get()->Info("VTask::clone()", "Add child clone");
        }
        foreach(VRelation * relation, this->getConstructor()->getRelations())
        {
            VRelation * relationCloned = new VRelation(task->getConstructor());
            relationCloned->setTaskLh(tasksCloned->value(relation->getTaskLh()));
            relationCloned->setOperator(relation->getOperator());
            relationCloned->setTaskRh(tasksCloned->value(relation->getTaskRh()));
            task->getConstructor()->addRelation(relationCloned);
            VTraceController::get()->Info("VTask::clone()", relationCloned->ToXml());
        }
    }

    task->_favorableConditions = this->_favorableConditions->clone(task);
    task->_regulatoryConditions = this->_regulatoryConditions->clone(task);
    task->_nomologicalConditions = this->_nomologicalConditions->clone(task);
    task->_contextualConditions = this->_contextualConditions->clone(task);
    task->_satisfactionConditions = this->_satisfactionConditions->clone(task);
    task->_stopConditions = this->_stopConditions->clone(task);

    for(int i = 0; i < _refTags.count(); i++)
    {
        task->addRefTag(_refTags.keys()[i], _refTags.values()[i]);
    }

    VTraceController::get()->Debug("VTask::clone()", "End");
    return task;
}

/*!
 Overrides VTaskContainer::childTaskAdded(VTask* parent)
*/
void VTask::childTaskAdded(VTask* task)
{
    VTraceController::get()->Debug("VTask::childTaskAdded()", "Begin");
    VTaskContainer* thisParent = (VTaskContainer*) this->parent();
    if (thisParent != NULL)
    {
        thisParent->childTaskAdded(task);
    }
    VTraceController::get()->Debug("VTask::childTaskAdded()", "End");
}

/**
 * @brief processChildTaskAdded
 * Override VTaskContainer::processChildTaskAdded
 * Gère La modification des tâches filles
 */
void VTask::processChildTaskAdded()
{
    VTraceController::get()->Debug("VTask::processChildTaskAdded()", "Begin");
    if(_constructor == NULL && getChildTasks().count() != 0) // Devient une tâche mère
    {
        setConstructor(new VConstructor(this));
        _constructor->setTask(this);
        disconnect(_operation, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        delete _operation;
        _operation = NULL;
        onModified(NULL);
    }
    else if(_constructor->getType() == SeqOrd && getChildTasks().count() >= 2)
    {
        // MaJ des relation
        QList<VTask *> childTasks = getChildTasks();
        VTask * rhTask = childTasks.last();
        childTasks.pop_back();
        VTask * lhTask = childTasks.last();
        if(lhTask == NULL) return;
        VRelation * relation = new VRelation(_constructor);
        relation->setTaskLh(lhTask);
        relation->setOperator(lt);
        relation->setTaskRh(rhTask);
        _constructor->addRelation(relation);
    }
    VTraceController::get()->Debug("VTask::processChildTaskAdded()", "End");
}

/**
 * @brief VTask::childTaskRemoved
 * Overrides VTaskContainer::childTaskRemoved(VTask* parent)
 * Fait remonter l'information jusqu'au VActivityModel
 * @param task la tâche qui est supprimée
 */
void VTask::childTaskRemoved(VTask* task)
{
    VTraceController::get()->Debug("VTask::childTaskRemoved()", "Begin");
    VTaskContainer* thisParent = (VTaskContainer*) this->parent();
    if (thisParent != NULL) thisParent->childTaskRemoved(task);
    VTraceController::get()->Debug("VTask::childTaskRemoved()", "End");
}

/**
 * @brief processChildTaskRemoved
 * Override VTaskContainer::processChildTaskRemoved
 * Gère La suppression des tâches filles
 */
void VTask::processChildTaskRemoved(VTask * task)
{
    VTraceController::get()->Debug("VTask::processChildTaskRemoved()", "Begin");
    if(getChildTasks().count() == 0 && _constructor != NULL) // Devient une tâche fille
    {
        _operation = new VOperation(this);
        connect(_operation, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
        disconnect(_constructor, SIGNAL(modified(QString, QObject*)), this, SLOT(onModified(QString, QObject*)));
       delete  _constructor;
        _constructor = NULL;
        onModified(NULL);
    }
    else if(_constructor != NULL)
    {
        _constructor->removeRelationOf(task);
    }
    VTraceController::get()->Debug("VTask::processChildTaskRemoved()", "End");
}

/*!
 Overrides VTaskContainer::childTaskModified(VTask* parent)
*/
void VTask::childTaskModified(VTask* task)
{
    VTraceController::get()->Debug("VTask::childTaskRemoved()", "Begin");
    VTaskContainer* thisParent = (VTaskContainer*) this->parent();
    if (thisParent != NULL)
    {
        if(task == NULL)
        {
            thisParent->childTaskModified(this);
        }
        else
        {
            thisParent->childTaskModified(task);
        }
    }
    VTraceController::get()->Debug("VTask::childTaskRemoved()", "End");
}

/**
 * @brief moveDown
 * Déplace les tâches passées en arguments vers le bas
 * @param tasks La liste des tâches à déplacer
 */
void VTask::moveDown(QList<QPointer<VTask> > tasks)
{
    VTraceController::get()->Debug("VTask::moveDown()", "Begin");
    VTaskContainer::moveDown(tasks);
    if(_constructor != NULL)
    {
        _constructor->updateRelations(this->getChildTasks());
    }
    childTaskModified();
    VTraceController::get()->Debug("VTask::moveDown()", "End");
}

/**
 * @brief moveUp
 * Déplace les tâches passées en arguments vers le haut
 * @param tasks La liste des tâches à déplacer
 */
void VTask::moveUp(QList<QPointer<VTask> > tasks)
{
    VTraceController::get()->Debug("VTask::moveUp()", "Begin");
    VTaskContainer::moveUp(tasks);
    if(_constructor != NULL)
    {
        _constructor->updateRelations(this->getChildTasks());
    }
    childTaskModified();
    VTraceController::get()->Debug("VTask::moveUp()", "End");
}

void VTask::setParent(VTaskContainer* parent, bool modelIsLoading)
{
    VTraceController::get()->Debug("VTask::setParent()", "Begin");
    VTaskContainer * oldParent = qobject_cast<VTaskContainer *>(QObject::parent());
    if(parent != oldParent)
    {
        VTaskContainer::setParent(parent);
        if(parent != NULL && !modelIsLoading) parent->processChildTaskAdded();
        if(oldParent != NULL) oldParent->processChildTaskRemoved(this);
        onModified(tr("Parent task changed"));
    }
    VTraceController::get()->Debug("VTask::setParent()", "End");
}
/**
 * @brief onModified
 * Signal envoyé quand une tâche est modifiée
 */
void VTask::onModified()
{
    onModified(NULL);
}

/**
 * @brief onModified
 * Signal envoyé quand une tâche est modifiée
 */
void VTask::onModified(QString message, QObject * object)
{
    VTraceController::get()->Debug("VTask::onModified()", "Begin");
    if(!_edit) childTaskModified();
    VTaskContainer::onModified(message, object);
    VTraceController::get()->Debug("VTask::onModified()", "End");
}

/**
 * @brief tagModified
 * Gère les modifications d'un tag
 * -> si ne tag ne prend plus de valeur : retirer la valeur du tag
 */
void VTask::tagModified()
{
    tagModified(NULL);
}

/**
 * @brief tagModified
 * Gère les modifications d'un tag
 * -> si ne tag ne prend plus de valeur : retirer la valeur du tag
 */
void VTask::tagModified(QString message, QObject * object)
{
    VTraceController::get()->Debug("VTask::tagModified()", "Begin");
    VTag * tag = qobject_cast<VTag *>(object);
    if(tag == NULL) return;
    if(!tag->getValued())
    {
        setRefTagValue(tag); // Retire la valeur associé au tag
    }
    VTraceController::get()->Debug("VTask::tagModified()", "End");
}
