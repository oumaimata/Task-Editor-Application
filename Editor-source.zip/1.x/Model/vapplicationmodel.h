#pragma once
#ifndef VAPPLICATIONMODEL_H
#define VAPPLICATIONMODEL_H

#include <QObject>

#include "VActivity/vactivitymodel.h"
#include "VWorld/vworldmodel.h"
#include "VHistory/vhistoryset.h"
#include "vsettings.h"

/**
 * @brief The VApplicationModel class
 * The model of the application.
 *
 * This class represents the model of the application and therefore provides
 * methods to get objects of the model (for instance, the activity model, properties
 * sets, user settings, ...). This class is a singleton, therefore his constructor
 * is private and you should use the getInstance() method to reference it.
 */
class VApplicationModel : public QObject
{
    Q_OBJECT

private:
    /**
     * @brief _instance
     * L'unique instance de VApplicationModel
     * Design pattern Singleton
     */
    static VApplicationModel* _instance;

    /**
     * @brief _activityModel
     * Le modèle d'activité
     */
    VActivityModel _activityModel;

    /**
     * @brief _activityHistorySet
     * L'historique pour le modèle d'activité
     */
    VHistorySet _activityHistorySet;

    /**
     * @brief _activityFutureSet
     * Le future pour le modèle d'activité
     */
    VHistorySet _activityFutureSet;

    /**
     * @brief _worldModel
     * Le modèle du monde
     */
    VWorldModel _worldModel;

    /**
     * @brief _worldHistorySet
     * L'historique pour le modèle du monde
     */
    VHistorySet _worldHistorySet;

    /**
     * @brief _worldFutureSet
     * Le future pour le modèle du monde
     */
    VHistorySet _worldFutureSet;
    /**
     * @brief _settings
     * les règlages de l'application
     */
    VSettings _settings;

    /**
     * @brief VApplicationModel
     * Default constructor of the application model, inherited from QObject.
     * @param parent The parent of the object
     */
    explicit VApplicationModel(QObject* parent = NULL);

public:
    /**
     * @brief getInstance
     * Get the instance of VApplicationModel
     * @return The instance
     */
    static VApplicationModel* getInstance();

    /**
     * @brief getActivityModel
     * Get the activity model of the application
     * @return A const reference to the activity model of the application
     */
    VActivityModel& getActivityModel();

    /**
     * @brief getActivityHistorySet
     * L'historique pour le modèle d'activité
     */
    VHistorySet& getActivityHistorySet();

    /**
     * @brief getActivityFutureSet
     * Le future pour le modèle d'activité
     */
    VHistorySet& getActivityFutureSet();

    /**
     * @brief getWorldModel
     * Get the world model of the application
     * @return A const reference to the world model of the application
     */
    VWorldModel& getWorldModel();

    /**
     * @brief getWorldHistorySet
     * L'historique pour le modèle du monde
     */
    VHistorySet& getWorldHistorySet();

    /**
     * @brief getWorldFutureSet
     * Le future pour le modèle du monde
     */
    VHistorySet& getWorldFutureSet();

    VSettings& getSettings();

};

#endif // VAPPLICATIONMODEL_H
