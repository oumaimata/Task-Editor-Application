#pragma once
#ifndef VSTOPCONDITIONS_H
#define VSTOPCONDITIONS_H

#include <QtXml>

#include "../VActivityCommon/vactivitymodelelement.h"

class VTask;
class VStopCondition;
class VBasisCondition;

class VStopConditions : public VActivityModelElement
{
    Q_OBJECT

private:
    QString _logicalOperator;

    /**
     * @brief _stopConditions
     *
     * Liste des stops conditions
     */
    QList<VStopCondition *> _stopConditions;

    QPointer<VTask> _task;

public:
    explicit VStopConditions(VTask *task = 0);

    VStopConditions(const VStopConditions& stopCondition, QObject *parent = 0);

    /**
     * @brief ~VStopConditions
     * Destructeur
     */
    ~VStopConditions();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setLogicalOperator(QString logicalOperator);
    QString getLogicalOperator() const;

    void addStopCondition(VStopCondition * stopCondition);
    void removeStopCondition(VStopCondition * stopCondition);
    QList<VStopCondition *> getStopConditions() const;
    QList<VBasisCondition *> getBasisConditions() const;
    VStopCondition * getStopConditionByUid(qint64 uid) const;

    /**
     * @brief clone
     * @return Le clone
     */
    VStopConditions * clone(QObject *parent = 0) const;
    
};

#endif // VSTOPCONDITIONS_H
