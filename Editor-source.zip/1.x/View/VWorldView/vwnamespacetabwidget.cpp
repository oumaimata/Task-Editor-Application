#include "vwnamespacetabwidget.h"
#include "ui_vwnamespacetabwidget.h"

#include "Model/VWorld/vworldmodel.h"

VWNamespaceTabWidget::VWNamespaceTabWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::VWNamespaceTabWidget),
    _edit(false)
{
    ui->setupUi(this);
}

VWNamespaceTabWidget::~VWNamespaceTabWidget()
{
    delete ui;
}

/**
 * @brief changeEvent
 * Permet de traduire dynamiquement l'interface
 */
void VWNamespaceTabWidget::changeEvent(QEvent* event)
{
    if (event->type() == QEvent::LanguageChange)
    {
        // retranslate designer form (single inheritance approach)
        ui->retranslateUi(this);

        // retranslate other widgets which weren't added in designer
        // retranslate();
    }

    // remember to call base class implementation
    QWidget::changeEvent(event);
}

/**
 * @brief setWorldModel
 * Définit le modèle du monde en cours
 * @param activityModel Le modèle du monde en cours
 */
void VWNamespaceTabWidget::setWorldModel(VWorldModel * worldModel)
{
    if(worldModel != _worldModel)
    {
        _worldModel = worldModel;
    }
    updateDisplay();
}

void VWNamespaceTabWidget::updateDisplay()
{
    _edit = true;
    if(_worldModel == NULL) return;
    ui->namespaceLineEdit->setText(_worldModel->getNamespace());
    _edit = false;
}

void VWNamespaceTabWidget::on_namespaceLineEdit_editingFinished()
{
    if(_edit || _worldModel == NULL) return;
    _worldModel->setNamespace(ui->namespaceLineEdit->text());
}
