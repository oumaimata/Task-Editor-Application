#pragma once
#ifndef VSTOPCONDITION_H
#define VSTOPCONDITION_H

#include <QtXml>
#include <QTime>

#include "vbasiscondition.h"

class VStatement;
class VCondition;
class VTask;
class VWorldModelElement;

class VStopCondition : public VBasisCondition
{
    Q_OBJECT

private:
    QString _type;

    int _iteration;

    QTime _duration;

    VStatement * _statement;

    QPointer<VCondition> _satisfactionCondition;

    QPointer<VWorldModelElement> _instance;

    QPointer<VTask> _task;

public:
    explicit VStopCondition(QObject *parent = 0);

    VStopCondition(const VStopCondition& stopCondition, QObject *parent = 0);

    /**
     * @brief ~VStopCondition
     * Destructeur
     */
    ~VStopCondition();

    /**
     * @brief parseDom
     * Permet de parser le model
     * @param elem Un élément du dom
     */
    void parseDom(QDomElement elem);

    /**
     * @brief ToXml
     * Export en xml
     * @param tabulation La tabulation actuelle
     * @return Une chaîne de caractère représentant le modèle en xml
     */
    QString ToXml(QString tabulation = "");

    void setType(QString type);
    QString getType() const;

    void setIteration(int iteration);
    int getIteration() const;

    void setDuration(QString duration);
    void setDuration(int h, int m, int s, int ms = 0);
    void setDuration(QTime duration);
    QTime getDuration() const;

    void setStatement(VStatement * statement);
    VStatement * getStatement() const;

    void setSatisfactionConditionById(qint64 id);
    void setSatisfactionCondition(QPointer<VCondition> satisfactionCondition);
    QPointer<VCondition> getSatisfactionCondition() const;

    void setInstance(qint64 id);
    void setInstance(QPointer<VWorldModelElement> instance);
    QPointer<VWorldModelElement> getInstance() const;

    void setTask(QPointer<VTask> task);
    QPointer<VTask> getTask() const;

    /**
     * @brief clone
     * @return Le clone
     */
    VStopCondition * clone(QObject *parent = 0) const;

};

#endif // VSTOPCONDITIONS_H
