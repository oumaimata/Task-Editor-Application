#ifndef VBASISCONDITION_H
#define VBASISCONDITION_H

#include <QObject>

#include "../VActivityCommon/vactivitymodelelement.h"

class VBasisCondition : public VActivityModelElement
{
    Q_OBJECT

private:
    qint64 _id;

public:
    explicit VBasisCondition(QObject *parent = 0);

    VBasisCondition(const VBasisCondition& basisCondition, QObject *parent = 0);

    void setId(qint64 id);
    void setId(QString id);
    qint64 getId() const;

};

#endif // VBASISCONDITION_H
