#include "vsettings.h"

VSettings::VSettings():
    _qSettings(qApp->organizationName(), qApp->applicationName())
{
}

VSettings::~VSettings()
{
    foreach (QAction* action, _activityImportedFiles) {
        delete action;
    }
    foreach (QAction* action, _worldImportedFiles) {
        delete action;
    }
}


QAction* VSettings::createActivityFileAction(const QString& fileName){
    return VSettings::createAction(fileName,ACTIVITY);
}
QAction* VSettings::createWorldFileAction(const QString& fileName){
    return VSettings::createAction(fileName, WORLD);
}

QAction* VSettings::createAction(const QString &fileName, FileType fileType){
    QAction* action = new QAction(fileName, NULL);
    action->setData(fileType);
    return action;
}

void VSettings::addActivityImportedFile(QAction* action){
    ActionFlags flag = beforeAddAction(&_activityImportedFiles, action);
    if(flag == ActionFlags::ADD_ACTION_NEEDED)
        _activityImportedFiles.push_front(action);
    emit activityImportedFilesChanged(_activityImportedFiles);
}
void VSettings::addWorldImportedFile(QAction* action){
    ActionFlags flag = beforeAddAction(&_worldImportedFiles, action);
    if(flag == ActionFlags::ADD_ACTION_NEEDED)
        _worldImportedFiles.push_front(action);
    emit worldImportedFilesChanged(_worldImportedFiles);
}

VSettings::ActionFlags VSettings::beforeAddAction(QList<QAction*> *actions, QAction* action){
    int i;
    int size = actions->size();
    for (i = 0; i < size; i++){
        if(actions->at(i)->text() == action->text()){
            actions->move(i,0);
            return ActionFlags::NO_ACTION_NEEDED;
        }
    }
    if(size ==  MAX_IMPORTED_FILES){
        delete actions->last();
        actions->pop_back();
    }
    return ActionFlags::ADD_ACTION_NEEDED;
}

void VSettings::addImportedFile(QString& fileName, FileType fileType){
    QAction* action = NULL;
    switch(fileType){
        case ACTIVITY:   action = createActivityFileAction(fileName);
                         addActivityImportedFile(action);
            break;
        case WORLD:      action = createWorldFileAction(fileName);
                         addWorldImportedFile(action);
        break;
    }

}
QList<QAction *> VSettings::getActivityImportedFiles() const
{
    return _activityImportedFiles;
}

void VSettings::setActivityImportedFiles(const QList<QAction *> &activityImportedFiles)
{
    _activityImportedFiles = activityImportedFiles;
}
QList<QAction *> VSettings::getWorldImportedFiles() const
{
    return _worldImportedFiles;
}
void VSettings::setWorldImportedFiles(const QList<QAction *> &worldImportedFiles)
{
    _worldImportedFiles = worldImportedFiles;
}

void VSettings::save()
{
    _qSettings.clear();
    _qSettings.setValue(ACTIVITY_IMPORTED_FILES_KEY, toQVariant(_activityImportedFiles));
    _qSettings.setValue(WORLD_IMPORTED_FILES_KEY, toQVariant(_worldImportedFiles));
}

void VSettings::load(){
    QStringList activityImportedFilesName = _qSettings.value(ACTIVITY_IMPORTED_FILES_KEY).toStringList();
    addActions(activityImportedFilesName.mid(0,MAX_IMPORTED_FILES), ACTIVITY);
    QStringList worldImportedFilesName = _qSettings.value(WORLD_IMPORTED_FILES_KEY).toStringList();
    addActions(worldImportedFilesName.mid(0,MAX_IMPORTED_FILES), WORLD);
}

QVariant VSettings::toQVariant(QList<QAction *> actions){
    QStringList stringList;
    foreach(QAction* action, actions ){
        stringList.push_front(action->text());
    }
    return QVariant(stringList);
}

void VSettings::addActions(QStringList filesName, FileType fileType){

    foreach(QString fileName, filesName){
        addImportedFile(fileName, fileType);
    }

}
