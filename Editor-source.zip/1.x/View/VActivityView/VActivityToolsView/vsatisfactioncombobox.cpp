#include "vsatisfactioncombobox.h"

#include "Model/VActivity/vtask.h"
#include "Model/VActivity/VActivityCondition/vcondition.h"
#include "Model/VActivity/VActivityCondition/vconditions.h"
#include "Model/VActivity/VActivityCondition/vstopcondition.h"

VSatisfactionComboBox::VSatisfactionComboBox(VStopCondition * stopCondition, QWidget *parent) :
    QComboBox(parent),
    _stopCondition(stopCondition)
{
    VTask * task = _stopCondition->getTask();
    if(task == NULL) return;
    VConditions * satisfaction = task->getSatisfactionConditions();
    if(satisfaction == NULL) return;
    this->addItem("");
    foreach(VCondition * condition , satisfaction->getConditions())
    {
        this->addItem(QString::number(condition->getId()), condition->getId());
        this->setItemData(this->count() - 1, condition->toString(), Qt::ToolTipRole);
    }
    if(_stopCondition->getSatisfactionCondition() != NULL)
        this->setCurrentText(QString::number(_stopCondition->getSatisfactionCondition()->getId()));
    connect(this, SIGNAL(currentTextChanged(QString)), this, SLOT(satisfactionTypeChanged(QString)));
}

void VSatisfactionComboBox::satisfactionTypeChanged(QString s)
{
    qint64 id = this->itemData(currentIndex()).toString().toLong();
    _stopCondition->setSatisfactionConditionById(id);
}
